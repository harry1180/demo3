from datetime import datetime, timedelta, time

from airflow import DAG
from airflow.operators import BashOperator, DummyOperator

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_identity'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2016, 06, 02),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_job = TimeSensor(
    target_time=time(8,15),
    task_id='Initiating_start_time',
    dag=dag)

task_core_start_job = TimeSensor(
    target_time=time(1,15),
    task_id='Initiating_identity_core_jobs_start_time',
    dag=dag)

################################################################################
# Deserialize ProtoBuf Events
################################################################################
event_names = {
    'RoleChangeEvent',
}
stage_load_tasks = dict()
for event_name in event_names:
    task_deser = NWBashScriptOperator(
        bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
        script_args=[event_name],
        task_id=event_name + '_deser',
        dag=dag)
    task_deser.set_upstream(task_start_job)

    task_stage_load = NWBashScriptOperator(
        bash_script='/data/etl/Common/redshift_load_event_stage_table.sh',
        script_args=[event_name],
        task_id='pbclass_{}_s'.format(event_name),
        dag=dag)
    task_stage_load.set_upstream(task_deser)

    stage_load_tasks[event_name] = task_stage_load

task_idb_identity_roles_s_script="/data/etl/Scripts/idb_identity_roles_s/shellscripts/idb_identity_roles_s.sh"
task_idb_identity_roles_s = NWBashScriptOperator(
    bash_script=task_idb_identity_roles_s_script,
    script_args=[],
    task_id='idb_identity_roles_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)


task_dw_identity_role_d_script="/data/etl/Scripts/dw_identity_role_d/shellscripts/dw_identity_role_d.sh"
task_dw_identity_role_d = NWBashScriptOperator(
    bash_script=task_dw_identity_role_d_script,
    script_args=[],
    task_id='dw_identity_role_d',
    dag=dag)

#task_dit_conversation_api_dwnld_script="/data/etl/Scripts/dit_conversation_s/shellscripts/dit_conversation.sh"
#task_dit_conversation_api_dwnld = NWBashScriptOperator(
#    bash_script=task_dit_conversation_api_dwnld_script,
#    script_args=[],
#    task_id='dit_conversation_api_dwnld',
#    dag=dag)
#
#task_dit_conversation_s_script="/data/etl/Scripts/dit_conversation_s/shellscripts/dit_conversation_stage_load.sh"
#task_dit_conversation_s = NWBashScriptOperator(
#    bash_script=task_dit_conversation_s_script,
#    script_args=[],
#    task_id='dit_conversation_s',
#    dag=dag)
#
#task_dit_conversation_tag_s_script="/data/etl/Scripts/dit_conversation_tag_s/shellscripts/dit_conversation_tag_stage_load.sh"
#task_dit_conversation_tag_s = NWBashScriptOperator(
#    bash_script=task_dit_conversation_tag_s_script,
#    script_args=[],
#    task_id='dit_conversation_tag_s',
#    dag=dag)
#
#task_dw_dit_convo_f_script="/data/etl/Scripts/dw_dit_convo_f/shellscripts/dit_conversation_fact_load.sh"
#task_dw_dit_convo_f = NWBashScriptOperator(
#    bash_script=task_dw_dit_convo_f_script,
#    script_args=[],
#    task_id='dw_dit_convo_f',
#    dag=dag)
#
#task_dw_dit_convo_tag_xref_script="/data/etl/Scripts/dw_dit_convo_tag_xref/shellscripts/dit_conversation_tag_xref_loading.sh"
#task_dw_dit_convo_tag_xref = NWBashScriptOperator(
#    bash_script=task_dw_dit_convo_tag_xref_script,
#    script_args=[],
#    task_id='dw_dit_convo_tag_xref',
#    dag=dag)
#
#task_dit_tag_s_script="/data/etl/Scripts/dit_tag_s/shellscripts/dit_tag.sh"
#task_dit_tag_s = NWBashScriptOperator(
#    bash_script=task_dit_tag_s_script,
#    script_args=[],
#    task_id='dit_tag_s',
#    dag=dag)
#
#task_dw_dit_tag_d_script="/data/etl/Scripts/dw_dit_tag_d/shellscripts/dit_tag_dimension_loading.sh"
#task_dw_dit_tag_d = NWBashScriptOperator(
#    bash_script=task_dw_dit_tag_d_script,
#    script_args=[],
#    task_id='dw_dit_tag_d',
#    dag=dag)
#
#task_dit_user_s_script="/data/etl/Scripts/dit_user_s/shellscripts/dit_user.sh"
#task_dit_user_s = NWBashScriptOperator(
#    bash_script=task_dit_user_s_script,
#    script_args=[],
#    task_id='dit_user_s',
#    dag=dag)
#
#task_dw_dit_user_d_script="/data/etl/Scripts/dw_dit_user_d/shellscripts/dit_user_dimension_loading.sh"
#task_dw_dit_user_d = NWBashScriptOperator(
#    bash_script=task_dw_dit_user_d_script,
#    script_args=[],
#    task_id='dw_dit_user_d',
#    dag=dag)
#
#task_dit_expert_s_script="/data/etl/Scripts/dit_expert_s/shellscripts/dit_expert.sh"
#task_dit_expert_s = NWBashScriptOperator(
#    bash_script=task_dit_expert_s_script,
#    script_args=[],
#    task_id='dit_expert_s',
#    dag=dag)
#
#task_dw_dit_exprt_d_script="/data/etl/Scripts/dw_dit_exprt_d/shellscripts/dit_expert_dimension_load.sh"
#task_dw_dit_exprt_d = NWBashScriptOperator(
#    bash_script=task_dw_dit_exprt_d_script,
#    script_args=[],
#    task_id='dw_dit_exprt_d',
#    dag=dag)
#
#task_dit_message_api_dwnld_script="/data/etl/Scripts/dit_message_s/shellscripts/dit_message.sh"
#task_dit_message_api_dwnld = NWBashScriptOperator(
#    bash_script=task_dit_message_api_dwnld_script,
#    script_args=[],
#    task_id='dit_message_api_dwnld',
#    dag=dag)
#
#task_dit_message_s_script="/data/etl/Scripts/dit_message_s/shellscripts/dit_message_stage_load.sh"
#task_dit_message_s = NWBashScriptOperator(
#    bash_script=task_dit_message_s_script,
#    script_args=[],
#    task_id='dit_message_s',
#    dag=dag)
#
#task_dit_message_tag_s_script="/data/etl/Scripts/dit_message_tag_s/shellscripts/dit_message_tag_stage_load.sh"
#task_dit_message_tag_s = NWBashScriptOperator(
#    bash_script=task_dit_message_tag_s_script,
#    script_args=[],
#    task_id='dit_message_tag_s',
#    dag=dag)
#
#task_dw_dit_msg_f_script="/data/etl/Scripts/dw_dit_msg_f/shellscripts/dit_message_fact_loading.sh"
#task_dw_dit_msg_f = NWBashScriptOperator(
#    bash_script=task_dw_dit_msg_f_script,
#    script_args=[],
#    task_id='dw_dit_msg_f',
#    dag=dag)
#
#task_dw_dit_msg_tag_xref_script="/data/etl/Scripts/dw_dit_msg_tag_xref/shellscripts/dit_message_tag_xref_loading.sh"
#task_dw_dit_msg_tag_xref = NWBashScriptOperator(
#    bash_script=task_dw_dit_msg_tag_xref_script,
#    script_args=[],
#    task_id='dw_dit_msg_tag_xref',
#    dag=dag)
#
#task_dit_question_api_dwnld_script="/data/etl/Scripts/dit_question_s/shellscripts/dit_question.sh"
#task_dit_question_api_dwnld = NWBashScriptOperator(
#    bash_script=task_dit_question_api_dwnld_script,
#    script_args=[],
#    task_id='dit_question_api_dwnld',
#    dag=dag)
#
#task_dit_question_s_script="/data/etl/Scripts/dit_question_s/shellscripts/dit_question_stage_load.sh"
#task_dit_question_s = NWBashScriptOperator(
#    bash_script=task_dit_question_s_script,
#    script_args=[],
#    task_id='dit_question_s',
#    dag=dag)
#
#task_dit_question_tag_s_script="/data/etl/Scripts/dit_question_tag_s/shellscripts/dit_question_tag_stage_load.sh"
#task_dit_question_tag_s = NWBashScriptOperator(
#    bash_script=task_dit_question_tag_s_script,
#    script_args=[],
#    task_id='dit_question_tag_s',
#    dag=dag)
#
#task_dw_dit_qstn_d_script="/data/etl/Scripts/dw_dit_qstn_d/shellscripts/dit_question_dimension_loading.sh"
#task_dw_dit_qstn_d = NWBashScriptOperator(
#    bash_script=task_dw_dit_qstn_d_script,
#    script_args=[],
#    task_id='dw_dit_qstn_d',
#    dag=dag)
#
#task_dw_dit_qstn_tag_xref_script="/data/etl/Scripts/dw_dit_qstn_tag_xref/shellscripts/dit_question_tag_xref_loading.sh"
#task_dw_dit_qstn_tag_xref = NWBashScriptOperator(
#    bash_script=task_dw_dit_qstn_tag_xref_script,
#    script_args=[],
#    task_id='dw_dit_qstn_tag_xref',
#    dag=dag)
#
#task_dit_user_feedback_s_script="/data/etl/Scripts/dit_user_feedback_s/shellscripts/dit_user_feedback.sh"
#task_dit_user_feedback_s = NWBashScriptOperator(
#    bash_script=task_dit_user_feedback_s_script,
#    script_args=[],
#    task_id='dit_user_feedback_s',
#    dag=dag)
#
#task_dw_dit_user_fdbk_f_script="/data/etl/Scripts/dw_dit_user_fdbk_f/shellscripts/dit_user_fdbk_fact_loading.sh"
#task_dw_dit_user_fdbk_f = NWBashScriptOperator(
#    bash_script=task_dw_dit_user_fdbk_f_script,
#    script_args=[],
#    task_id='dw_dit_user_fdbk_f',
#    dag=dag)
#
#task_dit_note_s_script="/data/etl/Scripts/dit_note_s/shellscripts/dit_note.sh"
#task_dit_note_s = NWBashScriptOperator(
#    bash_script=task_dit_note_s_script,
#    script_args=[],
#    task_id='dit_note_s',
#    dag=dag)
#
#task_dw_dit_note_xref_script="/data/etl/Scripts/dw_dit_note_xref/shellscripts/dit_note_xref_load.sh"
#task_dw_dit_note_xref = NWBashScriptOperator(
#    bash_script=task_dw_dit_note_xref_script,
#    script_args=[],
#    task_id='dw_dit_note_xref',
#    dag=dag)

task_role_change_event_fact_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_identity_role_chg_event_f/shellscripts/dw_identity_role_chg_event_f.sh",
    script_args=[],
    task_id='RoleChangeEvent_Fact_Load',
    dag=dag)
task_role_change_event_fact_load.set_upstream(stage_load_tasks['RoleChangeEvent'])

task_identity_site_visitor_xref_d_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_identity_site_visitor_xref_d/shellscripts/identity_site_visitor_xref_loading.sh",
    script_args=[],
    task_id='IDENTITY_SITE_VISITOR_XREF',
    dag=dag)

#task_tu_credit_report_profile_s_script="/data/etl/Scripts/tu_credit_report_profile_s/shellscripts/tu_credit_report_profile_s.sh"
#task_tu_credit_report_profile_s = NWBashScriptOperator(
#    bash_script=task_tu_credit_report_profile_s_script,
#    script_args=[],
#    task_id='tu_credit_report_profile_s',
#    dag=dag)

#task_dw_identity_tu_credit_rprt_profile_d_script="/data/etl/Scripts/dw_identity_tu_credit_rprt_profile_d/shellscripts/dw_identity_tu_credit_rprt_profile_d.sh"
#task_dw_identity_tu_credit_rprt_profile_d = NWBashScriptOperator(
#    bash_script=task_dw_identity_tu_credit_rprt_profile_d_script,
#    script_args=[],
#    task_id='dw_identity_tu_credit_rprt_profile_d',
#    dag=dag)

#task_tu_auth_status_profile_s_script="/data/etl/Scripts/tu_auth_status_profile_s/shellscripts/tu_auth_status_profile_s.sh"
#task_tu_auth_status_profile_s = NWBashScriptOperator(
#    bash_script=task_tu_auth_status_profile_s_script,
#    script_args=[],
#    task_id='tu_auth_status_profile_s',
#    dag=dag)

#task_dw_identity_tu_auth_status_profile_d_script="/data/etl/Scripts/dw_identity_tu_auth_status_profile_d/shellscripts/dw_identity_tu_auth_status_profile_d.sh"
#task_dw_identity_tu_auth_status_profile_d = NWBashScriptOperator(
#    bash_script=task_dw_identity_tu_auth_status_profile_d_script,
#    script_args=[],
#    task_id='dw_identity_tu_auth_status_profile_d',
#    dag=dag)


Task_PUD_IDENTITY_dependency = ExternalTaskSensor(
    task_id='waiting_for_daily_pud_identity_job',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_identity_d',
    dag=dag)

Task_PUD_IDENTITY_Tradeline_dependency = ExternalTaskSensor(
    task_id='waiting_for_daily_pud_identity_non_core_job',
    external_dag_id='dag_daily_pud_identity_non_core',
    external_task_id='dw_identity_tu_trdln_snap_f',
    dag=dag)

Task_PUD_IDENTITY_status_dependency = ExternalTaskSensor(
    task_id='waiting_for_status_update_daily_pud_identity_job',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='status_update',
    dag=dag)

task_dw_yd_acct_bal_f = ExternalTaskSensor(
    task_id='dag_daily_pud_identity.dw_yd_acct_bal_f',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_yd_acct_bal_f',
    dag=dag)
task_dw_yd_acct_bal_f.set_upstream(task_core_start_job)

task_dw_yd_acct_d = ExternalTaskSensor(
    task_id='dag_daily_pud_identity.dw_yd_acct_d',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_yd_acct_d',
    dag=dag)
task_dw_yd_acct_d.set_upstream(task_core_start_job)

task_dw_yd_tran_f = ExternalTaskSensor(
    task_id='dag_daily_pud_identity.dw_yd_tran_f',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_yd_tran_f',
    dag=dag)
task_dw_yd_tran_f.set_upstream(task_core_start_job)

Task_dw_goal_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_goal_d_job',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_goal_d',
    dag=dag)

Task_dw_goal_acct_xref_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_goal_acct_xref_f_job',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_goal_acct_xref_f',
    dag=dag)

Task_dw_bshrk_biller_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_bshrk_biller_d_job',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_bshrk_biller_d',
    dag=dag)

Task_dw_bshrk_bill_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_bshrk_bill_f_job',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_bshrk_bill_f',
    dag=dag)

Task_dw_feed_item_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_feed_item_d_job',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_feed_item_d',
    dag=dag)

Task_dw_feed_elem_intactn_event_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_feed_elem_intactn_event_f_job',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='FeedElementInteractionEvent_Fact_Load',
    dag=dag)


#task_dw_identity_actvy_snap_f_script="/data/etl/Scripts/dw_identity_actvy_snap_f/shellscripts/dw_identity_actvy_snap_f.sh"
#task_dw_identity_actvy_snap_f = NWBashScriptOperator(
#    bash_script=task_dw_identity_actvy_snap_f_script,
#    script_args=[],
#    task_id='dw_identity_actvy_snap_f',
#    dag=dag)


#task_dw_identity_actvy_snap_rollup_f_script="/data/etl/Scripts/dw_identity_actvy_snap_rollup_f/shellscripts/dw_identity_actvy_snap_rollup_f.sh"
#task_dw_identity_actvy_snap_rollup_f = NWBashScriptOperator(
#    bash_script=task_dw_identity_actvy_snap_rollup_f_script,
#    script_args=[],
#    task_id='dw_identity_actvy_snap_rollup_f',
#    dag=dag)

Task_Core_Dag_status_dependency = ExternalTaskSensor(
    task_id='waiting_for_status_update_daily_core_dag_job',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='status_update',
    dag=dag)

Task_Aflt_tran_Dag_status_dependency = ExternalTaskSensor(
    task_id='waiting_for_status_update_dag_daily_aflt_tran_job',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='status_update',
    dag=dag)

Task_Email_Event_Data_Load_Dag_status_dependency = ExternalTaskSensor(
    task_id='waiting_for_status_update_dag_daily_event_data_load_job',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='dw_email_event_Fact_Load',
    dag=dag)

Task_Dw_Actvy_F_Dag_Load_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_actvy_f_core_Fact_Load_job',
    external_dag_id='dag_daily_activity_merge',
    external_task_id='dw_actvy_f_core_Fact_Load',
    dag=dag)


#task_idb_addresses_s_script="/data/etl/Scripts/idb_addresses_s/shellscripts/idb_addresses_s.sh"
#task_idb_addresses_s = NWBashScriptOperator(
#    bash_script=task_idb_addresses_s_script,
#    script_args=[],
#    task_id='idb_addresses_s',
#    dag=dag)

#task_idb_global_profiles_s_script="/data/etl/Scripts/idb_global_profiles_s/shellscripts/idb_global_profiles_s.sh"
#task_idb_global_profiles_s = NWBashScriptOperator(
#    bash_script=task_idb_global_profiles_s_script,
#    script_args=[],
#    task_id='idb_global_profiles_s',
#    dag=dag)

#task_dw_identity_glb_profile_d_script="/data/etl/Scripts/dw_identity_glb_profile_d/shellscripts/dw_identity_glb_profile_d.sh"
#task_dw_identity_glb_profile_d = NWBashScriptOperator(
#    bash_script=task_dw_identity_glb_profile_d_script,
#    script_args=[],
#    task_id='dw_identity_glb_profile_d',
#    dag=dag)

task_idb_registration_tracking_profiles_s_script="/data/etl/Scripts/idb_registration_tracking_profiles_s/shellscripts/idb_registration_tracking_profiles_s.sh"
task_idb_registration_tracking_profiles_s = NWBashScriptOperator(
    bash_script=task_idb_registration_tracking_profiles_s_script,
    script_args=[],
    task_id='idb_registration_tracking_profiles_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_identity_rgstn_trkng_profile_d_script="/data/etl/Scripts/dw_identity_rgstn_trkng_profile_d/shellscripts/dw_identity_rgstn_trkng_profile_d.sh"
task_dw_identity_rgstn_trkng_profile_d = NWBashScriptOperator(
    bash_script=task_dw_identity_rgstn_trkng_profile_d_script,
    script_args=[],
    task_id='dw_identity_rgstn_trkng_profile_d',
    dag=dag)

task_idb_mobile_app_profile_devices_s_script="/data/etl/Scripts/idb_mobile_app_profile_devices_s/shellscripts/idb_mobile_app_profile_devices_s.sh"
task_idb_mobile_app_profile_devices_s = NWBashScriptOperator(
    bash_script=task_idb_mobile_app_profile_devices_s_script,
    script_args=[],
    task_id='idb_mobile_app_profile_devices_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_identity_mbl_app_dvc_profile_d_script="/data/etl/Scripts/dw_identity_mbl_app_dvc_profile_d/shellscripts/dw_identity_mbl_app_dvc_profile_d.sh"
task_dw_identity_mbl_app_dvc_profile_d = NWBashScriptOperator(
    bash_script=task_dw_identity_mbl_app_dvc_profile_d_script,
    script_args=[],
    task_id='dw_identity_mbl_app_dvc_profile_d',
    dag=dag)

###User Snap task ends here
task_dw_user_contact_s_script="/data/etl/Scripts/dw_user_contact_s/shellscripts/dw_user_contact_s.sh"
task_dw_user_contact_s = NWBashScriptOperator(
    bash_script=task_dw_user_contact_s_script,
    script_args=[],
    task_id='dw_user_contact_s',
    dag=dag)


task_dw_user_monetization_s_script="/data/etl/Scripts/dw_user_monetization_s/shellscripts/dw_user_monetization_s.sh"
task_dw_user_monetization_s = NWBashScriptOperator(
    bash_script=task_dw_user_monetization_s_script,
    script_args=[],
    task_id='dw_user_monetization_s',
    dag=dag)

task_dw_user_engagement_s_script="/data/etl/Scripts/dw_user_engagement_s/shellscripts/dw_user_engagement_s.sh"
task_dw_user_engagement_s = NWBashScriptOperator(
    bash_script=task_dw_user_engagement_s_script,
    script_args=[],
    task_id='dw_user_engagement_s',
    dag=dag)

task_dw_user_tu_credit_profile_s_script="/data/etl/Scripts/dw_user_tu_credit_profile_s/shellscripts/dw_user_tu_credit_profile_s.sh"
task_dw_user_tu_credit_profile_s = NWBashScriptOperator(
    bash_script=task_dw_user_tu_credit_profile_s_script,
    script_args=[],
    task_id='dw_user_tu_credit_profile_s',
    dag=dag)

task_dw_user_yd_actvy_s_script="/data/etl/Scripts/dw_user_yd_actvy_s/shellscripts/dw_user_yd_actvy_s.sh"
task_dw_user_yd_actvy_s = NWBashScriptOperator(
    bash_script=task_dw_user_yd_actvy_s_script,
    script_args=[],
    task_id='dw_user_yd_actvy_s',
    dag=dag)

task_dw_user_ipx_actvy_s_script="/data/etl/Scripts/dw_user_ipx_actvy_s/shellscripts/dw_user_ipx_actvy_s.sh"
task_dw_user_ipx_actvy_s = NWBashScriptOperator(
    bash_script=task_dw_user_ipx_actvy_s_script,
    script_args=[],
    task_id='dw_user_ipx_actvy_s',
    dag=dag)

task_dw_user_reg_profile_s_script="/data/etl/Scripts/dw_user_reg_profile_s/shellscripts/dw_user_reg_profile_s.sh"
task_dw_user_reg_profile_s = NWBashScriptOperator(
    bash_script=task_dw_user_reg_profile_s_script,
    script_args=[],
    task_id='dw_user_reg_profile_s',
    dag=dag)

task_dw_user_global_profile_s_script="/data/etl/Scripts/dw_user_global_profile_s/shellscripts/dw_user_global_profile_s.sh"
task_dw_user_global_profile_s = NWBashScriptOperator(
    bash_script=task_dw_user_global_profile_s_script,
    script_args=[],
    task_id='dw_user_global_profile_s',
    dag=dag)

task_dw_user_actvy_status_s_script="/data/etl/Scripts/dw_user_actvy_status_s/shellscripts/dw_user_actvy_status_s.sh"
task_dw_user_actvy_status_s = NWBashScriptOperator(
    bash_script=task_dw_user_actvy_status_s_script,
    script_args=[],
    task_id='dw_user_actvy_status_s',
    dag=dag)


task_dw_user_d_script="/data/etl/Scripts/dw_user_d/shellscripts/dw_user_d.sh"
task_dw_user_d = NWBashScriptOperator(
    bash_script=task_dw_user_d_script,
    script_args=[],
    task_id='dw_user_d',
    dag=dag)


task_dw_user_actvy_smry_f_script="/data/etl/Scripts/dw_user_actvy_smry_f/shellscripts/dw_user_actvy_smry_f.sh"
task_dw_user_actvy_smry_f = NWBashScriptOperator(
    bash_script=task_dw_user_actvy_smry_f_script,
    script_args=[],
    task_id='dw_user_actvy_smry_f',
    dag=dag)
### User Snap task ends here

task_identity_dag_status_update = DummyOperator(
    task_id='status_update',
    dag=dag)

Task_ipx_fact_dependency = DummyOperator(
    task_id='Task_ipx_fact_dependency',
    dag=dag)
#task_idb_identities_s.set_upstream(task_start_job)
task_idb_identity_roles_s.set_upstream(task_start_job)
#task_idb_identity_roles_s.set_upstream(task_idb_identities_s)
#task_dw_identity_d.set_upstream(task_idb_identity_roles_s)
task_dw_identity_role_d.set_upstream(task_idb_identity_roles_s)


#task_dit_tag_s.set_upstream(task_start_job)
#task_dw_dit_tag_d.set_upstream(task_dit_tag_s)
#
#task_dit_user_s.set_upstream(task_start_job)
#task_dw_dit_user_d.set_upstream(task_dit_user_s)
#task_dw_dit_user_d.set_upstream(Task_PUD_IDENTITY_dependency)
#
#task_dit_expert_s.set_upstream(task_start_job)
#task_dw_dit_exprt_d.set_upstream(task_dit_expert_s)
#task_dw_dit_exprt_d.set_upstream(Task_PUD_IDENTITY_dependency)
#
#task_dit_question_api_dwnld.set_upstream(task_start_job)
#task_dit_question_s.set_upstream(task_dit_question_api_dwnld)
#task_dw_dit_qstn_d.set_upstream(task_dit_question_s)
#
#task_dit_question_tag_s.set_upstream(task_dit_question_api_dwnld)
#task_dw_dit_qstn_tag_xref.set_upstream(task_dit_question_tag_s)
#task_dw_dit_qstn_tag_xref.set_upstream(task_dw_dit_tag_d)
#
#task_dit_conversation_api_dwnld.set_upstream(task_start_job)
#task_dit_conversation_s.set_upstream(task_dit_conversation_api_dwnld)
#task_dit_conversation_tag_s.set_upstream(task_dit_conversation_api_dwnld)
#
#task_dw_dit_convo_f.set_upstream(task_dit_conversation_s)
#task_dw_dit_convo_f.set_upstream(task_dw_dit_user_d)
#task_dw_dit_convo_f.set_upstream(task_dw_dit_exprt_d)
#
#task_dw_dit_convo_tag_xref.set_upstream(task_dit_conversation_tag_s)
#task_dw_dit_convo_tag_xref.set_upstream(task_dw_dit_tag_d)
#task_dw_dit_convo_tag_xref.set_upstream(task_dw_dit_convo_f)
#
#task_dit_message_api_dwnld.set_upstream(task_start_job)
#task_dit_message_s.set_upstream(task_dit_message_api_dwnld)
#task_dit_message_tag_s.set_upstream(task_dit_message_api_dwnld)
#
#task_dw_dit_msg_f.set_upstream(task_dit_message_s)
#task_dw_dit_msg_f.set_upstream(task_dw_dit_convo_f)
#task_dw_dit_msg_f.set_upstream(task_dw_dit_user_d)
#
#
#task_dw_dit_msg_tag_xref.set_upstream(task_dit_message_tag_s)
#task_dw_dit_msg_tag_xref.set_upstream(task_dw_dit_msg_f)
#task_dw_dit_msg_tag_xref.set_upstream(task_dw_dit_tag_d)
#
#task_dit_user_feedback_s.set_upstream(task_start_job)
#task_dw_dit_user_fdbk_f.set_upstream(task_dit_user_feedback_s)
#task_dw_dit_user_fdbk_f.set_upstream(task_dw_dit_user_d)
#
#task_dit_note_s.set_upstream(task_start_job)
#task_dw_dit_note_xref.set_upstream(task_dit_note_s)
#task_dw_dit_note_xref.set_upstream(task_dw_dit_convo_f)
#task_dw_dit_note_xref.set_upstream(task_dw_dit_exprt_d)


task_identity_site_visitor_xref_d_load.set_upstream(task_core_start_job)
task_identity_site_visitor_xref_d_load.set_upstream(Task_Dw_Actvy_F_Dag_Load_dependency)


#task_tu_credit_report_profile_s.set_upstream(task_start_job)
#task_dw_identity_tu_credit_rprt_profile_d.set_upstream(task_tu_credit_report_profile_s)
#task_dw_identity_tu_credit_rprt_profile_d.set_upstream(task_dw_identity_d)


#task_tu_auth_status_profile_s.set_upstream(task_start_job)
#task_dw_identity_tu_auth_status_profile_d.set_upstream(task_tu_auth_status_profile_s)
#task_dw_identity_tu_auth_status_profile_d.set_upstream(task_dw_identity_d)

#task_dw_identity_actvy_snap_f.set_upstream(task_start_job)
#task_dw_identity_actvy_snap_f.set_upstream(task_dw_identity_tu_auth_status_profile_d)
#task_dw_identity_actvy_snap_f.set_upstream(task_dw_identity_tu_credit_rprt_profile_d)
#task_dw_identity_actvy_snap_f.set_upstream(Task_PUD_IDENTITY_dependency)
#task_dw_identity_actvy_snap_f.set_upstream(task_dw_identity_d)
#task_dw_identity_actvy_snap_f.set_upstream(task_identity_site_visitor_xref_d_load)

#task_dw_identity_actvy_snap_rollup_f.set_upstream(task_start_job)
#task_dw_identity_actvy_snap_rollup_f.set_upstream(task_dw_identity_actvy_snap_f)

#task_idb_addresses_s.set_upstream(task_start_job)

#task_idb_global_profiles_s.set_upstream(task_start_job)

#task_dw_identity_glb_profile_d.set_upstream(task_idb_addresses_s)
#task_dw_identity_glb_profile_d.set_upstream(task_idb_global_profiles_s)
#task_dw_identity_glb_profile_d.set_upstream(task_dw_identity_d)


task_idb_registration_tracking_profiles_s.set_upstream(task_core_start_job)
task_dw_identity_rgstn_trkng_profile_d.set_upstream(task_idb_registration_tracking_profiles_s)
task_dw_identity_rgstn_trkng_profile_d.set_upstream(Task_PUD_IDENTITY_dependency)

task_idb_mobile_app_profile_devices_s.set_upstream(task_start_job)
task_dw_identity_mbl_app_dvc_profile_d.set_upstream(task_idb_mobile_app_profile_devices_s)
task_dw_identity_mbl_app_dvc_profile_d.set_upstream(Task_PUD_IDENTITY_dependency)

task_dw_user_contact_s.set_upstream(task_core_start_job)
task_dw_user_contact_s.set_upstream(Task_Email_Event_Data_Load_Dag_status_dependency)

task_dw_user_monetization_s.set_upstream(task_core_start_job)
task_dw_user_monetization_s.set_upstream(Task_Aflt_tran_Dag_status_dependency)
task_dw_user_monetization_s.set_upstream(task_dw_user_d)


task_dw_user_engagement_s.set_upstream(task_core_start_job)
task_dw_user_engagement_s.set_upstream(Task_Core_Dag_status_dependency)
task_dw_user_engagement_s.set_upstream(task_identity_site_visitor_xref_d_load)
task_dw_user_engagement_s.set_upstream(task_dw_user_d)



task_dw_user_tu_credit_profile_s.set_upstream(task_core_start_job)
task_dw_user_tu_credit_profile_s.set_upstream(Task_PUD_IDENTITY_status_dependency)
task_dw_user_tu_credit_profile_s.set_upstream(Task_PUD_IDENTITY_Tradeline_dependency)

Task_ipx_fact_dependency.set_upstream(task_dw_user_d)
Task_ipx_fact_dependency.set_upstream(Task_dw_goal_d_dependency)
Task_ipx_fact_dependency.set_upstream(Task_dw_goal_acct_xref_f_dependency)
Task_ipx_fact_dependency.set_upstream(Task_dw_bshrk_biller_d_dependency)
Task_ipx_fact_dependency.set_upstream(Task_dw_bshrk_bill_f_dependency)
Task_ipx_fact_dependency.set_upstream(Task_dw_feed_item_d_dependency)
Task_ipx_fact_dependency.set_upstream(Task_dw_feed_elem_intactn_event_f_dependency)

task_dw_user_yd_actvy_s.set_upstream(task_dw_yd_acct_bal_f)
task_dw_user_yd_actvy_s.set_upstream(task_dw_yd_acct_d)
task_dw_user_yd_actvy_s.set_upstream(task_dw_yd_tran_f)

task_dw_user_ipx_actvy_s.set_upstream(task_core_start_job)
task_dw_user_ipx_actvy_s.set_upstream(Task_ipx_fact_dependency)



task_dw_user_reg_profile_s.set_upstream(task_core_start_job)
task_dw_user_reg_profile_s.set_upstream(Task_PUD_IDENTITY_status_dependency)
task_dw_user_reg_profile_s.set_upstream(Task_PUD_IDENTITY_dependency)
task_dw_user_reg_profile_s.set_upstream(task_dw_identity_rgstn_trkng_profile_d)

task_dw_user_global_profile_s.set_upstream(task_core_start_job)
task_dw_user_global_profile_s.set_upstream(Task_PUD_IDENTITY_status_dependency)
task_dw_user_global_profile_s.set_upstream(Task_PUD_IDENTITY_dependency)

task_dw_user_actvy_status_s.set_upstream(task_core_start_job)
task_dw_user_actvy_status_s.set_upstream(Task_Dw_Actvy_F_Dag_Load_dependency)

task_dw_user_actvy_smry_f.set_upstream(task_dw_user_contact_s)
task_dw_user_actvy_smry_f.set_upstream(task_dw_user_monetization_s)
task_dw_user_actvy_smry_f.set_upstream(task_dw_user_engagement_s)
task_dw_user_actvy_smry_f.set_upstream(task_dw_user_tu_credit_profile_s)
task_dw_user_actvy_smry_f.set_upstream(task_dw_user_reg_profile_s)
task_dw_user_actvy_smry_f.set_upstream(task_dw_user_actvy_status_s)
task_dw_user_actvy_smry_f.set_upstream(task_dw_user_global_profile_s)
task_dw_user_actvy_smry_f.set_upstream(task_dw_user_yd_actvy_s)
task_dw_user_actvy_smry_f.set_upstream(task_dw_user_ipx_actvy_s)

task_dw_user_d.set_upstream(task_dw_user_tu_credit_profile_s)
task_dw_user_d.set_upstream(task_dw_user_reg_profile_s)
task_dw_user_d.set_upstream(task_dw_user_global_profile_s)

task_identity_dag_status_update.set_upstream(task_dw_identity_rgstn_trkng_profile_d)
task_identity_dag_status_update.set_upstream(task_dw_user_d)
task_identity_dag_status_update.set_upstream(task_dw_user_actvy_smry_f)

