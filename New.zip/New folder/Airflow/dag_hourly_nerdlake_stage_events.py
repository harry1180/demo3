from datetime import datetime, timedelta
import os
import sys

from airflow import DAG
from airflow.models import Variable
from airflow.operators import NWBashScriptOperator, DummyOperator
from airflow.operators.sensors import ExternalTaskSensor

sys.path.append(os.path.dirname(__file__))  # Allow importing of modules from the same directory as our DAGs
import airflow_dwh

dag_name = 'dag_hourly_nerdlake_events_stage'

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2018, 9, 18),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=10),
    'queue': 'highmem',
    'depends_on_past': True
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@hourly')

###########################################################################
# External task sensors
###########################################################################
task_all_events_s_nerdlake_load = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.all_events_s_nerdlake_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='all_events_s_nerdlake_load',
    dag=dag)

################################################################################
# Start stage deserialization only after the production deserialization has
# finished.
################################################################################
task_start_deser = DummyOperator(
    task_id='start_deser',
    dag=dag)
task_start_deser.set_upstream(task_all_events_s_nerdlake_load)

################################################################################
# Event Deserialization, create dictionary to store the tasks and a set to
# store the blacklist.
################################################################################
event_tasks = dict()

# Blacklist KaDu events as well as deserialized events
event_blacklist = set()
event_blacklist.update(airflow_dwh.csv_string_to_list(Variable.get('event_kadu_blacklist')))
event_blacklist.update(airflow_dwh.csv_string_to_list(Variable.get('event_deser_blacklist')))

################################################################################
# Kafka Topic Names
################################################################################
kafka_topic_names = airflow_dwh.get_kafka_topics(client_id=dag_name)

################################################################################
# ProtoBuf Events
################################################################################
task_start_protobuf_event_deser = DummyOperator(
    task_id='start_protobuf_deser',
    dag=dag)
task_start_protobuf_event_deser.set_upstream(task_start_deser)

protobuf_class_names = airflow_dwh.get_base_pbuf_class_names()
for pbuf_class_name in protobuf_class_names.intersection(kafka_topic_names):
    if pbuf_class_name in event_blacklist:
        continue

    # Give events that have a lot of downstream dependencies a higher weight so that they run first, allowing their
    # dependencies to run earlier. Also give large events a heavier weight so that they start running sooner. If large
    # events run late in the hour, they will often be the only process running which leaves other CPUs idle. Running
    # these earlier causes smaller tasks to fill up empty CPUs later in the batch cycle, resulting in an earlier overall
    # completion time.
    weight = 1
    if pbuf_class_name in ('PageViewEvent', 'FormInputChangedEvent'):
        weight = 10

    event_task = NWBashScriptOperator(
        task_id=pbuf_class_name + '_nerdlake_deserialization_load',
        bash_script='/data/etl/Common/deserialize_pb_nerdlake.sh',
        script_args=[pbuf_class_name, '--base-param-file /data/etl/Common/event_params_stage.json'],
        pool='nerdlake_deser_airflowhighmem',
        priority_weight=weight,
        dag=dag)
    event_task.set_upstream(task_start_protobuf_event_deser)
    event_tasks[pbuf_class_name] = event_task


################################################################################
# JSON Events
################################################################################
task_start_json_event_deser = DummyOperator(
    task_id='start_json_deser',
    dag=dag)
task_start_json_event_deser.set_upstream(task_start_deser)

# TODO: Build these from airflow_dwh.get_json_event_names() when we have a generic JSON deserializer
task_backend_model_execution_event_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/BackendModelExecutionEvent_nerdlake/shellscripts/BackendModelExecutionEvent_nerdlake_stage.sh',
    script_args=[],
    task_id='BackendModelExecutionEvent_nerdlake_load',
    dag=dag
    )
task_backend_model_execution_event_nerdlake_load.set_upstream(task_start_json_event_deser)
event_tasks['BackendModelExecutionEvent'] = task_backend_model_execution_event_nerdlake_load

task_ablogevent_plain_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/ablogevent_plain_nerdlake/shellscripts/ablogevent_plain.sh',
    script_args=['stageenv'],
    task_id='ablogevent_plain_nerdlake_load',
    dag=dag
    )
task_ablogevent_plain_nerdlake_load.set_upstream(task_start_json_event_deser)
event_tasks['ablogevent_plain'] = task_ablogevent_plain_nerdlake_load

task_api_response_event_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/APIResponseEvent_nerdlake/shellscripts/APIResponseEvent_nerdlake.sh',
    script_args=['stageenv'],
    task_id='ApiResponseEvent_nerdlake_load',
    dag=dag
    )
task_api_response_event_nerdlake_load.set_upstream(task_start_json_event_deser)
event_tasks['ApiResponseEvent'] = task_api_response_event_nerdlake_load
