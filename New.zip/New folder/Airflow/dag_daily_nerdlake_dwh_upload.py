from datetime import datetime, timedelta, time

from airflow import DAG
from airflow.operators import DummyOperator, NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_nerdlake_dwh_upload'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 9, 24),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

# Presto's Redshift connector is fairly heavy against Redshift
task_start_redshift_connector_tasks = TimeSensor(
    target_time=time(8, 15),
    task_id='Initiating_start_time',
    dag=dag)
task_start_redshift_connector_tasks.set_upstream(task_start_dag)

################################################################################
# External tasks
################################################################################
task_MinusWorldEvent = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.MinusWorldEvent_nerdlake_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='MinusWorldEvent_nerdlake_load',
    execution_delta=timedelta(hours=-23),
    dag=dag)
task_MinusWorldEvent.set_upstream(task_start_dag)

task_dwh_site_visitor_d_load = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.site_visitor_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='site_visitor_d',
    dag=dag)
task_dwh_site_visitor_d_load.set_upstream(task_start_dag)

task_dwh_dw_aflt_tran_consolidated_f_load = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran.aflt_tran_consolidated_fact',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_consolidated_fact',
    dag=dag)
task_dwh_dw_aflt_tran_consolidated_f_load.set_upstream(task_start_dag)

Task_identity_status_load = ExternalTaskSensor(
    task_id='dag_daily_identity.status_update',
    external_dag_id='dag_daily_identity',
    external_task_id='status_update',
    dag=dag)
Task_identity_status_load.set_upstream(task_start_redshift_connector_tasks)

task_dwh_url_d_redshift = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_url_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_url_d',
    dag=dag)
task_dwh_url_d_redshift.set_upstream(task_start_dag)

Task_dwh_yd_acct_bal_f_load = ExternalTaskSensor(
    task_id='dag_daily_pud_identity.dw_yd_acct_bal_f',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_yd_acct_bal_f',
    dag=dag)
Task_dwh_yd_acct_bal_f_load.set_upstream(task_start_redshift_connector_tasks)

Task_dwh_yd_acct_d_load = ExternalTaskSensor(
    task_id='dag_daily_pud_identity.dw_yd_acct_d',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_yd_acct_d',
    dag=dag)
Task_dwh_yd_acct_d_load.set_upstream(task_start_redshift_connector_tasks)

Task_dwh_yd_tran_f_load = ExternalTaskSensor(
    task_id='dag_daily_pud_identity.dw_yd_tran_f',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_yd_tran_f',
    dag=dag)
Task_dwh_yd_tran_f_load.set_upstream(task_start_redshift_connector_tasks)

Task_dwh_identity_tu_credit_rprt_profile_d_load = ExternalTaskSensor(
    task_id='dag_daily_pud_identity.dw_identity_tu_credit_rprt_profile_d',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_identity_tu_credit_rprt_profile_d',
    dag=dag)
Task_dwh_identity_tu_credit_rprt_profile_d_load.set_upstream(task_start_redshift_connector_tasks)

task_dwh_page_d_redshift = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_page_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_page_d',
    dag=dag)
task_dwh_page_d_redshift.set_upstream(task_start_dag)

task_dw_page_detail_d_redshift = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_page_detail_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_page_detail_d',
    dag=dag)
task_dw_page_detail_d_redshift.set_upstream(task_start_dag)

task_ba_mktg_sst_product_redshift = ExternalTaskSensor(
    task_id='baidag_mktg_sst.mktg_sst_stage_load.sql',
    external_dag_id='baidag_mktg_sst',
    external_task_id='mktg_sst_stage_load.sql',
    dag=dag)
task_ba_mktg_sst_product_redshift.set_upstream(task_start_dag)

task_ba_mktg_sst_aggs_done = ExternalTaskSensor(
    task_id='baidag_mktg_sst.aggs_done',
    external_dag_id='baidag_mktg_sst',
    external_task_id='aggs_done',
    dag=dag)
task_ba_mktg_sst_aggs_done.set_upstream(task_start_dag)

task_dw_page_view_event_trkng_param_f_load = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_page_view_event_trkng_param_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_page_view_event_trkng_param_f',
    dag=dag)
task_dw_page_view_event_trkng_param_f_load.set_upstream(task_start_dag)

task_mktg_tch_event_f_load = ExternalTaskSensor(
    task_id='dag_daily_marketing_mta.mktg_tch_event_f',
    external_dag_id='dag_daily_marketing_mta',
    external_task_id='mktg_tch_event_f',
    dag=dag)
task_mktg_tch_event_f_load.set_upstream(task_start_dag)

task_mktg_consolidated_campaign_perf_f_load = ExternalTaskSensor(
    task_id='dag_daily_marketing.mktg_consolidated_campaign_perf_f',
    external_dag_id='dag_daily_marketing',
    external_task_id='mktg_consolidated_campaign_perf_f',
    dag=dag)
task_mktg_consolidated_campaign_perf_f_load.set_upstream(task_start_dag)

task_mktg_tch_ad_d_load = ExternalTaskSensor(
    task_id='dag_daily_marketing_mta.mktg_tch_ad_d',
    external_dag_id='dag_daily_marketing_mta',
    external_task_id='mktg_tch_ad_d',
    dag=dag)
task_mktg_tch_ad_d_load.set_upstream(task_start_dag)

################################################################################
# Redshift - build working table before unloading
################################################################################
task_mktg_product_summary_sst_w = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_product_summary_sst_w/shellscripts/mktg_product_summary_sst_w.sh',
    script_args=[],
    task_id='mktg_product_summary_sst_w',
    pool='redshift_etl',
    dag=dag)
task_mktg_product_summary_sst_w.set_upstream(task_ba_mktg_sst_aggs_done)

################################################################################
# Redshift data unloads to NerdLake external staging table
################################################################################
task_dw_url_d_redshift_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['dw_url_d_unload', 'dw_report.dw_url_d', 'dwnl_stage.dw_url_s'],
    task_id='dw_url_d_unload',
    pool='redshift_etl',
    dag=dag)
task_dw_url_d_redshift_unload.set_upstream(task_dwh_url_d_redshift)

task_dw_page_d_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['dw_page_d_unload', 'dw_report.dw_page_d', 'dwnl_stage.dw_page_s'],
    task_id='dw_page_d_unload',
    pool='redshift_etl',
    dag=dag)
task_dw_page_d_unload.set_upstream(task_dwh_page_d_redshift)

task_dw_page_detail_d_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['dw_page_detail_d_unload', 'dw_report.dw_page_detail_d', 'dwnl_stage.dw_page_detail_s'],
    task_id='dw_page_detail_d_unload',
    pool='redshift_etl',
    dag=dag)
task_dw_page_detail_d_unload.set_upstream(task_dw_page_detail_d_redshift)

task_ba_mktg_sst_product_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['ba_mktg_sst_product_unload', 'dw_ba_report.ba_mktg_sst_product', 'dwnl_stage.ba_mktg_sst_product_s',
                 '--redshift-table-filter', '"dw_eff_dt >= CURRENT_DATE - INTERVAL \'60 DAY\'"'],
    task_id='ba_mktg_sst_product_unload',
    pool='redshift_etl',
    dag=dag)
task_ba_mktg_sst_product_unload.set_upstream(task_ba_mktg_sst_product_redshift)

task_ba_sst_metric_d_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['ba_sst_metric_d_unload', 'dw_ba_report.ba_sst_metric_dim', 'dwnl_stage.ba_sst_metric_s'],
    task_id='ba_sst_metric_d_unload',
    pool='redshift_etl',
    dag=dag)
task_ba_sst_metric_d_unload.set_upstream(task_start_dag)

task_mktg_campaign_domain_d_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['mktg_campaign_domain_d_unload', 'dw_report.mktg_campaign_domain_d',
                 'dwnl_stage.mktg_campaign_domain_s'],
    task_id='mktg_campaign_domain_d_unload',
    pool='redshift_etl',
    dag=dag)
task_mktg_campaign_domain_d_unload.set_upstream(task_start_dag)

task_mktg_sem_lbl_trck_f_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['mktg_sem_lbl_trck_f_unload', 'dw_report.mktg_sem_lbl_trck_f_new', 'dwnl_stage.mktg_sem_lbl_trck_s'],
    task_id='mktg_sem_lbl_trck_f_unload',
    pool='redshift_etl',
    dag=dag)
task_mktg_sem_lbl_trck_f_unload.set_upstream(task_start_dag)

task_dw_page_view_event_trkng_param_key_d_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['dw_page_view_event_trkng_param_key_d_unload', 'dw_report.dw_page_view_event_trkng_param_key_d',
                 'dwnl_stage.dw_page_view_event_trkng_param_key_s'],
    task_id='dw_page_view_event_trkng_param_key_d_unload',
    pool='redshift_etl',
    dag=dag)
task_dw_page_view_event_trkng_param_key_d_unload.set_upstream(task_dw_page_view_event_trkng_param_f_load)

task_mktg_consolidated_campaign_perf_f_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['mktg_consolidated_campaign_perf_f_unload', 'dw_report.mktg_consolidated_campaign_perf_f',
                 'dwnl_stage.mktg_consolidated_campaign_perf_s',
                 '--redshift-table-filter', '"dw_eff_dt >= CURRENT_DATE - INTERVAL \'30 DAY\'"'],
    task_id='mktg_consolidated_campaign_perf_f_unload',
    pool='redshift_etl',
    dag=dag)
task_mktg_consolidated_campaign_perf_f_unload.set_upstream(task_mktg_consolidated_campaign_perf_f_load)

task_mktg_tch_event_f_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['mktg_tch_event_f_unload', 'dw_report.mktg_tch_event_f', 'dwnl_stage.mktg_tch_event_s',
                 '--redshift-table-filter', '"dw_eff_dt >= CURRENT_DATE - INTERVAL \'7 DAY\'"'],
    task_id='mktg_tch_event_f_unload',
    pool='redshift_etl',
    dag=dag)
task_mktg_tch_event_f_unload.set_upstream(task_mktg_tch_event_f_load)

task_mktg_tch_ad_d_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['mktg_tch_ad_d_unload', 'dw_report.mktg_tch_ad_d', 'dwnl_stage.mktg_tch_ad_s',
                 '--redshift-table-filter', '"dw_eff_dt >= CURRENT_DATE - INTERVAL \'60 DAY\'"'],
    task_id='mktg_tch_ad_d_unload',
    pool='redshift_etl',
    dag=dag)
task_mktg_tch_ad_d_unload.set_upstream(task_mktg_tch_ad_d_load)

task_dw_page_view_event_trkng_param_f_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['dw_page_view_event_trkng_param_f_unload', 'dw_report.dw_page_view_event_trkng_param_f',
                 'dwnl_stage.dw_page_view_event_trkng_param_s',
                 '--redshift-table-filter', '"dw_eff_dt >= CURRENT_DATE - INTERVAL \'4 DAY\'"'],
    task_id='dw_page_view_event_trkng_param_f_unload',
    pool='redshift_etl',
    dag=dag)
task_dw_page_view_event_trkng_param_f_unload.set_upstream(task_dw_page_view_event_trkng_param_f_load)

task_ba_mktg_sst_additive_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['ba_mktg_sst_additive_unload', 'dw_ba_report.ba_mktg_sst_additive',
                 'dwnl_stage.ba_mktg_sst_additive_s',
                 '--redshift-table-filter', '"dw_eff_dt >= CURRENT_DATE - INTERVAL \'90 DAY\'"'],
    task_id='ba_mktg_sst_additive_unload',
    pool='redshift_etl',
    dag=dag)
task_ba_mktg_sst_additive_unload.set_upstream(task_ba_mktg_sst_product_redshift)

task_mktg_product_summary_sst_w_redshift_unload = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_to_nerdlake_parquet.sh',
    script_args=['mktg_product_summary_sst_w_unload', 'dw_stage.mktg_product_summary_sst_w', 'dwnl_rcd_aflt_tran_stage.mktg_product_summary_sst_w'],
    task_id='mktg_product_summary_sst_w_unload',
    pool='redshift_etl',
    dag=dag)
task_dw_url_d_redshift_unload.set_upstream(task_mktg_product_summary_sst_w)

################################################################################
# Convert Redshift unloaded data into NerdLake format
################################################################################
task_dw_page_d_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_d_nerdlake/shellscripts/dw_page_d_nerdlake.sh',
    script_args=[],
    task_id='dw_page_d_nerdlake',
    pool='presto_etl',
    dag=dag)
task_dw_page_d_nerdlake.set_upstream(task_dw_page_d_unload)

task_dwh_page_detail_d_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_detail_d_nerdlake/shellscripts/dw_page_detail_d_nerdlake.sh',
    script_args=[],
    task_id='dw_page_detail_d',
    pool='presto_etl',
    dag=dag)
task_dwh_page_detail_d_nerdlake.set_upstream(task_dw_page_detail_d_unload)
task_dwh_page_detail_d_nerdlake.set_upstream(task_dw_page_d_nerdlake)

task_dw_url_d_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_url_d_nerdlake/shellscripts/dw_url_d_nerdlake.sh',
    script_args=[],
    task_id='dw_url_d_nerdlake',
    pool='presto_etl',
    dag=dag)
task_dw_url_d_nerdlake.set_upstream(task_dw_url_d_redshift_unload)
task_dw_url_d_nerdlake.set_upstream(task_dw_page_d_nerdlake)

task_mktg_consolidated_campaign_perf_f_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_consolidated_campaign_perf_f_nerdlake/shellscripts/mktg_consolidated_campaign_perf_f.sh',
    script_args=[],
    task_id='mktg_consolidated_campaign_perf_f_nerdlake',
    pool='presto_etl',
    dag=dag)
task_mktg_consolidated_campaign_perf_f_nerdlake.set_upstream(task_mktg_consolidated_campaign_perf_f_unload)

task_mktg_tch_event_f_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_tch_event_f_nerdlake/shellscripts/mktg_tch_event_f.sh',
    script_args=[],
    task_id='mktg_tch_event_f_nerdlake',
    pool='presto_etl',
    dag=dag)
task_mktg_tch_event_f_nerdlake.set_upstream(task_mktg_tch_event_f_unload)

task_mktg_tch_ad_d_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_tch_ad_d_nerdlake/shellscripts/mktg_tch_ad_d.sh',
    script_args=[],
    task_id='mktg_tch_event_d_nerdlake',
    pool='presto_etl',
    dag=dag)
task_mktg_tch_ad_d_nerdlake.set_upstream(task_mktg_tch_ad_d_unload)

task_dw_page_view_event_trkng_param_f_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_view_event_trkng_param_f_nerdlake/shellscripts/dw_page_view_event_trkng_param_f.sh',
    script_args=[],
    task_id='dw_page_view_event_trkng_param_f_nerdlake',
    pool='presto_etl',
    dag=dag)
task_dw_page_view_event_trkng_param_f_nerdlake.set_upstream(task_dw_page_view_event_trkng_param_f_unload)

task_ba_mktg_sst_additive_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/ba_mktg_sst_additive_nerdlake/shellscripts/ba_mktg_sst_additive.sh',
    script_args=[],
    task_id='ba_mktg_sst_additive_nerdlake',
    pool='presto_etl',
    dag=dag)
task_ba_mktg_sst_additive_nerdlake.set_upstream(task_ba_mktg_sst_additive_unload)

################################################################################
# Legacy command tasks using Presto's Redshift connector
################################################################################
task3_dw_yd_acct_bal_f_nerdlake_temp = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_yd_acct_bal_f_nerdlake_temp/shellscripts/dw_yd_acct_bal_f_nerdlake.sh',
    script_args=[],
    task_id='dw_yd_acct_bal_f_nerdlake_temp',
    dag=dag)
task3_dw_yd_acct_bal_f_nerdlake_temp.set_upstream(Task_dwh_yd_acct_bal_f_load)

task4_dw_yd_acct_d_nerdlake_temp = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_yd_acct_d_nerdlake_temp/shellscripts/dw_yd_acct_d_nerdlake.sh',
    script_args=[],
    task_id='dw_yd_acct_d_nerdlake_temp',
    dag=dag)
task4_dw_yd_acct_d_nerdlake_temp.set_upstream(Task_dwh_yd_acct_d_load)

# task5_dw_yd_tran_f_nerdlake_temp = NWBashScriptOperator(
#     bash_script='/data/etl/Scripts/dw_yd_tran_f_nerdlake_temp/shellscripts/dw_yd_tran_f_nerdlake.sh',
#     script_args=[],
#     task_id='dw_yd_tran_f_nerdlake_temp',
#     dag=dag)
# task5_dw_yd_tran_f_nerdlake_temp.set_upstream(Task_dwh_yd_tran_f_load)

task6_dw_identity_tu_credit_rprt_profile_d_nerdlake_temp = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_identity_tu_credit_rprt_profile_d_nerdlake_temp/shellscripts/dw_identity_tu_credit_rprt_profile_d_nerdlake.sh',
    script_args=[],
    task_id='dw_identity_tu_credit_rprt_profile_d_nerdlake_temp',
    dag=dag)
task6_dw_identity_tu_credit_rprt_profile_d_nerdlake_temp.set_upstream(Task_dwh_identity_tu_credit_rprt_profile_d_load)

task7_dw_user_d_temp_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_user_d_temp_nerdlake/shellscripts/dw_user_d_nerdlake.sh',
    script_args=[],
    task_id='dw_user_d_temp_nerdlake',
    dag=dag)
task7_dw_user_d_temp_nerdlake.set_upstream(Task_identity_status_load)

task8_dw_user_actvy_smry_f_temp_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_user_actvy_smry_f_temp_nerdlake/shellscripts/dw_user_actvy_smry_f_nerdlake.sh',
    script_args=[],
    task_id='dw_user_actvy_smry_f_temp_nerdlake',
    dag=dag)
task8_dw_user_actvy_smry_f_temp_nerdlake.set_upstream(Task_identity_status_load)

task_dw_aflt_tran_user_visitor_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_user_visitor_d_nerdlake/shellscripts/dw_aflt_tran_user_visitor_d.sh',
    script_args=[],
    task_id='dw_aflt_tran_user_visitor_d_nerdlake',
    dag=dag)
task_dw_aflt_tran_user_visitor_d.set_upstream(task_dwh_site_visitor_d_load)
task_dw_aflt_tran_user_visitor_d.set_upstream(task_dwh_dw_aflt_tran_consolidated_f_load)

task_mktg_vendor_chnl_domain_xref = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_vendor_chnl_domain_xref_nerdlake/shellscripts/mktg_vendor_chnl_domain_xref.sh',
    script_args=[],
    task_id='mktg_vendor_chnl_domain_xref_nerdlake',
    dag=dag)
task_mktg_vendor_chnl_domain_xref.set_upstream(task_start_redshift_connector_tasks)

task_minusworld_clicks_event_w = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/minusworld_clicks_event_w/shellscripts/minusworld_clicks_event_w.sh',
    script_args=[],
    task_id='minusworld_clicks_event_w',
    dag=dag)
task_minusworld_clicks_event_w.set_upstream(task_MinusWorldEvent)

task_minusworld_clicks_event_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/minusworld_clicks_event_s/shellscripts/minusworld_clicks_event_s.sh',
    script_args=[],
    task_id='minusworld_clicks_event_s',
    pool='redshift_etl',
    dag=dag)
task_minusworld_clicks_event_s.set_upstream(task_minusworld_clicks_event_w)
