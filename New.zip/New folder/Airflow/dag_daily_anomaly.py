import sys
from datetime import *
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_anomaly"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime.now(),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 0,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@daily')

task_start_job = TimeSensor(
    target_time=time(14,15),
    task_id='Initiating_start_time',
    dag=dag)

Task_baidag_sst_aggregates_dependency = ExternalTaskSensor(
    task_id='waiting_for_baidag_sst_aggregates',
    external_dag_id='baidag_sst_aggregates',
    external_task_id='aggs_done',
    dag=dag)

Task_baidag_cc_umcpv_dependency = ExternalTaskSensor(
    task_id='waiting_for_cc_umcpv',
    external_dag_id='baidag_cc_umcpv_anomaly',
    external_task_id='cc_umcpv_anomaly_calc.sql',
    dag=dag)

task_anomaly_daily_script="/data/etl/Scripts/dw_anomaly_f/shellscripts/dw_anomaly_f.sh"
task_anomaly_daily = NWBashScriptOperator(
    bash_script=task_anomaly_daily_script,
    script_args=[],
    task_id='anomaly',
    dag=dag)

task_anomaly_daily.set_upstream(task_start_job)
task_anomaly_daily.set_upstream(Task_baidag_sst_aggregates_dependency)
task_anomaly_daily.set_upstream(Task_baidag_cc_umcpv_dependency)
