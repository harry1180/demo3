from datetime import datetime, timedelta, time

from airflow import DAG
from airflow.operators import NWBashScriptOperator, DummyOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_pud_identity'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 5, 24),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

# For all tables extracted from identities db please add dependency on identities stage table extract. This is to
# guarantee that all related tables will have data for the identities that were extracted. If identities is extracted
# last, it's possible that we would have an entry in the identities table which didn't have any related records in
# the other tables. See comments in:
#     https://github.com/NerdWallet/dwh/pull/2298/commits/456db8dd09ed016e54cdd33f1fb3e400f0270532

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_job = TimeSensor(
    target_time=time(1, 0),
    task_id='Initiating_start_time',
    dag=dag)
    
task_identity_start_job = TimeSensor(
    target_time=time(0, 5),
    task_id='Initiating_identity_start_time',
    dag=dag)    

################################################################################
# External Task Sensors
################################################################################
task_wait_for_kadu = ExternalTaskSensor(
    task_id='dag_kadu_event_consumption_prod.kadu_done_success',
    external_dag_id='dag_kadu_event_consumption_prod',
    external_task_id='kadu_done_success',
    execution_delta=timedelta(hours=-23),
    poke_interval=5,
    dag=dag)

Task_Registration_Tracking_Profile_dependency = ExternalTaskSensor(
    task_id='waiting_for_Registration_Tracking_Profile_Load',
    external_dag_id='dag_daily_identity',
    external_task_id='dw_identity_rgstn_trkng_profile_d',
    dag=dag)    

Task_dw_page_view_event_src_map_dw_page_view_dependency = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_page_view_event_src_map_dw_page_view',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_page_view_event_src_map_dw_page_view',
    dag=dag)

################################################################################
# Deserialization tasks for this DAG
################################################################################
event_names = {
    'ActivateCreditProfileEvent',
    'ActivationEvent',
    'DeactivateCreditProfileEvent',
    'DeactivateIdentityEvent',
    'DeactivationEvent',
    'LoginIdentityEvent',
    'LogoutIdentityEvent',
    'PasswordResetIdentityEvent',
    'ProviderAccountStateChangeEvent',
    'RegisterIdentityEvent',
    }
deser_tasks = dict()
for event_name in sorted(event_names, key=lambda s: s.lower()):
    task_deser = NWBashScriptOperator(
        bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
        script_args=[event_name],
        task_id=event_name,
        dag=dag)
    task_deser.set_upstream(task_wait_for_kadu)
    deser_tasks[event_name] = task_deser

## Internal Tasks Begin
task_idb_addresses_s_script="/data/etl/Scripts/idb_addresses_s/shellscripts/idb_addresses_s.sh"
task_idb_addresses_s = NWBashScriptOperator(
    bash_script=task_idb_addresses_s_script,
    script_args=[],
    task_id='idb_addresses_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_financial_profile_s_script="/data/etl/Scripts/idb_financial_profile_s/shellscripts/idb_financial_profile_s.sh"
task_idb_financial_profile_s = NWBashScriptOperator(
    bash_script=task_idb_financial_profile_s_script,
    script_args=[],
    task_id='idb_financial_profile_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_global_profile_s_script="/data/etl/Scripts/idb_global_profile_s/shellscripts/idb_global_profile_s.sh"
task_idb_global_profile_s = NWBashScriptOperator(
    bash_script=task_idb_global_profile_s_script,
    script_args=[],
    task_id='idb_global_profile_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_subscription_profile_s_script="/data/etl/Scripts/idb_subscription_profile_s/shellscripts/idb_subscription_profile_s.sh"
task_idb_subscription_profile_s = NWBashScriptOperator(
    bash_script=task_idb_subscription_profile_s_script,
    script_args=[],
    task_id='idb_subscription_profile_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)
    
task_dw_identity_glb_profile_d_script="/data/etl/Scripts/dw_identity_glb_profile_d/shellscripts/dw_identity_glb_profile_d.sh"
task_dw_identity_glb_profile_d = NWBashScriptOperator(
    bash_script=task_dw_identity_glb_profile_d_script,
    script_args=[],
    task_id='dw_identity_glb_profile_d',
    pool='redshift_etl',
    dag=dag)
    
task_tu_credit_report_profile_s_script="/data/etl/Scripts/tu_credit_report_profile_s/shellscripts/tu_credit_report_profile_s.sh"
task_tu_credit_report_profile_s = NWBashScriptOperator(
    bash_script=task_tu_credit_report_profile_s_script,
    script_args=[],
    task_id='tu_credit_report_profile_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_identity_tu_credit_rprt_profile_d_script="/data/etl/Scripts/dw_identity_tu_credit_rprt_profile_d/shellscripts/dw_identity_tu_credit_rprt_profile_d.sh"
task_dw_identity_tu_credit_rprt_profile_d = NWBashScriptOperator(
    bash_script=task_dw_identity_tu_credit_rprt_profile_d_script,
    script_args=[],
    task_id='dw_identity_tu_credit_rprt_profile_d',
    pool='redshift_etl',
    dag=dag)     
   
task_tu_authentication_status_profile_s_script="/data/etl/Scripts/tu_authentication_status_profile_s/shellscripts/tu_authentication_status_profile_s.sh"
task_tu_authentication_status_profile_s = NWBashScriptOperator(
    bash_script=task_tu_authentication_status_profile_s_script,
    script_args=[],
    task_id='tu_authentication_status_profile_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_identity_tu_auth_status_profile_d_script="/data/etl/Scripts/dw_identity_tu_auth_status_profile_d/shellscripts/dw_identity_tu_auth_status_profile_d.sh"
task_dw_identity_tu_auth_status_profile_d = NWBashScriptOperator(
    bash_script=task_dw_identity_tu_auth_status_profile_d_script,
    script_args=[],
    task_id='dw_identity_tu_auth_status_profile_d',
    pool='redshift_etl',
    dag=dag)       
 
 
task_dw_identity_addr_d_script="/data/etl/Scripts/dw_identity_addr_d/shellscripts/dw_identity_addr_d.sh"
task_dw_identity_addr_d = NWBashScriptOperator(
    bash_script=task_dw_identity_addr_d_script,
    script_args=[],
    task_id='dw_identity_addr_d',
    pool='redshift_etl',
    dag=dag)     
    
task_dit_user_profiles_s_script="/data/etl/Scripts/dit_user_profiles_s/shellscripts/dit_user_profiles_s.sh"
task_dit_user_profiles_s = NWBashScriptOperator(
    bash_script=task_dit_user_profiles_s_script,
    script_args=[],
    task_id='dit_user_profiles_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_dit_user_profile_d_script="/data/etl/Scripts/dw_dit_user_profile_d/shellscripts/dw_dit_user_profile_d.sh"
task_dw_dit_user_profile_d = NWBashScriptOperator(
    bash_script=task_dw_dit_user_profile_d_script,
    script_args=[],
    task_id='dw_dit_user_profile_d',
    pool='redshift_etl',
    dag=dag)  
    
   

task_pud_dag_status_update_script="/data/etl/Common/redshift_sql_function.sh"
task_pud_dag_status_update = NWBashScriptOperator(
    bash_script=task_pud_dag_status_update_script,
    script_args=["/data/etl/Airflow/post_updates/dag_daily_pud_identity_status_update.sql"],
    task_id='status_update',
    dag=dag)
    
task_idb_identities_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_identities_s/shellscripts/idb_identities_s.sh',
    script_args=[],
    task_id='idb_identities_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_identity_email_profile_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/identity_email_profile_s/shellscripts/identity_email_profile_s.sh',
    script_args=[],
    task_id='identity_email_profile_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_identity_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_identity_d/shellscripts/dw_identity_d.sh',
    script_args=[],
    task_id='dw_identity_d',
    pool='redshift_etl',
    priority_weight=100,  # Used in dw_page_view_event_f
    dag=dag)

task_idb_provider_account_states_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_provider_account_states_s/shellscripts/idb_provider_account_states_s.sh',
    script_args=[],
    task_id='idb_provider_account_states_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_providers_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_providers_s/shellscripts/idb_providers_s.sh',
    script_args=[],
    task_id='idb_providers_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_authorization_profile_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_authorization_profile_s/shellscripts/idb_yodlee_authorization_profile_s.sh',
    script_args=[],
    task_id='idb_yodlee_authorization_profile_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_accounts_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_accounts_s/shellscripts/idb_yodlee_accounts_s.sh',
    script_args=[],
    task_id='idb_yodlee_accounts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_tag_rules_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_tag_rules_s/shellscripts/idb_yodlee_tag_rules_s.sh',
    script_args=[],
    task_id='idb_yodlee_tag_rules_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_bank_accounts_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_bank_accounts_s/shellscripts/idb_yodlee_bank_accounts_s.sh',
    script_args=[],
    task_id='idb_yodlee_bank_accounts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_bill_accounts_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_bill_accounts_s/shellscripts/idb_yodlee_bill_accounts_s.sh',
    script_args=[],
    task_id='idb_yodlee_bill_accounts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_investment_accounts_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_investment_accounts_s/shellscripts/idb_yodlee_investment_accounts_s.sh',
    script_args=[],
    task_id='idb_yodlee_investment_accounts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_credit_accounts_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_credit_accounts_s/shellscripts/idb_yodlee_credit_accounts_s.sh',
    script_args=[],
    task_id='idb_yodlee_credit_accounts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_loan_accounts_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_loan_accounts_s/shellscripts/idb_yodlee_loan_accounts_s.sh',
    script_args=[],
    task_id='idb_yodlee_loan_accounts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_investment_holdings_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_investment_holdings_s/shellscripts/idb_yodlee_investment_holdings_s.sh',
    script_args=[],
    task_id='idb_yodlee_investment_holdings_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_user_reported_financial_account_s_extract = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_user_reported_financial_account_s/shellscripts/idb_user_reported_financial_account_s_extract.sh',
    script_args=[],
    task_id='idb_user_reported_financial_account_s_extract',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)
task_idb_user_reported_financial_account_s_extract.set_upstream(task_idb_identities_s)

task_idb_user_reported_financial_account_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_user_reported_financial_account_s/shellscripts/idb_user_reported_financial_account_s.sh',
    task_id='idb_user_reported_financial_account_s',
    pool='redshift_etl',
    dag=dag)
task_idb_user_reported_financial_account_s.set_upstream(task_idb_user_reported_financial_account_s_extract)

task_dw_user_rptd_fncl_acct_f_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_user_rptd_fncl_acct_f/shellscripts/dw_user_rptd_fncl_acct_f.sh",
    script_args=[],
    task_id='dw_user_rptd_fncl_acct_f_load',
    pool='redshift_etl',
    dag=dag)
task_dw_user_rptd_fncl_acct_f_load.set_upstream(task_idb_user_reported_financial_account_s)

task_idb_mortgage_profiles_s_extract = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_mortgage_profiles_s/shellscripts/idb_mortgage_profiles_s_extract.sh',
    script_args=[],
    task_id='idb_mortgage_profiles_s_extract',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)
task_idb_mortgage_profiles_s_extract.set_upstream(task_idb_identities_s)

task_idb_mortgage_profiles_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_mortgage_profiles_s/shellscripts/idb_mortgage_profiles_s.sh',
    task_id='idb_mortgage_profiles_s',
    pool='redshift_etl',
    dag=dag)
task_idb_mortgage_profiles_s.set_upstream(task_idb_mortgage_profiles_s_extract)

task_dw_mrtg_prfl_d_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_mrtg_prfl_d/shellscripts/dw_mrtg_prfl_d.sh",
    script_args=[],
    task_id='dw_mrtg_prfl_d_load',
    pool='redshift_etl',
    dag=dag)
task_dw_mrtg_prfl_d_load.set_upstream(task_idb_mortgage_profiles_s)

task_idb_yodlee_account_history_profile_s_extract = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_account_history_profile_s/shellscripts/idb_yodlee_account_history_profile_s_extract.sh',
    script_args=[],
    task_id='idb_yodlee_account_history_profile_s_extract',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)
task_idb_yodlee_account_history_profile_s_extract.set_upstream(task_idb_identities_s)

task_idb_yodlee_account_history_profile_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_account_history_profile_s/shellscripts/idb_yodlee_account_history_profile_s.sh',
    task_id='idb_yodlee_account_history_profile_s',
    pool='redshift_etl',
    dag=dag)
task_idb_yodlee_account_history_profile_s.set_upstream(task_idb_yodlee_account_history_profile_s_extract)

task_idb_yodlee_transactions_s_extract = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_transactions_s/shellscripts/idb_yodlee_transactions_s_extract.sh',
    script_args=[],
    task_id='idb_yodlee_transactions_s_extract',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)
task_idb_yodlee_transactions_s_extract.set_upstream(task_idb_identities_s)

task_idb_yodlee_transactions_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_yodlee_transactions_s/shellscripts/idb_yodlee_transactions_s.sh',
    task_id='idb_yodlee_transactions_s',
    pool='redshift_etl',
    dag=dag)
task_idb_yodlee_transactions_s.set_upstream(task_idb_yodlee_transactions_s_extract)

task_idb_feed_items_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_feed_items_s/shellscripts/idb_feed_items_s.sh',
    script_args=[],
    task_id='idb_feed_items_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_feed_recommendations_s_script="/data/etl/Scripts/idb_feed_recommendations_s/shellscripts/idb_feed_recommendations_s.sh"
task_idb_feed_recommendations_s = NWBashScriptOperator(
    bash_script=task_idb_feed_recommendations_s_script,
    script_args=[],
    task_id='idb_feed_recommendations_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_tu_alerts_s_script="/data/etl/Scripts/idb_tu_alerts_s/shellscripts/idb_tu_alerts_s.sh"
task_idb_tu_alerts_s = NWBashScriptOperator(
    bash_script=task_idb_tu_alerts_s_script,
    script_args=[],
    task_id='idb_tu_alerts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_tu_account_alerts_s_script="/data/etl/Scripts/idb_tu_account_alerts_s/shellscripts/idb_tu_account_alerts_s.sh"
task_idb_tu_account_alerts_s = NWBashScriptOperator(
    bash_script=task_idb_tu_account_alerts_s_script,
    script_args=[],
    task_id='idb_tu_account_alerts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_tu_fraud_alerts_s_script="/data/etl/Scripts/idb_tu_fraud_alerts_s/shellscripts/idb_tu_fraud_alerts_s.sh"
task_idb_tu_fraud_alerts_s = NWBashScriptOperator(
    bash_script=task_idb_tu_fraud_alerts_s_script,
    script_args=[],
    task_id='idb_tu_fraud_alerts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_tu_new_address_alerts_s_script="/data/etl/Scripts/idb_tu_new_address_alerts_s/shellscripts/idb_tu_new_address_alerts_s.sh"
task_idb_tu_new_address_alerts_s = NWBashScriptOperator(
    bash_script=task_idb_tu_new_address_alerts_s_script,
    script_args=[],
    task_id='idb_tu_new_address_alerts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_tu_new_bankruptcy_alerts_s_script="/data/etl/Scripts/idb_tu_new_bankruptcy_alerts_s/shellscripts/idb_tu_new_bankruptcy_alerts_s.sh"
task_idb_tu_new_bankruptcy_alerts_s = NWBashScriptOperator(
    bash_script=task_idb_tu_new_bankruptcy_alerts_s_script,
    script_args=[],
    task_id='idb_tu_new_bankruptcy_alerts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_tu_new_employment_alerts_s_script="/data/etl/Scripts/idb_tu_new_employment_alerts_s/shellscripts/idb_tu_new_employment_alerts_s.sh"
task_idb_tu_new_employment_alerts_s = NWBashScriptOperator(
    bash_script=task_idb_tu_new_employment_alerts_s_script,
    script_args=[],
    task_id='idb_tu_new_employment_alerts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_tu_new_inquiry_alerts_s_script="/data/etl/Scripts/idb_tu_new_inquiry_alerts_s/shellscripts/idb_tu_new_inquiry_alerts_s.sh"
task_idb_tu_new_inquiry_alerts_s = NWBashScriptOperator(
    bash_script=task_idb_tu_new_inquiry_alerts_s_script,
    script_args=[],
    task_id='idb_tu_new_inquiry_alerts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_tu_new_public_record_alerts_s_script="/data/etl/Scripts/idb_tu_new_public_record_alerts_s/shellscripts/idb_tu_new_public_record_alerts_s.sh"
task_idb_tu_new_public_record_alerts_s = NWBashScriptOperator(
    bash_script=task_idb_tu_new_public_record_alerts_s_script,
    script_args=[],
    task_id='idb_tu_new_public_record_alerts_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_bshrk_users_s_script="/data/etl/Scripts/bshrk_users_s/shellscripts/bshrk_users_s.sh"
task_bshrk_users_s = NWBashScriptOperator(
    bash_script=task_bshrk_users_s_script,
    script_args=[],
    task_id='bshrk_users_s',
    pool='redshift_etl',
    dag=dag)

task_bshrk_billers_s_script="/data/etl/Scripts/bshrk_billers_s/shellscripts/bshrk_billers_s.sh"
task_bshrk_billers_s = NWBashScriptOperator(
    bash_script=task_bshrk_billers_s_script,
    script_args=[],
    task_id='bshrk_billers_s',
    dag=dag)

task_bshrk_bills_s_script="/data/etl/Scripts/bshrk_bills_s/shellscripts/bshrk_bills_s.sh"
task_bshrk_bills_s = NWBashScriptOperator(
    bash_script=task_bshrk_bills_s_script,
    script_args=[],
    task_id='bshrk_bills_s',
    dag=dag)

task_bshrk_savings_records_s_script="/data/etl/Scripts/bshrk_savings_records_s/shellscripts/bshrk_savings_records_s.sh"
task_bshrk_savings_records_s = NWBashScriptOperator(
    bash_script=task_bshrk_savings_records_s_script,
    script_args=[],
    task_id='bshrk_savings_records_s',
    dag=dag)


task_dw_bshrk_user_d_script="/data/etl/Scripts/dw_bshrk_user_d/shellscripts/dw_bshrk_user_d.sh"
task_dw_bshrk_user_d = NWBashScriptOperator(
    bash_script=task_dw_bshrk_user_d_script,
    script_args=[],
    task_id='dw_bshrk_user_d',
    pool='redshift_etl',
    dag=dag)

task_dw_bshrk_biller_d_script="/data/etl/Scripts/dw_bshrk_biller_d/shellscripts/dw_bshrk_biller_d.sh"
task_dw_bshrk_biller_d = NWBashScriptOperator(
    bash_script=task_dw_bshrk_biller_d_script,
    script_args=[],
    task_id='dw_bshrk_biller_d',
    pool='redshift_etl',
    dag=dag)

task_dw_bshrk_bill_f_script="/data/etl/Scripts/dw_bshrk_bill_f/shellscripts/dw_bshrk_bill_f.sh"
task_dw_bshrk_bill_f = NWBashScriptOperator(
    bash_script=task_dw_bshrk_bill_f_script,
    script_args=[],
    task_id='dw_bshrk_bill_f',
    pool='redshift_etl',
    dag=dag)

task_dw_bshrk_svng_rec_f_script="/data/etl/Scripts/dw_bshrk_svng_rec_f/shellscripts/dw_bshrk_svng_rec_f.sh"
task_dw_bshrk_svng_rec_f = NWBashScriptOperator(
    bash_script=task_dw_bshrk_svng_rec_f_script,
    script_args=[],
    task_id='dw_bshrk_svng_rec_f',
    pool='redshift_etl',
    dag=dag)

task_dw_feed_item_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_feed_item_d/shellscripts/dw_feed_item_d.sh',
    script_args=[],
    task_id='dw_feed_item_d',
    pool='redshift_etl',
    dag=dag)

task_dw_feed_rcmnd_auth_f_script="/data/etl/Scripts/dw_feed_rcmnd_auth_f/shellscripts/dw_feed_rcmnd_auth_f.sh"
task_dw_feed_rcmnd_auth_f = NWBashScriptOperator(
    bash_script=task_dw_feed_rcmnd_auth_f_script,
    script_args=[],
    task_id='dw_feed_rcmnd_auth_f',
    pool='redshift_etl',
    dag=dag)

task_dw_feed_rcmnd_prod_xref_f_script="/data/etl/Scripts/dw_feed_rcmnd_prod_xref_f/shellscripts/dw_feed_rcmnd_prod_xref_f.sh"
task_dw_feed_rcmnd_prod_xref_f = NWBashScriptOperator(
    bash_script=task_dw_feed_rcmnd_prod_xref_f_script,
    script_args=[],
    task_id='dw_feed_rcmnd_prod_xref_f',
    pool='redshift_etl',
    dag=dag)

task_dw_feed_rcmnd_item_f_script="/data/etl/Scripts/dw_feed_rcmnd_item_f/shellscripts/dw_feed_rcmnd_item_f.sh"
task_dw_feed_rcmnd_item_f = NWBashScriptOperator(
    bash_script=task_dw_feed_rcmnd_item_f_script,
    script_args=[],
    task_id='dw_feed_rcmnd_item_f',
    pool='redshift_etl',
    dag=dag)

task_dw_tu_alert_d_script="/data/etl/Scripts/dw_tu_alert_d/shellscripts/dw_tu_alert_d.sh"
task_tu_alert_d = NWBashScriptOperator(
    bash_script=task_dw_tu_alert_d_script,
    script_args=[],
    task_id='dw_tu_alert_d',
    pool='redshift_etl',
    dag=dag)

task_idb_merchants_s_script="/data/etl/Scripts/idb_merchants_s/shellscripts/idb_merchants_s.sh"
task_idb_merchants_s = NWBashScriptOperator(
    bash_script=task_idb_merchants_s_script,
    script_args=[],
    task_id='idb_merchants_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_merchant_rules_s_script="/data/etl/Scripts/idb_merchant_rules_s/shellscripts/idb_merchant_rules_s.sh"
task_idb_merchant_rules_s = NWBashScriptOperator(
    bash_script=task_idb_merchant_rules_s_script,
    script_args=[],
    task_id='idb_merchant_rules_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_yd_auth_prfl_f_script="/data/etl/Scripts/dw_yd_auth_prfl_f/shellscripts/dw_yd_auth_prfl_f.sh"
task_dw_yd_auth_prfl_f = NWBashScriptOperator(
    bash_script=task_dw_yd_auth_prfl_f_script,
    script_args=[],
    task_id='dw_yd_auth_prfl_f',
    pool='redshift_etl',
    dag=dag)



task_dw_yd_prvdr_d_script="/data/etl/Scripts/dw_yd_prvdr_d/shellscripts/dw_yd_prvdr_d.sh"
task_dw_yd_prvdr_d = NWBashScriptOperator(
    bash_script=task_dw_yd_prvdr_d_script,
    script_args=[],
    task_id='dw_yd_prvdr_d',
    pool='redshift_etl',
    dag=dag)


task_dw_yd_prvdr_acct_d_script="/data/etl/Scripts/dw_yd_prvdr_acct_d/shellscripts/dw_yd_prvdr_acct_d.sh"
task_dw_yd_prvdr_acct_d = NWBashScriptOperator(
    bash_script=task_dw_yd_prvdr_acct_d_script,
    script_args=[],
    task_id='dw_yd_prvdr_acct_d',
    pool='redshift_etl',
    dag=dag)

task_dw_yd_acct_d_script="/data/etl/Scripts/dw_yd_acct_d/shellscripts/dw_yd_acct_d.sh"
task_dw_yd_acct_d = NWBashScriptOperator(
    bash_script=task_dw_yd_acct_d_script,
    script_args=[],
    task_id='dw_yd_acct_d',
    pool='redshift_etl',
    dag=dag)



task_dw_yd_inv_hold_f_script="/data/etl/Scripts/dw_yd_inv_hold_f/shellscripts/dw_yd_inv_hold_f.sh"
task_dw_yd_inv_hold_f = NWBashScriptOperator(
    bash_script=task_dw_yd_inv_hold_f_script,
    script_args=[],
    task_id='dw_yd_inv_hold_f',
    pool='redshift_etl',
    dag=dag)

task_dw_yd_acct_hist_prof_xref_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_yd_acct_hist_prof_xref_d/shellscripts/dw_yd_acct_hist_prof_xref_d.sh',
    script_args=[],
    task_id='dw_yd_acct_hist_prof_xref_d',
    pool='redshift_etl',
    dag=dag)

task_dw_yd_tran_f_script="/data/etl/Scripts/dw_yd_tran_f/shellscripts/dw_yd_tran_f.sh"
task_dw_yd_tran_f = NWBashScriptOperator(
    bash_script=task_dw_yd_tran_f_script,
    script_args=[],
    task_id='dw_yd_tran_f',
    pool='redshift_etl',
    dag=dag)

task_dw_cncl_mrchnt_d_script="/data/etl/Scripts/dw_cncl_mrchnt_d/shellscripts/dw_cncl_mrchnt_d.sh"
task_dw_cncl_mrchnt_d = NWBashScriptOperator(
    bash_script=task_dw_cncl_mrchnt_d_script,
    script_args=[],
    task_id='dw_cncl_mrchnt_d',
    pool='redshift_etl',
    dag=dag)

task_dw_mrchnt_rule_f_script="/data/etl/Scripts/dw_mrchnt_rule_f/shellscripts/dw_mrchnt_rule_f.sh"
task_dw_mrchnt_rule_f = NWBashScriptOperator(
    bash_script=task_dw_mrchnt_rule_f_script,
    script_args=[],
    task_id='dw_mrchnt_rule_f',
    pool='redshift_etl',
    dag=dag)

task_dw_yd_acct_bal_f_script="/data/etl/Scripts/dw_yd_acct_bal_f/shellscripts/dw_yd_acct_bal_f.sh"
task_dw_yd_acct_bal_f = NWBashScriptOperator(
    bash_script=task_dw_yd_acct_bal_f_script,
    script_args=[],
    task_id='dw_yd_acct_bal_f',
    pool='redshift_etl',
    dag=dag)

task_idb_yodlee_investment_options_s_script="/data/etl/Scripts/idb_yodlee_investment_options_s/shellscripts/idb_yodlee_investment_options_s.sh"
task_idb_yodlee_investment_options_s = NWBashScriptOperator(
    bash_script=task_idb_yodlee_investment_options_s_script,
    script_args=[],
    task_id='idb_yodlee_investment_options_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_yodlee_investment_plans_s_script="/data/etl/Scripts/idb_yodlee_investment_plans_s/shellscripts/idb_yodlee_investment_plans_s.sh"
task_idb_yodlee_investment_plans_s = NWBashScriptOperator(
    bash_script=task_idb_yodlee_investment_plans_s_script,
    script_args=[],
    task_id='idb_yodlee_investment_plans_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_nr_events_s_script="/data/etl/Scripts/nr_events_s/shellscripts/nr_events_s.sh"
task_nr_events_s = NWBashScriptOperator(
    bash_script=task_nr_events_s_script,
    script_args=[],
    task_id='nr_events_s',
    dag=dag)

task_nr_points_s_script="/data/etl/Scripts/nr_points_s/shellscripts/nr_points_s.sh"
task_nr_points_s = NWBashScriptOperator(
    bash_script=task_nr_points_s_script,
    script_args=[],
    task_id='nr_points_s',
    dag=dag)

task_nr_raffles_s_script="/data/etl/Scripts/nr_raffles_s/shellscripts/nr_raffles_s.sh"
task_nr_raffles_s = NWBashScriptOperator(
    bash_script=task_nr_raffles_s_script,
    script_args=[],
    task_id='nr_raffles_s',
    dag=dag)

task_nr_raffle_winners_s_script="/data/etl/Scripts/nr_raffle_winners_s/shellscripts/nr_raffle_winners_s.sh"
task_nr_raffle_winners_s = NWBashScriptOperator(
    bash_script=task_nr_raffle_winners_s_script,
    script_args=[],
    task_id='nr_raffle_winners_s',
    dag=dag)

task_nr_raffle_entries_s_script="/data/etl/Scripts/nr_raffle_entries_s/shellscripts/nr_raffle_entries_s.sh"
task_nr_raffle_entries_s = NWBashScriptOperator(
    bash_script=task_nr_raffle_entries_s_script,
    script_args=[],
    task_id='nr_raffle_entries_s',
    dag=dag)

task_nr_raffle_identities_s_script="/data/etl/Scripts/nr_raffle_identities_s/shellscripts/nr_raffle_identities_s.sh"
task_nr_raffle_identities_s = NWBashScriptOperator(
    bash_script=task_nr_raffle_identities_s_script,
    script_args=[],
    task_id='nr_raffle_identities_s',
    dag=dag)

task_nr_tos_acknowledgements_s_script="/data/etl/Scripts/nr_tos_acknowledgements_s/shellscripts/nr_tos_acknowledgements_s.sh"
task_nr_tos_acknowledgements_s = NWBashScriptOperator(
    bash_script=task_nr_tos_acknowledgements_s_script,
    script_args=[],
    task_id='nr_tos_acknowledgements_s',
    dag=dag)

task_dw_rwrd_event_d_script="/data/etl/Scripts/dw_rwrd_event_d/shellscripts/dw_rwrd_event_d.sh"
task_dw_rwrd_event_d = NWBashScriptOperator(
    bash_script=task_dw_rwrd_event_d_script,
    script_args=[],
    task_id='dw_rwrd_event_d',
    pool='redshift_etl',
    dag=dag)

task_dw_rwrd_point_f_script="/data/etl/Scripts/dw_rwrd_point_f/shellscripts/dw_rwrd_point_f.sh"
task_dw_rwrd_point_f = NWBashScriptOperator(
    bash_script=task_dw_rwrd_point_f_script,
    script_args=[],
    task_id='dw_rwrd_point_f',
    pool='redshift_etl',
    dag=dag)

task_dw_rwrd_raffle_d_script="/data/etl/Scripts/dw_rwrd_raffle_d/shellscripts/dw_rwrd_raffle_d.sh"
task_dw_rwrd_raffle_d = NWBashScriptOperator(
    bash_script=task_dw_rwrd_raffle_d_script,
    script_args=[],
    task_id='dw_rwrd_raffle_d',
    pool='redshift_etl',
    dag=dag)

task_dw_rwrd_raffle_user_d_script="/data/etl/Scripts/dw_rwrd_raffle_user_d/shellscripts/dw_rwrd_raffle_user_d.sh"
task_dw_rwrd_raffle_user_d = NWBashScriptOperator(
    bash_script=task_dw_rwrd_raffle_user_d_script,
    script_args=[],
    task_id='dw_rwrd_raffle_user_d',
    pool='redshift_etl',
    dag=dag)

task_dw_rwrd_raffle_entry_f_script="/data/etl/Scripts/dw_rwrd_raffle_entry_f/shellscripts/dw_rwrd_raffle_entry_f.sh"
task_dw_rwrd_raffle_entry_f = NWBashScriptOperator(
    bash_script=task_dw_rwrd_raffle_entry_f_script,
    script_args=[],
    task_id='dw_rwrd_raffle_entry_f',
    pool='redshift_etl',
    dag=dag)

task_dw_yd_inv_plan_d_script="/data/etl/Scripts/dw_yd_inv_plan_d/shellscripts/dw_yd_inv_plan_d.sh"
task_dw_yd_inv_plan_d = NWBashScriptOperator(
    bash_script=task_dw_yd_inv_plan_d_script,
    script_args=[],
    task_id='dw_yd_inv_plan_d',
    pool='redshift_etl',
    dag=dag)

task_dw_yd_inv_optn_d_script="/data/etl/Scripts/dw_yd_inv_optn_d/shellscripts/dw_yd_inv_optn_d.sh"
task_dw_yd_inv_optn_d = NWBashScriptOperator(
    bash_script=task_dw_yd_inv_optn_d_script,
    script_args=[],
    task_id='dw_yd_inv_optn_d',
    pool='redshift_etl',
    dag=dag)

task_idb_goals_s_script="/data/etl/Scripts/idb_goals_s/shellscripts/idb_goals_s.sh"
task_idb_goals_s = NWBashScriptOperator(
    bash_script=task_idb_goals_s_script,
    script_args=[],
    task_id='idb_goals_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_goals_savings_s_script="/data/etl/Scripts/idb_goals_savings_s/shellscripts/idb_goals_savings_s.sh"
task_idb_goals_savings_s = NWBashScriptOperator(
    bash_script=task_idb_goals_savings_s_script,
    script_args=[],
    task_id='idb_goals_savings_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_goals_profiles_s_script="/data/etl/Scripts/idb_goals_profiles_s/shellscripts/idb_goals_profiles_s.sh"
task_idb_goals_profiles_s = NWBashScriptOperator(
    bash_script=task_idb_goals_profiles_s_script,
    script_args=[],
    task_id='idb_goals_profiles_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_goals_debt_s_script="/data/etl/Scripts/idb_goals_debt_s/shellscripts/idb_goals_debt_s.sh"
task_idb_goals_debt_s = NWBashScriptOperator(
    bash_script=task_idb_goals_debt_s_script,
    script_args=[],
    task_id='idb_goals_debt_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_goals_retirement_s_script="/data/etl/Scripts/idb_goals_retirement_s/shellscripts/idb_goals_retirement_s.sh"
task_idb_goals_retirement_s = NWBashScriptOperator(
    bash_script=task_idb_goals_retirement_s_script,
    script_args=[],
    task_id='idb_goals_retirement_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_goals_credit_s_script="/data/etl/Scripts/idb_goals_credit_s/shellscripts/idb_goals_credit_s.sh"
task_idb_goals_credit_s = NWBashScriptOperator(
    bash_script=task_idb_goals_credit_s_script,
    script_args=[],
    task_id='idb_goals_credit_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_goal_d_script="/data/etl/Scripts/dw_goal_d/shellscripts/dw_goal_d.sh"
task_dw_goal_d = NWBashScriptOperator(
    bash_script=task_dw_goal_d_script,
    script_args=[],
    task_id='dw_goal_d',
    pool='redshift_etl',
    dag=dag)

task_dw_goal_acct_xref_f_script="/data/etl/Scripts/dw_goal_acct_xref_f/shellscripts/dw_goal_acct_xref_f.sh"
task_dw_goal_acct_xref_f = NWBashScriptOperator(
    bash_script=task_dw_goal_acct_xref_f_script,
    script_args=[],
    task_id='dw_goal_acct_xref_f',
    pool='redshift_etl',
    dag=dag)

#### Identity Events Begin -- 
task13_LoginIdentityEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/login_identity_event_s/shellscripts/login_identity_event_s.sh",
    script_args=[],
    task_id='LoginIdentityEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task13_LoginIdentityEvent_Stage_Load.set_upstream(deser_tasks['LoginIdentityEvent'])
    
task18_ActivationEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/activation_event_s/shellscripts/activation_event_s.sh",
    script_args=[],
    task_id='ActivationEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)    
task18_ActivationEvent_Stage_Load.set_upstream(deser_tasks['ActivationEvent'])
    
task19_DeactivationEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/deactivation_event_s/shellscripts/deactivation_event_s.sh",
    script_args=[],
    task_id='DeactivationEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)      
task19_DeactivationEvent_Stage_Load.set_upstream(deser_tasks['DeactivationEvent'])

task14_LogoutIdentityEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/logout_identity_event_s/shellscripts/logout_identity_event_s.sh",
    script_args=[],
    task_id='LogoutIdentityEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task14_LogoutIdentityEvent_Stage_Load.set_upstream(deser_tasks['LogoutIdentityEvent'])

task15_DeactivateIdentityEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/deactivate_identity_event_s/shellscripts/deactivate_identity_event_s.sh",
    script_args=[],
    task_id='DeactivateIdentityEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task15_DeactivateIdentityEvent_Stage_Load.set_upstream(deser_tasks['DeactivateIdentityEvent'])

task16_RegisterIdentityEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/register_identity_event_s/shellscripts/register_identity_event_s.sh",
    script_args=[],
    task_id='RegisterIdentityEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task16_RegisterIdentityEvent_Stage_Load.set_upstream(deser_tasks['RegisterIdentityEvent'])

task37_PasswordResetIdentityEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/password_reset_identity_event_s/shellscripts/password_reset_identity_event_s.sh",
    script_args=[],
    task_id='PasswordResetIdentityEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task37_PasswordResetIdentityEvent_Stage_Load.set_upstream(deser_tasks['PasswordResetIdentityEvent'])

task38_ActivateCreditProfileEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/activate_credit_profile_event_s/shellscripts/activate_credit_profile_event_s.sh",
    script_args=[],
    task_id='ActivateCreditProfileEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task38_ActivateCreditProfileEvent_Stage_Load.set_upstream(deser_tasks['ActivateCreditProfileEvent'])

task39_DeactivateCreditProfileEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/deactivate_credit_profile_event_s/shellscripts/deactivate_credit_profile_event_s.sh",
    script_args=[],
    task_id='DeactivateCreditProfileEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task39_DeactivateCreditProfileEvent_Stage_Load.set_upstream(deser_tasks['DeactivateCreditProfileEvent'])

task17_dw_identity_event_Fact_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_identity_event_f/shellscripts/dw_identity_event_f.sh",
    script_args=[],
    task_id='dw_identity_event_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task_idb_forecast_profiles_s_script = "/data/etl/Scripts/idb_forecast_profiles_s/shellscripts/idb_forecast_profiles_s.sh"
task_idb_forecast_profiles_s = NWBashScriptOperator(
    bash_script=task_idb_forecast_profiles_s_script,
    script_args=[],
    task_id='idb_forecast_profiles_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_idb_investing_profiles_s_script = "/data/etl/Scripts/idb_investing_profiles_s/shellscripts/idb_investing_profiles_s.sh"
task_idb_investing_profiles_s = NWBashScriptOperator(
    bash_script=task_idb_investing_profiles_s_script,
    script_args=[],
    task_id='idb_investing_profiles_s',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)

task_dw_identity_inv_profile_d_script = "/data/etl/Scripts/dw_identity_inv_profile_d/shellscripts/dw_identity_inv_profile_d.sh"
task_dw_identity_inv_profile_d = NWBashScriptOperator(
    bash_script=task_dw_identity_inv_profile_d_script,
    script_args=[],
    task_id='dw_identity_inv_profile_d',
    pool='redshift_etl',
    dag=dag)

task_prvdr_acct_state_change_event_s = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/prvdr_acct_state_change_event_s/shellscripts/prvdr_acct_state_change_event_s.sh",
    script_args=[],
    task_id='prvdr_acct_state_change_event_s',
    pool='redshift_etl',
    dag=dag)
task_prvdr_acct_state_change_event_s.set_upstream(deser_tasks['ProviderAccountStateChangeEvent'])

task_dw_yd_prvdr_acct_state_change_f = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_yd_prvdr_acct_state_change_f/shellscripts/dw_yd_prvdr_acct_state_change_f.sh",
    script_args=[],
    task_id='dw_yd_prvdr_acct_state_change_f',
    pool='redshift_etl',
    dag=dag)
task_dw_yd_prvdr_acct_state_change_f.set_upstream(task_prvdr_acct_state_change_event_s)

task_idb_public_records_s_extract = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_public_records_s/shellscripts/idb_public_records_s_extract.sh',
    script_args=[],
    task_id='idb_public_records_s_extract',
    pool='identity_replica_extract',
    retries=11,
    retry_delay=timedelta(minutes=5),
    dag=dag)
task_idb_public_records_s_extract.set_upstream(task_idb_identities_s)

task_idb_public_records_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/idb_public_records_s/shellscripts/idb_public_records_s.sh',
    task_id='idb_public_records_s',
    pool='redshift_etl',
    dag=dag)
task_idb_public_records_s.set_upstream(task_idb_public_records_s_extract)

task_dw_publ_rec_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_publ_rec_d/shellscripts/dw_publ_rec_d.sh',
    task_id='dw_publ_rec_d',
    pool='redshift_etl',
    dag=dag)
task_dw_publ_rec_d.set_upstream(task_idb_public_records_s)



#### Identity Events End 

## Internal Tasks End

## Internal Tasks Flow Begin

task_idb_identities_s.set_upstream(task_identity_start_job)
task_identity_email_profile_s.set_upstream(task_idb_identities_s)
task_dw_identity_d.set_upstream(task_identity_email_profile_s)
task_dw_identity_d.set_upstream(task_dw_identity_tu_auth_status_profile_d)

task_bshrk_users_s.set_upstream(task_identity_start_job)

task_bshrk_billers_s.set_upstream(task_bshrk_users_s)

task_bshrk_bills_s.set_upstream(task_bshrk_users_s)

task_bshrk_savings_records_s.set_upstream(task_bshrk_users_s)

task_dw_bshrk_user_d.set_upstream(task_bshrk_users_s)
task_dw_bshrk_biller_d.set_upstream(task_bshrk_billers_s)
task_dw_bshrk_bill_f.set_upstream(task_bshrk_bills_s)
task_dw_bshrk_svng_rec_f.set_upstream(task_bshrk_savings_records_s)
task_dw_bshrk_svng_rec_f.set_upstream(task_bshrk_bills_s)

task_idb_feed_items_s.set_upstream(task_idb_identities_s)

task_idb_feed_recommendations_s.set_upstream(task_idb_identities_s)

task_idb_tu_alerts_s.set_upstream(task_idb_identities_s)

task_idb_tu_account_alerts_s.set_upstream(task_idb_identities_s)

task_idb_tu_fraud_alerts_s.set_upstream(task_idb_identities_s)

task_idb_tu_new_address_alerts_s.set_upstream(task_idb_identities_s)

task_idb_tu_new_bankruptcy_alerts_s.set_upstream(task_idb_identities_s)

task_idb_tu_new_employment_alerts_s.set_upstream(task_idb_identities_s)

task_idb_tu_new_inquiry_alerts_s.set_upstream(task_idb_identities_s)

task_idb_tu_new_public_record_alerts_s.set_upstream(task_idb_identities_s)

task_idb_goals_s.set_upstream(task_idb_identities_s)

task_idb_goals_savings_s.set_upstream(task_idb_identities_s)

task_idb_goals_profiles_s.set_upstream(task_idb_identities_s)

task_idb_goals_debt_s.set_upstream(task_idb_identities_s)

task_idb_goals_retirement_s.set_upstream(task_idb_identities_s)

task_idb_goals_credit_s.set_upstream(task_idb_identities_s)

task_dw_goal_d.set_upstream(task_idb_goals_s)
task_dw_goal_d.set_upstream(task_idb_goals_savings_s)
task_dw_goal_d.set_upstream(task_idb_goals_profiles_s)
task_dw_goal_d.set_upstream(task_idb_goals_debt_s)
task_dw_goal_d.set_upstream(task_idb_goals_retirement_s)
task_dw_goal_d.set_upstream(task_idb_goals_credit_s)
task_dw_goal_acct_xref_f.set_upstream(task_dw_goal_d)

task_dw_feed_item_d.set_upstream(task_idb_feed_items_s)
task_dw_feed_item_d.set_upstream(task_idb_feed_recommendations_s)
task_dw_feed_item_d.set_upstream(task_idb_identities_s)
task_dw_feed_rcmnd_auth_f.set_upstream(task_dw_feed_item_d)
task_dw_feed_rcmnd_prod_xref_f.set_upstream(task_dw_feed_item_d)
task_dw_feed_rcmnd_item_f.set_upstream(task_dw_feed_item_d)
task_tu_alert_d.set_upstream(task_idb_tu_alerts_s)
task_tu_alert_d.set_upstream(task_idb_tu_account_alerts_s)
task_tu_alert_d.set_upstream(task_idb_tu_fraud_alerts_s)
task_tu_alert_d.set_upstream(task_idb_tu_new_address_alerts_s)
task_tu_alert_d.set_upstream(task_idb_tu_new_bankruptcy_alerts_s)
task_tu_alert_d.set_upstream(task_idb_tu_new_employment_alerts_s)
task_tu_alert_d.set_upstream(task_idb_tu_new_inquiry_alerts_s)
task_tu_alert_d.set_upstream(task_idb_tu_new_public_record_alerts_s)


task_idb_yodlee_investment_holdings_s.set_upstream(task_idb_identities_s)

task_idb_merchant_rules_s.set_upstream(task_idb_identities_s)

task_idb_yodlee_authorization_profile_s.set_upstream(task_idb_identities_s)

task_idb_yodlee_tag_rules_s.set_upstream(task_idb_identities_s)

task_nr_events_s.set_upstream(task_start_job)
task_nr_events_s.set_upstream(task_idb_identities_s)

task_nr_points_s.set_upstream(task_start_job)
task_nr_points_s.set_upstream(task_idb_identities_s)

task_nr_raffles_s.set_upstream(task_start_job)
task_nr_raffles_s.set_upstream(task_idb_identities_s)

task_nr_raffle_winners_s.set_upstream(task_start_job)
task_nr_raffle_winners_s.set_upstream(task_idb_identities_s)

task_nr_raffle_entries_s.set_upstream(task_start_job)
task_nr_raffle_entries_s.set_upstream(task_idb_identities_s)

task_nr_raffle_identities_s.set_upstream(task_start_job)
task_nr_raffle_identities_s.set_upstream(task_idb_identities_s)

task_nr_tos_acknowledgements_s.set_upstream(task_start_job)
task_nr_tos_acknowledgements_s.set_upstream(task_idb_identities_s)

task_idb_yodlee_investment_plans_s.set_upstream(task_idb_identities_s)
task_idb_yodlee_investment_options_s.set_upstream(task_idb_identities_s)
task_idb_provider_account_states_s.set_upstream(task_idb_identities_s)
task_idb_providers_s.set_upstream(task_idb_identities_s)
task_idb_merchants_s.set_upstream(task_idb_identities_s)
task_idb_yodlee_accounts_s.set_upstream(task_idb_identities_s)
task_idb_yodlee_bank_accounts_s.set_upstream(task_idb_identities_s)
task_idb_yodlee_bill_accounts_s.set_upstream(task_idb_identities_s)
task_idb_yodlee_investment_accounts_s.set_upstream(task_idb_identities_s)
task_idb_yodlee_credit_accounts_s.set_upstream(task_idb_identities_s)
task_idb_yodlee_loan_accounts_s.set_upstream(task_idb_identities_s)

task_dw_yd_inv_optn_d.set_upstream(task_idb_yodlee_investment_options_s)
task_dw_yd_inv_plan_d.set_upstream(task_idb_yodlee_investment_plans_s)
task_dw_yd_prvdr_d.set_upstream(task_idb_providers_s)
task_dw_yd_prvdr_acct_d.set_upstream(task_idb_provider_account_states_s)
task_dw_yd_acct_d.set_upstream(task_idb_yodlee_accounts_s)
task_dw_cncl_mrchnt_d.set_upstream(task_idb_merchants_s)

task_dw_yd_auth_prfl_f.set_upstream(task_idb_yodlee_authorization_profile_s)
task_dw_yd_inv_hold_f.set_upstream(task_idb_yodlee_investment_holdings_s)
task_dw_yd_inv_hold_f.set_upstream(task_idb_yodlee_accounts_s)
task_dw_yd_tran_f.set_upstream(task_idb_yodlee_transactions_s)
task_dw_yd_tran_f.set_upstream(task_idb_yodlee_accounts_s)
task_dw_yd_tran_f.set_upstream(task_idb_merchants_s)
task_dw_mrchnt_rule_f.set_upstream(task_idb_merchant_rules_s)
task_dw_yd_acct_bal_f.set_upstream(task_idb_yodlee_accounts_s)
task_dw_yd_acct_bal_f.set_upstream(task_idb_yodlee_bank_accounts_s)
task_dw_yd_acct_bal_f.set_upstream(task_idb_yodlee_bill_accounts_s)
task_dw_yd_acct_bal_f.set_upstream(task_idb_yodlee_credit_accounts_s)
task_dw_yd_acct_bal_f.set_upstream(task_idb_yodlee_investment_accounts_s)
task_dw_yd_acct_bal_f.set_upstream(task_idb_yodlee_loan_accounts_s)
task_dw_yd_acct_hist_prof_xref_d.set_upstream(task_idb_yodlee_account_history_profile_s)

task_dw_rwrd_event_d.set_upstream(task_nr_events_s)
task_dw_rwrd_point_f.set_upstream(task_dw_rwrd_event_d)
task_dw_rwrd_point_f.set_upstream(task_nr_points_s)
task_dw_rwrd_raffle_d.set_upstream(task_nr_raffles_s)
task_dw_rwrd_raffle_entry_f.set_upstream(task_nr_raffle_entries_s)
task_dw_rwrd_raffle_entry_f.set_upstream(task_nr_raffle_winners_s)
task_dw_rwrd_raffle_user_d.set_upstream(task_nr_raffle_identities_s)
task_dw_rwrd_raffle_user_d.set_upstream(task_nr_tos_acknowledgements_s)

task_idb_addresses_s.set_upstream(task_idb_identities_s)

task_idb_financial_profile_s.set_upstream(task_idb_identities_s)

task_idb_global_profile_s.set_upstream(task_idb_identities_s)

task_idb_subscription_profile_s.set_upstream(task_idb_identities_s)

task_dw_identity_glb_profile_d.set_upstream(task_idb_financial_profile_s)
task_dw_identity_glb_profile_d.set_upstream(task_idb_global_profile_s)
task_dw_identity_glb_profile_d.set_upstream(task_idb_subscription_profile_s)
task_dw_identity_glb_profile_d.set_upstream(task_idb_addresses_s)
#task_dw_identity_glb_profile_d.set_upstream(task_idb_identities_s)


task_dw_identity_addr_d.set_upstream(task_idb_addresses_s)

task_tu_credit_report_profile_s.set_upstream(task_idb_identities_s)
task_dw_identity_tu_credit_rprt_profile_d.set_upstream(task_tu_credit_report_profile_s)

task_tu_authentication_status_profile_s.set_upstream(task_idb_identities_s)
task_dw_identity_tu_auth_status_profile_d.set_upstream(task_tu_authentication_status_profile_s)
task_dw_identity_tu_auth_status_profile_d.set_upstream(task_dw_identity_tu_credit_rprt_profile_d)
task_dw_identity_tu_auth_status_profile_d.set_upstream(task_dw_identity_glb_profile_d)

task_dit_user_profiles_s.set_upstream(task_idb_identities_s)
task_dw_dit_user_profile_d.set_upstream(task_dit_user_profiles_s)

task17_dw_identity_event_Fact_Load.set_upstream(task13_LoginIdentityEvent_Stage_Load)
task17_dw_identity_event_Fact_Load.set_upstream(task14_LogoutIdentityEvent_Stage_Load)
task17_dw_identity_event_Fact_Load.set_upstream(task15_DeactivateIdentityEvent_Stage_Load)
task17_dw_identity_event_Fact_Load.set_upstream(task16_RegisterIdentityEvent_Stage_Load)
task17_dw_identity_event_Fact_Load.set_upstream(task37_PasswordResetIdentityEvent_Stage_Load)
task17_dw_identity_event_Fact_Load.set_upstream(task38_ActivateCreditProfileEvent_Stage_Load)
task17_dw_identity_event_Fact_Load.set_upstream(task39_DeactivateCreditProfileEvent_Stage_Load)
task17_dw_identity_event_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task17_dw_identity_event_Fact_Load.set_upstream(task18_ActivationEvent_Stage_Load)
task17_dw_identity_event_Fact_Load.set_upstream(Task_Registration_Tracking_Profile_dependency)
task17_dw_identity_event_Fact_Load.set_upstream(task19_DeactivationEvent_Stage_Load)

task_idb_forecast_profiles_s.set_upstream(task_idb_identities_s)

task_idb_investing_profiles_s.set_upstream(task_idb_identities_s)

task_dw_identity_inv_profile_d.set_upstream(task_idb_investing_profiles_s)
task_dw_identity_inv_profile_d.set_upstream(task_idb_forecast_profiles_s)

## Internal Tasks Flow End

## PUD status update
task_pud_dag_status_update.set_upstream(task17_dw_identity_event_Fact_Load)
task_pud_dag_status_update.set_upstream(task_dw_identity_tu_auth_status_profile_d)
task_pud_dag_status_update.set_upstream(task_dw_identity_addr_d)
#task_pud_dag_status_update.set_upstream(task_dw_dit_user_profile_d)
#task_pud_dag_status_update.set_upstream(task_dw_identity_tu_trdln_snap_f)

