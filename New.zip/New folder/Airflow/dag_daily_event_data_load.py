from airflow import DAG
from datetime import datetime, timedelta

from airflow.operators import DummyOperator, NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_event_data_load"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 4, 13),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_click_event_post_s = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.click_event_post_s',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='click_event_post_s',
    dag=dag)

task_dw_session_event_f = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_session_event_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_session_event_f',
    dag=dag)

task_dw_prod_d = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_prod_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_prod_d',
    dag=dag)

task_user_agent_d = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_user_agent_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_user_agent_d',
    dag=dag)

task_minusworld_clicks_event_s = ExternalTaskSensor(
    task_id='dag_daily_nerdlake_dwh_upload.minusworld_clicks_event_s',
    external_dag_id='dag_daily_nerdlake_dwh_upload',
    external_task_id='minusworld_clicks_event_s',
    dag=dag)

task_wait_for_kadu = ExternalTaskSensor(
    task_id='dag_kadu_event_consumption_prod.kadu_done_success',
    external_dag_id='dag_kadu_event_consumption_prod',
    external_task_id='kadu_done_success',
    execution_delta=timedelta(hours=-23),
    dag=dag)

task_site_visitor_d = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.site_visitor_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='site_visitor_d',
    dag=dag)

task_dw_url_d = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_url_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_url_d',
    dag=dag)

task_dw_clicks_event_f = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.clicks_event_fact',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)
    
Task_page_view_event_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_page_view_event_fact',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='page_view_event_f',
    dag=dag)

Task_dw_page_view_event_src_map_dw_page_view_dependency = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_page_view_event_src_map_dw_page_view',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_page_view_event_src_map_dw_page_view',
    dag=dag)

################################################################################
# These two tasks are used to release the ETL processes in this DAG. These
# processes will be released as soon as the core tasks are complete or 6 hours
# after the batch cycle starts, whichever happens first.
# TODO: We might want to add the soft_fail option here, if it wouldn't cause
#       cause all downstream tasks to be skipped.
################################################################################
task_exec_dashboard = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.status_update',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='status_update',
    timeout=timedelta(hours=6).total_seconds(),
    retries=0,
    dag=dag)

task_release_etl = DummyOperator(
    task_id='Release_ETL',
    trigger_rule='all_done',
    dag=dag)
task_release_etl.set_upstream(task_exec_dashboard)

################################################################################
# Deserialization tasks for this DAG
################################################################################
event_names = {
    'BackendNWUserDataExportEvent',
    'BankingRateImpressionEvent',
    'BrokersImpressionEvent',
    'BrowserTimingEvent',
    'CCElementImpressionEvent',
    'CCElementInteractionEvent',
    'CCImpressionEvent',
    'EDULoansPrequalOfferEvent',
    'ElementImpressionEvent',
    'ElementInteractionEvent',
    'EmailBounceEvent',
    'EmailClickEvent',
    'EmailOpenEvent',
    'EmailSendEvent',
    'FeedElementImpressionEvent',
    'FeedElementInteractionEvent',
    'FeedItemChangedEvent',
    'FormInputChangedEvent',
    'ForumActivityEvent',
    'GenericImpressionEvent',
    'InsuranceImpressionEvent',
    'JoinEvent',
    'MortgageLenderImpressionEvent',
    'MortgageLenderQuoteEvent',
    'PersonalLoansImpressionEvent',
    'PersonalLoansPrequalOfferEvent',
    'ProductApprovalEvent',
    'ProductInteractionEvent',
    'PushSendEvent',
    'SessionStartEvent',
    'SMBImpressionEvent',
    'SMBPrequalOfferEvent',
    'YodleeProviderAccountWorkflowEvent',
    }
deser_tasks = dict()
for event_name in sorted(event_names, key=lambda s: s.lower()):
    task_deser = NWBashScriptOperator(
        bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
        script_args=[event_name],
        task_id=event_name,
        dag=dag)
    task_deser.set_upstream(task_wait_for_kadu)
    deser_tasks[event_name] = task_deser

################################################################################
# Event staging load tasks for this DAG
################################################################################
event_names = {
    'BackendNWUserDataExportEvent',
    'FeedItemChangedEvent',
    'FormInputChangedEvent',
    'ForumActivityEvent',
    'SessionStartEvent',
    'YodleeProviderAccountWorkflowEvent',
    }
stage_load_tasks = dict()
for event_name in event_names:
    load_task = NWBashScriptOperator(
        task_id='pbclass_{}_s'.format(event_name),
        bash_script='/data/etl/Common/redshift_load_event_stage_table.sh',
        script_args=[event_name],
        pool='redshift_etl',
        dag=dag)
    load_task.set_upstream(deser_tasks[event_name])
    stage_load_tasks[event_name] = load_task

task_BrowserTimingEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/browser_timing_event/shellscripts/browser_timing_event.sh',
    script_args=[],
    task_id='BroswerTimingEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task_BrowserTimingEvent_Stage_Load.set_upstream(deser_tasks['BrowserTimingEvent'])

task_BrowserTimingEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_brwsr_tmng_event_f/shellscripts/dw_brwsr_tmng_event_f.sh',
    script_args=[],
    task_id='BrowserTimingEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task3_script = "/data/etl/Scripts/dw_prod_imprsn_event_cc_f/shellscripts/dw_prod_imprsn_event_cc_f.sh"
task3_CCImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script=task3_script,
    script_args=[],
    task_id='dw_prod_imprsn_event_cc_f_load',
    pool='redshift_etl',
    dag=dag)

task4_script = "/data/etl/Scripts/dw_derived_prod_d/shellscripts/dw_derived_prod_d.sh"
task4_CCImpressionEvent_Derived_Prod = NWBashScriptOperator(
    bash_script=task4_script,
    script_args=[],
    task_id='dw_derived_prod_d_load',
    pool='redshift_etl',
    dag=dag)

task5_script = "/data/etl/Scripts/dw_prod_imprsn_consolidated_f/shellscripts/dw_prod_imprsn_consolidated_f.sh"
task5_CCImpressionEvent_Consolidated_F = NWBashScriptOperator(
    bash_script=task5_script,
    script_args=[],
    task_id='CCImpressionEvent_Consolidated_F',
    pool='redshift_etl',
    dag=dag)

task7_script = "/data/etl/Scripts/dw_pv_form_input_chg_event_f/shellscripts/dw_pv_form_input_chg_event_f.sh"
task7_FormInputChangedEvent_Fact_Load = NWBashScriptOperator(
    bash_script=task7_script,
    script_args=[],
    task_id='FormInputChangedEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task9_script = "/data/etl/Scripts/impression_event_smb_s/shellscripts/impression_event_smb_s.sh"
task9_SMBImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task9_script,
    script_args=[],
    task_id='SMBImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task9_SMBImpressionEvent_Stage_Load.set_upstream(deser_tasks['SMBImpressionEvent'])

task10_script = "/data/etl/Scripts/dw_prod_imprsn_event_smb_f/shellscripts/dw_prod_imprsn_event_smb_f.sh"
task10_SMBImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script=task10_script,
    script_args=[],
    task_id='SMBImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task11_script = "/data/etl/Scripts/impression_event_pl_s/shellscripts/impression_event_pl_s.sh"
task11_PLImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task11_script,
    script_args=[],
    task_id='PersonalLoansImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task11_PLImpressionEvent_Stage_Load.set_upstream(deser_tasks['PersonalLoansImpressionEvent'])

task12_script = "/data/etl/Scripts/dw_prod_imprsn_event_pl_f/shellscripts/dw_prod_imprsn_event_pl_f.sh"
task12_PLImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script=task12_script,
    script_args=[],
    task_id='PersonalLoansImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task18_BrokersImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/impression_event_broker_s/shellscripts/impression_event_broker_s.sh',
    script_args=[],
    task_id='BrokersImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task19_BrokersImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_imprsn_event_broker_f/shellscripts/dw_prod_imprsn_event_broker_f.sh',
    script_args=[],
    task_id='BrokersImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task19_JoinEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/join_event_s/shellscripts/join_event_s.sh',
    script_args=[],
    task_id='JoinEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task20_dw_join_event_f_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_join_event_f/shellscripts/dw_join_event_f.sh',
    script_args=[],
    task_id='dw_join_event_f_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task21_ProductInteractionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/product_interaction_event_s/shellscripts/product_interaction_event_s.sh',
    script_args=[],
    task_id='ProductInteractionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task22_dw_prod_intactn_event_f_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_intactn_event_f/shellscripts/dw_prod_intactn_event_f.sh',
    script_args=[],
    task_id='dw_prod_intactn_event_f_Fact_Load',
    pool='redshift_etl',
    dag=dag)


task34_ProductApprovalEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/product_approval_event_s/shellscripts/product_approval_event_s.sh',
    script_args=[],
    task_id='ProductApprovalEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task35_dw_prod_approval_event_f_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_approval_event_f/shellscripts/dw_prod_approval_event_f.sh',
    script_args=[],
    task_id='dw_prod_approval_event_f_Fact_Load',
    pool='redshift_etl',
    dag=dag)


task23_script = "/data/etl/Scripts/prequal_offer_event_pl_s/shellscripts/prequal_offer_event_pl_s.sh"
task23_PLPrequalOfferEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task23_script,
    script_args=[],
    task_id='PersonalLoansPrequalOfferEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task23_PLPrequalOfferEvent_Stage_Load.set_upstream(deser_tasks['PersonalLoansPrequalOfferEvent'])

task24_script = "/data/etl/Scripts/dw_prequal_offer_event_pl_f/shellscripts/dw_prequal_offer_event_pl_f.sh"
task24_PLPrequalOfferEvent_Fact_Load = NWBashScriptOperator(
    bash_script=task24_script,
    script_args=[],
    task_id='PersonalLoansPrequalOfferEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task25_script = "/data/etl/Scripts/prequal_offer_event_smb_s/shellscripts/prequal_offer_event_smb_s.sh"
task25_SMBPrequalOfferEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task25_script,
    script_args=[],
    task_id='SMBPrequalOfferEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task26_script = "/data/etl/Scripts/dw_prequal_offer_event_smb_f/shellscripts/dw_prequal_offer_event_smb_f.sh"
task26_SMBPrequalOfferEvent_Fact_Load = NWBashScriptOperator(
    bash_script=task26_script,
    script_args=[],
    task_id='SMBPrequalOfferEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)
    
task27_script = "/data/etl/Scripts/dw_click_mrtg_f/shellscripts/dw_click_mrtg_f.sh"		
task27_Mortgage_click_Fact_Load = NWBashScriptOperator(		
    bash_script=task27_script,		
    script_args=[],		
    task_id='Mortgage_click_Fact_Load',		
    pool='redshift_etl',
    dag=dag)

task28_script = "/data/etl/Scripts/email_bounce_event_s/shellscripts/email_bounce_event_s.sh"
task28_EmailBounceEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task28_script,
    script_args=[],
    task_id='EmailBounceEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task28_EmailBounceEvent_Stage_Load.set_upstream(deser_tasks['EmailBounceEvent'])

task29_script = "/data/etl/Scripts/email_click_event_s/shellscripts/email_click_event_s.sh"
task29_EmailClickEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task29_script,
    script_args=[],
    task_id='EmailClickEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
    
task30_script = "/data/etl/Scripts/email_open_event_s/shellscripts/email_open_event_s.sh"
task30_EmailOpenEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task30_script,
    script_args=[],
    task_id='EmailOpenEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
    
task31_script = "/data/etl/Scripts/email_send_event_s/shellscripts/email_send_event_s.sh"
task31_EmailSendEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task31_script,
    script_args=[],
    task_id='EmailSendEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task_email_event_post_s = DummyOperator(
    task_id='email_event_post_s',
    dag=dag)
task_email_event_post_s.set_upstream(task28_EmailBounceEvent_Stage_Load)
task_email_event_post_s.set_upstream(task29_EmailClickEvent_Stage_Load)
task_email_event_post_s.set_upstream(task30_EmailOpenEvent_Stage_Load)
task_email_event_post_s.set_upstream(task31_EmailSendEvent_Stage_Load)

task32_script = "/data/etl/Scripts/dw_email_event_f/shellscripts/dw_email_event_f.sh"
task32_dw_email_event_Fact_Load = NWBashScriptOperator(
    bash_script=task32_script,
    script_args=[],
    task_id='dw_email_event_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task36_script = "/data/etl/Scripts/impression_event_insurance_s/shellscripts/impression_event_insurance_s.sh"
task36_InsuranceImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task36_script,
    script_args=[],
    task_id='InsuranceImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task36_InsuranceImpressionEvent_Stage_Load.set_upstream(deser_tasks['InsuranceImpressionEvent'])

task37_script = "/data/etl/Scripts/dw_prod_imprsn_event_ins_f/shellscripts/dw_prod_imprsn_event_ins_f.sh"
task37_InsuranceImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script=task37_script,
    script_args=[],
    task_id='InsuranceImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task38_script = "/data/etl/Scripts/dw_click_event_trkng_param_f/shellscripts/dw_click_event_trkng_param_f.sh"
task38_ClickEventTrackingParam_Fact_Load = NWBashScriptOperator(
    bash_script=task38_script,
    script_args=[],
    task_id='dw_click_event_trkng_param_f',
    pool='redshift_etl',
    dag=dag)

task40_ElementImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/element_impression_event/shellscripts/element_impression_event.sh',
    script_args=[],
    task_id='ElementImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task41_ElementImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_elem_imprsn_event_f/shellscripts/dw_elem_imprsn_event_f.sh',
    script_args=[],
    task_id='ElementImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task42_GenericImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/generic_impression_event/shellscripts/generic_impression_event.sh',
    script_args=[],
    task_id='GenericImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task43_GenericImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_imprsn_event_gnrc_f/shellscripts/dw_prod_imprsn_event_gnrc_f.sh',
    script_args=[],
    task_id='GenericImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task44_ElementInteractionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/element_interaction_event_s/shellscripts/element_interaction_event_s.sh',
    script_args=[],
    task_id='ElementInteractionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task45_ElementInteractionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_elem_intactn_event_f/shellscripts/dw_elem_intactn_event_f.sh',
    script_args=[],
    task_id='ElementInteractionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)
    
task46_script = "/data/etl/Scripts/push_send_event_s/shellscripts/push_send_event_s.sh"
task46_PushSendEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task46_script,
    script_args=[],
    task_id='PushSendEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
    
task47_script = "/data/etl/Scripts/dw_push_event_f/shellscripts/dw_push_event_f.sh"
task47_dw_push_event_fact_Load = NWBashScriptOperator(
    bash_script=task47_script,
    script_args=[],
    task_id='dw_push_event_fact_Load',
    pool='redshift_etl',
    dag=dag)

task48_script = "/data/etl/Scripts/cc_element_impression_event/shellscripts/cc_element_impression_event.sh"       
task48_cc_element_impression_event_Stage_Load = NWBashScriptOperator(
    bash_script=task48_script,
    script_args=[],
    task_id='CCElementImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task48_cc_element_impression_event_Stage_Load.set_upstream(deser_tasks['CCElementImpressionEvent'])

task49_script = "/data/etl/Scripts/dw_elem_imprsn_event_cc_f/shellscripts/dw_elem_imprsn_event_cc_f.sh"
task49_dw_elem_imprsn_event_cc_fact_Load = NWBashScriptOperator(
    bash_script=task49_script,
    script_args=[],
    task_id='dw_elem_imprsn_event_cc_fact_Load',
    pool='redshift_etl',
    dag=dag)

task50_CCElementInteractionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/cc_element_interaction_event_s/shellscripts/cc_element_interaction_event_s.sh',
    script_args=[],
    task_id='CCElementInteractionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task50_CCElementInteractionEvent_Stage_Load.set_upstream(deser_tasks['CCElementInteractionEvent'])

task51_CCElementInteractionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_elem_intactn_event_cc_f/shellscripts/dw_elem_intactn_event_cc_f.sh',
    script_args=[],
    task_id='CCElementInteractionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task50_script = "/data/etl/Scripts/quote_event_mrtg_s/shellscripts/quote_event_mrtg_s.sh"
task50_MortgageLenderQuoteEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task50_script,
    script_args=[],
    task_id='MortgageLenderQuoteEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task51_script = "/data/etl/Scripts/dw_quote_event_mrtg_f/shellscripts/dw_quote_event_mrtg_f.sh"
task51_MortgageLenderQuoteEvent_Fact_Load = NWBashScriptOperator(
    bash_script=task51_script,
    script_args=[],
    task_id='MortgageLenderQuoteEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task53_FeedItemChangedEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_feed_item_chg_event_f/shellscripts/dw_feed_item_chg_event_f.sh',
    script_args=[],
    task_id='FeedItemChangedEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task54_FeedElementInteractionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/feed_element_interaction_event_s/shellscripts/feed_element_interaction_event_s.sh',
    script_args=[],
    task_id='FeedElementInteractionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
    
task55_FeedElementInteractionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_feed_elem_intactn_event_f/shellscripts/dw_feed_elem_intactn_event_f.sh',
    script_args=[],
    task_id='FeedElementInteractionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task56_FeedElementImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/feed_element_impression_event_s/shellscripts/feed_element_impression_event_s.sh',
    script_args=[],
    task_id='FeedElementImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
    
task57_FeedElementImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_feed_elem_imprsn_event_f/shellscripts/dw_feed_elem_imprsn_event_f.sh',
    script_args=[],
    task_id='FeedElementImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task58_EDUPrequalOfferEvent_Stage_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/prequal_offer_event_edu_s/shellscripts/prequal_offer_event_edu_s.sh",
    script_args=[],
    task_id='EDULoansPrequalOfferEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task59_EDUPrequalOfferEvent_Fact_Load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_prequal_offer_event_edu_f/shellscripts/dw_prequal_offer_event_edu_f.sh",
    script_args=[],
    task_id='EDULoansPrequalOfferEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task60_BackendNWUserDataExportEvent_Fact_Load = NWBashScriptOperator(
    bash_script= "/data/etl/Scripts/dw_bckd_nw_user_data_xprt_event_f/shellscripts/dw_bckd_nw_user_data_xprt_event_f.sh",
    script_args=[],
    task_id='BackendNWUserDataExportEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)
task60_BackendNWUserDataExportEvent_Fact_Load.set_upstream(task_release_etl)
task60_BackendNWUserDataExportEvent_Fact_Load.set_upstream(stage_load_tasks['BackendNWUserDataExportEvent'])

task61_MortgageLenderImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/impression_event_mrtg_s/shellscripts/impression_event_mrtg_s.sh',
    script_args=[],
    task_id='MortgageLenderImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)

task62_MortgageLenderImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_imprsn_event_mrtg_f/shellscripts/dw_prod_imprsn_event_mrtg_f.sh',
    script_args=[],
    task_id='MortgageLenderImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task63_BankingRateImpressionEvent_Stage_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/impression_event_banking_rate_s/shellscripts/impression_event_banking_rate_s.sh',
    script_args=[],
    task_id='BankingRateImpressionEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task63_BankingRateImpressionEvent_Stage_Load.set_upstream(deser_tasks['BankingRateImpressionEvent'])

task64_BankingRateImpressionEvent_Fact_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_imprsn_event_banking_rate_f/shellscripts/dw_prod_imprsn_event_banking_rate_f.sh',
    script_args=[],
    task_id='BankingRateImpressionEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task65_YodleeProviderAccountWorkflowEvent_Fact_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_yd_prvdr_acct_wrkflw_event_f/shellscripts/dw_yd_prvdr_acct_wrkflw_event_f.sh',
    script_args=[],
    task_id='YodleeProviderAccountWorkflowEvent_Fact_Load',
    pool='redshift_etl',
    dag=dag)

task66_ForumActivityEvent_Load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_forum_actvy_f/shellscripts/dw_forum_actvy_f.sh',
    script_args=[],
    task_id='ForumActivityEvent_Load',
    pool='redshift_etl',
    dag=dag)

task_event_dag_status_update_script = "/data/etl/Common/redshift_sql_function.sh"
task_event_dag_status_update = NWBashScriptOperator(
    bash_script=task_event_dag_status_update_script,
    script_args=["/data/etl/Airflow/post_updates/dag_daily_event_data_load_status_update.sql"],
    task_id='status_update',
    dag=dag)

# Currently this is used for analysis. If we end up incorporating this into
# dw_clicks_event_f then it should be moved to dag_daily_core_dwh.
task_dw_minusworld_clicks_event_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_minusworld_clicks_event_f/shellscripts/dw_minusworld_clicks_event_f.sh',
    script_args=[],
    task_id='dw_minusworld_clicks_event_f',
    dag=dag)
task_dw_minusworld_clicks_event_f.set_upstream(task_minusworld_clicks_event_s)

task3_CCImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task3_CCImpressionEvent_Fact_Load.set_upstream(deser_tasks['CCImpressionEvent'])
task3_CCImpressionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task3_CCImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)
task3_CCImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)

task10_SMBImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task10_SMBImpressionEvent_Fact_Load.set_upstream(task9_SMBImpressionEvent_Stage_Load)
task10_SMBImpressionEvent_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task10_SMBImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)
task10_SMBImpressionEvent_Fact_Load.set_upstream(task_dw_prod_d)
task10_SMBImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)
task10_SMBImpressionEvent_Fact_Load.set_upstream(task_user_agent_d)

task12_PLImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task12_PLImpressionEvent_Fact_Load.set_upstream(task11_PLImpressionEvent_Stage_Load)
task12_PLImpressionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task12_PLImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)
task12_PLImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)

task24_PLPrequalOfferEvent_Fact_Load.set_upstream(task_release_etl)
task24_PLPrequalOfferEvent_Fact_Load.set_upstream(task23_PLPrequalOfferEvent_Stage_Load)
task24_PLPrequalOfferEvent_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task24_PLPrequalOfferEvent_Fact_Load.set_upstream(task_dw_url_d)
task24_PLPrequalOfferEvent_Fact_Load.set_upstream(task_site_visitor_d)
task24_PLPrequalOfferEvent_Fact_Load.set_upstream(task_user_agent_d)
task24_PLPrequalOfferEvent_Fact_Load.set_upstream(task_dw_prod_d)

task25_SMBPrequalOfferEvent_Stage_Load.set_upstream(deser_tasks['SMBPrequalOfferEvent'])
task26_SMBPrequalOfferEvent_Fact_Load.set_upstream(task_release_etl)
task26_SMBPrequalOfferEvent_Fact_Load.set_upstream(task25_SMBPrequalOfferEvent_Stage_Load)
task26_SMBPrequalOfferEvent_Fact_Load.set_upstream(task_click_event_post_s)
task26_SMBPrequalOfferEvent_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task26_SMBPrequalOfferEvent_Fact_Load.set_upstream(task_dw_url_d)
task26_SMBPrequalOfferEvent_Fact_Load.set_upstream(task_site_visitor_d)
task26_SMBPrequalOfferEvent_Fact_Load.set_upstream(task_user_agent_d)
task26_SMBPrequalOfferEvent_Fact_Load.set_upstream(task_dw_prod_d)

task58_EDUPrequalOfferEvent_Stage_Load.set_upstream(deser_tasks['EDULoansPrequalOfferEvent'])
task59_EDUPrequalOfferEvent_Fact_Load.set_upstream(task_release_etl)
task59_EDUPrequalOfferEvent_Fact_Load.set_upstream(task58_EDUPrequalOfferEvent_Stage_Load)
task59_EDUPrequalOfferEvent_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task59_EDUPrequalOfferEvent_Fact_Load.set_upstream(task_dw_url_d)
task59_EDUPrequalOfferEvent_Fact_Load.set_upstream(task_site_visitor_d)
task59_EDUPrequalOfferEvent_Fact_Load.set_upstream(task_user_agent_d)
task59_EDUPrequalOfferEvent_Fact_Load.set_upstream(task_dw_prod_d)

task18_BrokersImpressionEvent_Stage_Load.set_upstream(deser_tasks['BrokersImpressionEvent'])

task19_BrokersImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task19_BrokersImpressionEvent_Fact_Load.set_upstream(task18_BrokersImpressionEvent_Stage_Load)
task19_BrokersImpressionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task19_BrokersImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)
task19_BrokersImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)

task4_CCImpressionEvent_Derived_Prod.set_upstream(task18_BrokersImpressionEvent_Stage_Load)
task4_CCImpressionEvent_Derived_Prod.set_upstream(task3_CCImpressionEvent_Fact_Load)
task4_CCImpressionEvent_Derived_Prod.set_upstream(task42_GenericImpressionEvent_Stage_Load)
task4_CCImpressionEvent_Derived_Prod.set_upstream(task36_InsuranceImpressionEvent_Stage_Load)
task4_CCImpressionEvent_Derived_Prod.set_upstream(task61_MortgageLenderImpressionEvent_Stage_Load)
task4_CCImpressionEvent_Derived_Prod.set_upstream(task11_PLImpressionEvent_Stage_Load)
task4_CCImpressionEvent_Derived_Prod.set_upstream(task63_BankingRateImpressionEvent_Stage_Load)
task4_CCImpressionEvent_Derived_Prod.set_upstream(task9_SMBImpressionEvent_Stage_Load)

task5_CCImpressionEvent_Consolidated_F.set_upstream(task3_CCImpressionEvent_Fact_Load)
task5_CCImpressionEvent_Consolidated_F.set_upstream(task62_MortgageLenderImpressionEvent_Fact_Load)
task5_CCImpressionEvent_Consolidated_F.set_upstream(task10_SMBImpressionEvent_Fact_Load)
task5_CCImpressionEvent_Consolidated_F.set_upstream(task12_PLImpressionEvent_Fact_Load)
task5_CCImpressionEvent_Consolidated_F.set_upstream(task19_BrokersImpressionEvent_Fact_Load)
task5_CCImpressionEvent_Consolidated_F.set_upstream(task37_InsuranceImpressionEvent_Fact_Load)
task5_CCImpressionEvent_Consolidated_F.set_upstream(task43_GenericImpressionEvent_Fact_Load)
task5_CCImpressionEvent_Consolidated_F.set_upstream(task64_BankingRateImpressionEvent_Fact_Load)

task7_FormInputChangedEvent_Fact_Load.set_upstream(task_release_etl)
task7_FormInputChangedEvent_Fact_Load.set_upstream(stage_load_tasks['FormInputChangedEvent'])
task7_FormInputChangedEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task7_FormInputChangedEvent_Fact_Load.set_upstream(task_dw_url_d)
task7_FormInputChangedEvent_Fact_Load.set_upstream(task_user_agent_d)
task7_FormInputChangedEvent_Fact_Load.set_upstream(task_site_visitor_d)

task27_Mortgage_click_Fact_Load.set_upstream(task7_FormInputChangedEvent_Fact_Load)
task27_Mortgage_click_Fact_Load.set_upstream(task_dw_url_d)

task19_JoinEvent_Stage_Load.set_upstream(deser_tasks['JoinEvent'])
task20_dw_join_event_f_Fact_Load.set_upstream(task_release_etl)
task20_dw_join_event_f_Fact_Load.set_upstream(task19_JoinEvent_Stage_Load)
task20_dw_join_event_f_Fact_Load.set_upstream(task_site_visitor_d)

task21_ProductInteractionEvent_Stage_Load.set_upstream(deser_tasks['ProductInteractionEvent'])
task22_dw_prod_intactn_event_f_Fact_Load.set_upstream(task_release_etl)
task22_dw_prod_intactn_event_f_Fact_Load.set_upstream(task21_ProductInteractionEvent_Stage_Load)
task22_dw_prod_intactn_event_f_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task22_dw_prod_intactn_event_f_Fact_Load.set_upstream(task_dw_session_event_f)
task22_dw_prod_intactn_event_f_Fact_Load.set_upstream(task_dw_url_d)
task22_dw_prod_intactn_event_f_Fact_Load.set_upstream(task_dw_prod_d)
task22_dw_prod_intactn_event_f_Fact_Load.set_upstream(task_site_visitor_d)
task22_dw_prod_intactn_event_f_Fact_Load.set_upstream(task_user_agent_d)

task34_ProductApprovalEvent_Stage_Load.set_upstream(deser_tasks['ProductApprovalEvent'])
task35_dw_prod_approval_event_f_Fact_Load.set_upstream(task_release_etl)
task35_dw_prod_approval_event_f_Fact_Load.set_upstream(task34_ProductApprovalEvent_Stage_Load)
task35_dw_prod_approval_event_f_Fact_Load.set_upstream(task_dw_prod_d)
task35_dw_prod_approval_event_f_Fact_Load.set_upstream(task_dw_url_d)
task35_dw_prod_approval_event_f_Fact_Load.set_upstream(task_site_visitor_d)
task35_dw_prod_approval_event_f_Fact_Load.set_upstream(task_user_agent_d)

task29_EmailClickEvent_Stage_Load.set_upstream(deser_tasks['EmailClickEvent'])

task30_EmailOpenEvent_Stage_Load.set_upstream(deser_tasks['EmailOpenEvent'])

task31_EmailSendEvent_Stage_Load.set_upstream(deser_tasks['EmailSendEvent'])

task32_dw_email_event_Fact_Load.set_upstream(task_release_etl)
task32_dw_email_event_Fact_Load.set_upstream(task_email_event_post_s)
task32_dw_email_event_Fact_Load.set_upstream(task_user_agent_d)

task37_InsuranceImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task37_InsuranceImpressionEvent_Fact_Load.set_upstream(task36_InsuranceImpressionEvent_Stage_Load)
task37_InsuranceImpressionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task37_InsuranceImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)
task37_InsuranceImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)

task38_ClickEventTrackingParam_Fact_Load.set_upstream(task_dw_clicks_event_f)

task40_ElementImpressionEvent_Stage_Load.set_upstream(deser_tasks['ElementImpressionEvent'])

task41_ElementImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task41_ElementImpressionEvent_Fact_Load.set_upstream(task40_ElementImpressionEvent_Stage_Load)
task41_ElementImpressionEvent_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task41_ElementImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)
task41_ElementImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)
task41_ElementImpressionEvent_Fact_Load.set_upstream(task_user_agent_d)

task42_GenericImpressionEvent_Stage_Load.set_upstream(deser_tasks['GenericImpressionEvent'])

task43_GenericImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task43_GenericImpressionEvent_Fact_Load.set_upstream(task42_GenericImpressionEvent_Stage_Load)
task43_GenericImpressionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task43_GenericImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)
task43_GenericImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)

task44_ElementInteractionEvent_Stage_Load.set_upstream(deser_tasks['ElementInteractionEvent'])

task45_ElementInteractionEvent_Fact_Load.set_upstream(task_release_etl)
task45_ElementInteractionEvent_Fact_Load.set_upstream(task44_ElementInteractionEvent_Stage_Load)
task45_ElementInteractionEvent_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task45_ElementInteractionEvent_Fact_Load.set_upstream(task_dw_url_d)
task45_ElementInteractionEvent_Fact_Load.set_upstream(task_site_visitor_d)
task45_ElementInteractionEvent_Fact_Load.set_upstream(task_user_agent_d)

task46_PushSendEvent_Stage_Load.set_upstream(deser_tasks['PushSendEvent'])
task47_dw_push_event_fact_Load.set_upstream(task46_PushSendEvent_Stage_Load)    

task51_CCElementInteractionEvent_Fact_Load.set_upstream(task_release_etl)
task51_CCElementInteractionEvent_Fact_Load.set_upstream(task50_CCElementInteractionEvent_Stage_Load)
task51_CCElementInteractionEvent_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task51_CCElementInteractionEvent_Fact_Load.set_upstream(task_dw_url_d)
task51_CCElementInteractionEvent_Fact_Load.set_upstream(task_site_visitor_d)
task51_CCElementInteractionEvent_Fact_Load.set_upstream(task_user_agent_d)
task51_CCElementInteractionEvent_Fact_Load.set_upstream(task_dw_prod_d)

task_BrowserTimingEvent_Fact_Load.set_upstream(task_release_etl)
task_BrowserTimingEvent_Fact_Load.set_upstream(task_BrowserTimingEvent_Stage_Load)
task_BrowserTimingEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task_BrowserTimingEvent_Fact_Load.set_upstream(task_dw_url_d)
task_BrowserTimingEvent_Fact_Load.set_upstream(task_site_visitor_d)
task_BrowserTimingEvent_Fact_Load.set_upstream(task_user_agent_d)

task49_dw_elem_imprsn_event_cc_fact_Load.set_upstream(task_release_etl)
task49_dw_elem_imprsn_event_cc_fact_Load.set_upstream(task48_cc_element_impression_event_Stage_Load)
task49_dw_elem_imprsn_event_cc_fact_Load.set_upstream(Task_page_view_event_f_dependency)
task49_dw_elem_imprsn_event_cc_fact_Load.set_upstream(task_dw_url_d)
task49_dw_elem_imprsn_event_cc_fact_Load.set_upstream(task_site_visitor_d)
task49_dw_elem_imprsn_event_cc_fact_Load.set_upstream(task_user_agent_d)
task49_dw_elem_imprsn_event_cc_fact_Load.set_upstream(task_dw_prod_d)

task50_MortgageLenderQuoteEvent_Stage_Load.set_upstream(deser_tasks['MortgageLenderQuoteEvent'])
task51_MortgageLenderQuoteEvent_Fact_Load.set_upstream(task_release_etl)
task51_MortgageLenderQuoteEvent_Fact_Load.set_upstream(task50_MortgageLenderQuoteEvent_Stage_Load)
task51_MortgageLenderQuoteEvent_Fact_Load.set_upstream(Task_page_view_event_f_dependency)
task51_MortgageLenderQuoteEvent_Fact_Load.set_upstream(task_dw_url_d)
task51_MortgageLenderQuoteEvent_Fact_Load.set_upstream(task_site_visitor_d)
task51_MortgageLenderQuoteEvent_Fact_Load.set_upstream(task_user_agent_d)

task53_FeedItemChangedEvent_Fact_Load.set_upstream(task_release_etl)
task53_FeedItemChangedEvent_Fact_Load.set_upstream(stage_load_tasks['FeedItemChangedEvent'])

task54_FeedElementInteractionEvent_Stage_Load.set_upstream(deser_tasks['FeedElementInteractionEvent'])

task55_FeedElementInteractionEvent_Fact_Load.set_upstream(task_release_etl)
task55_FeedElementInteractionEvent_Fact_Load.set_upstream(task54_FeedElementInteractionEvent_Stage_Load)
task55_FeedElementInteractionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task55_FeedElementInteractionEvent_Fact_Load.set_upstream(task_site_visitor_d)
task55_FeedElementInteractionEvent_Fact_Load.set_upstream(task_user_agent_d)

task56_FeedElementImpressionEvent_Stage_Load.set_upstream(deser_tasks['FeedElementImpressionEvent'])

task57_FeedElementImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task57_FeedElementImpressionEvent_Fact_Load.set_upstream(task56_FeedElementImpressionEvent_Stage_Load)
task57_FeedElementImpressionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task57_FeedElementImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)
task57_FeedElementImpressionEvent_Fact_Load.set_upstream(task_user_agent_d)

task61_MortgageLenderImpressionEvent_Stage_Load.set_upstream(deser_tasks['MortgageLenderImpressionEvent'])

task62_MortgageLenderImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task62_MortgageLenderImpressionEvent_Fact_Load.set_upstream(task61_MortgageLenderImpressionEvent_Stage_Load)
task62_MortgageLenderImpressionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task62_MortgageLenderImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)
task62_MortgageLenderImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)

task64_BankingRateImpressionEvent_Fact_Load.set_upstream(task_release_etl)
task64_BankingRateImpressionEvent_Fact_Load.set_upstream(task63_BankingRateImpressionEvent_Stage_Load)
task64_BankingRateImpressionEvent_Fact_Load.set_upstream(Task_dw_page_view_event_src_map_dw_page_view_dependency)
task64_BankingRateImpressionEvent_Fact_Load.set_upstream(task_dw_url_d)
task64_BankingRateImpressionEvent_Fact_Load.set_upstream(task_site_visitor_d)

task65_YodleeProviderAccountWorkflowEvent_Fact_load.set_upstream(task_release_etl)
task65_YodleeProviderAccountWorkflowEvent_Fact_load.set_upstream(stage_load_tasks['YodleeProviderAccountWorkflowEvent'])

task66_ForumActivityEvent_Load.set_upstream(task_release_etl)
task66_ForumActivityEvent_Load.set_upstream(Task_page_view_event_f_dependency)
task66_ForumActivityEvent_Load.set_upstream(task_site_visitor_d)
task66_ForumActivityEvent_Load.set_upstream(task_user_agent_d)

task66_ForumActivityEvent_Load.set_upstream(stage_load_tasks['ForumActivityEvent'])

task_event_dag_status_update.set_upstream(task22_dw_prod_intactn_event_f_Fact_Load)
task_event_dag_status_update.set_upstream(task26_SMBPrequalOfferEvent_Fact_Load)
task_event_dag_status_update.set_upstream(task27_Mortgage_click_Fact_Load)
task_event_dag_status_update.set_upstream(task35_dw_prod_approval_event_f_Fact_Load)
task_event_dag_status_update.set_upstream(task24_PLPrequalOfferEvent_Fact_Load)
task_event_dag_status_update.set_upstream(task32_dw_email_event_Fact_Load)
task_event_dag_status_update.set_upstream(task12_PLImpressionEvent_Fact_Load)
task_event_dag_status_update.set_upstream(task20_dw_join_event_f_Fact_Load)
task_event_dag_status_update.set_upstream(task5_CCImpressionEvent_Consolidated_F)
task_event_dag_status_update.set_upstream(task47_dw_push_event_fact_Load)
task_event_dag_status_update.set_upstream(task49_dw_elem_imprsn_event_cc_fact_Load)
task_event_dag_status_update.set_upstream(task51_CCElementInteractionEvent_Fact_Load)
task_event_dag_status_update.set_upstream(task51_MortgageLenderQuoteEvent_Fact_Load)
task_event_dag_status_update.set_upstream(task53_FeedItemChangedEvent_Fact_Load)
task_event_dag_status_update.set_upstream(task55_FeedElementInteractionEvent_Fact_Load)
task_event_dag_status_update.set_upstream(task57_FeedElementImpressionEvent_Fact_Load)
task_event_dag_status_update.set_upstream(task59_EDUPrequalOfferEvent_Fact_Load)
