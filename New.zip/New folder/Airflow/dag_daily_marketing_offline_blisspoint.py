from datetime import datetime, timedelta, time
from email.mime.text import MIMEText
import smtplib
import os

from airflow import DAG
from airflow.operators import DummyOperator
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor
from airflow.operators.sensors import S3KeySensor
from airflow.operators.sensors import TimeSensor

dag_name = 'dag_daily_marketing_offline_blisspoint'


def notify_bliss_point_missing_file(context):
    bucket_key = context['task'].bucket_key

    # The Jinja templated fields aren't handled correctly when retrieving properties from the task, the macros are
    # simply replaced with empty strings. The workaround is to set them manually, not a great solution.
    if context['task'].task_id == 'Watch_for_nw_daily_spend_tv_YYYY-MM-DD_000.csv':
        bucket_key = 'blisspoint_to_nw/daily_media_spend/dw_eff_dt={ds}/nw_daily_spend_tv_{ds}_000.csv'.format(
            ds=context['ds'])
    elif context['task'].task_id == 'Watch_for_nw_spot_report_YYYY-MM-DD_000.csv':
        bucket_key = 'blisspoint_to_nw/spot_report/dw_eff_dt={ds}/nw_spot_report_{ds}_000.csv'.format(
            ds=context['ds'])
    elif context['task'].task_id == 'Watch_for_nerdwallet_day_uniques_filtered_streaming_responses_YYYY-MM.csv.gz_YYYY-MM-DD':
        bucket_key = 'blisspoint_to_nw/streaming_responses/dw_eff_dt={ds}/nerdwallet_day_uniques_filtered_streaming_responses_{ds_yyyy_mm}.csv.gz_{ds}'.format(
            ds=context['ds'], ds_yyyy_mm=context['ds'][0:7])
    elif context['task'].task_id == 'Watch_for_nw_streaming_impressions_YYYY-MM-DD_YYYY_MM_000.csv.gz':
        bucket_key = 'blisspoint_to_nw/streaming_impressions/dw_eff_dt={ds}/nw_streaming_impressions_{ds}_{ds_yyyy_mm}_000.csv.gz'.format(
            ds=context['ds'], ds_yyyy_mm=context['ds'][0:7])
    elif context['task'].task_id=='Watch_for_streaming_spend.csv':
        bucket_key = 'blisspoint_to_nw/streaming_spend/dw_eff_dt={ds}/streaming_spend.csv'.format(
            ds=context['ds'])
    message_text = 'This is to notify the following S3 file is missing: s3://{bucket_name}/{bucket_key}'.format(
        bucket_name=context['task'].bucket_name,
        bucket_key=bucket_key
    )
    msg = MIMEText(message_text)
    from_address = 'dwh@nerdwallet.com'
    to_addresses = 'marketing-analytics@nerdwallet.com, sean@blisspointmedia.com, justin@blisspointmedia.com'
    msg['From'] = from_address
    msg['To'] = to_addresses
    msg['Subject'] = 'Bliss Point file not uploaded: ' + os.path.basename(bucket_key)
    s = smtplib.SMTP('localhost')
    s.sendmail(from_address, to_addresses.split(','), msg.as_string())
    s.quit()


default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 4, 16),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh'
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

task_upload_start_dag = DummyOperator(
    task_id='Initiating_upload_task',
    dag=dag)

############## External Dependenties ########################
task_mktg_consolidated_campaign_perf_f = ExternalTaskSensor(
    task_id='waiting_for_dag_daily_marketing.mktg_consolidated_campaign_perf_f',
    external_dag_id='dag_daily_marketing',
    external_task_id='mktg_consolidated_campaign_perf_f',
    dag=dag)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_upload_start_dag)

task_dw_session_event_f = ExternalTaskSensor(
    task_id='waiting_for_dag_daily_core_dwh.dw_session_event_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_session_event_f',
    dag=dag)
task_dw_session_event_f.set_upstream(task_start_dag)

task_mktg_offline_tv_r2c_external_dependency_1 = ExternalTaskSensor(
    task_id='waiting_for_dag_daily_core_dwh.status_update',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='status_update',
    dag=dag)
task_mktg_offline_tv_r2c_external_dependency_1.set_upstream(task_upload_start_dag)

task_mktg_offline_tv_r2c_external_dependency_2 = ExternalTaskSensor(
    task_id='waiting_for_dag_daily_aflt_tran.aflt_tran_consolidated_fact',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_consolidated_fact',
    dag=dag)
task_mktg_offline_tv_r2c_external_dependency_2.set_upstream(task_upload_start_dag)

task_blisspoint_media_spend_file = S3KeySensor(
    task_id='Watch_for_nw_daily_spend_tv_YYYY-MM-DD_000.csv',
    s3_conn_id='dwh_s3_sensor',
    bucket_name='nw-dwh-r2c',
    bucket_key='blisspoint_to_nw/daily_media_spend/dw_eff_dt={{ ds }}/nw_daily_spend_tv_{{ ds }}_000.csv',
    poke_interval=300,  # Check every 5 minutes
    timeout=82800,  # Wait for 23 hours
    retries=0,
    on_failure_callback=notify_bliss_point_missing_file,
    dag=dag)
task_blisspoint_media_spend_file.set_upstream(task_start_dag)

task_blisspoint_spot_report_file = S3KeySensor(
    task_id='Watch_for_nw_spot_report_YYYY-MM-DD_000.csv',
    s3_conn_id='dwh_s3_sensor',
    bucket_name='nw-dwh-r2c',
    bucket_key='blisspoint_to_nw/spot_report/dw_eff_dt={{ ds }}/nw_spot_report_{{ ds }}_000.csv',
    poke_interval=300,  # Check every 5 minutes
    timeout=82800,  # Wait for 23 hours
    retries=0,
    on_failure_callback=notify_bliss_point_missing_file,
    dag=dag)
task_blisspoint_spot_report_file.set_upstream(task_start_dag)

task_blisspoint_streaming_impressions_file = S3KeySensor(
    task_id='Watch_for_nw_streaming_impressions_YYYY-MM-DD_YYYY_MM_000.csv.gz',
    s3_conn_id='dwh_s3_sensor',
    bucket_name='nw-dwh-r2c',
    bucket_key='blisspoint_to_nw/streaming_impressions/dw_eff_dt={{ ds }}/nw_streaming_impressions_{{ ds }}_{{ macros.ds_format(ds, \'%Y-%m-%d\', \'%Y-%m\') }}_000.csv.gz',
    poke_interval=300,  # Check every 5 minutes
    timeout=82800,  # Wait for 23 hours
    retries=0,
    on_failure_callback=notify_bliss_point_missing_file,
    dag=dag)
task_blisspoint_streaming_impressions_file.set_upstream(task_start_dag)

# There are a dozen or so files in the streaming_responses folder. They are
# created in alphabetical order and the 'uniques_filtered_streaming_responses'
# file is the last one that gets uploaded.
task_blisspoint_streaming_responses_file = S3KeySensor(
    task_id='Watch_for_nerdwallet_day_uniques_filtered_streaming_responses_YYYY-MM.csv.gz_YYYY-MM-DD',
    s3_conn_id='dwh_s3_sensor',
    bucket_name='nw-dwh-r2c',
    bucket_key='blisspoint_to_nw/streaming_responses/dw_eff_dt={{ yesterday_ds }}/nerdwallet_day_uniques_filtered_streaming_responses_{{ macros.ds_format(ds, \'%Y-%m-%d\', \'%Y-%m\') }}.csv.gz_{{ yesterday_ds }}',
    poke_interval=300,  # Check every 5 minutes
    timeout=82800,  # Wait for 23 hours
    retries=0,
    on_failure_callback=notify_bliss_point_missing_file,
    dag=dag)
task_blisspoint_streaming_responses_file.set_upstream(task_start_dag)

task_blisspoint_media_spend_ntwk_file = S3KeySensor(
    task_id='Watch_for_streaming_spend.csv',
    s3_conn_id='dwh_s3_sensor',
    bucket_name='nw-dwh-r2c',
    bucket_key='blisspoint_to_nw/streaming_spend/dw_eff_dt={{ ds }}/streaming_spend.csv',
    poke_interval=300,  # Check every 5 minutes
    timeout=82800,  # Wait for 23 hours
    retries=0,
    on_failure_callback=notify_bliss_point_missing_file,
    dag=dag)
task_blisspoint_media_spend_ntwk_file.set_upstream(task_start_dag)


############# Status Updates ################################

task_mktg_offline_status_update_blisspoint_script = "/data/etl/Common/redshift_sql_function.sh"
task_mktg_offline_status_update_blisspoint = NWBashScriptOperator(
    bash_script=task_mktg_offline_status_update_blisspoint_script,
    script_args=["/data/etl/Airflow/post_updates/dag_daily_marketing_offline_status_update_blisspoint.sql"],
    task_id='mktg_offline_status_update_blisspoint',
    dag=dag)

############# Status Updates for upload session ################################

task_mktg_offline_status_update_blisspoint_upload_session_script = "/data/etl/Common/redshift_sql_function.sh"
task_mktg_offline_status_update_blisspoint_upload_session = NWBashScriptOperator(
    bash_script=task_mktg_offline_status_update_blisspoint_upload_session_script,
    script_args=["/data/etl/Airflow/post_updates/dag_daily_marketing_offline_status_update_blisspoint_upload_session.sql"],
    task_id='mktg_offline_status_update_blisspoint_upload_session',
    dag=dag)

################# Blisspoint #############################

task_mktg_offline_tv_blisspoint_upload_scheduled_script="/data/etl/Scripts/mktg_offline_tv_blisspoint_upload_scheduled/shellscripts/mktg_offline_tv_blisspoint_upload_scheduled.sh"
task_mktg_offline_tv_blisspoint_upload_scheduled = NWBashScriptOperator(
          bash_script=task_mktg_offline_tv_blisspoint_upload_scheduled_script,
          script_args=[],
          task_id='mktg_offline_tv_blisspoint_upload_scheduled',
          dag=dag)


task_mktg_offline_media_spend_f_script="/data/etl/Scripts/mktg_offline_media_spend_f/shellscripts/mktg_offline_media_spend_f.sh"
task_mktg_offline_media_spend_f = NWBashScriptOperator(
          bash_script=task_mktg_offline_media_spend_f_script,
          script_args=[],
          task_id='mktg_offline_media_spend_f',
          pool='redshift_etl',
          dag=dag)
task_mktg_offline_media_spend_f.set_upstream(task_blisspoint_media_spend_file)

task_mktg_offline_media_spend_ntwk_f_script="/data/etl/Scripts/mktg_offline_media_spend_ntwk_f/shellscripts/mktg_offline_media_spend_ntwk_f.sh"
task_mktg_offline_media_spend_ntwk_f = NWBashScriptOperator(
          bash_script=task_mktg_offline_media_spend_ntwk_f_script,
          script_args=[],
          task_id='mktg_offline_media_spend_ntwk_f',
          pool='redshift_etl',
          dag=dag)
task_mktg_offline_media_spend_ntwk_f.set_upstream(task_blisspoint_media_spend_ntwk_file)


task_mktg_blisspoint_spot_report_f_script="/data/etl/Scripts/mktg_blisspoint_spot_report_f/shellscripts/mktg_blisspoint_spot_report_f.sh"
task_mktg_blisspoint_spot_report_f = NWBashScriptOperator(
          bash_script=task_mktg_blisspoint_spot_report_f_script,
          script_args=[],
          task_id='mktg_blisspoint_spot_report_f',
          pool='redshift_etl',
          dag=dag)

task_mktg_blisspoint_stream_rsp_f_script="/data/etl/Scripts/mktg_blisspoint_stream_rsp_f/shellscripts/mktg_blisspoint_stream_rsp_f.sh"
task_mktg_blisspoint_stream_rsp_f = NWBashScriptOperator(
          bash_script=task_mktg_blisspoint_stream_rsp_f_script,
          script_args=[],
          task_id='mktg_blisspoint_stream_rsp_f',
          pool='redshift_etl',
          dag=dag)

task_mktg_blisspoint_stream_imprsn_f_script="/data/etl/Scripts/mktg_blisspoint_stream_imprsn_f/shellscripts/mktg_blisspoint_stream_imprsn_f.sh"
task_mktg_blisspoint_stream_imprsn_f = NWBashScriptOperator(
          bash_script=task_mktg_blisspoint_stream_imprsn_f_script,
          script_args=[],
          task_id='mktg_blisspoint_stream_imprsn_f',
          pool='redshift_etl',
          dag=dag)

task_mktg_offline_tv_blisspoint_upload_scheduled.set_upstream(task_mktg_offline_tv_r2c_external_dependency_1)
task_mktg_offline_tv_blisspoint_upload_scheduled.set_upstream(task_mktg_offline_tv_r2c_external_dependency_2)
task_mktg_offline_tv_blisspoint_upload_scheduled.set_upstream(task_mktg_consolidated_campaign_perf_f)

task_mktg_blisspoint_stream_imprsn_f.set_upstream(task_blisspoint_streaming_impressions_file)
task_mktg_blisspoint_stream_rsp_f.set_upstream(task_blisspoint_streaming_responses_file)
task_mktg_blisspoint_stream_rsp_f.set_upstream(task_dw_session_event_f)
task_mktg_blisspoint_spot_report_f.set_upstream(task_blisspoint_spot_report_file)

task_mktg_offline_status_update_blisspoint_upload_session.set_upstream(task_mktg_offline_tv_blisspoint_upload_scheduled)
task_mktg_offline_status_update_blisspoint.set_upstream(task_mktg_offline_media_spend_f)
task_mktg_offline_status_update_blisspoint.set_upstream(task_mktg_offline_media_spend_ntwk_f)
task_mktg_offline_status_update_blisspoint.set_upstream(task_mktg_blisspoint_spot_report_f)
task_mktg_offline_status_update_blisspoint.set_upstream(task_mktg_blisspoint_stream_rsp_f)
task_mktg_offline_status_update_blisspoint.set_upstream(task_mktg_blisspoint_stream_imprsn_f)
