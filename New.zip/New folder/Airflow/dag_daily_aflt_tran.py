from datetime import datetime, timedelta, time

from airflow import DAG
from airflow.models import Variable
from airflow.operators import DummyOperator
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_aflt_tran'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 9, 19),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_dw_aflt_tran_banking_f = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran_banking.dw_aflt_tran_banking_f',
    external_dag_id='dag_daily_aflt_tran_banking',
    external_task_id='dw_aflt_tran_banking_f',
    dag=dag)

task_dag_daily_core_dwh_dependency = ExternalTaskSensor(
    task_id='waiting_for_core_dwh_job_vacuum',
    external_dag_id='dag_daily_core_dwh_vacuum',
    external_task_id='status_update',
    dag=dag)

task_mktg_gs_dependency = ExternalTaskSensor(
    task_id='waiting_for_mktg_gs_load_dwh',
    external_dag_id='dag_daily_marketing_mta',
    external_task_id='mktg_gs_load_dwh',
    dag=dag)
###########################################################################
# Command tasks
###########################################################################

task_dw_aflt_tran_bonus_payments = NWBashScriptOperator(
    bash_script='/data/etl/Common/gs_to_table.sh',
    script_args=['https://docs.google.com/spreadsheets/d/1a2iO_hbmjQPd-l_z4nuhXCt1pdvQesMvAZswakBc9pM/edit#gid=0',
                 'BonusPayments', 'dw_stage', 'dw_aflt_tran_bonus_payments_s'],
    task_id='dw_aflt_tran_bonus_payments',
    dag=dag)
task_dw_aflt_tran_bonus_payments.set_upstream(task_start_dag)

task_aflt_tran_link_share_coupons = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_tran_link_share_coupon/shellscripts/aflt_tran_link_share_coupons.sh',
    script_args=[20],
    task_id='aflt_tran_link_share_coupons',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_link_share_coupons.set_upstream(task_dw_aflt_tran_bonus_payments)

task_aflt_tran_link_share_coupon_optimization_rpt = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_tran_link_share_coupon_optmzn_rpt/shellscripts/aflt_tran_link_share_coupon_optimization_rpt.sh',
    script_args=[20],
    task_id='aflt_tran_link_share_coupon_optimization_rpt',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_link_share_coupon_optimization_rpt.set_upstream(task_aflt_tran_link_share_coupons)

task_impact_extract = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/impact_extract/shellscripts/impact_extract.sh',
    script_args=[],
    task_id='impact_extract',
    pool='redshift_etl',
    dag=dag)
task_impact_extract.set_upstream(task_start_dag)

task_aflt_tran_impact_radius = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_impactradius_f/shellscripts/dw_aflt_tran_impactradius_f_load.sh',
    script_args=[],
    task_id='aflt_tran_impact_radius',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_impact_radius.set_upstream(task_impact_extract)
task_aflt_tran_impact_radius.set_upstream(task_dw_aflt_tran_bonus_payments)

task_aflt_tran_click_meter = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/clickmeter/shellscripts/clickmeter.sh',
    script_args=[],
    task_id='aflt_tran_click_meter',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_click_meter.set_upstream(task_start_dag)

task_aflt_tran_consolidated_fact = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_tran_consolidated_fact/shellscripts/aflt_tran_consolidated_fact.sh',
    script_args=[],
    task_id='aflt_tran_consolidated_fact',
    pool='redshift_etl',
    dag=dag)

task_dw_aflt_tran_citi_product_mapping = NWBashScriptOperator(
    bash_script='/data/etl/Common/gs_to_table.sh',
    script_args=['https://docs.google.com/spreadsheets/d/1z9uFUghn2fc8zfM3AhzpCVL2hWIMCu7grToxQMXdoJ0/',
                 'Sheet1', 'dw_report', 'dw_citi_cpa_d'],
    task_id='dw_aflt_tran_citi_product_mapping',
    pool='redshift_etl',
    dag=dag)
task_dw_aflt_tran_citi_product_mapping.set_upstream(task_start_dag)


task_aflt_tran_citi_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_citi_f/shellscripts/dw_aflt_tran_citi_f.sh',
    script_args=[],
    task_id='aflt_tran_citi_f',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_citi_f.set_upstream(task_dw_aflt_tran_citi_product_mapping)

task_aflt_tran_commission_junction = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_tran_commission_junction/shellscripts/aflt_tran_commission_junction.sh',
    script_args=[],
    task_id='aflt_tran_commission_junction',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_commission_junction.set_upstream(task_aflt_tran_citi_f)


task_aflt_tran_consolidated_fact.set_upstream(task_aflt_tran_commission_junction)
task_aflt_tran_consolidated_fact.set_upstream(task_aflt_tran_link_share_coupon_optimization_rpt)
task_aflt_tran_consolidated_fact.set_upstream(task_aflt_tran_impact_radius)
task_aflt_tran_consolidated_fact.set_upstream(task_dag_daily_core_dwh_dependency)
task_aflt_tran_consolidated_fact.set_upstream(task_aflt_tran_click_meter)
task_aflt_tran_consolidated_fact.set_upstream(task_dw_aflt_tran_banking_f)

task_status_update = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_sql_function.sh',
    script_args=['/data/etl/Airflow/post_updates/dag_daily_aflt_tran_status_update.sql'],
    task_id='status_update',
    dag=dag)
task_status_update.set_upstream(task_aflt_tran_consolidated_fact)

task_aflt_tran_link_share_prequal = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_tran_link_share_prequal/shellscripts/aflt_tran_link_share_prequal.sh',
    script_args=[],
    task_id='aflt_tran_link_share_prequal',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_link_share_prequal.set_upstream(task_start_dag)

task_aflt_tran_commission_junction_calls = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_com_junc_calls_f/shellscripts/dw_aflt_tran_com_junc_calls_f.sh',
    script_args=[],
    task_id='aflt_tran_commission_junction_calls',
    pool='redshift_etl',
    dag=dag)
task_aflt_tran_commission_junction_calls.set_upstream(task_start_dag)

task_dw_aflt_tran_hasoffers_extract_personalcapital = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_hasoffers_extract/shellscripts/dw_aflt_tran_hasoffers_extract.sh',
    script_args=['PersonalCapital', 'Investing'],
    task_id='personalcapital_extract',
    trigger_rule='all_done',
    dag=dag)
task_dw_aflt_tran_hasoffers_extract_personalcapital.set_upstream(task_start_dag)

task_dw_aflt_tran_hasoffers_extract_quickenloans = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_hasoffers_extract/shellscripts/dw_aflt_tran_hasoffers_extract.sh',
    script_args=['QuickenLoans', 'Mortgages'],
    task_id='quickenloans_extract',
    trigger_rule='all_done',
    dag=dag)
task_dw_aflt_tran_hasoffers_extract_quickenloans.set_upstream(task_start_dag)

task_dw_aflt_tran_hasoffers_extract_deserve = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_hasoffers_extract/shellscripts/dw_aflt_tran_hasoffers_extract.sh',
    script_args=['Deserve', '"Credit Cards"'],
    task_id='deserve_extract',
    trigger_rule='all_done',
    dag=dag)
task_dw_aflt_tran_hasoffers_extract_deserve.set_upstream(task_start_dag)

task_dw_aflt_tran_hasoffers_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_hasoffers_s/shellscripts/dw_aflt_tran_hasoffers_s.sh',
    script_args=[],
    task_id='dw_aflt_tran_hasoffers_s',
    pool='redshift_etl',
    dag=dag)
task_dw_aflt_tran_hasoffers_s.set_upstream(task_dw_aflt_tran_hasoffers_extract_quickenloans)
task_dw_aflt_tran_hasoffers_s.set_upstream(task_dw_aflt_tran_hasoffers_extract_personalcapital)
task_dw_aflt_tran_hasoffers_s.set_upstream(task_dw_aflt_tran_hasoffers_extract_deserve)

task_dw_aflt_tran_hasoffers_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_aflt_tran_hasoffers_f/shellscripts/dw_aflt_tran_hasoffers_f.sh',
    script_args=[],
    task_id='dw_aflt_tran_hasoffers_f',
    pool='redshift_etl',
    dag=dag)
task_dw_aflt_tran_hasoffers_f.set_upstream(task_dw_aflt_tran_hasoffers_s)

task_mktg_daily_epc_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_daily_epc_d/shellscripts/mktg_daily_epc_d.sh',
    script_args=[],
    task_id='mktg_daily_epc_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)
task_mktg_daily_epc_d.set_upstream(task_aflt_tran_consolidated_fact)
task_mktg_daily_epc_d.set_upstream(task_mktg_gs_dependency)
