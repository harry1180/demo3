from datetime import datetime, timedelta, time
import os
import sys

from airflow import DAG
from airflow.operators import BashOperator, DummyOperator
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

sys.path.append(os.path.dirname(__file__))  # Allow importing of modules from the same directory as our DAGs
import airflow_dwh

dag_name = 'dag_daily_core_dwh'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2015, 11, 12),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_job = TimeSensor(
    target_time=time(1, 15),
    task_id='Initiating_start_time',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_dw_prod_d_new_load = ExternalTaskSensor(
    task_id='dag_daily_nerdlake_to_dwh_core_p0.dw_prod_d_new',
    external_dag_id='dag_daily_nerdlake_to_dwh_core_p0',
    external_task_id='dw_prod_d_new',
    dag=dag)

task_dw_identity_d = ExternalTaskSensor(
    task_id='dag_daily_pud_identity.dw_identity_d',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_identity_d',
    dag=dag)

task_dag_kadu_event_consumption_prod = ExternalTaskSensor(
    task_id='dag_kadu_event_consumption_prod.kadu_done_success',
    external_dag_id='dag_kadu_event_consumption_prod',
    external_task_id='kadu_done_success',
    execution_delta=timedelta(hours=-23),
    poke_interval=5,
    dag=dag)

task_dw_wp_content_d = ExternalTaskSensor(
    task_id='dag_daily_wordpress.dw_wp_content_d',
    external_dag_id='dag_daily_wordpress',
    external_task_id='dw_wp_content_d',
    dag=dag)

task_dw_wp_category_d = ExternalTaskSensor(
    task_id='dag_daily_wordpress.dw_wp_category_d',
    external_dag_id='dag_daily_wordpress',
    external_task_id='dw_wp_category_d',
    dag=dag)

###########################################################################
# Event deserialize and load into staging (standard)
###########################################################################
event_names = {
    'BrokersClickEvent',
    'EmbedViewEvent',
    'PageViewEvent',
}
stage_load_task = dict()
for event_name in sorted(event_names, key=lambda s: s.lower()):
    deser_task = NWBashScriptOperator(
        bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
        script_args=[event_name],
        task_id='{}_deser'.format(event_name),
        dag=dag)
    deser_task.set_upstream(task_dag_kadu_event_consumption_prod)

    load_task = NWBashScriptOperator(
        bash_script='/data/etl/Common/redshift_load_event_stage_table.sh',
        script_args=[event_name],
        task_id='pbclass_{}_s'.format(event_name),
        pool='redshift_etl',
        dag=dag)
    load_task.set_upstream(deser_task)
    stage_load_task[event_name] = load_task

###########################################################################
# Command tasks
###########################################################################
task_wp_staging = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/wp_staging/shellscripts/wp_staging.sh',
    script_args=[],
    task_id='wp_staging',
    pool='redshift_etl',
    dag=dag)
task_wp_staging.set_upstream(task_dw_wp_category_d)

task_dw_prod_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_s/shellscripts/dw_prod_s.sh',
    script_args=[],
    task_id='dw_prod_s',
    pool='redshift_etl',
    dag=dag)
task_dw_prod_s.set_upstream(task_dw_prod_d_new_load)

task_dw_prod_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_d/shellscripts/dw_prod_d.sh',
    script_args=[],
    task_id='dw_prod_d',
    pool='redshift_etl',
    dag=dag)
task_dw_prod_d.set_upstream(task_dw_prod_s)

task_ExperimentExposureEvent_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['ExperimentExposureEvent'],
    task_id='ExperimentExposureEvent',
    dag=dag)
task_ExperimentExposureEvent_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_1_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['CCClickEvent'],
    task_id='clicks_event_cc_deserialization',
    dag=dag)

task1_2_script="/data/etl/Scripts/ccclicks_event_s/shellscripts/CCClickEvent_stage_load.sh"
task1_2_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_2_script,
    script_args=[],
    task_id='clicks_event_cc_s',
    pool='redshift_etl',
    dag=dag)

task1_3_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['CreditScoreClickEvent'],
    task_id='clicks_event_credit_score_deserialization',
    dag=dag)

task1_4_script="/data/etl/Scripts/click_event_credit_score_s/shellscripts/click_event_credit_score_s.sh"
task1_4_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_4_script,
    script_args=[],
    task_id='clicks_event_credit_score_s',
    pool='redshift_etl',
    dag=dag)

task1_5_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['GenericClickEvent'],
    task_id='clicks_event_generic_deserialization',
    dag=dag)

task1_6_script="/data/etl/Scripts/click_event_generic_s/shellscripts/click_event_generic_s.sh"
task1_6_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_6_script,
    script_args=[],
    task_id='clicks_event_generic_s',
    pool='redshift_etl',
    dag=dag)


task1_7_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['InsuranceClickEvent'],
    task_id='clicks_event_insurance_provider_deserialization',
    dag=dag)

task1_8_script="/data/etl/Scripts/click_event_insurance_s/shellscripts/click_event_insurance_s.sh"
task1_8_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_8_script,
    script_args=[],
    task_id='clicks_event_insurance_provider_s',
    pool='redshift_etl',
    dag=dag)

task1_9_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['InvestingClickEvent'],
    task_id='clicks_event_brokerage_deserialization',
    dag=dag)

task1_10_script="/data/etl/Scripts/click_event_investing_s/shellscripts/click_event_investing_s.sh"
task1_10_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_10_script,
    script_args=[],
    task_id='clicks_event_brokerage_s',
    pool='redshift_etl',
    dag=dag)

task1_11_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['PrepaidClickEvent'],
    task_id='clicks_event_prepaid_card_deserialization',
    dag=dag)

task1_12_script="/data/etl/Scripts/click_event_prepaid_s/shellscripts/click_event_prepaid_s.sh"
task1_12_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_12_script,
    script_args=[],
    task_id='clicks_event_prepaid_card_s',
    pool='redshift_etl',
    dag=dag)

task1_13_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['RateClickEvent'],
    task_id='clicks_event_rate_deserialization',
    dag=dag)

task1_14_script="/data/etl/Scripts/click_event_rate_s/shellscripts/click_event_rate_s.sh"
task1_14_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_14_script,
    script_args=[],
    task_id='clicks_event_rate_s',
    pool='redshift_etl',
    dag=dag)


task1_15_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['TaxesClickEvent'],
    task_id='clicks_event_tax_deserialization',
    dag=dag)

task1_16_script="/data/etl/Scripts/click_event_taxes_s/shellscripts/click_event_taxes_s.sh"
task1_16_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_16_script,
    script_args=[],
    task_id='clicks_event_tax_s',
    pool='redshift_etl',
    dag=dag)

task1_17_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['InsuranceProductClickEvent'],
    task_id='clicks_event_insurance_product_deserialization',
    dag=dag)

task1_18_script="/data/etl/Scripts/click_event_insurance_product_s/shellscripts/click_event_insurance_product_s.sh"
task1_18_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_18_script,
    script_args=[],
    task_id='clicks_event_insurance_product_s',
    pool='redshift_etl',
    dag=dag)

task1_19_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['ShoppingClickEvent'],
    task_id='clicks_event_shopping_deserialization',
    dag=dag)

task1_20_script="/data/etl/Scripts/click_event_shopping_s/shellscripts/click_event_shopping_s.sh"
task1_20_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_20_script,
    script_args=[],
    task_id='clicks_event_shopping_s',
    pool='redshift_etl',
    dag=dag)

task1_21_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['PersonalLoansClickEvent'],
    task_id='clicks_event_pl_deserialization',
    dag=dag)

task1_22_script="/data/etl/Scripts/click_event_personal_loans_s/shellscripts/click_event_personal_loans_s.sh"
task1_22_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_22_script,
    script_args=[],
    task_id='clicks_event_pl_s',
    pool='redshift_etl',
    dag=dag)

task1_23_script="/data/etl/Scripts/SMBClickEvent/shellscripts/SMBClickEvent.sh"
task1_23_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['SMBClickEvent'],
    task_id='clicks_event_smb_deserialization',
    dag=dag)

task1_24_script="/data/etl/Scripts/click_event_smb_s/shellscripts/click_event_smb_s.sh"
task1_24_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_24_script,
    script_args=[],
    task_id='clicks_event_smb_s',
    pool='redshift_etl',
    dag=dag)

task1_27_clicks_event_deserialization = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['MortgageLenderClickEvent'],
    task_id='clicks_event_mrtg_deserialization',
    dag=dag)

task1_28_script="/data/etl/Scripts/click_event_mortgage_s/shellscripts/click_event_mortgage_s.sh"
task1_28_clicks_event_s = NWBashScriptOperator(
    bash_script=task1_28_script,
    script_args=[],
    task_id='clicks_event_mrtg_s',
    pool='redshift_etl',
    dag=dag)

task1_99_click_event_post_s = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/click_event_post_s/shellscripts/click_event_post_s.sh",
    script_args=[],
    task_id='click_event_post_s',
    pool='redshift_etl',
    dag=dag)

# task29_script="/data/etl/Scripts/dw_creditcard_catg_d/shellscripts/dw_creditcard_catg_d.sh"
# task29_cc_catg = NWBashScriptOperator(
#     bash_script=task29_script,
#     script_args=[],
#     task_id='cc_catg',
#     pool='redshift_etl',
#     dag=dag)

task5_script="/data/etl/Scripts/dw_referral_d/shellscripts/dw_referral_d.sh"
task5_dw_referral_d = NWBashScriptOperator(
    bash_script=task5_script,
    script_args=[],
    task_id='dw_referral_d',
    pool='redshift_etl',
    dag=dag)

task_url_unload_s = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/url_unload_s/shellscripts/url_unload_s.sh",
    script_args=[],
    task_id='url_unload_s',
    pool='redshift_etl',
    dag=dag)

task_url_stage_s_new_daily = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/url_stage_s/shellscripts/url_stage_s.sh",
    script_args=["new_daily"],
    task_id='url_stage_s_new_daily',
    pool='redshift_etl',
    dag=dag)

task7_dw_page_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_d/shellscripts/dw_page_d.sh',
    script_args=[],
    task_id='dw_page_d',
    pool='redshift_etl',
    dag=dag)


task_page_detail_script="/data/etl/Scripts/dw_page_detail_d/shellscripts/dw_page_detail_d.sh"
task_dw_page_detail_d = NWBashScriptOperator(
    bash_script=task_page_detail_script,
    script_args=[],
    task_id='dw_page_detail_d',
    pool='redshift_etl',
    dag=dag)


task8_dw_url_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_url_d/shellscripts/dw_url_d.sh',
    script_args=[],
    task_id='dw_url_d',
    pool='redshift_etl',
    dag=dag)

task_url_detail_script="/data/etl/Scripts/dw_url_detail_d/shellscripts/dw_url_detail_d.sh"
task_dw_url_detail_d = NWBashScriptOperator(
    bash_script=task_url_detail_script,
    script_args=[],
    task_id='dw_url_detail_d',
    pool='redshift_etl',
    dag=dag)

task10_script="/data/etl/Scripts/site_visitor_d/shellscripts/site_visitor_d_full_load.sh"
task10_site_visitor_d = NWBashScriptOperator(
    bash_script=task10_script,
    script_args=[],
    task_id='site_visitor_d',
    pool='redshift_etl',
    dag=dag)

task11_script="/data/etl/Scripts/dw_user_agent_d/shellscripts/user_agent_d.sh"
task11_dw_user_agent_d = NWBashScriptOperator(
    bash_script=task11_script,
    script_args=[],
    task_id='dw_user_agent_d',
    pool='redshift_etl',
    dag=dag)

task_dw_page_view_event_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_view_event_f/shellscripts/dw_page_view_event_f.sh',
    script_args=[],
    task_id='page_view_event_f',
    pool='redshift_etl',
    dag=dag)

task_dw_clicks_event_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_clicks_event_f/shellscripts/dw_clicks_event_f.sh',
    script_args=[],
    task_id='clicks_event_fact',
    pool='redshift_etl',
    dag=dag)

task19_script="/data/etl/Scripts/dw_session_event_f/shellscripts/dw_session_event_f.sh"
task19_dw_session_event_f = NWBashScriptOperator(
    bash_script=task19_script,
    script_args=[],
    task_id='dw_session_event_f',
    pool='redshift_etl',
    dag=dag)

task21_script="/data/etl/Scripts/dw_click_event_pl_f/shellscripts/dw_click_event_pl_f.sh"
task21_dw_click_event_pl_f = NWBashScriptOperator(
    bash_script=task21_script,
    script_args=[],
    task_id='dw_click_event_pl_f',
    pool='redshift_etl',
    dag=dag)

task22_script="/data/etl/Scripts/dw_click_event_smb_f/shellscripts/dw_click_event_smb_f.sh"
task22_dw_click_event_smb_f = NWBashScriptOperator(
    bash_script=task22_script,
    script_args=[],
    task_id='dw_click_event_smb_f',
    pool='redshift_etl',
    dag=dag)

task23_script="/data/etl/Scripts/dw_click_event_broker_f/shellscripts/dw_click_event_broker_f.sh"
task23_dw_click_event_broker_f = NWBashScriptOperator(
    bash_script=task23_script,
    script_args=[],
    task_id='dw_click_event_broker_f',
    pool='redshift_etl',
    dag=dag)

task24_script="/data/etl/Scripts/dw_click_event_mrtg_f/shellscripts/dw_click_event_mrtg_f.sh"
task24_dw_click_event_mrtg_f = NWBashScriptOperator(
    bash_script=task24_script,
    script_args=[],
    task_id='dw_click_event_mrtg_f',
    pool='redshift_etl',
    dag=dag)

task_optimizely_protobuf_json_script="/data/etl/Scripts/OptimizelyExperimentsEvent/shellscripts/OptimizelyExperimentsEvent.sh"
task_optimizely_protobuf_json = NWBashScriptOperator(
    bash_script=task_optimizely_protobuf_json_script,
    script_args=[],
    task_id='OptimizelyExperimentsEvent',
    dag=dag)
task_optimizely_protobuf_json.set_upstream(task_dag_kadu_event_consumption_prod)

task_optimizely_experiment_stage_load_script="/data/etl/Scripts/OptimizelyExperimentsEvent_s/shellscripts/OptimizelyExperimentsEvent_s.sh"
task_optimizely_experiment_stage_load = NWBashScriptOperator(
    bash_script=task_optimizely_experiment_stage_load_script,
    script_args=[],
    task_id='optimizely_experiment_stage_load',
    pool='redshift_etl',
    dag=dag)

task_optimizely_load_script="/data/etl/Scripts/dw_page_view_event_exp_var_xref_f/shellscripts/dw_page_view_event_exp_var_xref_f.sh"
task_optimizely_load = NWBashScriptOperator(
    bash_script=task_optimizely_load_script,
    script_args=[],
    task_id='optimizely_load',
    pool='redshift_etl',
    dag=dag)

task_pageviewevent_ab_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/PageViewEvent_AB_s/shellscripts/PageViewEvent_AB_s.sh',
    script_args=[],
    task_id='pageviewevent_ab_s',
    pool='redshift_etl',
    dag=dag)

task_dw_page_view_event_src_map_dw_page_view = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_page_view_event_src_map_dw_page_view/shellscripts/dw_page_view_event_src_map_dw_page_view.sh',
    script_args=[],
    task_id='dw_page_view_event_src_map_dw_page_view',
    pool='redshift_etl',
    dag=dag)
task_dw_page_view_event_src_map_dw_page_view.set_upstream(task_dw_page_view_event_f)
task_dw_page_view_event_src_map_dw_page_view.set_upstream(task8_dw_url_d)

task_pageview_ab_xref_fact_script="/data/etl/Scripts/dw_page_view_event_exp_var_xref_f_ab/shellscripts/dw_page_view_event_exp_var_xref_f_ab.sh"
task_pageview_ab_xref_fact_load = NWBashScriptOperator(
    bash_script=task_pageview_ab_xref_fact_script,
    script_args=[],
    task_id='pageview_ab_xref_fact_load',
    pool='redshift_etl',
    dag=dag)

task_pageview_xy_xref_fact_script="/data/etl/Scripts/dw_page_view_event_exp_var_xref_f_xy/shellscripts/dw_page_view_event_exp_var_xref_f_xy.sh"
task_pageview_xy_xref_fact_load = NWBashScriptOperator(
    bash_script=task_pageview_xy_xref_fact_script,
    script_args=[],
    task_id='pageview_xy_xref_fact_load',
    pool='redshift_etl',
    dag=dag)

task_pageview_trkng_param_stage_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_page_view_event_trkng_param_s/shellscripts/dw_page_view_event_trkng_param_s.sh",
    script_args=[],
    task_id='dw_page_view_event_trkng_param_s',
    pool='redshift_etl',
    dag=dag)

task_pageview_trkng_param_fact_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_page_view_event_trkng_param_f/shellscripts/dw_page_view_event_trkng_param_f.sh",
    script_args=[],
    task_id='dw_page_view_event_trkng_param_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_trkng_param_stage_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_mktg_trkng_param_s/shellscripts/dw_mktg_trkng_param_s.sh",
    script_args=[],
    task_id='mktg_trkng_param_stage_load',
    pool='redshift_etl',
    dag=dag)

task_mktg_trkng_param_fact_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_mktg_trkng_param_f/shellscripts/dw_mktg_trkng_param_f.sh",
    script_args=[],
    task_id='mktg_trkng_param_fact_load',
    pool='redshift_etl',
    dag=dag)

task_dw_ab_test_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_ab_test_d/shellscripts/dw_ab_test_d.sh',
    script_args=[],
    task_id='dw_ab_test_d',
    pool='redshift_etl',
    dag=dag)

task_dw_ab_adm_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_ab_adm_d/shellscripts/dw_ab_adm_d.sh',
    script_args=[],
    task_id='dw_ab_adm_d',
    pool='redshift_etl',
    dag=dag)

task_dw_ab_ramp_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_ab_ramp_d/shellscripts/dw_ab_ramp_d.sh',
    script_args=[],
    task_id='dw_ab_ramp_d',
    pool='redshift_etl',
    dag=dag)

task_dw_ab_state_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_ab_state_d/shellscripts/dw_ab_state_d.sh',
    script_args=[],
    task_id='dw_ab_state_d',
    pool='redshift_etl',
    dag=dag)

task_dw_ab_variant_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_ab_variant_d/shellscripts/dw_ab_variant_d.sh',
    script_args=[],
    task_id='dw_ab_variant_d',
    pool='redshift_etl',
    dag=dag)

task_heart_beat_deserialization_load = NWBashScriptOperator(
    bash_script='/data/etl/Common/deserialize_pb_dwh.sh',
    script_args=['HeartbeatEvent'],
    task_id='heart_beat_event_deserialization',
    dag=dag)


task_heart_beat_stage_script="/data/etl/Scripts/heart_beat_event_s/shellscripts/heart_beat_event_s.sh"
task_heart_beat_stage_load = NWBashScriptOperator(
    bash_script=task_heart_beat_stage_script,
    script_args=[],
    task_id='heart_beat_event_stage_load',
    pool='redshift_etl',
    dag=dag)


task_heart_beat_fact_script="/data/etl/Scripts/dw_pv_heart_beat_event_f/shellscripts/dw_pv_heart_beat_event_f.sh"
task_heart_beat_fact_load = NWBashScriptOperator(
    bash_script=task_heart_beat_fact_script,
    script_args=[],
    task_id='heart_beat_event_fact_load',
    pool='redshift_etl',
    dag=dag)


task_heart_beat_rollup_script="/data/etl/Scripts/dw_pv_heart_beat_rollup_f/shellscripts/dw_pv_heart_beat_rollup_f.sh"
task_heart_beat_rollup_load = NWBashScriptOperator(
    bash_script=task_heart_beat_rollup_script,
    script_args=[],
    task_id='heart_beat_event_rollup_load',
    pool='redshift_etl',
    dag=dag)


task21_script="/data/etl/Common/redshift_sql_function.sh"
task21_status_update = NWBashScriptOperator(
    bash_script=task21_script,
    script_args=["/data/etl/Airflow/post_updates/dag_daily_core_dwh_status_update.sql"],
    task_id='status_update',
    priority_weight=100,
    dag=dag)

task_status_update_notify = airflow_dwh.send_slack_message_task_complete(
    channel='#dwh-oncall',
    task=task21_status_update)

task_optimizely_stage_pull_script="/data/etl/Scripts/optimizely_stage_pull/shellscripts/optimizely_stage_pull.sh"
task_optimizely_stage_pull = NWBashScriptOperator(
    bash_script=task_optimizely_stage_pull_script,
    script_args=[],
    task_id='optimizely_stage_pull',
    dag=dag)

task_optimizely_project_d_script="/data/etl/Scripts/optimizely_project_d/shellscripts/optimizely_project_d.sh"
task_optimizely_project_d = NWBashScriptOperator(
    bash_script=task_optimizely_project_d_script,
    script_args=[],
    task_id='optimizely_project_d',
    pool='redshift_etl',
    dag=dag)


task_optimizely_experiment_d_script="/data/etl/Scripts/optimizely_experiment_d/shellscripts/optimizely_experiment_d.sh"
task_optimizely_experiment_d = NWBashScriptOperator(
    bash_script=task_optimizely_experiment_d_script,
    script_args=[],
    task_id='optimizely_experiment_d',
    pool='redshift_etl',
    dag=dag)

task_optimizely_variant_d_script="/data/etl/Scripts/optimizely_variant_d/shellscripts/optimizely_variant_d.sh"
task_optimizely_variant_d = NWBashScriptOperator(
    bash_script=task_optimizely_variant_d_script,
    script_args=[],
    task_id='optimizely_variant_d',
    pool='redshift_etl',
    dag=dag)

task33_script="/data/etl/Scripts/experiment_exposure_event_s/shellscripts/experiment_exposure_event_s.sh"
task33_ExperimentExposureEvent_Stage_Load = NWBashScriptOperator(
    bash_script=task33_script,
    script_args=[],
    task_id='ExperimentExposureEvent_Stage_Load',
    pool='redshift_etl',
    dag=dag)
task33_ExperimentExposureEvent_Stage_Load.set_upstream(task_ExperimentExposureEvent_deserialization)

task37_script="/data/etl/Scripts/dw_expmt_expsr_event_f/shellscripts/dw_expmt_expsr_event_f.sh"
task37_dw_expmt_expsr_event_Fact_Load = NWBashScriptOperator(
    bash_script=task37_script,
    script_args=[],
    task_id='dw_expmt_expsr_event_f',
    pool='redshift_etl',
    dag=dag)

task_dw_google_kw_ftrd_snpt_prfmnc_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_google_kw_ftrd_snpt_prfmnc_f/shellscripts/dw_google_kw_ftrd_snpt_prfmnc_f.sh',
    script_args=[],
    task_id='dw_google_kw_ftrd_snpt_prfmnc_f',
    pool='redshift_etl',
    dag=dag)

task_dw_clicks_enriched = DummyOperator(
    task_id='dw_clicks_enriched',
    dag=dag)
task_dw_clicks_enriched.set_upstream(task_dw_clicks_event_f)
task_dw_clicks_enriched.set_upstream(task_dw_prod_d)
task_dw_clicks_enriched.set_upstream(task11_dw_user_agent_d)
task_dw_clicks_enriched.set_upstream(task_dw_page_detail_d)

task_ab_status_update = DummyOperator(
    task_id='ab_status_update',
    dag=dag)

task1_1_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_2_clicks_event_s.set_upstream(task1_1_clicks_event_deserialization)

task1_3_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_4_clicks_event_s.set_upstream(task1_3_clicks_event_deserialization)

task1_5_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_6_clicks_event_s.set_upstream(task1_5_clicks_event_deserialization)

task1_7_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_8_clicks_event_s.set_upstream(task1_7_clicks_event_deserialization)

task1_9_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_10_clicks_event_s.set_upstream(task1_9_clicks_event_deserialization)

task1_11_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_12_clicks_event_s.set_upstream(task1_11_clicks_event_deserialization)

task1_13_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_14_clicks_event_s.set_upstream(task1_13_clicks_event_deserialization)

task1_15_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_16_clicks_event_s.set_upstream(task1_15_clicks_event_deserialization)

task1_17_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_18_clicks_event_s.set_upstream(task1_17_clicks_event_deserialization)

task1_19_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_20_clicks_event_s.set_upstream(task1_19_clicks_event_deserialization)

task1_21_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_22_clicks_event_s.set_upstream(task1_21_clicks_event_deserialization)

task1_23_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_24_clicks_event_s.set_upstream(task1_23_clicks_event_deserialization)

task1_27_clicks_event_deserialization.set_upstream(task_dag_kadu_event_consumption_prod)

task1_28_clicks_event_s.set_upstream(task1_27_clicks_event_deserialization)


task1_99_click_event_post_s.set_upstream(task1_2_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_4_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_6_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_8_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_10_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_12_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_14_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_16_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_18_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_20_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_22_clicks_event_s)

task1_99_click_event_post_s.set_upstream(task1_24_clicks_event_s)

task1_99_click_event_post_s.set_upstream(stage_load_task['BrokersClickEvent'])

task1_99_click_event_post_s.set_upstream(task1_28_clicks_event_s)

task_dw_ab_test_d.set_upstream(task_start_job)

task_dw_ab_adm_d.set_upstream(task_start_job)

task_dw_ab_ramp_d.set_upstream(task_start_job)

task_dw_ab_state_d.set_upstream(task_start_job)

task_dw_ab_variant_d.set_upstream(task_start_job)

task_heart_beat_deserialization_load.set_upstream(task_dag_kadu_event_consumption_prod)

task_optimizely_stage_pull.set_upstream(task_start_job)

task5_dw_referral_d.set_upstream(stage_load_task['PageViewEvent'])

task_url_unload_s.set_upstream(stage_load_task['PageViewEvent'])

task_url_stage_s_new_daily.set_upstream(task_url_unload_s)
task_url_stage_s_new_daily.set_upstream(task_dw_wp_content_d)
task_url_stage_s_new_daily.set_upstream(task_wp_staging)

task7_dw_page_d.set_upstream(task_url_stage_s_new_daily)

task8_dw_url_d.set_upstream(task7_dw_page_d)

task_dw_page_detail_d.set_upstream(task7_dw_page_d)
task_dw_url_detail_d.set_upstream(task8_dw_url_d)

task10_site_visitor_d.set_upstream(stage_load_task['PageViewEvent'])
task10_site_visitor_d.set_upstream(task1_99_click_event_post_s)

task11_dw_user_agent_d.set_upstream(stage_load_task['PageViewEvent'])
task11_dw_user_agent_d.set_upstream(task1_99_click_event_post_s)

# task_dw_page_view_event_f.set_upstream(task_dw_identity_d)
task_dw_page_view_event_f.set_upstream(task5_dw_referral_d)
task_dw_page_view_event_f.set_upstream(task8_dw_url_d)
task_dw_page_view_event_f.set_upstream(task10_site_visitor_d)
task_dw_page_view_event_f.set_upstream(task11_dw_user_agent_d)
task_dw_page_view_event_f.set_upstream(task7_dw_page_d)
task_dw_page_view_event_f.set_upstream(task_dw_page_detail_d)
task_dw_page_view_event_f.set_upstream(stage_load_task['PageViewEvent'])

task_heart_beat_stage_load.set_upstream(task_heart_beat_deserialization_load)
task_heart_beat_fact_load.set_upstream(task_heart_beat_stage_load)
task_heart_beat_fact_load.set_upstream(task10_site_visitor_d)
task_heart_beat_rollup_load.set_upstream(task_heart_beat_fact_load)

task19_dw_session_event_f.set_upstream(task_dw_page_view_event_f)
task19_dw_session_event_f.set_upstream(task7_dw_page_d)
task19_dw_session_event_f.set_upstream(task_heart_beat_rollup_load)

task_dw_clicks_event_f.set_upstream(task19_dw_session_event_f)
task_dw_clicks_event_f.set_upstream(task1_99_click_event_post_s)
task_dw_clicks_event_f.set_upstream(task_dw_prod_d)
task_dw_clicks_event_f.set_upstream(task10_site_visitor_d)
task_dw_clicks_event_f.set_upstream(task11_dw_user_agent_d)
task_dw_clicks_event_f.set_upstream(task_dw_page_view_event_f)
task_dw_clicks_event_f.set_upstream(task_dw_page_detail_d)

task21_dw_click_event_pl_f.set_upstream(task19_dw_session_event_f)

task22_dw_click_event_smb_f.set_upstream(task19_dw_session_event_f)

task23_dw_click_event_broker_f.set_upstream(task19_dw_session_event_f)

task24_dw_click_event_mrtg_f.set_upstream(task19_dw_session_event_f)

task_optimizely_experiment_stage_load.set_upstream(task_optimizely_protobuf_json)

task_optimizely_project_d.set_upstream(task_optimizely_stage_pull)

task_optimizely_experiment_d.set_upstream(task_optimizely_stage_pull)
task_optimizely_experiment_d.set_upstream(task_optimizely_experiment_stage_load)

task_optimizely_variant_d.set_upstream(task_optimizely_experiment_d)

#task_optimizely_load.set_upstream(task_optimizely_variant_d)
#task_optimizely_load.set_upstream(task10_site_visitor_d)
task_optimizely_load.set_upstream(task_pageview_ab_xref_fact_load)

task_pageviewevent_ab_s.set_upstream(task_optimizely_variant_d)
task_pageviewevent_ab_s.set_upstream(task10_site_visitor_d)

task_pageview_ab_xref_fact_load.set_upstream(task_pageviewevent_ab_s)
task_pageview_ab_xref_fact_load.set_upstream(task_dw_page_view_event_src_map_dw_page_view)
task_pageview_ab_xref_fact_load.set_upstream(task10_site_visitor_d)
task_pageview_ab_xref_fact_load.set_upstream(task_dw_ab_variant_d)

task_pageview_xy_xref_fact_load.set_upstream(task_pageview_ab_xref_fact_load)

task_pageview_trkng_param_stage_load.set_upstream(stage_load_task['PageViewEvent'])
task_pageview_trkng_param_fact_load.set_upstream(task_pageview_trkng_param_stage_load)
task_pageview_trkng_param_fact_load.set_upstream(task_dw_page_view_event_src_map_dw_page_view)
task_pageview_trkng_param_fact_load.set_upstream(task8_dw_url_d)
task_pageview_trkng_param_fact_load.set_upstream(task_dw_page_view_event_f)

task_mktg_trkng_param_stage_load.set_upstream(stage_load_task['PageViewEvent'])
task_mktg_trkng_param_fact_load.set_upstream(task_mktg_trkng_param_stage_load)
task_mktg_trkng_param_fact_load.set_upstream(task_dw_page_view_event_f)

task21_status_update.set_upstream(task_dw_clicks_event_f)
task21_status_update.set_upstream(task21_dw_click_event_pl_f)
task21_status_update.set_upstream(task22_dw_click_event_smb_f)
task21_status_update.set_upstream(task23_dw_click_event_broker_f)
task21_status_update.set_upstream(task24_dw_click_event_mrtg_f)
#task21_status_update.set_upstream(task_ab_config_test_load)
#task21_status_update.set_upstream(task_ab_config_adm_load)
#task21_status_update.set_upstream(task_ab_config_ramp_load)
#task21_status_update.set_upstream(task_ab_config_state_load)
#task21_status_update.set_upstream(task_ab_config_variant_load)
#task21_status_update.set_upstream(task_xylogevent_fact_load) # remove AB dependency/downstream impact on the status_update
#task21_status_update.set_upstream(task_pageview_trkng_param_fact_load) # don't create dependency at present to the task21_status_update
task21_status_update.set_upstream(task_heart_beat_rollup_load)
task21_status_update.set_upstream(task_dw_page_detail_d)
#task21_status_update.set_upstream(task_optimizely_project_d)
task21_status_update.set_upstream(task_dw_google_kw_ftrd_snpt_prfmnc_f)

task37_dw_expmt_expsr_event_Fact_Load.set_upstream(task33_ExperimentExposureEvent_Stage_Load)
task37_dw_expmt_expsr_event_Fact_Load.set_upstream(task_pageview_ab_xref_fact_load)

task_dw_google_kw_ftrd_snpt_prfmnc_f.set_upstream(task8_dw_url_d)

task_ab_status_update.set_upstream(task37_dw_expmt_expsr_event_Fact_Load)
task_ab_status_update.set_upstream(task_pageview_xy_xref_fact_load)
task_ab_status_update.set_upstream(task_optimizely_load)
