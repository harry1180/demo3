import sys
from datetime import *
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_dwhops_redshift_memory_monitor"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2017, 1, 5),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval='*/3 * * * *')


task_perf_memory_monitor_script="/data/etl/Scripts/dw_dba_redshift_memory_utilization/shellscripts/dw_memory_utilization.sh"
task_perf_memory_monitor = NWBashScriptOperator(
    bash_script=task_perf_memory_monitor_script,
    script_args=[],
    task_id='Redshift_memory_monitor',
    dag=dag)
