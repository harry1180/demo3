from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators import NWBashScriptOperator, ExternalTaskSensor, DummyOperator


job_name = "dag_daily_nerdlake_core_p0"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime.now().replace(minute=0, second=0, microsecond=0) - timedelta(days=2),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=10),
    'depends_on_past': True
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

###########################################################################
# Command tasks
###########################################################################

task_dw_marketplace_export_s_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_marketplace_export_s/shellscripts/dw_marketplace_export_s.sh',
    script_args=[],
    task_id='dw_marketplace_export_s',
    dag=dag)
task_dw_marketplace_export_s_load.set_upstream(task_start_dag)

task_dw_inst_d_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_inst_d_nerdlake/shellscripts/dw_inst_d_nerdlake.sh',
    script_args=[],
    task_id='dw_inst_d_load',
    pool='presto_etl',
    dag=dag)
task_dw_inst_d_load.set_upstream(task_dw_marketplace_export_s_load)

task_dw_prod_d_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_d_nerdlake/shellscripts/dw_prod_d_nerdlake.sh',
    script_args=[],
    task_id='dw_prod_d_load',
    pool='presto_etl',
    dag=dag)
task_dw_prod_d_load.set_upstream(task_dw_marketplace_export_s_load)

task_dw_offer_d_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_offer_d_nerdlake/shellscripts/dw_offer_d_nerdlake.sh',
    script_args=[],
    task_id='dw_offer_d_load',
    pool='presto_etl',
    dag=dag)
task_dw_offer_d_load.set_upstream(task_dw_marketplace_export_s_load)

task_offer_api_load_complete = DummyOperator(
    task_id='offer_api_load_complete',
    dag=dag)
task_offer_api_load_complete.set_upstream(task_dw_inst_d_load)
task_offer_api_load_complete.set_upstream(task_dw_prod_d_load)
task_offer_api_load_complete.set_upstream(task_dw_offer_d_load)
