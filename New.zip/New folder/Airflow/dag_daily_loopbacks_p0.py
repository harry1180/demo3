from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators import BashOperator, DummyOperator, NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor, TimeSensor

job_name = "dag_daily_loopbacks_p0"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 8, 2),
    'email': ['airflowalerts@nerdwallet.com','dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))


################################################################################
# External tasks
################################################################################

task_dw_user_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_user_d',
    external_dag_id='dag_daily_identity',
    external_task_id='dw_user_d',
    dag=dag)

task_dw_user_actvy_smry_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_user_actvy_smry_f',
    external_dag_id='dag_daily_identity',
    external_task_id='dw_user_actvy_smry_f',
    dag=dag)

task_dw_identity_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_identity_d',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_identity_d',
    dag=dag)

task_dw_page_detail_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_page_detail_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_page_detail_d',
    dag=dag)
    
task_dw_actvy_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_actvy_f',
    external_dag_id='dag_daily_activity_merge',
    external_task_id='dw_actvy_f_non_core_Fact_Load',
    dag=dag)
    
task_dw_prod_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_prod_d',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_prod_d',
    dag=dag)

task_dw_feed_elem_imprsn_event_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_feed_elem_imprsn_event_f',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='FeedElementImpressionEvent_Fact_Load',
    dag=dag)

task_dw_feed_elem_intactn_event_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_feed_elem_intactn_event_f',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='FeedElementInteractionEvent_Fact_Load',
    dag=dag)

task_dw_feed_item_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_feed_item_d',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_feed_item_d',
    dag=dag)

task_dw_yd_acct_bal_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_yd_acct_bal_f',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_yd_acct_bal_f',
    dag=dag)

task_dw_yd_acct_hist_prof_xref_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_yd_acct_hist_prof_xref_d',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='dw_yd_acct_hist_prof_xref_d',
    dag=dag)

task_mktg_product_summary_sst_w_redshift_unload = ExternalTaskSensor(
    task_id='dag_daily_nerdlake_dwh_upload.mktg_product_summary_sst_w_unload',
    external_dag_id='dag_daily_nerdlake_dwh_upload',
    external_task_id='mktg_product_summary_sst_w_unload',
    dag=dag)

task_loopback_dwh_udp_egmt = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_dwh_udp_egmt/shellscripts/loopback_dwh_udp_egmt.sh',
    script_args=[],
    task_id='loopback_dwh_udp_egmt',
    dag=dag)
task_loopback_dwh_udp_egmt.set_upstream(task_dw_user_actvy_smry_f_dependency)
task_loopback_dwh_udp_egmt.set_upstream(task_dw_identity_d_dependency)

task_loopback_dwh_udp_monetization = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_dwh_udp_monetization/shellscripts/loopback_dwh_udp_monetization.sh',
    script_args=[],
    task_id='loopback_dwh_udp_monetization',
    dag=dag)
task_loopback_dwh_udp_monetization.set_upstream(task_dw_user_actvy_smry_f_dependency)
task_loopback_dwh_udp_monetization.set_upstream(task_dw_identity_d_dependency)

task_loopback_dwh_udp_tu_cr_rprt = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_dwh_udp_tu_cr_rprt/shellscripts/loopback_dwh_udp_tu_cr_rprt.sh',
    script_args=[],
    task_id='loopback_dwh_udp_tu_cr_rprt',
    dag=dag)
task_loopback_dwh_udp_tu_cr_rprt.set_upstream(task_dw_user_actvy_smry_f_dependency)
task_loopback_dwh_udp_tu_cr_rprt.set_upstream(task_dw_identity_d_dependency)
task_loopback_dwh_udp_tu_cr_rprt.set_upstream(task_dw_user_d_dependency)


# SKIPPING PROCESSING UNTIL JIRA PIE-2828 IS IMPLEMENTED
#task_loopback_dwh_udp_yd = NWBashScriptOperator(
#    bash_script='/data/etl/Scripts/loopback_dwh_udp_yd/shellscripts/loopback_dwh_udp_yd.sh',
#    script_args=[],
#    task_id='loopback_dwh_udp_yd',
#    dag=dag)
#task_loopback_dwh_udp_yd.set_upstream(task_dw_user_actvy_smry_f_dependency)
#task_loopback_dwh_udp_yd.set_upstream(task_dw_identity_d_dependency)
#task_loopback_dwh_udp_yd.set_upstream(task_dw_user_d_dependency)


task_loopback_dwh_udp_rgstn_trkng = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_dwh_udp_rgstn_trkng/shellscripts/loopback_dwh_udp_rgstn_trkng.sh',
    script_args=[],
    task_id='loopback_dwh_udp_rgstn_trkng',
    dag=dag)
task_loopback_dwh_udp_rgstn_trkng.set_upstream(task_dw_user_d_dependency)
task_loopback_dwh_udp_rgstn_trkng.set_upstream(task_dw_page_detail_d_dependency)
task_loopback_dwh_udp_rgstn_trkng.set_upstream(task_dw_identity_d_dependency)

task_loopback_dwh_udp_prod_shp_actn = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_dwh_udp_prod_shp_actn/shellscripts/loopback_dwh_udp_prod_shp_actn.sh',
    script_args=[],
    task_id='loopback_dwh_udp_prod_shp_actn',
    dag=dag)
task_loopback_dwh_udp_prod_shp_actn.set_upstream(task_dw_actvy_f_dependency)
task_loopback_dwh_udp_prod_shp_actn.set_upstream(task_dw_prod_d_dependency)
task_loopback_dwh_udp_prod_shp_actn.set_upstream(task_dw_identity_d_dependency)

task_loopback_dwh_udp_feed_actn = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_dwh_udp_feed_actn/shellscripts/loopback_dwh_udp_feed_actn.sh',
    script_args=[],
    task_id='loopback_dwh_udp_feed_actn',
    dag=dag)
task_loopback_dwh_udp_feed_actn.set_upstream(task_dw_feed_elem_intactn_event_f_dependency)
task_loopback_dwh_udp_feed_actn.set_upstream(task_dw_feed_elem_imprsn_event_f_dependency)
task_loopback_dwh_udp_feed_actn.set_upstream(task_dw_feed_item_d_dependency)
task_loopback_dwh_udp_feed_actn.set_upstream(task_dw_identity_d_dependency)

task_loopback_dwh_udp_acct_bal = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_dwh_udp_acct_bal/shellscripts/loopback_dwh_udp_acct_bal.sh',
    script_args=[],
    task_id='loopback_dwh_udp_acct_bal',
    dag=dag)
task_loopback_dwh_udp_acct_bal.set_upstream(task_dw_yd_acct_hist_prof_xref_d_dependency)
task_loopback_dwh_udp_acct_bal.set_upstream(task_dw_yd_acct_bal_f_dependency)
task_loopback_dwh_udp_acct_bal.set_upstream(task_dw_identity_d_dependency)

task_loopback_mktg_product_summary_nerdlake = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/loopback_mktg_product_summary/shellscripts/loopback_mktg_product_summary.sh',
    script_args=[],
    task_id='loopback_mktg_product_summary_nerdlake',
    dag=dag)
task_loopback_mktg_product_summary_nerdlake.set_upstream(task_mktg_product_summary_sst_w_redshift_unload)
