import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_amplitude_upload"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime.now(),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(1,0),
    task_id='Initiating_start_time',
    dag=dag)

Task_non_core_amp_load_transaction_event_dependency = ExternalTaskSensor(
    task_id='waiting_for_non_core_amp_load_transaction_event',
    external_dag_id='dag_daily_non_core_dwh',
    external_task_id='amp_load_transaction_event',
    dag=dag)

Task_non_core_amp_load_user_property_dependency = ExternalTaskSensor(
    task_id='waiting_for_non_core_amp_load_user_property',
    external_dag_id='dag_daily_non_core_dwh',
    external_task_id='amp_load_user_property',
    dag=dag)

task_amp_transaction_event = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/amp_transaction_event/shellscripts/amp_transaction_event.sh",
    script_args=[],
    task_id='amp_transaction_event',
    dag=dag)

task_amp_modify_user_property = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/amp_modify_user_property/shellscripts/amp_modify_user_property.sh",
    script_args=[],
    task_id='amp_modify_user_property',
    dag=dag)

task_amp_bot_detected_event = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/amp_bot_detected_event/shellscripts/amp_bot_detected_event.sh",
    script_args=[],
    task_id='amp_bot_detected_event',
    dag=dag)

task_amp_transaction_event.set_upstream(task_start_job)
task_amp_transaction_event.set_upstream(Task_non_core_amp_load_transaction_event_dependency)

task_amp_modify_user_property.set_upstream(task_start_job)
task_amp_modify_user_property.set_upstream(Task_non_core_amp_load_user_property_dependency)

task_amp_bot_detected_event.set_upstream(task_start_job)
task_amp_bot_detected_event.set_upstream(Task_non_core_amp_load_user_property_dependency)
