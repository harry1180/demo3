import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_edu"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2017,6,15),
    'email': ['dwh@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(5,15),
    task_id='Initiating_start_time',
    dag=dag)

task_dag_daily_aflt_tran_personal_loans_dependency = ExternalTaskSensor(
    task_id='dag_daily_aflt_tran_personal_loans.dw_aflt_tran_personal_loans_f',
    external_dag_id='dag_daily_aflt_tran_personal_loans',
    external_task_id='dw_aflt_tran_personal_loans_f',
    allowed_states=['success', 'failed'],
    dag=dag)

task_get_purefy_spreadsheet="/data/etl/Scripts/aflt_tran_process_google_spreadsheet/shellscripts/aflt_tran_process_google_spreadsheet.sh"
task_aflt_tran_process_google_spreadsheet_purefy = NWBashScriptOperator(
     bash_script=task_get_purefy_spreadsheet,
     script_args=["edu","purefy","https://docs.google.com/spreadsheets/d/1gpSiD7G3IY_ar8s8DytZkNkfm7VlwXzuH0nhfvpnKG4","Refinance","eduloan.airdrop@nerdwallet.awsapps.com",1],
     task_id='aflt_tran_process_google_spreadsheet_purefy',
     trigger_rule='all_done',
     dag=dag)


task_transform_file_script="/data/etl/Scripts/aflt_tran_process_edu_loan/shellscripts/aflt_tran_process_edu_loan_file.sh"
task_aflt_tran_process_edu_loan_file = NWBashScriptOperator(
    bash_script=task_transform_file_script,
    script_args=[],
    task_id='aflt_tran_process_edu_loan_file',
    trigger_rule='all_done',
    dag=dag)

task_aflt_tran_stage_load_script="/data/etl/Scripts/aflt_tran_edu_loan_s/shellscripts/aflt_tran_edu_loan_s.sh"
task_aflt_tran_edu_loan_s = NWBashScriptOperator(
    bash_script=task_aflt_tran_stage_load_script,
    script_args=[],
    task_id='aflt_tran_edu_loan_s',
    trigger_rule='all_done',
    dag=dag)

task_aflt_tran_fact_load_script="/data/etl/Scripts/dw_aflt_tran_edu_loan_f/shellscripts/dw_aflt_tran_edu_loan_f.sh"
task_dw_aflt_tran_edu_loan_f = NWBashScriptOperator(
    bash_script=task_aflt_tran_fact_load_script,
    script_args=[],
    task_id='dw_aflt_tran_edu_loan_f',
    trigger_rule='all_done',
    dag=dag)

task_aflt_tran_process_google_spreadsheet_purefy.set_upstream(task_start_job)
task_aflt_tran_process_edu_loan_file.set_upstream(task_aflt_tran_process_google_spreadsheet_purefy)
task_aflt_tran_edu_loan_s.set_upstream(task_aflt_tran_process_edu_loan_file)
task_dw_aflt_tran_edu_loan_f.set_upstream(task_aflt_tran_edu_loan_s)
task_dw_aflt_tran_edu_loan_f.set_upstream(task_dag_daily_aflt_tran_personal_loans_dependency)
