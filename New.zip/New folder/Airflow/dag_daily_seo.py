from datetime import datetime, timedelta, time

from airflow import DAG
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import ExternalTaskSensor
from airflow.operators.sensors import TimeSensor


job_name = "dag_daily_seo"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2016, 07, 20),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(15, 00),
    task_id='Initiating_start_time',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_aggs_done_sst = ExternalTaskSensor(
    task_id='baidag_sst_aggregates.aggs_done',
    external_dag_id='baidag_sst_aggregates',
    external_task_id='aggs_done',
    dag=dag)

###########################################################################
# Command tasks
###########################################################################
task_google_webmaster = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/google_webmaster_s/shellscripts/google_webmaster_s.sh',
    script_args=[],
    task_id='google_webmaster',
    dag=dag)
task_google_webmaster.set_upstream(task_start_job)

task_google_webmaster_page = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/google_webmaster_s/shellscripts/google_webmaster_s.sh',
    script_args=['page'],
    task_id='google_webmaster_page',
    dag=dag)
task_google_webmaster_page.set_upstream(task_google_webmaster)

task_google_webmaster_device_cntry = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/google_webmaster_s/shellscripts/google_webmaster_s.sh',
    script_args=['device_cntry'],
    task_id='google_webmaster_device_cntry',
    dag=dag)
task_google_webmaster_device_cntry.set_upstream(task_google_webmaster_page)

task_google_webmaster_keyword = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/google_webmaster_s/shellscripts/google_webmaster_s.sh',
    script_args=['keyword'],
    task_id='google_webmaster_keyword',
    dag=dag)
task_google_webmaster_keyword.set_upstream(task_google_webmaster_device_cntry)

task_stat_json = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/seo_kw_stat_f/shellscripts/seo_kw_stat_f.sh',
    script_args=['json'],
    task_id='stat_json',
    dag=dag)
task_stat_json.set_upstream(task_start_job)

task_stat_html = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/seo_kw_stat_f/shellscripts/seo_kw_stat_f.sh',
    script_args=['html'],
    task_id='stat_html',
    dag=dag)
task_stat_html.set_upstream(task_stat_json)

task_seo_dashboard = NWBashScriptOperator(
    bash_script='/data/etl/Common/redshift_sql_function.sh',
    script_args=['/data/etl/Scripts/seo_dashboard/sqlfiles/seo_dashboard.sql'],
    task_id='seo_dashboard',
    dag=dag)
task_seo_dashboard.set_upstream(task_stat_html)

task_wp_page_metrics = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/wp_page_metrics/shellscripts/wp_page_metrics.sh',
    script_args=[],
    task_id='wp_page_metrics',
    dag=dag)
task_wp_page_metrics.set_upstream(task_aggs_done_sst)
task_wp_page_metrics.set_upstream(task_stat_json)
