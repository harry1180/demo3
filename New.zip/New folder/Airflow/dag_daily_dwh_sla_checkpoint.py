import sys
from datetime import datetime, timedelta, time
from airflow import DAG
import airflow.operators
from airflow.operators import PythonOperator
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor



# k6v7j9w6n5r3w2v4@nerdwallet.slack.com dwh-oncall slack#
# o2h5c1k1l5p7e3z9@nerdwallet.slack.com mktg-dq slack#

dag_name = "dag_daily_dwh_sla_checkpoint"

default_args = {
    'owner': 'dwh',
    'start_date': datetime.combine(datetime.now().date(), time()) - timedelta(days=2),
    'retries': 0,
    'queue': 'dwh'
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

task_start_job = TimeSensor(
    target_time=time(00,5), #HH,MM
    task_id='job_start_time_UTC_00_PDT_18_PST_17',
    dag=dag)

task_start_job_11 = TimeSensor(
     target_time=time(11,5), #HH,MM
     task_id='job_start_time_UTC_11_PDT_03_PST_04',
     dag=dag)

task_start_job_18_30 = TimeSensor(
     target_time=time(18,35), #HH,MM
     task_id='job_start_time_UTC_18_30_PDT_10_30_PST_11_30',
     dag=dag)

### check marketing mta completed at UTC 06 ###
task_mktg_mta_done = ExternalTaskSensor(
    task_id='dag_daily_marketing_mta_done',
    external_dag_id='dag_daily_marketing_mta',
    external_task_id='mktg_mta_status_update',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com','jyoo@nerdwallet.com'],
    sla=timedelta(hours=6),
    dag=dag)

### check marketing core completed at UTC 12 ###
task_mktg_core_done = ExternalTaskSensor(
    task_id='check_marketing_core_done',
    external_dag_id='dag_daily_marketing',
    external_task_id='marketing_monitor',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com'],
    sla=timedelta(hours=12),
    dag=dag)

### check marketing offline first task finished by UTC 00:20 ###
task_mktg_offline_started = ExternalTaskSensor(
    task_id='dag_daily_marketing_offline_started',
    external_dag_id='dag_daily_marketing_offline',
    external_task_id='mktg_sizmek',
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com','k6v7j9w6n5r3w2v4@nerdwallet.slack.com'],
    sla=timedelta(minutes=35),
    dag=dag)

### check marketing offline completed at UTC 06 ###
task_mktg_offline_done = ExternalTaskSensor(
    task_id='dag_daily_marketing_offline_done',
    external_dag_id='dag_daily_marketing_offline',
    external_task_id='mktg_offline_status_update',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com','k6v7j9w6n5r3w2v4@nerdwallet.slack.com'],
    sla=timedelta(hours=6),
    dag=dag)

### check core DWH first task finished by UTC 03:00 ###
task_core_dwh_started = ExternalTaskSensor(
    task_id='dag_daily_core_dwh_started',
    external_dag_id='dag_daily_core_dwh',
    allowed_states=['success','failed'],
    external_task_id='heart_beat_event_deserialization',
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com','k6v7j9w6n5r3w2v4@nerdwallet.slack.com'],
    sla=timedelta(hours=3),
    dag=dag)

### check core DWH completed at UTC 05 ###
task_core_dwh_done = ExternalTaskSensor(
    task_id='dag_daily_core_dwh_done',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='status_update',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com','k6v7j9w6n5r3w2v4@nerdwallet.slack.com'],
    sla=timedelta(hours=5),
    dag=dag)

### check handshake completed at UTC 07 ###
task_bai_dwh_handshake_done = ExternalTaskSensor(
    task_id='dag_daily_bai_dwh_handshake_done',
    external_dag_id='dag_daily_bai_dwh_handshake',
    external_task_id='Task_Daily_Core_Process',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com','k6v7j9w6n5r3w2v4@nerdwallet.slack.com'],
    sla=timedelta(hours=7),
    dag=dag)


### check Blisspoint upload completed at UTC 11 ###
task_blisspoint_upload_done = ExternalTaskSensor(
    task_id='dag_daily_marketing_offline_blisspoint_upload_done',
    external_dag_id='dag_daily_marketing_offline_blisspoint',
    external_task_id='mktg_offline_tv_blisspoint_upload_scheduled',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com', 'jyoo@nerdwallet.com', 'ssundara@nerdwallet.com'],
    sla=timedelta(hours=23),
    dag=dag)


### check Blisspoint completed at UTC 19.00 ###
task_blisspoint_done = ExternalTaskSensor(
    task_id='dag_daily_marketing_offline_blisspoint_done',
    external_dag_id='dag_daily_marketing_offline_blisspoint',
    external_task_id='mktg_blisspoint_spot_report_f',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com', 'jyoo@nerdwallet.com', 'ssundara@nerdwallet.com'],
    sla=timedelta(hours=23),
    dag=dag)

### check DS conversion upload completed at UTC 19.00 ###
task_ds_conv_done = ExternalTaskSensor(
    task_id='dag_daily_marketing_offline_ds_conv_done',
    external_dag_id='dag_daily_marketing_offline',
    external_task_id='mktg_conv_upload_ds_post_f',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com', 'jyoo@nerdwallet.com', 'ssundara@nerdwallet.com'],
    sla=timedelta(hours=19),
    dag=dag)


task_mktg_mta_done.set_upstream(task_start_job)

task_mktg_core_done.set_upstream(task_start_job)

task_mktg_offline_started.set_upstream(task_start_job)
task_mktg_offline_done.set_upstream(task_mktg_offline_started)

task_core_dwh_started.set_upstream(task_start_job)
task_core_dwh_done.set_upstream(task_core_dwh_started)

task_bai_dwh_handshake_done.set_upstream(task_mktg_mta_done)

task_blisspoint_upload_done.set_upstream(task_start_job_11)

task_blisspoint_done.set_upstream(task_start_job_18_30)

task_ds_conv_done.set_upstream(task_start_job_11)
