from datetime import datetime, timedelta, time

from airflow import DAG
from airflow.operators import NWBashScriptOperator, ExternalTaskSensor, DummyOperator


job_name = "dag_daily_nerdlake_non_core_p1"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime.combine(datetime.now().date(), time()) - timedelta(days=2),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=10),
    'depends_on_past': True
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@daily')

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_all_events_s_nerdlake = ExternalTaskSensor(
    task_id='dag_hourly_nerdlake_events_p0.all_events_s_nerdlake_load',
    external_dag_id='dag_hourly_nerdlake_events_p0',
    external_task_id='all_events_s_nerdlake_load',
    execution_delta=timedelta(hours=-23),
    dag=dag)
task_all_events_s_nerdlake.set_upstream(task_start_dag)

###########################################################################
# Command tasks
###########################################################################
task_site_visitor_d_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/site_visitor_d_nerdlake/shellscripts/site_visitor_d.sh',
    script_args=[],
    task_id='site_visitor_d_nerdlake',
    pool='presto_etl',
    dag=dag)
task_site_visitor_d_nerdlake_load.set_upstream(task_all_events_s_nerdlake)
