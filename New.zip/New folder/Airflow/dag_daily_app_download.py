from datetime import datetime, timedelta, time, date
import pytz

from airflow import DAG
import airflow.operators
from airflow.operators import BashOperator
from airflow.operators import DummyOperator
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

dag_name = "dag_daily_app_download"

default_args = {
    'owner': 'dwh',
    'depends_on_past': False,
    'wait_for_downstream': True,
    'start_date': datetime.combine(datetime.now().date(), time()) - timedelta(days=2),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_dag = DummyOperator(
    task_id='Initiating_task',
    depends_on_past=False,
    dag=dag)

################################################################################
# Time Sensors
################################################################################
task_start_job = TimeSensor(
    target_time=time(16,00),
    task_id='Initiating_start_time',
    dag=dag)
task_start_job.set_upstream(task_start_dag)

# Apple data availability:
#   "Daily reports for the Americas are available by 5 am Pacific Time; Japan,
#    Australia, and New Zealand by 5 am Japan Standard Time; and 5 am Central
#    European Time for all other territories."
# Presumably "pacific time" respects daylight savings time.
#
# Note: The reports are semi-regularly not ready at 5:00 AM pacific time so we
#       wait until 8:00 AM.
task_apple_data_ready = TimeSensor(
    target_time=pytz.timezone('America/Los_Angeles').localize(datetime.combine(date.today(), time(8))).astimezone(pytz.UTC).time(),
    task_id='Apple_data_ready',
    dag=dag)
task_apple_data_ready.set_upstream(task_start_dag)

################################################################################
# Command tasks
################################################################################
task_apple_app_download_s = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/apple_app_download_s/shellscripts/apple_app_download_s.sh',
    script_args=[],
    task_id='apple_app_download_s',
    retries=1,
    retry_interval= timedelta(minutes=180),
    trigger_rule='all_done',
    dag=dag)
task_apple_app_download_s.set_upstream(task_apple_data_ready)

task_dw_app_apple_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_app_apple_d/shellscripts/dw_app_apple_d.sh',
    script_args=[],
    task_id='dw_app_apple_d',
    trigger_rule='all_done',
    dag=dag)
task_dw_app_apple_d.set_upstream(task_apple_app_download_s)

task_dw_app_apple_dwnld_rollup_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_app_apple_dwnld_rollup_f/shellscripts/dw_app_apple_dwnld_rollup_f.sh',
    script_args=[],
    task_id='dw_app_apple_dwnld_rollup_f',
    trigger_rule='all_done',
    dag=dag)
task_dw_app_apple_dwnld_rollup_f.set_upstream(task_dw_app_apple_d)

task_google_app_download_s_script="/data/etl/Scripts/google_app_download_s/shellscripts/google_app_download_s.sh"
task_google_app_download_s = NWBashScriptOperator(
    bash_script=task_google_app_download_s_script,
    script_args=[],
    task_id='google_app_download_s',
    trigger_rule='all_done',
    dag=dag)

task_dw_app_goog_dwnld_rollup_f_script="/data/etl/Scripts/dw_app_goog_dwnld_rollup_f/shellscripts/dw_app_goog_dwnld_rollup_f.sh"
task_dw_app_goog_dwnld_rollup_f = NWBashScriptOperator(
    bash_script=task_dw_app_goog_dwnld_rollup_f_script,
    script_args=[],
    task_id='dw_app_goog_dwnld_rollup_f',
    trigger_rule='all_done',
    dag=dag)

task_google_supported_device_s_script="/data/etl/Scripts/google_supported_device_s/shellscripts/google_supported_device_s.sh"
task_google_supported_device_s = NWBashScriptOperator(
    bash_script=task_google_supported_device_s_script,
    script_args=[],
    task_id='google_supported_device_s',
    trigger_rule='all_done',
    dag=dag)

task_dw_goog_sprt_dvc_d_script="/data/etl/Scripts/dw_goog_sprt_dvc_d/shellscripts/dw_goog_sprt_dvc_d.sh"
task_dw_goog_sprt_dvc_d = NWBashScriptOperator(
    bash_script=task_dw_goog_sprt_dvc_d_script,
    script_args=[],
    task_id='dw_goog_sprt_dvc_d',
    trigger_rule='all_done',
    dag=dag)


task_google_app_rating_s_script="/data/etl/Scripts/google_app_rating_s/shellscripts/google_app_rating_s.sh"
task_google_app_rating_s = NWBashScriptOperator(
    bash_script=task_google_app_rating_s_script,
    script_args=[],
    task_id='google_app_rating_s',
    trigger_rule='all_done',
    dag=dag)

task_dw_app_goog_rtng_rollup_f_script="/data/etl/Scripts/dw_app_goog_rtng_rollup_f/shellscripts/dw_app_goog_rtng_rollup_f.sh"
task_dw_app_goog_rtng_rollup_f = NWBashScriptOperator(
    bash_script=task_dw_app_goog_rtng_rollup_f_script,
    script_args=[],
    task_id='dw_app_goog_rtng_rollup_f',
    trigger_rule='all_done',
    dag=dag)

task_google_app_review_s_script="/data/etl/Scripts/google_app_review_s/shellscripts/google_app_review_s.sh"
task_google_app_review_s = NWBashScriptOperator(
    bash_script=task_google_app_review_s_script,
    script_args=[],
    task_id='google_app_review_s',
    trigger_rule='all_done',
    dag=dag)

task_dw_app_goog_rvw_f_script="/data/etl/Scripts/dw_app_goog_rvw_f/shellscripts/dw_app_goog_rvw_f.sh"
task_dw_app_goog_rvw_f = NWBashScriptOperator(
    bash_script=task_dw_app_goog_rvw_f_script,
    script_args=[],
    task_id='dw_app_goog_rvw_f',
    trigger_rule='all_done',
    dag=dag)

task_branch_link_s_script="/data/etl/Scripts/branch_link_s/shellscripts/branch_link_s.sh"
task_branch_link_s = NWBashScriptOperator(
    bash_script=task_branch_link_s_script,
    script_args=[],
    task_id='branch_link_s',
    retries=1,
    retry_interval= timedelta(minutes=180),
    trigger_rule='all_done',
    dag=dag)

task_dw_app_branch_link_d_script="/data/etl/Scripts/dw_app_branch_link_d/shellscripts/dw_app_branch_link_d.sh"
task_dw_app_branch_link_d = NWBashScriptOperator(
    bash_script=task_dw_app_branch_link_d_script,
    script_args=[],
    task_id='dw_app_branch_link_d',
    trigger_rule='all_done',
    dag=dag)

task_branch_link_click_s_script="/data/etl/Scripts/branch_link_click_s/shellscripts/branch_link_click_s.sh"
task_branch_link_click_s = NWBashScriptOperator(
    bash_script=task_branch_link_click_s_script,
    script_args=[],
    task_id='branch_link_click_s',
    retries=1,
    retry_interval= timedelta(minutes=180),
    trigger_rule='all_done',
    dag=dag)

task_dw_app_branch_link_click_f_script="/data/etl/Scripts/dw_app_branch_link_click_f/shellscripts/dw_app_branch_link_click_f.sh"
task_dw_app_branch_link_click_f = NWBashScriptOperator(
    bash_script=task_dw_app_branch_link_click_f_script,
    script_args=[],
    task_id='dw_app_branch_link_click_f',
    trigger_rule='all_done',
    dag=dag)

task_branch_event_s_script="/data/etl/Scripts/branch_event_s/shellscripts/branch_event_s.sh"
task_branch_event_s = NWBashScriptOperator(
    bash_script=task_branch_event_s_script,
    script_args=[],
    task_id='branch_event_s',
    retries=1,
    retry_interval= timedelta(minutes=180),
    trigger_rule='all_done',
    dag=dag)

task_dw_app_branch_actvy_f_script="/data/etl/Scripts/dw_app_branch_actvy_f/shellscripts/dw_app_branch_actvy_f.sh"
task_dw_app_branch_actvy_f = NWBashScriptOperator(
    bash_script=task_dw_app_branch_actvy_f_script,
    script_args=[],
    task_id='dw_app_branch_actvy_f',
    trigger_rule='all_done',
    dag=dag)

task_google_app_crashes_s_script="/data/etl/Scripts/google_app_crashes_s/shellscripts/google_app_crashes_s.sh"
task_google_app_crashes_s = NWBashScriptOperator(
    bash_script=task_google_app_crashes_s_script,
    script_args=[],
    task_id='google_app_crashes_s',
    trigger_rule='all_done',
    dag=dag)

task_dw_app_goog_err_f_script="/data/etl/Scripts/dw_app_goog_err_f/shellscripts/dw_app_goog_err_f.sh"
task_dw_app_goog_err_f = NWBashScriptOperator(
    bash_script=task_dw_app_goog_err_f_script,
    script_args=[],
    task_id='dw_app_goog_err_f',
    trigger_rule='all_done',
    dag=dag)


task_google_app_anr_s_script="/data/etl/Scripts/google_app_anr_s/shellscripts/google_app_anr_s.sh"
task_google_app_anr_s = NWBashScriptOperator(
    bash_script=task_google_app_anr_s_script,
    script_args=[],
    task_id='google_app_anr_s',
    trigger_rule='all_done',
    dag=dag)



task_google_app_download_s.set_upstream(task_start_job)
task_google_supported_device_s.set_upstream(task_start_job)
task_dw_goog_sprt_dvc_d.set_upstream(task_google_supported_device_s)
task_dw_app_goog_dwnld_rollup_f.set_upstream(task_google_app_download_s)

task_google_app_rating_s.set_upstream(task_start_job)
task_dw_app_goog_rtng_rollup_f.set_upstream(task_google_app_rating_s)

task_google_app_review_s.set_upstream(task_start_job)
task_dw_app_goog_rvw_f.set_upstream(task_google_app_review_s)

task_branch_link_s.set_upstream(task_start_job)
task_dw_app_branch_link_d.set_upstream(task_branch_link_s)

task_branch_link_click_s.set_upstream(task_start_job)
task_dw_app_branch_link_click_f.set_upstream(task_branch_link_click_s)

task_branch_event_s.set_upstream(task_start_job)
task_dw_app_branch_actvy_f.set_upstream(task_branch_event_s)
task_dw_app_branch_actvy_f.set_upstream(task_dw_app_branch_link_click_f)


task_google_app_crashes_s.set_upstream(task_start_job)
task_google_app_anr_s.set_upstream(task_start_job)
task_dw_app_goog_err_f.set_upstream(task_google_app_crashes_s)
task_dw_app_goog_err_f.set_upstream(task_google_app_anr_s)
