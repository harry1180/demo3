import sys
from datetime import datetime, timedelta, time
from airflow import DAG
import airflow.operators
from airflow.operators import PythonOperator
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor



# k6v7j9w6n5r3w2v4@nerdwallet.slack.com dwh-oncall slack#
# o2h5c1k1l5p7e3z9@nerdwallet.slack.com mktg-dq slack#

dag_name = "dag_daily_dwh_backup"

default_args = {
    'owner': 'dwh',
    'start_date': datetime.combine(datetime.now().date(), time()) - timedelta(days=2),
    'retries': 0,
    'queue': 'dwh'
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

### external dependency on dw_aflt_tran_consolidated_f ###
task_dw_aflt_tran_consolidated_f = ExternalTaskSensor(
    task_id='waiting_for_dag_daily_aflt_tran.aflt_tran_consolidated_fact',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='aflt_tran_consolidated_fact',
    dag=dag)


### external dependency on BAI dashboard ###
task_bai_p1 = ExternalTaskSensor(
    task_id='waiting_for_baidag__dashboard_milestones.P1_dashboards_done',
    external_dag_id='baidag__dashboard_milestones',
    external_task_id='P1_dashboards_done',
    dag=dag)

task_dw_aflt_tran_consolidated_snapshot_f_script="/data/etl/Scripts/aflt_tran_consolidated_fact/shellscripts/dw_aflt_tran_consolidated_snapshot_f.sh"
task_dw_aflt_tran_consolidated_snapshot_f = NWBashScriptOperator(
    bash_script=task_dw_aflt_tran_consolidated_snapshot_f_script,
    script_args=[],
    task_id='dw_aflt_tran_consolidated_snapshot_f',
    trigger_rule='all_done',
    dag=dag)

task_dw_aflt_tran_consolidated_snapshot_f.set_upstream(task_dw_aflt_tran_consolidated_f)
task_dw_aflt_tran_consolidated_snapshot_f.set_upstream(task_bai_p1)
