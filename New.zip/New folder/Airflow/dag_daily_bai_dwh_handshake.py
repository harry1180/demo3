from datetime import datetime, timedelta, time
import os
import sys

from airflow import DAG
from airflow.models import Variable
from airflow.operators import NWBashScriptOperator, BashOperator, DummyOperator, PythonOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

sys.path.append(os.path.dirname(__file__))  # Allow importing of modules from the same directory as our DAGs
import airflow_dwh


# Attaching the Slack notification to an external task sensor causes the task ID in the notification to be a bit
# mangled so I'm creating a custom function in this DAG that calls airflow_dwh.send_slack_message() directly.
def exec_dashboard_complete():
    airflow_dwh.send_slack_message(
        channel='#dwh-oncall',
        message='`baidag_exec_dashboard.baidag_exec_dashboard_done` is complete'
    )


job_name = "dag_daily_bai_dwh_handshake"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 9, 19),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

h, m = Variable.get('ba_master_start_time', '4,1').split(',')
h, m = [int(h), int(m)]
task_start_job = TimeSensor(
    target_time=time(h, m),
    task_id='Initiating_start_time',
    dag=dag)

task_event_dag_dependency = ExternalTaskSensor(
    task_id='waiting_for_Event_Data_dag',
    external_dag_id='dag_daily_event_data_load',
    external_task_id='status_update',
    dag=dag)

task_pud_dag_dependency = ExternalTaskSensor(
    task_id='waiting_for_PUD_Data_dag',
    external_dag_id='dag_daily_pud_identity',
    external_task_id='status_update',
    dag=dag)

task_aflt_tran_dag_dependency = ExternalTaskSensor(
    task_id='waiting_for_Aflt_Tran_Data_dag',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='status_update',
    dag=dag)

task_core_dag_dependency = ExternalTaskSensor(
    task_id='waiting_for_Core_Data_dag',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='status_update',
    dag=dag)

task_page_view_event_dependency = ExternalTaskSensor(
    task_id='waiting_for_Core_Page_View_Event',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='page_view_event_f',
    dag=dag)

task_clicks_event_dependency = ExternalTaskSensor(
    task_id='waiting_for_Core_Clicks_Event',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

task_mta_dependency = ExternalTaskSensor(
    task_id='waiting_for_MTA',
    external_dag_id='dag_daily_marketing_mta',
    external_task_id='mktg_mta_status_update',
    dag=dag)

task_ab_dag_dependency = ExternalTaskSensor(
    task_id='waiting_for_AB_Data_dag',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='ab_status_update',
    dag=dag)

task_identity_dag_dependency = ExternalTaskSensor(
    task_id='waiting_for_Identity_Data_dag',
    external_dag_id='dag_daily_identity',
    external_task_id='status_update',
    dag=dag)

task_exec_dashboard = ExternalTaskSensor(
    task_id='baidag_exec_dashboard.baidag_exec_dashboard_done',
    external_dag_id='baidag_exec_dashboard',
    external_task_id='baidag_exec_dashboard_done',
    dag=dag)

task_exec_dashboard_notify = PythonOperator(
    task_id='slack_notify_complete_baidag_exec_dashboard.baidag_exec_dashboard_done',
    python_callable=exec_dashboard_complete,
    dag=dag)
task_exec_dashboard_notify.set_upstream(task_exec_dashboard)

task_pud_dag_status = DummyOperator(
    task_id='Dag_Daily_PUD_Status',
    dag=dag)

task_event_dag_status = DummyOperator(
    task_id='Dag_Daily_Event_Status',
    dag=dag)

task_aflt_tran_dag_status = DummyOperator(
    task_id='Dag_Daily_Aflt_Tran_Status',
    dag=dag)

task_core_dag_status = DummyOperator(
    task_id='Dag_Daily_Core_Status',
    dag=dag)

task_page_view_event_task_status = DummyOperator(
    task_id='Task_Daily_PageViewEvent_Status',
    dag=dag)

task_click_event_task_status = DummyOperator(
    task_id='Task_Daily_ClickEvent_Status',
    dag=dag)

task_all_core_status = DummyOperator(
    task_id='Task_Daily_Core_Process',
    dag=dag)

task_mta_status = DummyOperator(
    task_id='Task_Daily_MTA_Status',
    dag=dag)

task_identity_dag_status = DummyOperator(
    task_id='Dag_Daily_Identity_Status',
    dag=dag)    

task_ab_dag_status = DummyOperator(
    task_id='Dag_AB_Event_Status',
    dag=dag)     

task_pud_dag_status.set_upstream([task_start_job, task_pud_dag_dependency])
task_identity_dag_status.set_upstream([task_start_job, task_identity_dag_dependency])
task_event_dag_status.set_upstream([task_start_job, task_event_dag_dependency])
task_aflt_tran_dag_status.set_upstream([task_start_job, task_aflt_tran_dag_dependency])
task_core_dag_status.set_upstream([task_start_job, task_core_dag_dependency])
task_page_view_event_task_status.set_upstream([task_start_job, task_page_view_event_dependency])
task_click_event_task_status.set_upstream([task_start_job, task_clicks_event_dependency])
task_mta_status.set_upstream([task_start_job, task_mta_dependency])
task_all_core_status.set_upstream([task_pud_dag_status, task_core_dag_status, task_page_view_event_task_status,
                                   task_click_event_task_status, task_mta_status, task_aflt_tran_dag_status,
                                   task_identity_dag_status])
task_ab_dag_status.set_upstream([task_start_job, task_ab_dag_dependency])
