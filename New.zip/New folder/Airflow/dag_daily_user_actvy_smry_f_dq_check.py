import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_user_actvy_smry_f_dq_check"

default_args = {
    'owner': 'dwh',
    'depends_on_past': False,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 10, 8),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(4,15),
    task_id='Initiating_start_time',
    dag=dag)

Task_dw_user_actvy_smry_f_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_user_actvy_smry_f',
    external_dag_id='dag_daily_identity',
    external_task_id='dw_user_actvy_smry_f',
    dag=dag)

Task_dw_user_d_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_user_d',
    external_dag_id='dag_daily_identity',
    external_task_id='dw_user_d',
    dag=dag)

task_dw_eff_dt= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_dw_eff_dt_check.json"],
    task_id='dw_eff_dt_check',
    dag=dag)


task_dw_eff_dt.set_upstream(task_start_job)
task_dw_eff_dt.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_last_visit_ts= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_last_visit_ts_check.json"],
    task_id='egmt_last_visit_ts_check',
    dag=dag)


task_egmt_last_visit_ts.set_upstream(task_start_job)
task_egmt_last_visit_ts.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_snd_last_visit_ts= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_snd_last_visit_ts_check.json"],
    task_id='egmt_snd_last_visit_ts_check',
    dag=dag)


task_egmt_snd_last_visit_ts.set_upstream(task_start_job)
task_egmt_snd_last_visit_ts.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_thrd_last_visit_ts= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_thrd_last_visit_ts_check.json"],
    task_id='egmt_thrd_last_visit_ts_check',
    dag=dag)


task_egmt_thrd_last_visit_ts.set_upstream(task_start_job)
task_egmt_thrd_last_visit_ts.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_user_actvy_status_cd= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_user_actvy_status_cd_check.json"],
    task_id='egmt_user_actvy_status_cd_check',
    dag=dag)


task_egmt_user_actvy_status_cd.set_upstream(task_start_job)
task_egmt_user_actvy_status_cd.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_last_used_pfm_nm= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_last_used_pfm_nm_check.json"],
    task_id='egmt_last_used_pfm_nm_check',
    dag=dag)


task_egmt_last_used_pfm_nm.set_upstream(task_start_job)
task_egmt_last_used_pfm_nm.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_last_used_form_fctr_nm= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_last_used_form_fctr_nm_check.json"],
    task_id='egmt_last_used_form_fctr_nm_check',
    dag=dag)


task_egmt_last_used_form_fctr_nm.set_upstream(task_start_job)
task_egmt_last_used_form_fctr_nm.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_vstd_web_home_page_in= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_vstd_web_home_page_in_check.json"],
    task_id='egmt_vstd_web_home_page_in_check',
    dag=dag)


task_egmt_vstd_web_home_page_in.set_upstream(task_start_job)
task_egmt_vstd_web_home_page_in.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_vstd_mbl_in= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_vstd_mbl_in_check.json"],
    task_id='egmt_vstd_mbl_in_check',
    dag=dag)


task_egmt_vstd_mbl_in.set_upstream(task_start_job)
task_egmt_vstd_mbl_in.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_first_visit_ts= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_first_visit_ts_check.json"],
    task_id='egmt_first_visit_ts_check',
    dag=dag)


task_egmt_first_visit_ts.set_upstream(task_start_job)
task_egmt_first_visit_ts.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_egmt_last_seen_mbl_app_dt= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_egmt_last_seen_mbl_app_dt_check.json"],
    task_id='egmt_last_seen_mbl_app_dt_check',
    dag=dag)


task_egmt_last_seen_mbl_app_dt.set_upstream(task_start_job)
task_egmt_last_seen_mbl_app_dt.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_mntzn_ltv_amt= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_mntzn_ltv_amt_check.json"],
    task_id='mntzn_ltv_amt_check',
    dag=dag)


task_mntzn_ltv_amt.set_upstream(task_start_job)
task_mntzn_ltv_amt.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_mntzn_total_txn_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_mntzn_total_txn_ct_check.json"],
    task_id='mntzn_total_txn_ct_check',
    dag=dag)


task_mntzn_total_txn_ct.set_upstream(task_start_job)
task_mntzn_total_txn_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_mntzn_avg_txn_amt= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_mntzn_avg_txn_amt_check.json"],
    task_id='mntzn_avg_txn_amt_check',
    dag=dag)


task_mntzn_avg_txn_amt.set_upstream(task_start_job)
task_mntzn_avg_txn_amt.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_mntzn_total_srvc_amt= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_mntzn_total_srvc_amt_check.json"],
    task_id='mntzn_total_srvc_amt_check',
    dag=dag)


task_mntzn_total_srvc_amt.set_upstream(task_start_job)
task_mntzn_total_srvc_amt.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_vantage_cr_scr_v3_bkt_nm= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_vantage_cr_scr_v3_bkt_nm_check.json"],
    task_id='vantage_cr_scr_v3_bkt_nm_check',
    dag=dag)


task_vantage_cr_scr_v3_bkt_nm.set_upstream(task_start_job)
task_vantage_cr_scr_v3_bkt_nm.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_vantage_cr_scr_delta_chg_nr= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_vantage_cr_scr_delta_chg_nr_check.json"],
    task_id='vantage_cr_scr_delta_chg_nr_check',
    dag=dag)


task_vantage_cr_scr_delta_chg_nr.set_upstream(task_start_job)
task_vantage_cr_scr_delta_chg_nr.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_total_rvlng_debt_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_total_rvlng_debt_am_check.json"],
    task_id='tu_rptd_total_rvlng_debt_am_check',
    dag=dag)


task_tu_rptd_total_rvlng_debt_am.set_upstream(task_start_job)
task_tu_rptd_total_rvlng_debt_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_asset_bckd_debt_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_asset_bckd_debt_am_check.json"],
    task_id='tu_rptd_asset_bckd_debt_am_check',
    dag=dag)


task_tu_rptd_asset_bckd_debt_am.set_upstream(task_start_job)
task_tu_rptd_asset_bckd_debt_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_cc_cr_limit_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_cc_cr_limit_am_check.json"],
    task_id='tu_rptd_cc_cr_limit_am_check',
    dag=dag)


task_tu_rptd_cc_cr_limit_am.set_upstream(task_start_job)
task_tu_rptd_cc_cr_limit_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_cc_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_cc_trdln_ct_check.json"],
    task_id='tu_rptd_cc_trdln_ct_check',
    dag=dag)


task_tu_rptd_cc_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_cc_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_cc_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_cc_trdln_am_check.json"],
    task_id='tu_rptd_cc_trdln_am_check',
    dag=dag)


task_tu_rptd_cc_trdln_am.set_upstream(task_start_job)
task_tu_rptd_cc_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_sl_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_sl_trdln_ct_check.json"],
    task_id='tu_rptd_sl_trdln_ct_check',
    dag=dag)


task_tu_rptd_sl_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_sl_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_sl_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_sl_trdln_am_check.json"],
    task_id='tu_rptd_sl_trdln_am_check',
    dag=dag)


task_tu_rptd_sl_trdln_am.set_upstream(task_start_job)
task_tu_rptd_sl_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_al_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_al_trdln_ct_check.json"],
    task_id='tu_rptd_al_trdln_ct_check',
    dag=dag)


task_tu_rptd_al_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_al_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_al_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_al_trdln_am_check.json"],
    task_id='tu_rptd_al_trdln_am_check',
    dag=dag)


task_tu_rptd_al_trdln_am.set_upstream(task_start_job)
task_tu_rptd_al_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_pl_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_pl_trdln_ct_check.json"],
    task_id='tu_rptd_pl_trdln_ct_check',
    dag=dag)


task_tu_rptd_pl_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_pl_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_pl_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_pl_trdln_am_check.json"],
    task_id='tu_rptd_pl_trdln_am_check',
    dag=dag)


task_tu_rptd_pl_trdln_am.set_upstream(task_start_job)
task_tu_rptd_pl_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_mrtg_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_mrtg_trdln_ct_check.json"],
    task_id='tu_rptd_mrtg_trdln_ct_check',
    dag=dag)


task_tu_rptd_mrtg_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_mrtg_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_mrtg_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_mrtg_trdln_am_check.json"],
    task_id='tu_rptd_mrtg_trdln_am_check',
    dag=dag)


task_tu_rptd_mrtg_trdln_am.set_upstream(task_start_job)
task_tu_rptd_mrtg_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_ol_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_ol_trdln_ct_check.json"],
    task_id='tu_rptd_ol_trdln_ct_check',
    dag=dag)


task_tu_rptd_ol_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_ol_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_ol_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_ol_trdln_am_check.json"],
    task_id='tu_rptd_ol_trdln_am_check',
    dag=dag)


task_tu_rptd_ol_trdln_am.set_upstream(task_start_job)
task_tu_rptd_ol_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_heloc_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_heloc_trdln_ct_check.json"],
    task_id='tu_rptd_heloc_trdln_ct_check',
    dag=dag)


task_tu_rptd_heloc_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_heloc_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_heloc_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_heloc_trdln_am_check.json"],
    task_id='tu_rptd_heloc_trdln_am_check',
    dag=dag)


task_tu_rptd_heloc_trdln_am.set_upstream(task_start_job)
task_tu_rptd_heloc_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_utlty_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_utlty_trdln_ct_check.json"],
    task_id='tu_rptd_utlty_trdln_ct_check',
    dag=dag)


task_tu_rptd_utlty_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_utlty_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_utlty_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_utlty_trdln_am_check.json"],
    task_id='tu_rptd_utlty_trdln_am_check',
    dag=dag)


task_tu_rptd_utlty_trdln_am.set_upstream(task_start_job)
task_tu_rptd_utlty_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_other_trdln_ct= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_other_trdln_ct_check.json"],
    task_id='tu_rptd_other_trdln_ct_check',
    dag=dag)


task_tu_rptd_other_trdln_ct.set_upstream(task_start_job)
task_tu_rptd_other_trdln_ct.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_rptd_other_trdln_am= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_rptd_other_trdln_am_check.json"],
    task_id='tu_rptd_other_trdln_am_check',
    dag=dag)


task_tu_rptd_other_trdln_am.set_upstream(task_start_job)
task_tu_rptd_other_trdln_am.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_cntc_last_touch_ts= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_cntc_last_touch_ts_check.json"],
    task_id='cntc_last_touch_ts_check',
    dag=dag)


task_cntc_last_touch_ts.set_upstream(task_start_job)
task_cntc_last_touch_ts.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_cntc_last_touch_chnl_nm= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_cntc_last_touch_chnl_nm_check.json"],
    task_id='cntc_last_touch_chnl_nm_check',
    dag=dag)


task_cntc_last_touch_chnl_nm.set_upstream(task_start_job)
task_cntc_last_touch_chnl_nm.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_cntc_last_touch_cmpgn_nm= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_cntc_last_touch_cmpgn_nm_check.json"],
    task_id='cntc_last_touch_cmpgn_nm_check',
    dag=dag)


task_cntc_last_touch_cmpgn_nm.set_upstream(task_start_job)
task_cntc_last_touch_cmpgn_nm.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_dw_load_ts= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_dw_load_ts_check.json"],
    task_id='dw_load_ts_check',
    dag=dag)


task_dw_load_ts.set_upstream(task_start_job)
task_dw_load_ts.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_user_id_unique= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_user_id_unique_check.json"],
    task_id='user_id_unique_check',
    dag=dag)


task_user_id_unique.set_upstream(task_start_job)
task_user_id_unique.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_src_tgt_count_match= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_src_tgt_count_match_check.json"],
    task_id='src_tgt_count_match_check',
    dag=dag)


task_src_tgt_count_match.set_upstream(task_start_job)
task_src_tgt_count_match.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_time_series_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_time_series_check_check.json"],
    task_id='time_series_check_check',
    dag=dag)


task_time_series_check.set_upstream(task_start_job)
task_time_series_check.set_upstream(Task_dw_user_actvy_smry_f_dependency)


task_tu_activation_date_score_check= NWBashScriptOperator (
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_user_actvy_smry_f/pythonscripts/dw_user_actvy_smry_f_tu_activation_date_score_check_check.json"],
    task_id='tu_activation_date_score_check_check',
    dag=dag)


task_tu_activation_date_score_check.set_upstream(task_start_job)
task_tu_activation_date_score_check.set_upstream(Task_dw_user_actvy_smry_f_dependency)
task_tu_activation_date_score_check.set_upstream(Task_dw_user_d_dependency)


