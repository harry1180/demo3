import sys
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os
from airflow.models import Variable
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_daily_aflt_tran_investing"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2018, 9, 20),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(0,30),
    task_id='Initiating_start_time',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_dw_aflt_tran_hasoffers_f = ExternalTaskSensor(
task_id='waiting_for_aflt_tran',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='dw_aflt_tran_hasoffers_f',
    dag=dag)

###########################################################################
# Command tasks
###########################################################################
task1_script = "/data/etl/Scripts/aflt_process_email_attachments/shellscripts/aflt_process_email_attachments.sh"
task1_email_download = NWBashScriptOperator(
    bash_script=task1_script,
    script_args=[],
    task_id='aflt_email_download',
    dag=dag)

task2_script = "/data/etl/Scripts/dw_aflt_tran_investing_googleDDM_f/shellscripts/dw_aflt_tran_investing_googleDDM_f.sh"
task2_aflt_tran_investing_ddm_fact = NWBashScriptOperator(
    bash_script=task2_script,
    script_args=[],
    task_id='aflt_tran_investing_ddm_fact',
    pool='redshift_etl',
    dag=dag)

task4_script = "/data/etl/Scripts/aflt_tran_process_investing/shellscripts/aflt_tran_process_investing.sh"
task4_aflt_tran_process_investing = NWBashScriptOperator(
    bash_script=task4_script,
    script_args=[],
    task_id='aflt_tran_process_investing',
    dag=dag)

task5_script = "/data/etl/Scripts/dw_aflt_tran_investing_s/shellscripts/dw_aflt_tran_investing_s.sh"
task5_aflt_tran_investing_s = NWBashScriptOperator(
    bash_script=task5_script,
    script_args=[],
    task_id='aflt_tran_investing_s',
    pool='redshift_etl',
    dag=dag)

task6_script = "/data/etl/Scripts/dw_aflt_tran_investing_f/shellscripts/dw_aflt_tran_investing_f.sh"
task6_aflt_tran_investing_f = NWBashScriptOperator(
    bash_script=task6_script,
    script_args=[],
    task_id='aflt_tran_investing_f',
    pool='redshift_etl',
    dag=dag)

task1_email_download.set_upstream(task_start_job)
task2_aflt_tran_investing_ddm_fact.set_upstream(task1_email_download)
task4_aflt_tran_process_investing.set_upstream(task_dw_aflt_tran_hasoffers_f)
task4_aflt_tran_process_investing.set_upstream(task2_aflt_tran_investing_ddm_fact)
task5_aflt_tran_investing_s.set_upstream(task4_aflt_tran_process_investing)
task6_aflt_tran_investing_f.set_upstream(task5_aflt_tran_investing_s)
