
import sys
from datetime import datetime, timedelta, time
from airflow import DAG
import airflow.operators
from airflow.operators import PythonOperator
from airflow.operators import BashOperator
import os
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor
sys.path.append(os.path.dirname(__file__))
from nw_slack import send_message

# k6v7j9w6n5r3w2v4@nerdwallet.slack.com dwh-oncall slack#
# o2h5c1k1l5p7e3z9@nerdwallet.slack.com mktg-dq slack#

dag_name = "dag_send_slack_hourly_alerts"

default_args = {
    'owner': 'dwh',
    'start_date': datetime(2018,8,12),
    'retries': 0,
    'queue': 'dwh'
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@hourly')


### check marketing mta completed at UTC 06 ###
task_hourly_nerdlake_core_page_view = ExternalTaskSensor(
    task_id='dag_hourlynerdlake_core_page_view_done',
    external_dag_id='dag_hourly_nerdlake_core_p0',
    external_task_id='dw_page_view_event_f_nerdlake_load',
    allowed_states=['success','failed'],
    email_on_failure=True,
    email=['nmylarappa@nerdwallet.com'],
    dag=dag)

# *****************Sending Slack Message*************************

task_send_slack_nerdlake_core_page_view=PythonOperator(
               task_id='send_slack_message',
               provide_context=False,
               python_callable=send_message,
               op_args=["UAA9M8NAK","DAG Hourly - nerdlake core page view completed"],
               dag=dag)


task_send_slack_nerdlake_core_page_view.set_upstream(task_hourly_nerdlake_core_page_view)
