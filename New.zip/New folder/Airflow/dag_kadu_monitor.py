from datetime import datetime, timedelta
import os
import sys
import urllib

from airflow import DAG
from airflow.operators.sensors import ExternalTaskSensor

sys.path.append(os.path.dirname(__file__))  # Allow importing of modules from the same directory as our DAGs
import airflow_dwh

dag_name = 'dag_kadu_monitor'

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': False,
    'start_date': datetime(2018, 9, 18),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 0,
    'depends_on_past': False
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@hourly')


def notify_kadu_not_complete(context):
    scheduled_ts = context['execution_date'].strftime('%Y-%m-%d %H:%M:%S')
    dag_url = 'https://airflow.nerdwallet.io/admin/airflow/graph?{}'.format(
        urllib.urlencode({'dag_id': context['task'].external_dag_id}))
    airflow_dwh.send_slack_message(
        channel='#dwh-oncall',
        message='@channel Production KaDu not complete for schedule `{}`: {}'.format(scheduled_ts, dag_url)
    )


task_monitor_kadu = ExternalTaskSensor(
    task_id='dag_kadu_event_consumption_prod.kadu_done_success',
    external_dag_id='dag_kadu_event_consumption_prod',
    external_task_id='kadu_done_success',
    on_failure_callback=notify_kadu_not_complete,
    timeout=timedelta(minutes=10).total_seconds(),
    email_on_failure=False,
    dag=dag)
