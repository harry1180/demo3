import sys
from datetime import *
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_monthly_get_aws_ips"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2017, 10, 25, 19, 0),
    'email': ['airflowalerts@nerdwallet.com','dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@monthly')

task_get_amazon_ips_extract = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/get_amazon_ips/shellscripts/get_amazon_ips.sh",
    script_args=[],
    task_id="get_amazon_ips_extract",
    dag=dag)

task_amazon_ips_s_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/amazon_ips_s/shellscripts/amazon_ips_s.sh",
    script_args=[],
    task_id='amazon_ips_s_load',
    dag=dag)
task_amazon_ips_s_load.set_upstream(task_get_amazon_ips_extract)

task_amazon_ips_d_nerdlake_load = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/amazon_ips_d_nerdlake/shellscripts/amazon_ips_d.sh",
    script_args=[],
    task_id="amazon_ips_d_nerdlake_load",
    pool='presto_etl',
    dag=dag)
task_amazon_ips_d_nerdlake_load.set_upstream(task_get_amazon_ips_extract)
