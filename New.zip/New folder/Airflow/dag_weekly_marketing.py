import sys
from datetime import *
from airflow import DAG
import airflow.operators
from datetime import datetime, timedelta,time
from airflow.operators import BashOperator
import os

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

job_name = "dag_weekly_marketing"

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2018,7,1),
    'email': ['hkoppuravuri@nerdwallet.com','nmylarappa@nerdwallet.com','ssundara@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval='15 0 * * 2')




task_mktg_mailchimp_open_details_perf_f_script = "/data/etl/Scripts/mktg_mailchimp_open_details_perf_f/shellscripts/mktg_mailchimp_open_details_perf_f.sh"
task_mktg_mailchimp_open_details_perf_f = NWBashScriptOperator(
      bash_script=task_mktg_mailchimp_open_details_perf_f_script,
      script_args=[],
      task_id='mktg_mailchimp_open_details_perf_f',
      dag=dag)

task_mktg_mailchimp_sent_to_perf_f_script = "/data/etl/Scripts/mktg_mailchimp_sent_to_perf_f/shellscripts/mktg_mailchimp_sent_to_perf_f.sh"
task_mktg_mailchimp_sent_to_perf_f = NWBashScriptOperator(
      bash_script=task_mktg_mailchimp_sent_to_perf_f_script,
      script_args=[],
      task_id='mktg_mailchimp_sent_to_perf_f',
      dag=dag)

task_mktg_mailchimp_click_details_perf_f_script = "/data/etl/Scripts/mktg_mailchimp_click_details_perf_f/shellscripts/mktg_mailchimp_click_details_perf_f.sh"
task_mktg_mailchimp_click_details_perf_f = NWBashScriptOperator(
      bash_script=task_mktg_mailchimp_click_details_perf_f_script,
      script_args=[],
      task_id='mktg_mailchimp_click_details_perf_f',
      dag=dag)
task_mktg_mailchimp_sent_to_perf_f.set_upstream(task_mktg_mailchimp_open_details_perf_f)
task_mktg_mailchimp_click_details_perf_f.set_upstream(task_mktg_mailchimp_sent_to_perf_f)

