from datetime import datetime, timedelta, time
import sys

from airflow import DAG
from airflow.operators import NWBashScriptOperator, PythonOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

sys.path.append('/data/etl/Common')
from run_dq_check import dq_check as dq_check_call


# k6v7j9w6n5r3w2v4@nerdwallet.slack.com dwh-oncall slack#
# o2h5c1k1l5p7e3z9@nerdwallet.slack.com mktg-dq slack#

job_name = "dag_daily_marketing"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 03, 13),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job_google = TimeSensor(
    target_time=time(1, 5),
    task_id='mktg_digital_start_time_UTC_01_PDT_18_PST_17',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

external_dag_id = 'baidag_sst_aggregates'
external_task_id = 'exec_aggs_done'
task_id = external_dag_id + "__" + external_task_id
task_dep1 = ExternalTaskSensor(
    task_id=task_id,
    external_dag_id=external_dag_id,
    external_task_id=external_task_id,
    dag=dag)

task_start_job_utc01_fb = TimeSensor(
    target_time=time(00,30), #HH,MM
    task_id='mktg_fb_start_time_UTC_00_30',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_start_job_utc01_taboola = TimeSensor(
    target_time=time(1, 5),
    task_id='mktg_taboola_start_time_UTC_01',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_mta_external_dependency = ExternalTaskSensor(
    task_id='waiting_for_mta',
    external_dag_id='dag_daily_marketing_mta',
    external_task_id='mktg_mta_status_update',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

#task_start_job_utc01 = TimeSensor(     # changed name 
task_start_job_utc0005 = TimeSensor(            
    target_time=time(00, 05),  # changed from 1 05 to 00 05 due to long running content_d_job
    task_id='mktg_digital_start_time_UTC_0005_no_upstream',   #changed ID name
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

#new timesensor for outbrain content to start at 8am UTC due to data availablility from Outbrain
task_start_job_utc08_00_ob_cntnt = TimeSensor(
    target_time=time(8, 00),  
    task_id='mktg_outbrain_content_start_time_UTC_08_00', 
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])


task19_script = "/data/etl/Scripts/marketing_monitor/shellscripts/marketing_monitor.sh"
task19_marketing_monitor = NWBashScriptOperator(
    bash_script=task19_script,
    script_args=[],
    task_id='marketing_monitor',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

# task20_script="/data/etl/Scripts/marketing_bing/shellscripts/bing_download.sh"
# task20_marketing_bing = NWBashScriptOperator(
#           bash_script=task20_script,
#           script_args=[],
#           task_id='marketing_bing',
#           trigger_rule='all_done',
#           dag=dag)
#
# task21_script="/data/etl/Scripts/mktg_bing_cmpgn_d/shellscripts/mktg_bing_cmpgn_d.sh"
# task21_mktg_bing_cmpgn_d = NWBashScriptOperator(
#           bash_script=task21_script,
#           script_args=[],
#           task_id='mktg_bing_cmpgn_d',
#           trigger_rule='all_done',
#           dag=dag)
#
# task22_script="/data/etl/Scripts/mktg_bing_kw_d/shellscripts/mktg_bing_kw_d.sh"
# task22_mktg_bing_kw_d = NWBashScriptOperator(
#           bash_script=task22_script,
#           script_args=[],
#           task_id='mktg_bing_kw_d',
#           trigger_rule='all_done',
#           dag=dag)
#
# task23_script="/data/etl/Scripts/mktg_bing_cmpgn_kw_d/shellscripts/mktg_bing_cmpgn_kw_d.sh"
# task23_mktg_bing_cmpgn_kw_d = NWBashScriptOperator(
#           bash_script=task23_script,
#           script_args=[],
#           task_id='mktg_bing_cmpgn_kw_d',
#           trigger_rule='all_done',
#           dag=dag)
#
# task24_script="/data/etl/Scripts/mktg_bing_cmpgn_f/shellscripts/mktg_bing_cmpgn_f.sh"
# task24_mktg_bing_cmpgn_f = NWBashScriptOperator(
#           bash_script=task24_script,
#           script_args=[],
#           task_id='mktg_bing_cmpgn_f',
#           trigger_rule='all_done',
#           dag=dag)
#
# task25_script="/data/etl/Scripts/mktg_bing_kw_f/shellscripts/mktg_bing_kw_f.sh"
# task25_mktg_bing_kw_f = NWBashScriptOperator(
#           bash_script=task25_script,
#           script_args=[],
#           task_id='mktg_bing_kw_f',
#           trigger_rule='all_done',
#           dag=dag)
#
# task26_script="/data/etl/Scripts/mktg_bing_sq_f/shellscripts/mktg_bing_sq_f.sh"
# task26_mktg_bing_sq_f = NWBashScriptOperator(
#           bash_script=task26_script,
#           script_args=[],
#           task_id='mktg_bing_sq_f',
#           trigger_rule='all_done',
#           dag=dag)
#
# task27_script="/data/etl/Scripts/mktg_bing_geo_f/shellscripts/mktg_bing_geo_f.sh"
# task27_mktg_bing_geo_f = NWBashScriptOperator(
#           bash_script=task27_script,
#           script_args=[],
#           task_id='mktg_bing_geo_f',
#           trigger_rule='all_done',
#           dag=dag)

task_appsflyer_doc_monitor = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/appsflyer_doc_monitor/shellscripts/appsflyer_doc_monitor.sh",
    script_args=[],
    task_id="appsflyer_doc_monitor",
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])
task_appsflyer_doc_monitor.set_upstream(task_start_job_google)

task28_script = "/data/etl/Common/redshift_sql_function.sh"
task28_status_update = NWBashScriptOperator(
    bash_script=task28_script,
    script_args=["/data/etl/Airflow/post_updates/dag_daily_marketing_status_update.sql"],
    task_id='status_update',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

######################################################## google adwords 2.0 dependency ###############################################
task_mktg_goog_campaign_d_script = "/data/etl/Scripts/mktg_goog_campaign_d/shellscripts/mktg_goog_campaign_d.sh"
task_mktg_goog_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_goog_campaign_d_script,
    script_args=[],
    task_id='mktg_goog_campaign_d',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_goog_keyword_d_script = "/data/etl/Scripts/mktg_goog_keyword_d/shellscripts/mktg_goog_keyword_d.sh"
task_mktg_goog_keyword_d = NWBashScriptOperator(
    bash_script=task_mktg_goog_keyword_d_script,
    script_args=[],
    task_id='mktg_goog_keyword_d',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task8_script = "/data/etl/Scripts/mktg_goog_campaign_perf_f/shellscripts/mktg_goog_campaign_perf_f.sh"
task8_mktg_goog_campaign_perf_f = NWBashScriptOperator(
    bash_script=task8_script,
    script_args=[],
    task_id='mktg_goog_campaign_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task10_script = "/data/etl/Scripts/mktg_goog_keyword_perf_f/shellscripts/mktg_goog_keyword_perf_f.sh"
task10_mktg_goog_keyword_perf_f = NWBashScriptOperator(
    bash_script=task10_script,
    script_args=[],
    task_id='mktg_goog_keyword_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_goog_campaign_keyword_d_script = "/data/etl/Scripts/mktg_goog_campaign_keyword_d/shellscripts/mktg_goog_campaign_keyword_d.sh"
task_mktg_goog_campaign_keyword_d = NWBashScriptOperator(
    bash_script=task_mktg_goog_campaign_keyword_d_script,
    script_args=[],
    task_id='mktg_goog_campaign_keyword_d',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_goog_ad_d_script = "/data/etl/Scripts/mktg_goog_ad_d/shellscripts/mktg_goog_ad_d.sh"
task_mktg_goog_ad_d = NWBashScriptOperator(
    bash_script=task_mktg_goog_ad_d_script,
    script_args=[],
    task_id='mktg_goog_ad_d',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_goog_ad_perf_f_script = "/data/etl/Scripts/mktg_goog_ad_perf_f/shellscripts/mktg_goog_ad_perf_f.sh"
task_mktg_goog_ad_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_goog_ad_perf_f_script,
    script_args=[],
    task_id='mktg_goog_ad_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_goog_campaign_d.set_upstream(task_start_job_google)
task_mktg_goog_keyword_d.set_upstream(task_mktg_goog_campaign_d)
task8_mktg_goog_campaign_perf_f.set_upstream(task_start_job_google)
task10_mktg_goog_keyword_perf_f.set_upstream(task8_mktg_goog_campaign_perf_f)
task_mktg_goog_ad_perf_f.set_upstream(task10_mktg_goog_keyword_perf_f)
task28_status_update.set_upstream(task10_mktg_goog_keyword_perf_f)
task_mktg_goog_campaign_keyword_d.set_upstream(task_mktg_goog_keyword_d)
task_mktg_goog_ad_d.set_upstream(task_mktg_goog_campaign_keyword_d)
task28_status_update.set_upstream(task_mktg_goog_ad_d)
######################################################## Bing ads 2.0 dependency ###############################################

task_mktg_bing_campaign_perf_f_script = "/data/etl/Scripts/mktg_bing_campaign_perf_f/shellscripts/mktg_bing_campaign_perf_f.sh"
task_mktg_bing_campaign_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_bing_campaign_perf_f_script,
    script_args=[],
    task_id='mktg_bing_campaign_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_bing_keyword_perf_f_script = "/data/etl/Scripts/mktg_bing_keyword_perf_f/shellscripts/mktg_bing_keyword_perf_f.sh"
task_mktg_bing_keyword_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_bing_keyword_perf_f_script,
    script_args=[],
    task_id='mktg_bing_keyword_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_bing_campaign_perf_f.set_upstream(task_start_job_google)
task_mktg_bing_keyword_perf_f.set_upstream(task_mktg_bing_campaign_perf_f)
task28_status_update.set_upstream(task_mktg_bing_keyword_perf_f)

######################################################## Facebook ads dependency ###############################################

task_mktg_fb_campaign_perf_f_script = "/data/etl/Scripts/mktg_fb_campaign_perf_f/shellscripts/mktg_fb_campaign_perf_f.sh"
task_mktg_fb_campaign_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_fb_campaign_perf_f_script,
    script_args=[],
    task_id='mktg_fb_campaign_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_campaign_d_script = "/data/etl/Scripts/mktg_fb_campaign_d/shellscripts/mktg_fb_campaign_d.sh"
task_mktg_fb_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_fb_campaign_d_script,
    script_args=[],
    task_id='mktg_fb_campaign_d',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_adset_perf_f_script = "/data/etl/Scripts/mktg_fb_adset_perf_f/shellscripts/mktg_fb_adset_perf_f.sh"
task_mktg_fb_adset_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_fb_adset_perf_f_script,
    script_args=[],
    task_id='mktg_fb_adset_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_adset_d_script = "/data/etl/Scripts/mktg_fb_adset_d/shellscripts/mktg_fb_adset_d.sh"
task_mktg_fb_adset_d = NWBashScriptOperator(
    bash_script=task_mktg_fb_adset_d_script,
    script_args=[],
    task_id='mktg_fb_adset_d',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_ad_perf_f_script = "/data/etl/Scripts/mktg_fb_ad_perf_f/shellscripts/mktg_fb_ad_perf_f.sh"
task_mktg_fb_ad_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_fb_ad_perf_f_script,
    script_args=[],
    task_id='mktg_fb_ad_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_ad_d_script = "/data/etl/Scripts/mktg_fb_ad_d/shellscripts/mktg_fb_ad_d.sh"
task_mktg_fb_ad_d = NWBashScriptOperator(
    bash_script=task_mktg_fb_ad_d_script,
    script_args=[],
    task_id='mktg_fb_ad_d',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_adset_social_perf_f_script = "/data/etl/Scripts/mktg_fb_adset_social_perf_f/shellscripts/mktg_fb_adset_social_perf_f.sh"
task_mktg_fb_adset_social_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_fb_adset_social_perf_f_script,
    script_args=[],
    task_id='mktg_fb_adset_social_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_post_xref_script = "/data/etl/Scripts/mktg_fb_post_xref/shellscripts/mktg_fb_post_xref.sh"
task_mktg_fb_post_xref = NWBashScriptOperator(
    bash_script=task_mktg_fb_post_xref_script,
    script_args=[],
    task_id='mktg_fb_post_xref',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_ad_social_perf_f_script = "/data/etl/Scripts/mktg_fb_ad_social_perf_f/shellscripts/mktg_fb_ad_social_perf_f.sh"
task_mktg_fb_ad_social_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_fb_ad_social_perf_f_script,
    script_args=[],
    task_id='mktg_fb_ad_social_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_order_id_imprsn_f_script = "/data/etl/Scripts/mktg_fb_order_id_imprsn_f/shellscripts/mktg_fb_order_id_imprsn_f.sh"
task_mktg_fb_order_id_imprsn_f = NWBashScriptOperator(
    bash_script=task_mktg_fb_order_id_imprsn_f_script,
    script_args=[],
    task_id='mktg_fb_order_id_imprsn_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])


task_start_job_google.set_upstream([task_dep1, task_mktg_mta_external_dependency])
task_mktg_fb_campaign_perf_f.set_upstream(task_start_job_utc01_fb)
task_mktg_fb_campaign_d.set_upstream(task_mktg_fb_campaign_perf_f)
task_mktg_fb_adset_perf_f.set_upstream(task_mktg_fb_campaign_d)
task_mktg_fb_adset_d.set_upstream(task_mktg_fb_adset_perf_f)
task_mktg_fb_ad_perf_f.set_upstream(task_mktg_fb_adset_d)
task_mktg_fb_ad_d.set_upstream(task_mktg_fb_ad_perf_f)
task_mktg_fb_adset_social_perf_f.set_upstream(task_mktg_fb_ad_d)
task_mktg_fb_post_xref.set_upstream(task_mktg_fb_adset_social_perf_f)
task_mktg_fb_ad_social_perf_f.set_upstream(task_mktg_fb_post_xref)
task_mktg_fb_order_id_imprsn_f.set_upstream(task_mktg_fb_ad_d)

######################################################## Facebook post dependency ###############################################
task_mktg_fb_post_d_script = "/data/etl/Scripts/mktg_fb_post_d/shellscripts/mktg_fb_post_d.sh"
task_mktg_fb_post_d = NWBashScriptOperator(
    bash_script=task_mktg_fb_post_d_script,
    script_args=[],
    task_id='mktg_fb_post_d',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_post_perf_f_script = "/data/etl/Scripts/mktg_fb_post_perf_f/shellscripts/mktg_fb_post_perf_f.sh"
task_mktg_fb_post_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_fb_post_perf_f_script,
    script_args=[],
    task_id='mktg_fb_post_perf_f',
    trigger_rule='all_done',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_fb_post_d.set_upstream(task_start_job_google)
task_mktg_fb_post_perf_f.set_upstream(task_mktg_fb_post_d)

######################################################## Taboola  ####################################################################
task_mktg_taboola_campaign_d_script = "/data/etl/Scripts/mktg_taboola_campaign_d/shellscripts/mktg_taboola_campaign_d.sh"
task_mktg_taboola_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_taboola_campaign_d_script,
    script_args=[],
    task_id='mktg_taboola_campaign_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_taboola_item_d_script = "/data/etl/Scripts/mktg_taboola_item_d/shellscripts/mktg_taboola_item_d.sh"
task_mktg_taboola_item_d = NWBashScriptOperator(
    bash_script=task_mktg_taboola_item_d_script,
    script_args=[],
    task_id='mktg_taboola_item_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_taboola_campaign_perf_f_script = "/data/etl/Scripts/mktg_taboola_campaign_perf_f/shellscripts/mktg_taboola_campaign_perf_f.sh"
task_mktg_taboola_campaign_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_taboola_campaign_perf_f_script,
    script_args=[],
    task_id='mktg_taboola_campaign_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_taboola_item_perf_f_script = "/data/etl/Scripts/mktg_taboola_item_perf_f/shellscripts/mktg_taboola_item_perf_f.sh"
task_mktg_taboola_item_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_taboola_item_perf_f_script,
    script_args=[],
    task_id='mktg_taboola_item_perf_f',
    trigger_rule='all_done',
    execution_timeout=timedelta(hours=6),
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_taboola_campaign_site_perf_f_script = "/data/etl/Scripts/mktg_taboola_campaign_site_perf_f/shellscripts/mktg_taboola_campaign_site_perf_f.sh"
task_mktg_taboola_campaign_site_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_taboola_campaign_site_perf_f_script,
    script_args=[],
    task_id='mktg_taboola_campaign_site_perf_f',
    trigger_rule='all_done',
    execution_timeout=timedelta(hours=1),
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_taboola_item_perf_f.set_upstream(task_start_job_utc01_taboola)
task_mktg_taboola_campaign_d.set_upstream(task_start_job_utc01_taboola)
task_mktg_taboola_item_d.set_upstream(task_mktg_taboola_campaign_d)
task_mktg_taboola_campaign_perf_f.set_upstream(task_mktg_taboola_item_d)
task_mktg_taboola_campaign_site_perf_f.set_upstream(task_mktg_taboola_campaign_perf_f)

######################################################## Outbrain  ####################################################################

task_mktg_outbrain_acct_d_script = "/data/etl/Scripts/mktg_outbrain_acct_d/shellscripts/mktg_outbrain_acct_d.sh"
task_mktg_outbrain_acct_d = NWBashScriptOperator(
    bash_script=task_mktg_outbrain_acct_d_script,
    script_args=[],
    task_id='mktg_outbrain_acct_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_outbrain_budget_d_script = "/data/etl/Scripts/mktg_outbrain_budget_d/shellscripts/mktg_outbrain_budget_d.sh"
task_mktg_outbrain_budget_d = NWBashScriptOperator(
    bash_script=task_mktg_outbrain_budget_d_script,
    script_args=[],
    task_id='mktg_outbrain_budget_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_outbrain_campaign_d_script = "/data/etl/Scripts/mktg_outbrain_campaign_d/shellscripts/mktg_outbrain_campaign_d.sh"
task_mktg_outbrain_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_outbrain_campaign_d_script,
    script_args=[],
    task_id='mktg_outbrain_campaign_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_outbrain_content_d_script = "/data/etl/Scripts/mktg_outbrain_content_d/shellscripts/mktg_outbrain_content_d.sh"
task_mktg_outbrain_content_d = NWBashScriptOperator(
    bash_script=task_mktg_outbrain_content_d_script,
    script_args=[],
    task_id='mktg_outbrain_content_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_outbrain_campaign_perf_f_script = "/data/etl/Scripts/mktg_outbrain_campaign_perf_f/shellscripts/mktg_outbrain_campaign_perf_f.sh"
task_mktg_outbrain_campaign_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_outbrain_campaign_perf_f_script,
    script_args=[],
    task_id='mktg_outbrain_campaign_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_outbrain_content_perf_f_script = "/data/etl/Scripts/mktg_outbrain_content_perf_f/shellscripts/mktg_outbrain_content_perf_f.sh"
task_mktg_outbrain_content_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_outbrain_content_perf_f_script,
    script_args=[],
    task_id='mktg_outbrain_content_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_outbrain_section_perf_f_script = "/data/etl/Scripts/mktg_outbrain_section_perf_f/shellscripts/mktg_outbrain_section_perf_f.sh"
task_mktg_outbrain_section_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_outbrain_section_perf_f_script,
    script_args=[],
    task_id='mktg_outbrain_section_perf_f',
    trigger_rule='all_done',
    execution_timeout=timedelta(hours=4),
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_outbrain_acct_d.set_upstream(task_start_job_utc0005)  #changed name
task_mktg_outbrain_content_d.set_upstream(task_start_job_utc0005) # moved job to dependency on start time
task_mktg_outbrain_budget_d.set_upstream(task_mktg_outbrain_acct_d)
task_mktg_outbrain_campaign_d.set_upstream(task_mktg_outbrain_budget_d)
task_mktg_outbrain_campaign_perf_f.set_upstream(task_mktg_outbrain_campaign_d)
task_mktg_outbrain_content_perf_f.set_upstream(task_mktg_outbrain_campaign_perf_f)
task_mktg_outbrain_content_perf_f.set_upstream(task_start_job_utc08_00_ob_cntnt)
task_mktg_outbrain_section_perf_f.set_upstream(task_mktg_outbrain_content_perf_f)

######################################################## Yahoo ads dependency ###############################################

task_mktg_yahoo_campaign_perf_f_script = "/data/etl/Scripts/mktg_yahoo_campaign_perf_f/shellscripts/mktg_yahoo_campaign_perf_f.sh"
task_mktg_yahoo_campaign_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_yahoo_campaign_perf_f_script,
    script_args=[],
    task_id='mktg_yahoo_campaign_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_yahoo_campaign_d_script = "/data/etl/Scripts/mktg_yahoo_campaign_d/shellscripts/mktg_yahoo_campaign_d.sh"
task_mktg_yahoo_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_yahoo_campaign_d_script,
    script_args=[],
    task_id='mktg_yahoo_campaign_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_yahoo_keyword_perf_f_script = "/data/etl/Scripts/mktg_yahoo_keyword_perf_f/shellscripts/mktg_yahoo_keyword_perf_f.sh"
task_mktg_yahoo_keyword_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_yahoo_keyword_perf_f_script,
    script_args=[],
    task_id='mktg_yahoo_keyword_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

# task_mktg_yahoo_keyword_d_script = "/data/etl/Scripts/mktg_yahoo_keyword_d/shellscripts/mktg_yahoo_keyword_d.sh"
# task_mktg_yahoo_keyword_d = NWBashScriptOperator(
#     bash_script=task_mktg_yahoo_keyword_d_script,
#     script_args=[],
#     task_id='mktg_yahoo_keyword_d',
#     trigger_rule='all_done',
#     dag=dag,
#     email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])
#
task_mktg_yahoo_campaign_d.set_upstream(task_start_job_google)
task_mktg_yahoo_campaign_perf_f.set_upstream(task_mktg_yahoo_campaign_d)
#task_mktg_yahoo_keyword_d.set_upstream(task_mktg_yahoo_campaign_perf_f)
task_mktg_yahoo_keyword_perf_f.set_upstream(task_mktg_yahoo_campaign_perf_f)
task28_status_update.set_upstream(task_mktg_yahoo_keyword_perf_f)

######################################################## Dianomi ads dependency ###############################################

task_mktg_dianomi_ad_perf_variant_actns_f_script = "/data/etl/Scripts/mktg_dianomi_ad_perf_variant_actns_f/shellscripts/mktg_dianomi_ad_perf_variant_actns_f.sh"
task_mktg_dianomi_ad_perf_variant_actns_f = NWBashScriptOperator(
    bash_script=task_mktg_dianomi_ad_perf_variant_actns_f_script,
    script_args=[],
    task_id='mktg_dianomi_ad_perf_variant_actns_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_dianomi_campaign_d_script = "/data/etl/Scripts/mktg_dianomi_campaign_d/shellscripts/mktg_dianomi_campaign_d.sh"
task_mktg_dianomi_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_dianomi_campaign_d_script,
    script_args=[],
    task_id='mktg_dianomi_campaign_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_dianomi_variant_d_script = "/data/etl/Scripts/mktg_dianomi_variant_d/shellscripts/mktg_dianomi_variant_d.sh"
task_mktg_dianomi_variant_d = NWBashScriptOperator(
    bash_script=task_mktg_dianomi_variant_d_script,
    script_args=[],
    task_id='mktg_dianomi_variant_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_dianomi_campaign_d.set_upstream(task_start_job_google)
task_mktg_dianomi_variant_d.set_upstream(task_mktg_dianomi_campaign_d)
task_mktg_dianomi_ad_perf_variant_actns_f.set_upstream(task_mktg_dianomi_variant_d)
task28_status_update.set_upstream(task_mktg_dianomi_ad_perf_variant_actns_f)

######################################################## Apple search ads dependency ###############################################

task_mktg_apple_campaign_perf_f_script = "/data/etl/Scripts/mktg_apple_campaign_perf_f/shellscripts/mktg_apple_campaign_perf_f.sh"
task_mktg_apple_campaign_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_apple_campaign_perf_f_script,
    script_args=[],
    task_id='mktg_apple_campaign_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_apple_campaign_d_script = "/data/etl/Scripts/mktg_apple_campaign_d/shellscripts/mktg_apple_campaign_d.sh"
task_mktg_apple_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_apple_campaign_d_script,
    script_args=[],
    task_id='mktg_apple_campaign_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_apple_keyword_perf_f_script = "/data/etl/Scripts/mktg_apple_keyword_perf_f/shellscripts/mktg_apple_keyword_perf_f.sh"
task_mktg_apple_keyword_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_apple_keyword_perf_f_script,
    script_args=[],
    task_id='mktg_apple_keyword_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_apple_keyword_d_script = "/data/etl/Scripts/mktg_apple_keyword_d/shellscripts/mktg_apple_keyword_d.sh"
task_mktg_apple_keyword_d = NWBashScriptOperator(
    bash_script=task_mktg_apple_keyword_d_script,
    script_args=[],
    task_id='mktg_apple_keyword_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_apple_campaign_d.set_upstream(task_start_job_google)
task_mktg_apple_campaign_perf_f.set_upstream(task_mktg_apple_campaign_d)
task_mktg_apple_keyword_d.set_upstream(task_mktg_apple_campaign_perf_f)
task_mktg_apple_keyword_perf_f.set_upstream(task_mktg_apple_keyword_d)
task28_status_update.set_upstream(task_mktg_apple_keyword_perf_f)

############################################################ Marketting Adroll #########################################################

task_mktg_adroll_perf_f_script = "/data/etl/Scripts/mktg_adroll_perf_f/shellscripts/mktg_adroll_perf_f.sh"
task_mktg_adroll_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_adroll_perf_f_script,
    script_args=[],
    task_id='mktg_adroll_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_adroll_campaign_d_script = "/data/etl/Scripts/mktg_adroll_campaign_d/shellscripts/mktg_adroll_campaign_d.sh"
task_mktg_adroll_campaign_d = NWBashScriptOperator(
    bash_script=task_mktg_adroll_campaign_d_script,
    script_args=[],
    task_id='mktg_adroll_campaign_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_adroll_ad_d_script = "/data/etl/Scripts/mktg_adroll_ad_d/shellscripts/mktg_adroll_ad_d.sh"
task_mktg_adroll_ad_d = NWBashScriptOperator(
    bash_script=task_mktg_adroll_ad_d_script,
    script_args=[],
    task_id='mktg_adroll_ad_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])

task_mktg_adroll_adgroup_d_script = "/data/etl/Scripts/mktg_adroll_adgroup_d/shellscripts/mktg_adroll_adgroup_d.sh"
task_mktg_adroll_adgroup_d = NWBashScriptOperator(
    bash_script=task_mktg_adroll_adgroup_d_script,
    script_args=[],
    task_id='mktg_adroll_adgroup_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag,
    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])


task_mktg_adroll_campaign_d.set_upstream(task_start_job_google)
task_mktg_adroll_ad_d.set_upstream(task_mktg_adroll_campaign_d)
task_mktg_adroll_adgroup_d.set_upstream(task_mktg_adroll_ad_d)
task_mktg_adroll_perf_f.set_upstream(task_mktg_adroll_adgroup_d)
############################################################ Consolidated #########################################################

task_mktg_consolidated_campaign_perf_f_script = "/data/etl/Scripts/mktg_consolidated_campaign_perf_f/shellscripts/mktg_consolidated_campaign_perf_f.sh"
task_mktg_consolidated_campaign_perf_f = NWBashScriptOperator(
    bash_script=task_mktg_consolidated_campaign_perf_f_script,
    script_args=[],
    email=['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    task_id='mktg_consolidated_campaign_perf_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task_mktg_consolidated_campaign_perf_f.set_upstream(task8_mktg_goog_campaign_perf_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_goog_ad_perf_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_bing_campaign_perf_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_bing_keyword_perf_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_yahoo_campaign_perf_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_yahoo_keyword_perf_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_dianomi_ad_perf_variant_actns_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_apple_campaign_perf_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_apple_keyword_perf_f)
task_mktg_consolidated_campaign_perf_f.set_upstream(task_mktg_adroll_perf_f)
task28_status_update.set_upstream(task_mktg_consolidated_campaign_perf_f)

############################################################ Offline Completion #####################################################
#task_mktg_dag_completion_script = "/data/etl/Scripts/mktg_dag_completion/shellscripts/mktg_dag_completion.sh"
#task_mktg_dag_completion = NWBashScriptOperator(
#    bash_script=task_mktg_dag_completion_script,
#    script_args=[],
#    task_id='mktg_dag_completion',
#    trigger_rule='all_done',
#    dag=dag,
#    email=['o2h5c1k1l5p7e3z9@nerdwallet.slack.com', 'k6v7j9w6n5r3w2v4@nerdwallet.slack.com'])


#######################################################################################################################################

task19_marketing_monitor.set_upstream(task28_status_update)

# task20_marketing_bing.set_upstream(task_start_job_google)
# task21_mktg_bing_cmpgn_d.set_upstream(task20_marketing_bing)
# task22_mktg_bing_kw_d.set_upstream(task21_mktg_bing_cmpgn_d)
# task23_mktg_bing_cmpgn_kw_d.set_upstream(task22_mktg_bing_kw_d)
# task24_mktg_bing_cmpgn_f.set_upstream(task23_mktg_bing_cmpgn_kw_d)
# task25_mktg_bing_kw_f.set_upstream(task24_mktg_bing_cmpgn_f)
# task26_mktg_bing_sq_f.set_upstream(task25_mktg_bing_kw_f)
# task27_mktg_bing_geo_f.set_upstream(task26_mktg_bing_sq_f)
# task28_status_update.set_upstream(task27_mktg_bing_geo_f)
