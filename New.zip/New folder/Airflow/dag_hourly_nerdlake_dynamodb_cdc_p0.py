from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeDeltaSensor
import boto

dag_name = 'dag_hourly_nerdlake_dynamodb_cdc_p0'

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2018, 5, 17),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=2),
    'depends_on_past': True
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@hourly')

task_start_dag = TimeDeltaSensor(
    delta=timedelta(minutes=3),
    task_id='Wait_for_Firehose',
    poke_interval=5,
    dag=dag)


###########################################################################
# Function to find the list of S3 folders that contain CDC files from
# DynamoDB tables. Function returns a dictionary containing the S3 folder
# name as the key and the corresponding DynamoDB table name as the value.
# The DynamoDB table name contains the 'udp-' database name prefix, e.g.
# 'udp-global_profiles'.
###########################################################################
def get_identity_s3_folders():
    s3 = boto.connect_s3()
    bucket_name = Variable.get('s3_bucket_dynamodb_cdc')

    # Parse off the first two pieces of the bucket name, this will be the prefix of the folders.
    region_name, env_name, remainder = bucket_name.split('-', 2)
    folder_prefix = '{}-{}-udp-'.format(region_name, env_name)

    bucket = s3.get_bucket(bucket_name)
    dynamodb_cdc_folders = dict()
    for key in bucket.list(prefix=folder_prefix, delimiter='/'):
        if key.name[-1] != '/':
            continue
        folder_name = key.name.rstrip('/')
        dynamodb_cdc_folders[folder_name] = folder_name[len(region_name) + len(env_name) + 2:]

    return dynamodb_cdc_folders


###########################################################################
# Command tasks
###########################################################################
for dynamodb_cdc_folder_name, dynamodb_table_name in get_identity_s3_folders().iteritems():

    transform_task = NWBashScriptOperator(
        task_id='transform_json_{}'.format(dynamodb_cdc_folder_name),
        bash_script='/data/etl/Scripts/dynamodb_cdc_transform_json/shellscripts/dynamodb_cdc_transform_json.sh',
        script_args=[Variable.get('s3_bucket_dynamodb_cdc'), dynamodb_cdc_folder_name],
        dag=dag)
    transform_task.set_upstream(task_start_dag)

    convert_task = NWBashScriptOperator(
        task_id='json_to_orc_{}'.format(dynamodb_table_name),
        bash_script='/data/etl/Scripts/dynamodb_cdc_json_to_orc/shellscripts/dynamodb_cdc_json_to_orc.sh',
        script_args=[dynamodb_table_name],
        pool='presto_etl',
        dag=dag)
    convert_task.set_upstream(transform_task)

    if dynamodb_table_name in ('udp-visitor_tokens', 'udp-consumer_data_contribs', 'udp-consumer_profiles'):
        weight = 1
        if dynamodb_table_name == 'udp-visitor_tokens':
            weight = 10
        materialize_task = NWBashScriptOperator(
            task_id='materialize_{}'.format(dynamodb_table_name),
            bash_script='/data/etl/Scripts/dynamodb_cdc_materialize_current/shellscripts/dynamodb_cdc_materialize_current.sh',
            script_args=[dynamodb_table_name],
            pool='presto_etl',
            priority_weight=weight,
            dag=dag)
        materialize_task.set_upstream(convert_task)
