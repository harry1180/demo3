from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators import NWBashScriptOperator, DummyOperator
from airflow.operators.sensors import ExternalTaskSensor

job_name = 'dag_hourly_nerdlake_events_p0'

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2018, 5, 17),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=10),
    'queue': 'highmem',
    'depends_on_past': True
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@hourly')

###########################################################################
# External task sensors
###########################################################################
kadu_external_task_sensor = ExternalTaskSensor(
    task_id='dag_kadu_event_consumption_prod.kadu_done',
    external_dag_id='dag_kadu_event_consumption_prod',
    external_task_id='kadu_done',
    poke_interval=5,
    dag=dag)

################################################################################
# Event deserialization
################################################################################
event_names = {
# Disabling ABLog on 1/26/2018 because events are coming in with timestamps
# throughout all of 2015/2016/2017/2018 and creating thousands of files.
# PqWriter fails with "too many files" errors.
#   'ABLog',
    'ActivateCreditProfileEvent',
    'ActivationEvent',
    'AppsFlyerWebhookEvent',
    'BackendNWUserDataExportEvent',
    'BankingRateImpressionEvent',
    'BrokersClickEvent',
    'BrokersImpressionEvent',
    'CCClickEvent',
    'CCElementImpressionEvent',
    'CCElementInteractionEvent',
    'CCImpressionEvent',
    # 'CLOUserTokenRequestEvent',
    'ClientNWUserDataExportEvent',
    'CreditScoreClickEvent',
    'DeactivateCreditProfileEvent',
    'DeactivateIdentityEvent',
    'DeactivationEvent',
    'DuplicateTUUserEvent',
    'EDULoansPrequalOfferEvent',
    'ElementImpressionEvent',
    'ElementInteractionEvent',
    'EmbedViewEvent',
    'EmailBounceEvent',
    'EmailClickEvent',
    'EmailOpenEvent',
    'EmailSendEvent',
    'ExperimentExposureEvent',
    'FeedElementImpressionEvent',
    'FeedElementInteractionEvent',
    'FeedItemChangedEvent',
    'FormInputChangedEvent',
    'ForumActivityEvent',
    'GenericClickEvent',
    'GenericImpressionEvent',
    'HeartbeatEvent',
    'InsuranceClickEvent',
    'InsuranceImpressionEvent',
    'InsuranceProductClickEvent',
    'JoinEvent',
    'LoginIdentityEvent',
    'LogoutIdentityEvent',
    'MortgageLenderClickEvent',
    'MortgageLenderImpressionEvent',
    'MortgageLenderQuoteEvent',
    'OptimizelyExperimentsEvent',
    'PageViewEvent',
    'PasswordResetIdentityEvent',
    'PersonalLoansClickEvent',
    'PersonalLoansImpressionEvent',
    'PersonalLoansPrequalOfferEvent',
    'PrepaidClickEvent',
    'ProductApprovalEvent',
    'ProductInteractionEvent',
    'ProviderAccountStateChangeEvent',
    'PushSendEvent',
    'RateClickEvent',
    'RoleChangeEvent',
    'RegisterIdentityEvent',
    'SessionStartEvent',
    'SMBClickEvent',
    'SMBImpressionEvent',
    'SMBPrequalOfferEvent',
    'ShoppingClickEvent',
    'TaxesClickEvent',
    'YodleeProviderAccountWorkflowEvent'
}
event_tasks = dict()
for event_name in sorted(event_names, key=lambda s: s.lower()):
    weight = 1
    if event_name in ('PageViewEvent', 'FormInputChangedEvent'):
        weight = 10
    event_task = NWBashScriptOperator(
        bash_script='/data/etl/Common/deserialize_pb_nerdlake.sh',
        script_args=[event_name],
        task_id='{}_nerdlake_deserialization_load'.format(event_name),
        pool='nerdlake_deser_airflowhighmem',
        priority_weight=weight,
        dag=dag)
    event_task.set_upstream(kadu_external_task_sensor)
    event_tasks[event_name] = event_task

################################################################################
# Custom event deserialization
################################################################################

# This is a meta-event, don't add it to the event_tasks dictionary
task_minus_world_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/MinusWorldEvent_nerdlake/shellscripts/MinusWorldEvent_nerdlake.sh',
    script_args=[],
    task_id='MinusWorldEvent_nerdlake_load',
    dag=dag
    )
task_minus_world_nerdlake_load.set_upstream(kadu_external_task_sensor)

# This is a meta-event, don't add it to the event_tasks dictionary
task_shadow_realm_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/ShadowRealmEvent_nerdlake/shellscripts/ShadowRealmEvent_nerdlake.sh',
    script_args=[],
    task_id='ShadowRealmEvent_nerdlake_load',
    dag=dag
    )
task_shadow_realm_nerdlake_load.set_upstream(kadu_external_task_sensor)

task_backend_model_execution_event_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/BackendModelExecutionEvent_nerdlake/shellscripts/BackendModelExecutionEvent_nerdlake.sh',
    script_args=[],
    task_id='BackendModelExecutionEvent_nerdlake_load',
    dag=dag
    )
task_backend_model_execution_event_nerdlake_load.set_upstream(kadu_external_task_sensor)
event_tasks['BackendModelExecutionEvent'] = task_backend_model_execution_event_nerdlake_load

task_api_response_event_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/APIResponseEvent_nerdlake/shellscripts/APIResponseEvent_nerdlake.sh',
    script_args=['prod'],
    task_id='ApiResponseEvent_nerdlake_load',
    dag=dag
    )
task_api_response_event_nerdlake_load.set_upstream(kadu_external_task_sensor)
event_tasks['ApiResponseEvent'] = task_api_response_event_nerdlake_load

################################################################################
# Composite Hive tables
################################################################################task_ProviderAccountStateChangeEvent_nerdlake_deserialization_load = NWBashScriptOperator(

# dwnl_stage.click_events_s
task_click_events_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/click_events_s_nerdlake/shellscripts/click_events_s.sh',
    script_args=[],
    task_id='click_events_s_nerdlake_load',
    priority_weight=5,
    dag=dag)
task_click_events_nerdlake_load.set_upstream(event_tasks['BrokersClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['CCClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['CreditScoreClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['GenericClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['InsuranceClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['InsuranceProductClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['MortgageLenderClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['PersonalLoansClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['PrepaidClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['RateClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['SMBClickEvent'])
task_click_events_nerdlake_load.set_upstream(event_tasks['TaxesClickEvent'])

# dwnl_stage.all_events_s -- use all events except a small number of excluded events which appear to be retired
task_all_events_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/all_events_s_nerdlake/shellscripts/all_events_s.sh',
    script_args=[],
    task_id='all_events_s_nerdlake_load',
    dag=dag)
for event_name in sorted(event_tasks.keys()):
    if event_name in ['ABLog', 'DeactivateCreditProfileEvent', 'ProductApprovalEvent', 'ShoppingClickEvent']:
        continue
    task_all_events_nerdlake_load.set_upstream(event_tasks[event_name])

# dwnl_stage.identity_events_s
task_identity_events_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/identity_events_s_nerdlake/shellscripts/identity_events_s.sh',
    script_args=[],
    task_id='identity_events_s_nerdlake_load',
    dag=dag)
task_identity_events_nerdlake_load.set_upstream(event_tasks['ActivationEvent'])
task_identity_events_nerdlake_load.set_upstream(event_tasks['DeactivateIdentityEvent'])
task_identity_events_nerdlake_load.set_upstream(event_tasks['DeactivationEvent'])
task_identity_events_nerdlake_load.set_upstream(event_tasks['LoginIdentityEvent'])
task_identity_events_nerdlake_load.set_upstream(event_tasks['LogoutIdentityEvent'])
task_identity_events_nerdlake_load.set_upstream(event_tasks['PasswordResetIdentityEvent'])
task_identity_events_nerdlake_load.set_upstream(event_tasks['RegisterIdentityEvent'])

# dwnl_stage.impression_events_s
task_impression_events_nerdlake_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/impression_events_s_nerdlake/shellscripts/impression_events_s.sh',
    script_args=[],
    task_id='impression_events_s_nerdlake_load',
    dag=dag)
task_impression_events_nerdlake_load.set_upstream(event_tasks['BankingRateImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['BrokersImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['CCElementImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['CCImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['ElementImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['FeedElementImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['GenericImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['InsuranceImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['MortgageLenderImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['PersonalLoansImpressionEvent'])
task_impression_events_nerdlake_load.set_upstream(event_tasks['SMBImpressionEvent'])
