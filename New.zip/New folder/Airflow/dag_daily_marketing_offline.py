from airflow import DAG
from datetime import datetime, timedelta, time

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

dag_name = 'dag_daily_marketing_offline'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 03, 13),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

################################################################################
# Time sensors
################################################################################
task_start_job = TimeSensor(
    target_time=time(00,5), #HH,MM
    task_id='mktg_offline_start_time_UTC_01_PDT_18_PST_17',
    dag=dag)

task_mktg_offline_start_time_UTC_01_PST_18 = TimeSensor(
    target_time=time(1,00), #HH,MM
    task_id='mktg_offline_start_time_UTC_01_PST_18',
    dag=dag)

task_mktg_offline_start_time_UTC_19_PDT_11 = TimeSensor(
    target_time=time(19,00), #HH,MM
    task_id='mktg_offline_start_time_UTC_19_PDT_11',
    dag=dag)

task_mktg_offline_start_time_UTC_15_PDT_07 = TimeSensor(
    target_time=time(15,00), #HH,MM
    task_id='mktg_offline_start_time_UTC_15_PDT_07',
    dag=dag)

task_mktg_offline_fb_multi_step_external_dependency = ExternalTaskSensor(
    task_id='waiting_for_non_core_amp_load_transaction_event',
    external_dag_id='dag_daily_non_core_dwh',
    external_task_id='amp_load_transaction_event',
    dag=dag)

################################################################################
# External task sensors
################################################################################
task_mktg_app_offline_external_dependency = ExternalTaskSensor(
    task_id='waiting_for_aflt_tran',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='mktg_daily_epc_d',
    dag=dag)

task_mktg_gs_dependency = ExternalTaskSensor(
    task_id='waiting_for_mktg_gs_load_dwh',
    external_dag_id='dag_daily_marketing_mta',
    external_task_id='mktg_gs_load_dwh',
    dag=dag)

task_dw_page_view_event_f_external_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_page_view_event_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='page_view_event_f',
    allowed_states=['success','failed'],
    dag=dag)

task_dw_session_event_f = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_session_event_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_session_event_f',
    dag=dag)

task_dw_clicks_enriched = ExternalTaskSensor(
    task_id='dag_daily_core_dwh.dw_clicks_enriched',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_clicks_enriched',
    dag=dag)

task_dw_clicks_event_f_external_dependency = ExternalTaskSensor(
    task_id='waiting_for_dw_clicks_event_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    allowed_states=['success','failed'],
    dag=dag)

task_mktg_trkng_param_fact_f_external_dependency = ExternalTaskSensor(
    task_id='waiting_for_mktg_trkng_param_fact_f',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='mktg_trkng_param_fact_load',
    allowed_states=['success','failed'],
    dag=dag)

task_baidag_mktg_sst_external_dependency = ExternalTaskSensor(
    task_id='waiting_for_baidag_mktg_sst',
    external_dag_id='baidag_mktg_sst',
    external_task_id='aggs_done',
    dag=dag)

task_baidag_sem_conversion_model_prediction_external_dependency = ExternalTaskSensor(
    task_id='baidag_sem_conversion_model_prediction.bash_predict_probabilities',
    external_dag_id='baidag_sem_conversion_model_prediction',
    external_task_id='bash_predict_probabilities',
    dag=dag)

### --------- Status Update ---------- ###

task29_script = "/data/etl/Common/redshift_sql_function.sh"
task29_status_update = NWBashScriptOperator(
    bash_script=task29_script,
    script_args=[
        "/data/etl/Airflow/post_updates/dag_daily_marketing_offline_status_update.sql"
    ],
    task_id='mktg_offline_status_update',
    dag=dag)

task_mktg_offline_status_update_sizmek_script = "/data/etl/Common/redshift_sql_function.sh"
task_mktg_offline_status_update_sizmek = NWBashScriptOperator(
    bash_script=task_mktg_offline_status_update_sizmek_script,
    script_args=[
        "/data/etl/Airflow/post_updates/dag_daily_marketing_offline_status_update_sizmek.sql"
    ],
    task_id='mktg_offline_status_update_sizmek',
    dag=dag)

task_mktg_offline_status_update_upload_script = "/data/etl/Common/redshift_sql_function.sh"
task_mktg_offline_status_update_upload = NWBashScriptOperator(
    bash_script=task_mktg_offline_status_update_upload_script,
    script_args=[
        "/data/etl/Airflow/post_updates/dag_daily_marketing_offline_status_update_upload.sql"
    ],
    task_id='mktg_offline_status_update_upload',
    dag=dag)
### -------- End Status Update _________####

task1_script = "/data/etl/Scripts/mktg_sizmek/shellscripts/sizmek_upload_s3.sh"
task1_sizmek = NWBashScriptOperator(
    bash_script=task1_script, 
    script_args=[], 
    task_id='mktg_sizmek',
    trigger_rule='all_done', 
    dag=dag)

task2_script = "/data/etl/Scripts/mktg_sizmek_acct_d/shellscripts/mktg_sizmek_acct_d.sh"
task2_sizmek = NWBashScriptOperator(
    bash_script=task2_script,
    script_args=[],
    task_id='mktg_sizmek_acct_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task3_script = "/data/etl/Scripts/mktg_sizmek_ad_d/shellscripts/mktg_sizmek_ad_d.sh"
task3_sizmek = NWBashScriptOperator(
    bash_script=task3_script,
    script_args=[],
    task_id='mktg_sizmek_ad_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task4_script = "/data/etl/Scripts/mktg_sizmek_plcmt_d/shellscripts/mktg_sizmek_plcmt_d.sh"
task4_sizmek = NWBashScriptOperator(
    bash_script=task4_script,
    script_args=[],
    task_id='mktg_sizmek_plcmt_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task5_script = "/data/etl/Scripts/mktg_sizmek_event_type_d/shellscripts/mktg_sizmek_event_type_d.sh"
task5_sizmek = NWBashScriptOperator(
    bash_script=task5_script,
    script_args=[],
    task_id='mktg_sizmek_event_type_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task_mktg_sizmek_dsp_campaign_d = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_sizmek_dsp_campaign_d/shellscripts/mktg_sizmek_dsp_campaign_d.sh',
    script_args=[],
    task_id='mktg_sizmek_dsp_campaign_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task7_script = "/data/etl/Scripts/mktg_sizmek_rich_feed_f/shellscripts/mktg_sizmek_rich_feed_f.sh"
task7_sizmek = NWBashScriptOperator(
    bash_script=task7_script,
    script_args=[],
    task_id='mktg_sizmek_rich_feed_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task_mktg_sizmek_conv_f = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/mktg_sizmek_conv_f/shellscripts/mktg_sizmek_conv_f.sh',
    script_args=[],
    task_id='mktg_sizmek_conv_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task9_script = "/data/etl/Scripts/mktg_sizmek_std_dsp_f/shellscripts/mktg_sizmek_std_dsp_f.sh"
task9_sizmek = NWBashScriptOperator(
    bash_script=task9_script,
    script_args=[],
    task_id='mktg_sizmek_std_dsp_f',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task10_script = "/data/etl/Scripts/mktg_sizmek_site_d/shellscripts/mktg_sizmek_site_d.sh"
task10_sizmek = NWBashScriptOperator(
    bash_script=task10_script,
    script_args=[],
    task_id='mktg_sizmek_site_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task11_script = "/data/etl/Scripts/mktg_sizmek_brwsr_type_d/shellscripts/mktg_sizmek_brwsr_type_d.sh"
task11_sizmek = NWBashScriptOperator(
    bash_script=task11_script,
    script_args=[],
    task_id='mktg_sizmek_brwsr_type_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task12_script = "/data/etl/Scripts/mktg_sizmek_os_type_d/shellscripts/mktg_sizmek_os_type_d.sh"
task12_sizmek = NWBashScriptOperator(
    bash_script=task12_script,
    script_args=[],
    task_id='mktg_sizmek_os_type_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task13_script = "/data/etl/Scripts/mktg_sizmek_video_nm_d/shellscripts/mktg_sizmek_video_nm_d.sh"
task13_sizmek = NWBashScriptOperator(
    bash_script=task13_script,
    script_args=[],
    task_id='mktg_sizmek_video_nm_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task14_script = "/data/etl/Scripts/mktg_sizmek_conv_tag_d/shellscripts/mktg_sizmek_conv_tag_d.sh"
task14_sizmek = NWBashScriptOperator(
    bash_script=task14_script,
    script_args=[],
    task_id='mktg_sizmek_conv_tag_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task15_script = "/data/etl/Scripts/mktg_sizmek_srvng_period_d/shellscripts/mktg_sizmek_srvng_period_d.sh"
task15_sizmek = NWBashScriptOperator(
    bash_script=task15_script,
    script_args=[],
    task_id='mktg_sizmek_srvng_period_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task16_script = "/data/etl/Scripts/mktg_sizmek_intactn_d/shellscripts/mktg_sizmek_intactn_d.sh"
task16_sizmek = NWBashScriptOperator(
    bash_script=task16_script,
    script_args=[],
    task_id='mktg_sizmek_intactn_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task17_script = "/data/etl/Scripts/mktg_sizmek_audience_d/shellscripts/mktg_sizmek_audience_d.sh"
task17_sizmek = NWBashScriptOperator(
    bash_script=task17_script,
    script_args=[],
    task_id='mktg_sizmek_audience_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task18_script = "/data/etl/Scripts/mktg_sizmek_master_campaign_d/shellscripts/mktg_sizmek_master_campaign_d.sh"
task18_sizmek = NWBashScriptOperator(
    bash_script=task18_script,
    script_args=[],
    task_id='mktg_sizmek_master_campaign_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task19_script = "/data/etl/Scripts/mktg_sizmek_panel_nm_d/shellscripts/mktg_sizmek_panel_nm_d.sh"
task19_sizmek = NWBashScriptOperator(
    bash_script=task19_script,
    script_args=[],
    task_id='mktg_sizmek_panel_nm_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task20_script = "/data/etl/Scripts/mktg_sizmek_prod_d/shellscripts/mktg_sizmek_prod_d.sh"
task20_sizmek = NWBashScriptOperator(
    bash_script=task20_script,
    script_args=[],
    task_id='mktg_sizmek_prod_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task21_script = "/data/etl/Scripts/mktg_sizmek_city_d/shellscripts/mktg_sizmek_city_d.sh"
task21_sizmek = NWBashScriptOperator(
    bash_script=task21_script,
    script_args=[],
    task_id='mktg_sizmek_city_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task22_script = "/data/etl/Scripts/mktg_sizmek_dma_d/shellscripts/mktg_sizmek_dma_d.sh"
task22_sizmek = NWBashScriptOperator(
    bash_script=task22_script,
    script_args=[],
    task_id='mktg_sizmek_dma_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task23_script = "/data/etl/Scripts/mktg_sizmek_brand_d/shellscripts/mktg_sizmek_brand_d.sh"
task23_sizmek = NWBashScriptOperator(
    bash_script=task23_script,
    script_args=[],
    task_id='mktg_sizmek_brand_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task24_script = "/data/etl/Scripts/mktg_sizmek_adr_d/shellscripts/mktg_sizmek_adr_d.sh"
task24_sizmek = NWBashScriptOperator(
    bash_script=task24_script,
    script_args=[],
    task_id='mktg_sizmek_adr_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task25_script = "/data/etl/Scripts/mktg_sizmek_country_d/shellscripts/mktg_sizmek_country_d.sh"
task25_sizmek = NWBashScriptOperator(
    bash_script=task25_script,
    script_args=[],
    task_id='mktg_sizmek_country_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task26_script = "/data/etl/Scripts/mktg_sizmek_state_d/shellscripts/mktg_sizmek_state_d.sh"
task26_sizmek = NWBashScriptOperator(
    bash_script=task26_script,
    script_args=[],
    task_id='mktg_sizmek_state_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task_sizmek_xref_script = "/data/etl/Scripts/mktg_sizmek_xref_d/shellscripts/mktg_sizmek_xref_d.sh"
task_sizmek_xref_dim = NWBashScriptOperator(
    bash_script=task_sizmek_xref_script,
    script_args=[],
    task_id='mktg_sizmek_xref_d',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task_sizmek_plcmt_ad_xref_script = "/data/etl/Scripts/mktg_sizmek_plcmt_ad_xref/shellscripts/mktg_sizmek_plcmt_ad_xref.sh"
task_sizmek_plcmt_ad_xref = NWBashScriptOperator(
    bash_script=task_sizmek_plcmt_ad_xref_script,
    script_args=[],
    task_id='mktg_sizmek_plcmt_ad_xref',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

task_sizmek_post_imp_script = "/data/etl/Scripts/mktg_sizmek_digital_post_imp_session/shellscripts/mktg_sizmek_digital_post_imp_session.sh"
task_sizmek_post_imp_dim = NWBashScriptOperator(
    bash_script=task_sizmek_post_imp_script,
    script_args=[],
    task_id='mktg_sizmek_digital_post_imp_session',
    trigger_rule='all_done',
    pool='redshift_etl',
    dag=dag)

### -------- dw_click_epc_rev_f ----- ###
task_dw_click_epc_rev_f_script = "/data/etl/Scripts/dw_click_epc_rev_f/shellscripts/dw_click_epc_rev_f.sh"
task_dw_click_epc_rev_f = NWBashScriptOperator(
    bash_script=task_dw_click_epc_rev_f_script,
    script_args=[],
    task_id='dw_click_epc_rev_f',
    dag=dag)

task_dw_click_epc_rev_f.set_upstream(task_mktg_app_offline_external_dependency)
task_dw_click_epc_rev_f.set_upstream(task_dw_clicks_enriched)
task_dw_click_epc_rev_f.set_upstream(task_mktg_gs_dependency)

### -------- offline conversion upload ----- ###
task_mktg_conv_upload_session_f_script = "/data/etl/Scripts/mktg_conv_upload_session_f/shellscripts/mktg_conv_upload_session_f.sh"
task_mktg_conv_upload_session_f = NWBashScriptOperator(
    bash_script=task_mktg_conv_upload_session_f_script,
    script_args=[],
    task_id='mktg_conv_upload_session_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_conv_upload_goog_f_script = "/data/etl/Scripts/mktg_conv_upload_goog_f/shellscripts/mktg_conv_upload_goog_f.sh"
task_mktg_conv_upload_goog_f = NWBashScriptOperator(
    bash_script=task_mktg_conv_upload_goog_f_script,
    script_args=[],
    task_id='mktg_conv_upload_goog_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_conv_upload_session_f.set_upstream(task_dw_click_epc_rev_f)
task_mktg_conv_upload_session_f.set_upstream(task_baidag_mktg_sst_external_dependency)
task_mktg_conv_upload_session_f.set_upstream(task_mktg_offline_start_time_UTC_15_PDT_07)
task_mktg_conv_upload_goog_f.set_upstream(task_mktg_conv_upload_session_f)


### -------- offline conversion upload - Bing----- ###

task_mktg_conv_upload_bing_f_script = "/data/etl/Scripts/mktg_conv_upload_bing_f/shellscripts/mktg_conv_upload_bing_f.sh"
task_mktg_conv_upload_bing_f = NWBashScriptOperator(
    bash_script=task_mktg_conv_upload_bing_f_script,
    script_args=[],
    task_id='mktg_conv_upload_bing_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_conv_upload_bing_f.set_upstream(task_mktg_conv_upload_session_f)


### -------- offline conversion upload - DoubleClick----- ###

task_mktg_conv_upload_ds_post_f_script = "/data/etl/Scripts/mktg_conv_upload_ds_post_f/shellscripts/mktg_conv_upload_ds_post_f.sh"
task_mktg_conv_upload_ds_post_f = NWBashScriptOperator(
    bash_script=task_mktg_conv_upload_ds_post_f_script,
    script_args=[],
    task_id='mktg_conv_upload_ds_post_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_conv_upload_ds_post_f.set_upstream(task_mktg_conv_upload_session_f)

task_mktg_conv_upload_session_prediction_f_script = "/data/etl/Scripts/mktg_conv_upload_session_prediction_f/shellscripts/mktg_conv_upload_session_prediction_f.sh"
task_mktg_conv_upload_session_prediction_f = NWBashScriptOperator(
    bash_script=task_mktg_conv_upload_session_prediction_f_script,
    script_args=[],
    task_id='mktg_conv_upload_session_prediction_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_conv_upload_session_prediction_f.set_upstream(task_mktg_conv_upload_session_f)
task_mktg_conv_upload_session_prediction_f.set_upstream(task_baidag_sem_conversion_model_prediction_external_dependency)

task_mktg_conv_list_ds_f_script = "/data/etl/Scripts/mktg_conv_list_ds_f/shellscripts/mktg_conv_list_ds_f.sh"
task_mktg_conv_list_ds_f = NWBashScriptOperator(
    bash_script=task_mktg_conv_list_ds_f_script,
    script_args=[],
    task_id='mktg_conv_list_ds_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_conv_list_ds_f.set_upstream(task_mktg_conv_upload_ds_post_f)
task_mktg_conv_list_ds_f.set_upstream(task_mktg_offline_start_time_UTC_19_PDT_11)

### --------- fb multi step offline ---------- ###
task_mktg_fb_multi_step_offline_conv_upload_f_dq_script = "/data/etl/Scripts/mktg_fb_multi_step_offline_conv_upload_f/shellscripts/mktg_fb_multi_step_offline_conv_upload_f_dq.sh"
task_mktg_fb_multi_step_offline_conv_upload_f_dq = NWBashScriptOperator(
          bash_script=task_mktg_fb_multi_step_offline_conv_upload_f_dq_script,
          script_args=[],
          task_id='mktg_fb_multi_step_offline_conv_upload_f_dq_check',
          pool='redshift_etl',
          dag=dag)

task_mktg_fb_multi_step_offline_conv_upload_f_script = "/data/etl/Scripts/mktg_fb_multi_step_offline_conv_upload_f/shellscripts/mktg_fb_multi_step_offline_conv_upload_f.sh"
task_mktg_fb_multi_step_offline_conv_upload_f = NWBashScriptOperator(
          bash_script=task_mktg_fb_multi_step_offline_conv_upload_f_script,
          script_args=[],
          task_id='mktg_fb_multi_step_offline_conv_upload_f',
          pool='redshift_etl',
          dag=dag)

task_mktg_fb_multi_step_offline_conv_upload_f_dq.set_upstream(task_mktg_offline_start_time_UTC_01_PST_18)
task_mktg_fb_multi_step_offline_conv_upload_f_dq.set_upstream(task_mktg_offline_fb_multi_step_external_dependency)
task_mktg_fb_multi_step_offline_conv_upload_f_dq.set_upstream(task_mktg_trkng_param_fact_f_external_dependency)
task_mktg_fb_multi_step_offline_conv_upload_f.set_upstream(task_mktg_fb_multi_step_offline_conv_upload_f_dq)

### --------- fb application offline conv upload---------- ###
task_mktg_fb_app_offline_conv_upload_f_script = "/data/etl/Scripts/mktg_fb_app_offline_conv_upload_f/shellscripts/mktg_fb_app_offline_conv_upload_f.sh"
task_mktg_fb_app_offline_conv_upload_f = NWBashScriptOperator(
          bash_script=task_mktg_fb_app_offline_conv_upload_f_script,
          script_args=[],
          task_id='mktg_fb_app_offline_conv_upload_f',
          pool='redshift_etl',
          dag=dag)

task_mktg_fb_app_offline_conv_upload_f.set_upstream(task_mktg_offline_start_time_UTC_01_PST_18)
task_mktg_fb_app_offline_conv_upload_f.set_upstream(task_mktg_app_offline_external_dependency)
task_mktg_fb_app_offline_conv_upload_f.set_upstream(task_dw_clicks_event_f_external_dependency)
task_mktg_fb_app_offline_conv_upload_f.set_upstream(task_mktg_trkng_param_fact_f_external_dependency)


### ------- outbrain ----- ###
task_mktg_outbrain_upload_conv_f_script = "/data/etl/Scripts/mktg_outbrain_upload_conv_f/shellscripts/mktg_outbrain_upload_conv_f.sh"
task_mktg_outbrain_upload_conv_f = NWBashScriptOperator(
      bash_script=task_mktg_outbrain_upload_conv_f_script,
      script_args=[],
      task_id='mktg_outbrain_upload_conv_f',
      trigger_rule='all_done',
      execution_timeout=timedelta(hours=4),
      pool='redshift_etl',
      dag=dag)

task_mktg_outbrain_upload_conv_f.set_upstream(task_mktg_app_offline_external_dependency)
task_mktg_outbrain_upload_conv_f.set_upstream(task_dw_page_view_event_f_external_dependency)

### -------- offline conversion upload - Appsflyer----- ###

task_mktg_conv_upload_af_f_script = "/data/etl/Scripts/mktg_conv_upload_af_f/shellscripts/mktg_conv_upload_af_f.sh"
task_mktg_conv_upload_af_f = NWBashScriptOperator(
    bash_script=task_mktg_conv_upload_af_f_script,
    script_args=[],
    task_id='mktg_conv_upload_af_f',
    pool='redshift_etl',
    dag=dag)

task_mktg_conv_upload_af_f.set_upstream(task_mktg_conv_upload_session_f)


### --------- Sizmek -------- ###
# Dimensions
task1_sizmek.set_upstream(task_start_job)
task2_sizmek.set_upstream(task1_sizmek)
task3_sizmek.set_upstream(task1_sizmek)
task4_sizmek.set_upstream(task1_sizmek)
task5_sizmek.set_upstream(task1_sizmek)
task_mktg_sizmek_dsp_campaign_d.set_upstream(task1_sizmek)
task10_sizmek.set_upstream(task1_sizmek)
task11_sizmek.set_upstream(task1_sizmek)
task12_sizmek.set_upstream(task1_sizmek)
task13_sizmek.set_upstream(task1_sizmek)
task14_sizmek.set_upstream(task1_sizmek)
task15_sizmek.set_upstream(task1_sizmek)
task16_sizmek.set_upstream(task1_sizmek)
task17_sizmek.set_upstream(task1_sizmek)
task18_sizmek.set_upstream(task1_sizmek)
task19_sizmek.set_upstream(task1_sizmek)
task20_sizmek.set_upstream(task1_sizmek)
task21_sizmek.set_upstream(task1_sizmek)
task22_sizmek.set_upstream(task1_sizmek)
task23_sizmek.set_upstream(task1_sizmek)
task24_sizmek.set_upstream(task1_sizmek)
task25_sizmek.set_upstream(task1_sizmek)
task26_sizmek.set_upstream(task1_sizmek)
# Facts
task7_sizmek.set_upstream(task_mktg_sizmek_dsp_campaign_d)
task_mktg_sizmek_conv_f.set_upstream(task_dw_session_event_f)
task_mktg_sizmek_conv_f.set_upstream(task_mktg_sizmek_dsp_campaign_d)
task9_sizmek.set_upstream(task_mktg_sizmek_dsp_campaign_d)
task_sizmek_xref_dim.set_upstream(task7_sizmek)
task_sizmek_xref_dim.set_upstream(task_mktg_sizmek_conv_f)
task_sizmek_xref_dim.set_upstream(task9_sizmek)
task_sizmek_post_imp_dim.set_upstream(task_sizmek_xref_dim)
task_sizmek_plcmt_ad_xref.set_upstream(task_sizmek_xref_dim)
### --------- Sizmek -------- ###


### --------- Status Update ---------- ###

task_mktg_offline_status_update_sizmek.set_upstream(task2_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task3_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task4_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task5_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task10_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task11_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task12_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task13_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task14_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task15_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task16_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task17_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task18_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task19_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task20_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task21_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task22_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task23_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task24_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task25_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task26_sizmek)
task_mktg_offline_status_update_sizmek.set_upstream(task_sizmek_post_imp_dim)
task_mktg_offline_status_update_sizmek.set_upstream(task_sizmek_plcmt_ad_xref)
task_mktg_offline_status_update_upload.set_upstream(task_mktg_conv_list_ds_f)
task_mktg_offline_status_update_upload.set_upstream(task_mktg_fb_multi_step_offline_conv_upload_f)
task_mktg_offline_status_update_upload.set_upstream(task_mktg_fb_app_offline_conv_upload_f)
task_mktg_offline_status_update_upload.set_upstream(task_mktg_conv_upload_bing_f)
task_mktg_offline_status_update_upload.set_upstream(task_mktg_conv_upload_af_f)
task_mktg_offline_status_update_upload.set_upstream(task_mktg_conv_upload_goog_f)
task29_status_update.set_upstream(task_mktg_offline_status_update_sizmek)
#task29_status_update.set_upstream(task_mktg_offline_status_update_upload)
### --------- Status Update ---------- ###
