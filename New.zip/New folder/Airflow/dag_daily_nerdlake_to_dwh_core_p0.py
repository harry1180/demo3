from airflow import DAG
import airflow.operators
from airflow.operators import BashOperator, DummyOperator, ExternalTaskSensor
from datetime import datetime, timedelta, time

from airflow.operators import NWBashScriptOperator

dag_name = 'dag_daily_nerdlake_to_dwh_core_p0'

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime.combine(datetime.now().date(), time()) - timedelta(days=1),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@daily')

# Used to mark all tasks successful when doing DAG cleanup
task_start_dag = DummyOperator(
    task_id='Initiating_task',
    dag=dag)

###########################################################################
# External task sensors
###########################################################################
task_offer_api_load_complete = ExternalTaskSensor(
    task_id='dag_daily_nerdlake_core_p0.offer_api_load_complete',
    external_dag_id='dag_daily_nerdlake_core_p0',
    external_task_id='offer_api_load_complete',
    dag=dag)
task_offer_api_load_complete.set_upstream(task_start_dag)

###########################################################################
# Command tasks
###########################################################################
task_dw_prod_d_new_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_prod_d_new/shellscripts/dw_prod_d_new.sh',
    script_args=[],
    task_id='dw_prod_d_new',
    pool='redshift_etl',
    dag=dag)
task_dw_prod_d_new_load.set_upstream(task_offer_api_load_complete)

task_dw_cc_prod_d_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_cc_prod_d/shellscripts/dw_cc_prod_d.sh',
    script_args=[],
    task_id='dw_cc_prod_d',
    pool='redshift_etl',
    dag=dag)
task_dw_cc_prod_d_load.set_upstream(task_offer_api_load_complete)

task_dw_banking_prod_d_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_banking_prod_d/shellscripts/dw_banking_prod_d.sh',
    script_args=[],
    task_id='dw_banking_prod_d',
    pool='redshift_etl',
    dag=dag)
task_dw_banking_prod_d_load.set_upstream(task_offer_api_load_complete)

task_dw_investing_prod_d_load = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/dw_investing_prod_d/shellscripts/dw_investing_prod_d.sh',
    script_args=[],
    task_id='dw_investing_prod_d',
    pool='redshift_etl',
    dag=dag)
task_dw_investing_prod_d_load.set_upstream(task_offer_api_load_complete)
