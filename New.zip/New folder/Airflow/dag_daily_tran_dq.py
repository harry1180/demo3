from airflow import DAG
from datetime import datetime, timedelta, time

from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor, ExternalTaskSensor

job_name = "dag_daily_tran_dq"

default_args = {
    'owner': 'dwh',
    'depends_on_past': False,
    'wait_for_downstream': True,
    'start_date': datetime(2017, 01, 23),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(10, 00),
    task_id='Initiating_start_time',
    dag=dag)

task_aflt_tran_dependency = ExternalTaskSensor(
    task_id='waiting_for_aflt_tran_status_update',
    external_dag_id='dag_daily_aflt_tran',
    external_task_id='status_update',
    dag=dag)

task1_script="/data/etl/Scripts/aflt_tran_dq/shellscripts/aflt_tran_dq.sh"
task1_aflt_tran_dq = NWBashScriptOperator(
    bash_script=task1_script,
    script_args=[],
    task_id='aflt_tran_dq',
    dag=dag)

task_consolidated_catg_mp = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/aflt_category_mapping_manual/shellscripts/aflt_catg_non_map_email.sh',
    script_args=[],
    task_id='send_catg_mp_email',
    dag=dag)

task_consolidated_fact_01_check_Tran_rev_rlzd_dt = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/aflt_tran_consolidated_fact/pythonscripts/check_Tran_rev_rlzd_dt.json"],
    task_id='check_Tran_rev_rlzd_dt',
    dag=dag)

task_consolidated_fact_02_check_nw_click_dt = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/aflt_tran_consolidated_fact/pythonscripts/check_nw_click_dt.json"],
    task_id='check_nw_click_dt',
    dag=dag)

task_consolidated_fact_03_check_mssng_clks = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/aflt_tran_consolidated_fact/pythonscripts/check_mssng_clks.json"],
    task_id='check_mssng_clks',
    dag=dag)

task_consolidated_fact_04_cmpre_avg_comm = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/aflt_tran_consolidated_fact/pythonscripts/cmpre_avg_comm.json"],
    task_id='cmpre_avg_comm',
    dag=dag)

task_consolidated_fact_05_rptd_clks = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/aflt_tran_consolidated_fact/pythonscripts/repeated_dw_click_id.json"],
    task_id='rptd_clks',
    dag=dag)


task_consolidated_fact_06_cmpre_cmm = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/aflt_tran_consolidated_fact/pythonscripts/compare_cmm_cons_fct.json"],
    task_id='cmpre_cmm',
    dag=dag)

task_consolidated_catg_mp.set_upstream(task_start_job)
task_consolidated_catg_mp.set_upstream(task_aflt_tran_dependency)
task1_aflt_tran_dq.set_upstream(task_start_job)
task1_aflt_tran_dq.set_upstream(task_aflt_tran_dependency)
task_consolidated_fact_01_check_Tran_rev_rlzd_dt.set_upstream(task_start_job)
task_consolidated_fact_01_check_Tran_rev_rlzd_dt.set_upstream(task_aflt_tran_dependency)
task_consolidated_fact_02_check_nw_click_dt.set_upstream(task_start_job)
task_consolidated_fact_02_check_nw_click_dt.set_upstream(task_aflt_tran_dependency)
task_consolidated_fact_03_check_mssng_clks.set_upstream(task_start_job)
task_consolidated_fact_03_check_mssng_clks.set_upstream(task_aflt_tran_dependency)
task_consolidated_fact_04_cmpre_avg_comm.set_upstream(task_start_job)
task_consolidated_fact_04_cmpre_avg_comm.set_upstream(task_aflt_tran_dependency)
task_consolidated_fact_05_rptd_clks.set_upstream(task_start_job)
task_consolidated_fact_05_rptd_clks.set_upstream(task_aflt_tran_dependency)
task_consolidated_fact_06_cmpre_cmm.set_upstream(task_start_job)
task_consolidated_fact_06_cmpre_cmm.set_upstream(task_aflt_tran_dependency)
