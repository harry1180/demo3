from datetime import datetime, timedelta,time
import sys

from airflow import DAG
from airflow.operators import NWBashScriptOperator
from airflow.operators.sensors import TimeSensor
from airflow.operators.sensors import ExternalTaskSensor

sys.path.append('/data/etl/Common')

job_name = "dag_daily_core_dwh_dq_notify"

default_args = {
    'owner': 'dwh',
    'depends_on_past': True,
    'wait_for_downstream': True,
    'start_date': datetime(2016, 12, 03),
    'email': ['airflowalerts@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=15),
    'queue': 'dwh',
}

dag = DAG(job_name, default_args=default_args, schedule_interval=timedelta(1))

task_start_job = TimeSensor(
    target_time=time(3, 15),
    task_id='Initiating_start_time',
    dag=dag)

Task_daily_core_dwh_clicks_event_fact_dependency = ExternalTaskSensor(
    task_id='waiting_for_daily_core_dwh_clicks_event_fact',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='clicks_event_fact',
    dag=dag)

Task_daily_core_dwh_session_event_fact_dependency = ExternalTaskSensor(
    task_id='waiting_for_daily_core_dwh_session_event_fact',
    external_dag_id='dag_daily_core_dwh',
    external_task_id='dw_session_event_f',
    dag=dag)

Task_daily_dwh_actvy_fact_dependency = ExternalTaskSensor(
    task_id='waiting_for_daily_dwh_actvy_fact',
    external_dag_id='dag_daily_activity_merge',
    external_task_id='dw_actvy_f_core_Fact_Load',
    dag=dag)

task_actvy_aflt_tran_commission_check = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_actvy_f/pythonscripts/actvy_aflt_tran_commission_dq.json"],
    task_id='actvy_aflt_tran_commission_check',
    dag=dag)

task_clicks_event_fact_dq = NWBashScriptOperator(
    bash_script="/data/etl/Scripts/dw_clicks_event_f_dq/shellscripts/dw_clicks_event_f_dq.sh",
    script_args=[],
    task_id='clicks_event_fact_dq',
    dag=dag)

task_click_event_01_check_dup_click = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_01_check_dup_click.json"],
    task_id='click_event_01_check_dup_click',
    dag=dag)

task_click_event_02_check_num_of_dw_site_visitor_id = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_02_check_num_of_dw_site_visitor_id.json"],
    task_id='click_event_02_check_num_of_dw_site_visitor_id',
    dag=dag)

task_click_event_03_check_num_of_user_id = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_03_check_num_of_user_id.json"],
    task_id='click_event_03_check_num_of_user_id',
    dag=dag)

task_click_event_04_check_num_of_dw_session_id = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_04_check_num_of_dw_session_id.json"],
    task_id='click_event_04_check_num_of_dw_session_id',
    dag=dag)

task_click_event_05_check_num_of_dw_page_view_id = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_05_check_num_of_dw_page_view_id.json"],
    task_id='click_event_05_check_num_of_dw_page_view_id',
    dag=dag)

task_dq_click_event_work = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/click_event_post_s/qa/click_event_work.json"],
    task_id='dq_click_event_work',
    dag=dag)

task_dq_click_event_day_mismatch = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_day_mismatch.json"],
    task_id='dq_click_event_day_mismatch',
    dag=dag)


task_dq_click_event_hr_mismatch = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_hr_mismatch.json"],
    task_id='dq_click_event_hr_mismatch',
    dag=dag)

task_dq_click_event_compare_match_by_day_pct = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_compare_match_by_day_pct.json"],
    task_id='dq_click_event_compare_match_by_day_pct',
    dag=dag)

task_dq_click_event_clicks_missing_page_or_url_sk = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_clicks_missing_page_or_url_sk.json"],
    task_id='dq_click_event_clicks_missing_page_or_url_sk',
    dag=dag)

task_dq_click_event_clicks_missing_products = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_clicks_missing_products.json"],
    task_id='dq_click_event_clicks_missing_products',
    dag=dag)

task_dq_click_event_pl_count_change_wow = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_pl_count_change_wow.json"],
    task_id='dq_click_event_pl_count_change_wow',
    dag=dag)

task_aws_click_page_views_count_change_wow = NWBashScriptOperator(
        bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
        script_args=['/data/etl/Scripts/amazon_ips_s/pythonscripts/aws_click_page_views_dq.json'],
        task_id='dq_aws_click_page_views_count_change_wow',
        dag=dag)

task_dq_click_event_smb_count_change_wow = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_clicks_event_f/pythonscripts/click_event_smb_count_change_wow.json"],
    task_id='dq_click_event_smb_count_change_wow',
    dag=dag)

task_dq_heart_beat_data_availability = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_pv_heart_beat_event_f/pythonscripts/heart_beat_data_availability.json"],
    task_id='dq_heart_beat_data_availability',
    dag=dag)

task_dq_heart_beat_hard_bounce_weekly_avg = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_pv_heart_beat_event_f/pythonscripts/heart_beat_hard_bounce_weekly_avg.json"],
    task_id='dq_heart_beat_hard_bounce_weekly_avg',
    dag=dag)

task_dq_session_data_availability_by_avg = NWBashScriptOperator(
    bash_script='/data/etl/Common/run_dq_check_wrapper.sh',
    script_args=["/data/etl/Scripts/dw_session_event_f/pythonscripts/session_data_availability_by_avg.json"],
    task_id='dq_session_data_availability_by_avg',
    dag=dag)

task_clicks_event_fact_dq.set_upstream(task_start_job)
task_clicks_event_fact_dq.set_upstream(Task_daily_core_dwh_clicks_event_fact_dependency)

task_click_event_01_check_dup_click.set_upstream(task_clicks_event_fact_dq)
task_click_event_02_check_num_of_dw_site_visitor_id.set_upstream(task_clicks_event_fact_dq)
task_click_event_03_check_num_of_user_id.set_upstream(task_clicks_event_fact_dq)
task_click_event_04_check_num_of_dw_session_id.set_upstream(task_clicks_event_fact_dq)
task_click_event_05_check_num_of_dw_page_view_id.set_upstream(task_clicks_event_fact_dq)
task_dq_click_event_work.set_upstream(task_clicks_event_fact_dq)
task_dq_click_event_day_mismatch.set_upstream(task_clicks_event_fact_dq)
task_dq_click_event_hr_mismatch.set_upstream(task_clicks_event_fact_dq)
task_dq_click_event_compare_match_by_day_pct.set_upstream(task_clicks_event_fact_dq)
task_dq_click_event_clicks_missing_page_or_url_sk.set_upstream(task_clicks_event_fact_dq)
task_dq_click_event_clicks_missing_products.set_upstream(task_clicks_event_fact_dq)
task_dq_click_event_pl_count_change_wow.set_upstream(task_clicks_event_fact_dq)
task_aws_click_page_views_count_change_wow.set_upstream(task_clicks_event_fact_dq)
task_dq_click_event_smb_count_change_wow.set_upstream(task_clicks_event_fact_dq)

task_dq_heart_beat_data_availability.set_upstream(task_start_job)
task_dq_heart_beat_data_availability.set_upstream(Task_daily_core_dwh_session_event_fact_dependency)

task_dq_heart_beat_hard_bounce_weekly_avg.set_upstream(task_start_job)
task_dq_heart_beat_hard_bounce_weekly_avg.set_upstream(Task_daily_core_dwh_session_event_fact_dependency)

task_dq_session_data_availability_by_avg.set_upstream(task_start_job)
task_dq_session_data_availability_by_avg.set_upstream(Task_daily_core_dwh_session_event_fact_dependency)

task_actvy_aflt_tran_commission_check.set_upstream(task_start_job)
task_actvy_aflt_tran_commission_check.set_upstream(Task_daily_dwh_actvy_fact_dependency)
