from datetime import datetime, timedelta
import os
import platform
import sys

from airflow import DAG
from airflow.models import Variable
from airflow.operators import NWBashScriptOperator, DummyOperator
from airflow.operators.sensors import TimeDeltaSensor

sys.path.append(os.path.dirname(__file__))  # Allow importing of modules from the same directory as our DAGs
import airflow_dwh

dag_name = 'dag_kadu_event_consumption_prod'

default_args = {
    'owner': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2018, 9, 4),
    'email': ['airflowalerts@nerdwallet.com', 'dwh@nerdwallet.pagerduty.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=2),
    'depends_on_past': True
}

dag = DAG(dag_name, default_args=default_args, schedule_interval='@hourly')

# Wait 1 minute into the hour to allow for all events from the previous
# hour to make their way into Kafka.
task_start_dag = TimeDeltaSensor(
    delta=timedelta(minutes=1),
    task_id='Initiating_task',
    poke_interval=5,
    dag=dag)

###########################################################################
# Parameters for this DAG
###########################################################################
kafka_environment = 'prod'
s3_key_format = 'prod_s3_key'

# All topic names from Kafka
kafka_topics = airflow_dwh.get_kafka_topics(client_id=dag_name)
if len(kafka_topics) < 80:
    msg = '{}\n{} Kafka topics were found, must be >= 80'.format(platform.node(), len(kafka_topics))
    text = '\n'.join(kafka_topics)
    text = '\n'.join([text, msg])
    airflow_dwh.log_text(text=text, bucket_name=Variable.get('s3_bucket_dwh'), key_base_name=dag_name, ignore_failure=True)
    raise RuntimeError(msg)

# All first-class ProtoBuf class names
pbuf_class_names = airflow_dwh.get_base_pbuf_class_names()
if len(pbuf_class_names) < 70:
    msg = '{}\n{} ProtoBuf classes were found, must be >= 70'.format(platform.node(), len(pbuf_class_names))
    text = '\n'.join(pbuf_class_names)
    text = '\n'.join([text, msg])
    airflow_dwh.log_text(text=text, bucket_name=Variable.get('s3_bucket_dwh'), key_base_name=dag_name, ignore_failure=True)
    raise RuntimeError(msg)

# All text (JSON) event names
json_event_names = airflow_dwh.get_json_event_names()

# Events to skip
events_to_skip = set()
skip_events_csv = Variable.get('event_kadu_blacklist')
if skip_events_csv:
    for skip_event in skip_events_csv.split(','):
        if skip_event.strip() == '':
            continue
        events_to_skip.add(skip_event.strip().lower())

kadu_tasks = dict()

###########################################################################
# Create KaDu tasks for each Protobuf Kafka topic.
###########################################################################
for kafka_topic in kafka_topics.intersection(pbuf_class_names):
    if kafka_topic.lower() in events_to_skip:
        continue
    kadu_task = NWBashScriptOperator(
        bash_script='/data/etl/Common/kadu_event_consumption.sh',
        script_args=[kafka_topic, kafka_environment, s3_key_format],
        task_id='{}_kadu_consumption'.format(kafka_topic),
        dag=dag)
    kadu_task.set_upstream(task_start_dag)
    kadu_tasks[kafka_topic] = kadu_task

###########################################################################
# Create KaDu tasks for each JSON Kafka topic.
###########################################################################
for kafka_topic in kafka_topics.intersection(json_event_names):
    if kafka_topic.lower() in events_to_skip:
        continue
    kadu_task = NWBashScriptOperator(
        bash_script='/data/etl/Common/kadu_event_consumption.sh',
        script_args=[kafka_topic, kafka_environment, s3_key_format],
        task_id='{}_kadu_consumption'.format(kafka_topic),
        dag=dag)
    kadu_task.set_upstream(task_start_dag)
    kadu_tasks[kafka_topic] = kadu_task

###########################################################################
# Dummy Completion tasks
###########################################################################
task_kadu_done = DummyOperator(
    task_id='kadu_done',
    trigger_rule='all_done',
    dag=dag)
task_kadu_done.set_upstream(kadu_tasks.values())

task_kadu_done_success = DummyOperator(
    task_id='kadu_done_success',
    dag=dag)
task_kadu_done_success.set_upstream(kadu_tasks.values())

###########################################################################
# Log the task list
###########################################################################
msg = '{}\n{}'.format(platform.node(), '\n'.join(sorted(kadu_tasks.keys())))
airflow_dwh.log_text(
    text=msg,
    bucket_name=Variable.get('s3_bucket_dwh'),
    key_base_name=dag_name,
    ignore_failure=True)
