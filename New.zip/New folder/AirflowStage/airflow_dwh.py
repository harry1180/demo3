from datetime import datetime
import inspect
import json
import pkgutil

from airflow.operators import PythonOperator
import boto
from boto.s3.key import Key
from kafka import KafkaConsumer
import requests

import nwpyschemas.event


def get_base_pbuf_class_names():
    """
    Get the ProtoBuf class names that are base events e.g., not include-only events like Header classes. This is done by
    looking for events that define the indicatesConsumerActivity property, which can be true or false. The existence of
    the attribute is what causes it to be returned by this function.
    :return: Set containing a list of ProtoBuf class names
    """
    class_names = set()
    for importer, modname, ispkg in pkgutil.iter_modules(nwpyschemas.event.__path__):
        import_name = nwpyschemas.event.__name__ + '.' + modname
        imported_module = __import__(import_name, fromlist=['x'])
        classes_in_module = dict(inspect.getmembers(imported_module, inspect.isclass))
        if len(classes_in_module) != 1:
            continue
        class_name = classes_in_module.keys()[0]
        if class_name == 'CLOUserTokenRequestEvent':  # This JSON-based event was incorrectly created as a ProtoBuf schema
            continue
        event_class = classes_in_module[class_name]

        if 'DESCRIPTOR' not in dir(event_class):
            continue

        for field_descriptor, field_value in event_class.DESCRIPTOR.GetOptions().ListFields():
            if field_descriptor.name.lower() == 'indicatesConsumerActivity'.lower():
                class_names.add(class_name)
                break

    return class_names


def get_kafka_topics(client_id='get_kafka_topic_names'):
    """
    Get list of Kafka topic names.
    :param client_id:
    :return: Set containing a list of Kafka topic names
    """
    consumer = KafkaConsumer(
        bootstrap_servers=['kafka10-1:6667', 'kafka10-2:6667', 'kafka10-3:6667'],
        client_id=client_id)
    topics = consumer.topics()
    consumer.close()
    return topics


def get_json_event_names():
    """
    Event names that store JSON data in Kafka (as opposed to ProtoBuf messages)
    :return: Set containing a list of JSON-based event names
    """
    # TODO: Pick these up from app config
    return {
        'ablogevent_plain',
        'ApiResponseEvent',
        'BackendModelExecutionEvent',
        'CLOUserTokenRequestEvent',
        'minusworld',
        'shadowrealm',
    }


def log_text(text, bucket_name, key_base_name, ignore_failure=False):
    """
    Store a list of task IDs on S3.

    :return:
    """
    try:
        s3 = boto.connect_s3()
        bucket = s3.get_bucket(bucket_name)
        k = Key(bucket)
        k.content_type = 'text/plain'  # Let web browsers know they can display the file
        k.key = 'Airflow-custom-logs/dynamic_task_ids/{}-{}.log'.format(
            key_base_name, datetime.utcnow().strftime('%Y-%m-%d-%H-%M-%S.%f'))
        if text is None:
            k.set_contents_from_string('')
        else:
            k.set_contents_from_string(text)
    except boto.exception.S3ResponseError as ex:
        if not ignore_failure:
            raise ex


def send_slack_message(channel, message):
    """
    Sends a message to a Slack channel as the 'Airflow' user.
    :param channel: The Slack channel that the message should be sent to, should start with '#'
    :param message: The message to send to the channel
    :return:
    """
    slack_hook_url = 'https://hooks.slack.com/services/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'
    slack_params = {
        'channel': channel,
        'text': message,
        'link_names': True,  # Treat text like '@channel' the same way the desktop client does
    }
    requests.post(
        url=slack_hook_url,
        data=json.dumps(slack_params),
        headers={'Content-Type': 'application/json'})


def send_slack_message_task_complete(channel, task):
    """
    Sends a slack message indicating that the specified task is complete.

    :param channel: The Slack channel to send the message to
    :param task: The task object (not the task ID!) that the notification should be sent for
    :return: The task object that sends the notification, this is an Airflow PythonOperator object
    """
    notify_task = PythonOperator(
        task_id='slack_notify_complete_{}'.format(task.task_id),
        python_callable=send_slack_message,
        op_kwargs={
            'channel': channel,
            'message': '`{}.{}` is complete'.format(task.dag.dag_id, task.task_id),
        },
        dag=task.dag
    )
    notify_task.set_upstream(task)
    return notify_task
