from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators import NWBashScriptOperator, DummyOperator

job_name = "dag_ds_consume_stage"

default_args = {
    'owner': 'ds',
    'queue': 'dwh',
    'wait_for_downstream': True,
    'start_date': datetime(2018, 6, 17),
    'email': ['isingh@nerdwallet.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_interval': timedelta(minutes=2),
    'depends_on_past': True
}

dag = DAG(job_name, default_args=default_args, schedule_interval='@hourly')

###########################################################################
# Command tasks
###########################################################################

topic_task = NWBashScriptOperator(
    bash_script='/data/etl/Scripts/validate_ablogevent_plain/shellscripts/validate_ablogevent_plain.sh',
    script_args=[],
    task_id='validate_ablogevent_plain',
    dag=dag)
