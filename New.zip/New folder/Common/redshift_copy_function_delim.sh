source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

var_header=$5
if [ -n "$var_header" ]; then
   query="copy "$1" from '"$s3_bucket_name$2$3"' credentials 'aws_access_key_id="$s3_access_key";aws_secret_access_key="$s3_secret_key"' gzip delimiter '"$4"' dateformat 'auto' NULL AS 'NULL' IGNOREHEADER AS 1 ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
else
    query="copy "$1" from '"$s3_bucket_name$2$3"' credentials 'aws_access_key_id="$s3_access_key";aws_secret_access_key="$s3_secret_key"' gzip delimiter '"$4"' dateformat 'auto' NULL AS 'NULL' ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
fi
#query="copy "$1" from 's3://dwh-staging"$2$3"' credentials 'aws_access_key_id="$s3_access_key";aws_secret_access_key="$s3_secret_key"' gzip delimiter '\t' dateformat 'auto' NULL AS 'NULL' ACCEPTINVCHARS;"
#psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
