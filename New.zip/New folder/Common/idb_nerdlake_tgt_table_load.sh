set -e
identity_profile="$1"
job_name=${identity_profile}"_tgt_load_nerdlake"
job_start_time=$(date +%s)

echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
source ${dwh_common_base_dir}/set_dwh_schema_variables.sh
export dwh_common_base_dir
export dwh_scripts_base_dir
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
  bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0

bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
table_tstamp=$(date +%Y/%m/%d/%H.%M.%S)
work_table="hive.${hive_pudstagedb}.idb_${identity_profile}_w"
stage_table="hive.${hive_pudstagedb}.idb_${identity_profile}_s"
target_table="hive.${hive_puddatadb}.idb_${identity_profile}_d"

if [ $identity_profile = 'yodlee_transactions' ]
then
    target_table="hive.${hive_puddatadb}.idb_${identity_profile}_f"
fi

echo "table_tstamp              :- $table_tstamp"
echo "work_table                :- $work_table"
echo "stage_table               :- $stage_table"
echo "target_table              :- $target_table"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

Processing_Step="Loading data into ${target_table}"
echo_processing_step ${job_name} "$Processing_Step" "Started"

python $dwh_common_base_dir/identity_tgt_table_load.py \
    --target_table "$target_table" \
    --work_table "$work_table" \
    --stage_table "$stage_table" \
    --location_ts $table_tstamp

echo_processing_step ${job_name} "Calling End Script" "Completed"


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
