import sys, os
import requests, csv
from time import strftime, gmtime
from urlparse import urlparse

#domain=sys.argv[1]
#limit=sys.argv[2]
#offset=sys.argv[3]
dfolder='/data/etl/Data/semrush/input/'
pfolder='/data/etl/Data/semrush/output/'

def generate_url(domain,display_limit=0,display_offset=0):
 """Call the generate_url by passing domain name,display limit, display offset
 where domain name is domain you want to analyze, diplay limit is number of words you want to bring from the display offset. This data is assumed to be sorted on traffic value desc"""
 url_base = 'http://api.semrush.com/'
 display_date = strftime("%Y%m%d", gmtime())  # current date to set as data as of date
 # key='e900796280754eb8c3882bbaaf42ba28' # Tim's key
 key='af3b0ff47256e01c23939e9ab4fa3bbc' # VJ key
 #key='5c8a186d5e54f9fbedcb13e257d43899' #Mike's key
 display_filter= '%2B%7CCp%7CGt%7C0'
 export_columns='Ph,Po,Pp,Pd,Nq,Cp,Ur,Tr,Tc,Co,Nr,Td'
 display_sort='tr_desc' # traffic decc
 database='us' # 
 report_type='domain_organic'
 url=url_base+'?type='+report_type
 url+= '&key='+key
 url+= '&display_filter='+display_filter
 url+='&display_limit='+display_limit
 url+='&export_columns='+export_columns
 url+='&domain='+domain
 url+='&display_sort='+display_sort
 url+='&database='+database
 url+='&display_offset='+display_offset
 return url


def pull_semrush_data(url,domain,display_offset,input_folder, output_folder):
 dfolder=input_folder
 pfolder=output_folder
 display_date = strftime("%Y%m%d", gmtime())
 fname = 'sr_dom_org_'+domain.split('.')[0]+'_'+display_date+'_'+display_offset
 filename=fname+'.csv'
 response = requests.get(url,allow_redirects=True,timeout=1000, stream=True)
 if response.status_code == 200:
  with open(dfolder+filename,'w') as f:
   f.write(response.text.encode('ascii','ignore'))
   print 'API call succeded with response code:'+str(response.status_code)
   print 'Download file:' + dfolder+filename
   return [response.status_code,dfolder+filename]
 else:
  print 'API call failed with response code:'+str(response.status_code)
  print 'Check if the account has run out of API units'
  return [response.status_code,'NONE']
  quit() 


def parse_semrush_data(domain,display_offset,input_folder, output_folder):
 display_date = strftime("%Y%m%d", gmtime())
 fname = 'sr_dom_org_'+domain.split('.')[0]+'_'+display_date+'_'+display_offset
 filename=fname+'.csv'
 outfile = fname + '_parsed.csv'
 with open(dfolder+filename,'r') as rhandle:
        with open(pfolder+outfile,'wb') as whandle:
#            print whandle
            csvwriter=csv.writer(whandle,delimiter='\t')
            for inrow in rhandle:
                path=urlparse(inrow.split(';')[6]).path
#                print inrow 
                outrow=[domain,display_date]+[column.strip() for column in inrow.split(';')]+[path]
#                print outrow
                csvwriter.writerow(outrow)

#url_output=spit_url(domain,limit,offset)
#print url_output

#pull_semrush_data(url_output,domain,offset,dfolder,pfolder)

#parse_semrush_data(domain,offset,dfolder,pfolder)
