#!/usr/bin/env python

import argparse
import gzip
import logging
import os
import pwd
import re
import StringIO
import subprocess
import textwrap  # To build a nicely formatted COPY command
from urlparse import urlparse
import zlib

import boto3

import redshift_modules

logging.basicConfig(format='[%(asctime)s] [%(levelname)-8s] %(name)s - %(message)s', level=logging.DEBUG)
logger = logging.getLogger()
logging.getLogger('botocore').setLevel(logging.WARNING)
logging.getLogger('s3transfer').setLevel(logging.WARNING)


def _is_iterable(var):
    """
    Returns whether or not the specified variable can be iterated over. Does not return True for strings.

    :param var:
    :return:
    """
    try:
        i = iter(var)
        return True
    except TypeError as e:
        return False


def get_psql_copy_command(table_name, column_names, input_filename, gzipped_input=None):
    """
    Generates a psql '\copy' command that extracts data from the specified source into the specified output filename.

    :param table_name:
    :param column_names:
    :param input_filename:
    :param gzipped_input:
    :return:
    """
    # Make sure column_names is a list or a tuple or some other iterable -- i.e., not a string
    if column_names and not _is_iterable(column_names):
        raise ValueError('get_copy_command.column_names is not iterable')

    # TODO: Decompress local files before loading. For bonus points, do this using a named pipe to avoid disk usage.
    if gzipped_input:
        raise NotImplementedError('Gzipped local input files are not yet supported')

    cmd = '\\copy ' + table_name
    cmd += ' ( "' + '", "'.join(column_names) + '" ) '

    cmd += 'from \'{}\' '.format(input_filename)
    cmd += 'with ( format csv, header true )'

    return cmd.replace('\n', ' ')  # psql meta-commands can't span lines


def run_psql_command(server, port, database, username, sql_statement):
    """
    Executes a SQL script using psql.

    :param server:
    :param port:
    :param database:
    :param username:
    :param sql_filename:
    :return:
    """
    cmd = [
        'psql',
        '-h', server,
        '-p', str(port),
        '-d', database,
        '-U', username,
        '-v', 'ON_ERROR_STOP=on',
        '-c', sql_statement]
    rc = subprocess.call(cmd)
    if rc != 0:
        return False

    return True


def _get_column_headers(input_spec, col_header_line=1, aws_profile=None, gzipped_file=None):
    """
    Reads the first line of a CSV file and returns the values split by ','. Does not handle quoting or escapes.

    :param input: Filename or S3 URL
    :param col_header_line: Which line the column headers are in, this is 1-based
    :param aws_profile:
    :return:
    """

    if gzipped_file is None:
        gzipped_file = input_spec.lower().endswith('.gz')

    # Read the first line of the local file and split by ','
    if not input_spec.lower().startswith('s3://'):
        if os.path.getsize(input_spec) == 0:
            logger.warning('{}: empty file, unable to retrieve column headers'.format(input_spec))
            return None

        if gzipped_file:
            fhin = gzip.open(input_spec, 'rb')
        else:
            fhin = open(input_spec, 'r')
        line_no = 0
        while True:
            line = fhin.readline()
            if line is None:
                fhin.close()
                return None
            line_no += 1
            if col_header_line < line_no:
                continue
            fhin.close()
            return [field.strip() for field in line.strip().split(',')]

    # Get the first 64K of the file, decompress it if necessary, read the first line from it, and split by ','
    input_url = urlparse(input_spec)
    aws_session = boto3.session.Session(profile_name=aws_profile)
    s3 = aws_session.client('s3')
    resp = s3.get_object(
        Bucket=input_url.netloc,
        Key=input_url.path[1:],
        Range='bytes=0-65535',
    )
    first_chunk = resp['Body'].read()

    # If the file is compressed, put the chunk we read into a decompression stream and read the chunk from the
    # decompressed stream.
    if gzipped_file:
        gz_stream = StringIO.StringIO(first_chunk)
        decompressed_chunk = gzip.GzipFile(fileobj=gz_stream).read(65535)
        gz_stream.close()
        first_chunk = decompressed_chunk

    key_lines = re.split(r'[\r\n]', first_chunk.decode('utf-8'))
    if len(key_lines) < col_header_line:
        logger.warning('Header line #{} but {} does not contain this many lines'.format(col_header_line, input_spec))
        return None
    return [field.strip() for field in key_lines[col_header_line - 1].strip().split(',')]


def get_s3_copy_command(table_name, field_names, input_s3_url, header_row=1, gzipped_input=None):
    """
    Builds a Redshift COPY command that imports a file from S3. Command contains a '{}' token for the S3 credentials.

    :param table_name:
    :param field_names:
    :param input_s3_url:
    :param gzipped_input:
    :return:
    """
    if gzipped_input is None:
        gzipped_input = input_s3_url.lower().endswith('.gz')

    sql = 'COPY {} (\n'.format(table_name)
    field_list = '"{}"'.format('", "'.join(field_names))
    sql += '    ' + '\n    '.join(textwrap.wrap(field_list, 116))
    sql += '\n)\n'
    sql += 'FROM \'{}\'\n'.format(input_s3_url)
    sql += 'CREDENTIALS \'{}\'\n'  # Intentionally not adding the credentials here
    if gzipped_input:
        sql += 'GZIP\n'
    sql += 'FORMAT AS CSV\n'
    sql += 'IGNOREHEADER AS {}\n'.format(header_row)
    sql += 'ACCEPTINVCHARS\nCOMPUPDATE OFF\nBLANKSASNULL\nEMPTYASNULL'
    return sql


def import_table(server, port, database, username, table_name, input_spec, s3_credentials, col_header_line=1,
                 gzipped_input=None, aws_profile=None):

    logging.info('Getting fieldnames from line #{} of {}'.format(col_header_line, input_spec))
    field_names = _get_column_headers(input_spec, col_header_line, aws_profile)
    if not field_names:
        raise RuntimeError('Failed to get field names')
    logging.info('Found {} fields'.format(len(field_names)))

    if not input_spec.lower().startswith('s3://'):
        psql_command = get_psql_copy_command(table_name, field_names, input_spec, gzipped_input)
        logger.info(psql_command)
        rc = run_psql_command(server, port, database, username, psql_command)
        if not rc:
            raise RuntimeError('\\copy command failed')
    else:
        # The COPY command retrieved here contains '{}' where the S3 credentials should go.
        sql = get_s3_copy_command(table_name, field_names, input_spec, header_row=col_header_line,
                                  gzipped_input=gzipped_input)
        with redshift_modules.redshift_connect() as conn, conn.cursor() as curs:
            logging.info(sql)
            curs.execute(sql.format(s3_credentials))
            for notice in conn.notices:
                logging.info(notice.rstrip())


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Import CSV data into Redshift')
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument('--input-filename', required=False)
    input_group.add_argument('--input-s3-url', required=False)
    parser.add_argument('--server', required=True)
    parser.add_argument('--port', required=False, default=5432, type=int)
    parser.add_argument('--database', required=True)
    parser.add_argument('--username', required=False)
    parser.add_argument('--table-name', required=True)
    parser.add_argument('--gzip', action='store_true', default=None, required=False)
    parser.add_argument('--redshift-s3-creds-envar', required=False,
                        help='Environment variable that holds the Redshift/S3 credentials string')

    args = parser.parse_args()

    if args.input_s3_url and not args.input_s3_url.lower().startswith('s3://'):
        print('ERROR: Input S3 URL must start with \'s3://\'')
    elif args.input_filename and args.input_filename.lower().startswith('s3://'):
        print('ERROR: Input filename can\'t start with \'s3://\'')

    logger.info('Execution begins')

    aws_profile_name = None
    if pwd.getpwuid(os.getuid()).pw_name != 'airflow':
        aws_profile_name = 'nwprod'

    s3_creds = os.environ.get(args.redshift_s3_creds_envar)

    import_table(
        server=args.server,
        port=args.port,
        database=args.database,
        username=args.username,
        table_name=args.table_name,
        input_spec=args.input_filename or args.input_s3_url,
        s3_credentials=s3_creds,
        gzipped_input=args.gzip,
        aws_profile=aws_profile_name)

    logger.info('Execution ends')
