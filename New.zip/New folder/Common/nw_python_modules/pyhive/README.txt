This directory contains PyHive 0.5.0 which has been modified to support SSL
connections. If the standard release of PyHive is modified to add SSL support,
we should switch to the standard library and this directory should be removed.

Derek Middleton - dmiddleton@nerdwallet.com
