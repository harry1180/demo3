from redshift_modules import redshift_connect

import nw_hive
import nw_presto


class LoopbackDB(object):
    """
    Handles DB connections for loopback to support Redshift and Nerdlake. Three different connections are created:

        journal_conn: Used to insert/update journal table (redshift)
        sql_conn: Used to run DML SQL statements (redshift/presto)
        ddl_conn: Used to run DDL SQL statements (redshift/hive)
    """
    _CONNECTORS = {
        'redshift': redshift_connect,
        'presto': nw_presto.connect,
        'hive': nw_hive.connect
    }

    def __init__(self, nerdlake_in=False):

        self.nerdlake_in = nerdlake_in

        if self.nerdlake_in:
            self.journal_conn = self._CONNECTORS.get('redshift')()
            self.sql_conn = self._CONNECTORS.get('presto')()
            self.ddl_conn = self._CONNECTORS.get('hive')()
        else:
            self.journal_conn = self.sql_conn = self.ddl_conn = self._CONNECTORS.get('redshift')()


    def __exit__(self):
        self.journal_conn.close()
        self.sql_conn.close()
        self.ddl_conn.close()
