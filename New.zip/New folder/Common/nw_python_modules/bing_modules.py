from bingads.service_client import ServiceClient
from bingads.authorization import *
import importlib
CURRENT_VERSION=12
m = importlib.import_module("bingads.v%s" % CURRENT_VERSION)
m2 = importlib.import_module("bingads.v%s.bulk" % CURRENT_VERSION)
#from bingads.v12 import *
#from bingads.v12.bulk import *

def authenticate_with_oauth(authorization_data,bing_refresh_token,bing_client_ID, bing_client_secret, bing_redirection_uri):
    authentication = OAuthWebAuthCodeGrant(
                client_id=bing_client_ID,
                client_secret=bing_client_secret,
                redirection_uri=bing_redirection_uri
    )
    # Assign this authentication instance to the authorization_data.
    authorization_data.authentication = authentication
    authorization_data.authentication.request_oauth_tokens_by_refresh_token(bing_refresh_token)


def search_accounts_by_user_id(customer_service, user_id):
    ''' 
    Search for account details by UserId.

    :param user_id: The Bing Ads user identifier.
    :type user_id: long
    :return: List of accounts that the user can manage.
    :rtype: ArrayOfAccount
    '''
    print 'Getting account List'
    paging = {
        'Index': 0,
        'Size': 20
    }

    predicates = {
        'Predicate': [
            {
                'Field': 'UserId',
                'Operator': 'Equals',
                'Value': user_id,
            },
        ]
    }

    search_accounts_request = {
        'PageInfo': paging,
        'Predicates': predicates
    }

    return customer_service.SearchAccounts(
        PageInfo=paging,
        Predicates=predicates
    )


def set_elements_to_none(suds_object):
    # Bing Ads Campaign Management service operations require that if you specify a non-primitives, 
    # it must be one of the values defined by the service i.e. it cannot be a nil element. 
    # Since Suds requires non-primitives and Bing Ads won't accept nil elements in place of an enum value, 
    # you must either set the non-primitives or they must be set to None. Also in case new properties are added 
    # in a future service release, it is a good practice to set each element of the SUDS object to None as a baseline. 

    for (element) in suds_object:
        suds_object.__setitem__(element[0], None)
    return suds_object

def output_status_message(message):
    print(message)

def output_bing_ads_webfault_error(error):
    if hasattr(error, 'ErrorCode'):
        output_status_message("ErrorCode: {0}".format(error.ErrorCode))
    if hasattr(error, 'Code'):
        output_status_message("Code: {0}".format(error.Code))
    if hasattr(error, 'Message'):
        output_status_message("Message: {0}".format(error.Message))
    output_status_message('')

def output_webfault_errors(ex):
    if hasattr(ex.fault, 'detail') \
            and hasattr(ex.fault.detail, 'ApiFault') \
            and hasattr(ex.fault.detail.ApiFault, 'OperationErrors') \
            and hasattr(ex.fault.detail.ApiFault.OperationErrors, 'OperationError'):
        api_errors = ex.fault.detail.ApiFault.OperationErrors.OperationError
        if type(api_errors) == list:
            for api_error in api_errors:
                output_bing_ads_webfault_error(api_error)
        else:
            output_bing_ads_webfault_error(api_errors)
    elif hasattr(ex.fault, 'detail') \
            and hasattr(ex.fault.detail, 'AdApiFaultDetail') \
            and hasattr(ex.fault.detail.AdApiFaultDetail, 'Errors') \
            and hasattr(ex.fault.detail.AdApiFaultDetail.Errors, 'AdApiError'):
        api_errors = ex.fault.detail.AdApiFaultDetail.Errors.AdApiError
        if type(api_errors) == list:
            for api_error in api_errors:
                output_bing_ads_webfault_error(api_error)
        else:
            output_bing_ads_webfault_error(api_errors)
    elif hasattr(ex.fault, 'detail') \
            and hasattr(ex.fault.detail, 'ApiFaultDetail') \
            and hasattr(ex.fault.detail.ApiFaultDetail, 'BatchErrors') \
            and hasattr(ex.fault.detail.ApiFaultDetail.BatchErrors, 'BatchError'):
        api_errors = ex.fault.detail.ApiFaultDetail.BatchErrors.BatchError
        if type(api_errors) == list:
            for api_error in api_errors:
                output_bing_ads_webfault_error(api_error)
        else:
            output_bing_ads_webfault_error(api_errors)
    elif hasattr(ex.fault, 'detail') \
            and hasattr(ex.fault.detail, 'ApiFaultDetail') \
            and hasattr(ex.fault.detail.ApiFaultDetail, 'OperationErrors') \
            and hasattr(ex.fault.detail.ApiFaultDetail.OperationErrors, 'OperationError'):
        api_errors = ex.fault.detail.ApiFaultDetail.OperationErrors.OperationError
        if type(api_errors) == list:
            for api_error in api_errors:
                output_bing_ads_webfault_error(api_error)
        else:
            output_bing_ads_webfault_error(api_errors)
    elif hasattr(ex.fault, 'detail') \
            and hasattr(ex.fault.detail, 'EditorialApiFaultDetail') \
            and hasattr(ex.fault.detail.EditorialApiFaultDetail, 'BatchErrors') \
            and hasattr(ex.fault.detail.EditorialApiFaultDetail.BatchErrors, 'BatchError'):
        api_errors = ex.fault.detail.EditorialApiFaultDetail.BatchErrors.BatchError
        if type(api_errors) == list:
            for api_error in api_errors:
                output_bing_ads_webfault_error(api_error)
        else:
            output_bing_ads_webfault_error(api_errors)
    elif hasattr(ex.fault, 'detail') \
            and hasattr(ex.fault.detail, 'EditorialApiFaultDetail') \
            and hasattr(ex.fault.detail.EditorialApiFaultDetail, 'EditorialErrors') \
            and hasattr(ex.fault.detail.EditorialApiFaultDetail.EditorialErrors, 'EditorialError'):
        api_errors = ex.fault.detail.EditorialApiFaultDetail.EditorialErrors.EditorialError
        if type(api_errors) == list:
            for api_error in api_errors:
                output_bing_ads_webfault_error(api_error)
        else:
            output_bing_ads_webfault_error(api_errors)
    elif hasattr(ex.fault, 'detail') \
            and hasattr(ex.fault.detail, 'EditorialApiFaultDetail') \
            and hasattr(ex.fault.detail.EditorialApiFaultDetail, 'OperationErrors') \
            and hasattr(ex.fault.detail.EditorialApiFaultDetail.OperationErrors, 'OperationError'):
        api_errors = ex.fault.detail.EditorialApiFaultDetail.OperationErrors.OperationError
        if type(api_errors) == list:
            for api_error in api_errors:
                output_bing_ads_webfault_error(api_error)
        else:
            output_bing_ads_webfault_error(api_errors)
    # Handle serialization errors e.g. The formatter threw an exception while trying to deserialize the message:
    # There was an error while trying to deserialize parameter https://bingads.microsoft.com/CampaignManagement/v9:Entities.
    elif hasattr(ex.fault, 'detail') \
            and hasattr(ex.fault.detail, 'ExceptionDetail'):
        api_errors = ex.fault.detail.ExceptionDetail
        if type(api_errors) == list:
            for api_error in api_errors:
                output_status_message(api_error.Message)
        else:
            output_status_message(api_errors.Message)
    else:
        raise Exception('Unknown WebFault')

        # def output_partial_errors(partial_errors):
#     if not partial_errors:
#         return None
#     output_status_message("BatchError (PartialErrors) item:\n")
#     for error in partial_errors['BatchError']:
#         output_status_message("\tIndex: {0}".format(error.Index))
#         output_status_message("\tCode: {0}".format(error.Code))
#         output_status_message("\tErrorCode: {0}".format(error.ErrorCode))
#         output_status_message("\tMessage: {0}\n".format(error.Message))
#         output_status_message("\tFieldPath: {0}\n".format(error.Message))
#         output_status_message("\tDetails: {0}\n".format(error.Message))
#
#         # In the case of an EditorialError, more details are available
#         if error.Type == "EditorialError" and error.ErrorCode == "CampaignServiceEditorialValidationError":
#             output_status_message("\tDisapprovedText: {0}".format(error.DisapprovedText))
#             output_status_message("\tLocation: {0}".format(error.Location))
#             output_status_message("\tPublisherCountry: {0}".format(error.PublisherCountry))
#             output_status_message("\tReasonCode: {0}\n".format(error.ReasonCode))
