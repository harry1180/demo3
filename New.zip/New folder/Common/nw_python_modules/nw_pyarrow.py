"""
Convenience functions for interacting with PyArrow.
"""
from datetime import datetime
import logging
import os
import six

import pyarrow
from pyarrow.parquet import ParquetWriter


def get_pyarrow_types(database_cols):
    """
    Given a list of database columns, return a list of the corresponding PyArrow data types.

    :param database_cols: List of database columns, stored as a list of dictionaries.
    :return: List of PyArrow types.
    """
    pyarrow_types = list()
    for col in database_cols:
        data_type = col['type']
        if data_type in ('character', 'character varying'):
            pyarrow_types.append(pyarrow.string())
        elif data_type == 'date':
            pyarrow_types.append(pyarrow.date32())
        elif data_type == 'timestamp without time zone':
            pyarrow_types.append(pyarrow.timestamp('ms'))
        elif data_type == 'bigint':
            pyarrow_types.append(pyarrow.int64())
        elif data_type == 'integer':
            pyarrow_types.append(pyarrow.int32())
        elif data_type == 'smallint':
            pyarrow_types.append(pyarrow.int16())
        elif data_type == 'numeric':
            pyarrow_types.append(pyarrow.decimal128(col['precision'], col['scale']))
        elif data_type == 'boolean':
            pyarrow_types.append(pyarrow.bool_())
        elif data_type == 'uuid':
            pyarrow_types.append(pyarrow.string())
        elif data_type == 'bytea':
            pyarrow_types.append(pyarrow.binary())
        else:
            raise TypeError('Couldn\'t convert data type \'{}\' to PyArrow data type'.format(data_type))
    return pyarrow_types


def write_data_to_parquet(pqwriter, parquet_filename, columnar_data, col_names, pyarrow_types):
    """
    Translate the data into a PyArrow table then write that table to a Parquet file. We create the parquet writer in
    in this function so that, in the future, we might have a max. file size and write multiple files.

    :param pqwriter: A PyArrow ParquetWriter object. If set to None, a new ParquetWriter will be created.
    :param parquet_filename: Filename of the Parquet output file.
    :param columnar_data: The data to be written, stored as a list of columnar-oriented data.
    :param col_names: Names of the column
    :param pyarrow_types: List of the PyArrow types for each column of the data.
    :return: The ParquetWriter object used to write the data.
    """

    # Convert the data into a list of PyArrow arrays then build a PyArrow table
    arrays = list()
    for i in range(len(col_names)):
        arrays.append(pyarrow.array(columnar_data[i], type=pyarrow_types[i]))
    tbl = pyarrow.Table.from_arrays(names=col_names, arrays=arrays)
    del arrays

    # Write the PyArrow table to a Parquet file
    if pqwriter is None:
        if os.path.exists(parquet_filename):
            os.remove(parquet_filename)
        pqwriter = ParquetWriter(parquet_filename, tbl.schema, flavor='spark')
    pqwriter.write_table(tbl)
    del tbl

    return pqwriter


def cursor_to_parquet_file(curs, cols, parquet_filename, buffer_size=50000):
    """
    Writes the data from a database cursor to a Parquet file.

    :param curs: Database cursor
    :param cols: List of columns returned by the cursor
    :param parquet_filename: File that the Parquet data will be written to.
    :param buffer_size: Number of database records that are buffered in memory before being written to the Parquet file.
    :return:
    """
    col_names = [c['name'] for c in cols]
    col_names.append('extract_ts')
    pyarrow_types = get_pyarrow_types(cols)
    pyarrow_types.append(pyarrow.timestamp('ms'))
    pqwriter = None
    row_count = 0
    status_message_timestamp = None
    start_timestamp = datetime.now()
    logging.info('Converting {:,} records at a time to Parquet'.format(buffer_size))
    while True:
        if status_message_timestamp is None:
            logging.info('Fetching first batch of records')
        row_data = curs.fetchmany(buffer_size)
        if status_message_timestamp is None:
            logging.info('Fetch of first batch is complete')
            status_message_timestamp = datetime.now()
        if row_data is None or len(row_data) == 0:
            break
        row_count += len(row_data)
        col_data = zip(*row_data)  # Flip the data from row-oriented to column-oriented
        del row_data

        # Update character-based columns, replacing the null control picture character with the null character
        for i, col in enumerate(cols):
            if col['type'] not in ('character', 'character varying'):
                continue
            new_col = list()
            for field_value in col_data[i]:
                if field_value is None:
                    new_col.append(None)
                else:
                    new_col.append(field_value.replace(u'\u2400', six.unichr(0)))
            col_data[i] = new_col

        # Dump our data into a PyArrow Table and then into a Parquet file
        pqwriter = write_data_to_parquet(pqwriter, parquet_filename, col_data, col_names, pyarrow_types)
        del col_data

        # Emit a progress message every 30 seconds
        if status_message_timestamp is None or (datetime.now() - status_message_timestamp).total_seconds() >= 30:
            status_message_timestamp = datetime.now()
            logging.info('Processed {:,} records so far'.format(row_count))

    elapsed_secs = (datetime.now() - start_timestamp).total_seconds()
    logging.info('Conversion complete')
    logging.info('Stats:')
    logging.info('    Record Count:       {:,}'.format(row_count))
    logging.info('    Elapsed Seconds:    {:,.2f}'.format(elapsed_secs))
    logging.info('    Records per Second: {:,.1f}'.format(row_count / elapsed_secs))
    logging.info('    Parquet file size:  {:,} bytes'.format(os.stat(parquet_filename).st_size))

    if pqwriter is not None:
        pqwriter.close()

    return row_count
