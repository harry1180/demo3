# /usr/bin/python
"""Getting Google Adwords performance data through API call and save results as .csv file.
Input file is config.json that contains query string, output file name based on the group of attributes, query string to call Google API
and input/output directories

The LoadFromStorage method is pulling credentials and properties from "/etc/dwh_secured_tokens/googleads_marketing_report.yaml"
"""

from googleads import adwords
import csv
import json
import logging
import sys
import os
import datetime
import nw_generic_utils_modules

API_VERSION = 'v201806'
def aw_auth():
    ### Initialize client object.
    adwords_client = adwords.AdWordsClient.LoadFromStorage("/etc/dwh_secured_tokens/googleads_marketing_report.yaml")
    return adwords_client

def get_all_accounts():
    """
       Get all account IDs under master account and return the account list
    """
    client = aw_auth()
    accounts = []
    # Initialize appropriate service.
    managed_customer_service = client.GetService('ManagedCustomerService', version=API_VERSION)
    # Construct selector to get all accounts.
    offset = 0
    PAGE_SIZE = 500
    selector = {
        'fields': ['CustomerId', 'Name'],
        'paging': {
            'startIndex': str(offset),
            'numberResults': str(PAGE_SIZE)
        }
    }
    page = managed_customer_service.get(selector)
    if 'entries' in page and page['entries']:
        # Create map from customerId to parent and child links.
        if 'links' in page:
            for link in page['links']:
                account = str(link['clientCustomerId'])
                accounts.append(account)
    return accounts


# logging.getLogger('suds.client').setLevel(logging.CRITICAL)

def adwords_awql_report(report_query_string, dwh_file_name, report_query, date_range, input_file_dir,
                        client_key):
    """
    Get data based on 'report_query_string' and generate .csv with dwh_file_name
    sample call: adwords_awql_report("CostPerConvertedClickSignificance,ConvertedClicksSignificance","google_campaign_performance_cost_significance","SELECT CostPerConvertedClickSignificance,ConvertedClicksSignificance FROM CAMPAIGN_PERFORMANCE_REPORT",'/data/etl/Data/marketing_google/input','400-092-3014')
    """
    adwords_client = aw_auth()
    adwords_client.SetClientCustomerId(client_key)
    ### Initialize appropriate service.
    report_downloader = adwords_client.GetReportDownloader(version=API_VERSION)

    report_query = report_query + " " + date_range
    print report_query
    values = report_downloader.DownloadReportAsStringWithAwql(report_query, 'CSV', skip_report_header=True,
                                                              skip_column_header=True,
                                                              skip_report_summary=True, include_zero_impressions=False)

    with open(input_file_dir + dwh_file_name + '.csv', 'a') as rpt_writer:
        rpt_writer.write(values.encode('utf-8'));
