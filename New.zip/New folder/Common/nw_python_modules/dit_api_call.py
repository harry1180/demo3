import sys
import requests
import json
import dateutil.parser
import datetime

#dit_api_call_test.api_to_list('http://ditservices/api/v1/analytics/messages/?limit=1000&offset=',0,'True',' 	11','/home/jsequeira/dwh/Manual_Loads/Adhoc_Run/tag_output_json1')      

def write_to_tags_jsonfile(input,json_tag_outfile) :
  """
  This function scans the list of tags and denormalizes them.
  It then writes the denormalized data into tag output file.
  """
  try :
      tag_dict_record={}
      for tag in input["tags"]:  
             tag_dict_record['id']=input["id"]  
             tag_dict_record['tag']=tag   
             tag_dict_record['src_tag']=input["tags"]                
             json_tag_outfile.write(json.dumps(tag_dict_record, sort_keys=True))  
             json_tag_outfile.write("\n")
      return 1
  except Exception,err:
      print Exception,err
      return -1             
  



def write_to_json(input_list,filename,json_tag_outfile="ZZZ"):
  """ 
  This function scans through a input list and write one  dictionary record at a time to a json out file.
  If tags key is present it will write to the optional tags out file.
  call example:
  1) call to generate output file as well as tag output file
  write_to_json(input_list=result_list,filename="$home/output_json",json_tag_outfile)
  2) call to genearte only output file
  write_to_json(input_list=result_list,filename="$home/output_json")
    
  """ 
  try:
      with open(filename, 'w') as json_outfile:
          for input in input_list:
            if json_tag_outfile != "ZZZ" :
                if write_to_tags_jsonfile(input,json_tag_outfile) == -1 :
                    print "Error while writing to tag file"
                    return -1
            json_outfile.write(json.dumps(input, sort_keys=True))  
            json_outfile.write("\n")
                       
      return 1      
  except Exception,err:
      print Exception,err
      return -1          


def  format_list(input_list):
  """ 
  Function to format the input list data. If key is date stored in unicode, this function will parse the date and return a datetime.
  eg 2016-04-14T17:13:10.701000Z will be converted to 2016-04-14 17:13:10.701000+00:00
  """ 
  date_keys=['created_at','updated_at','last_seen_at','sent_at']
  
  for input_dict in input_list:
      for key in input_dict:
          try:
            if (key in date_keys ) and (isinstance(dateutil.parser.parse(input_dict[key]),datetime.datetime) ) :
                # parses the unciode and converts to datetime
                input_dict[key]=dateutil.parser.parse(input_dict[key]).strftime('%Y-%m-%d %H:%M:%S')
                #print key, input_dict[key]     
          except:
             #For keys which are not datetime
             pass            
         
  return input_list           
          
            



def api_to_list(url,offset=0,pagination="True",output_filename="ZZZ", tag_output_filename="ZZZ"):
  """
  This method is used to invoke dit api . Page size is set to 1000. Offset will be incremented to scan next page.
  If pagination is set function will scan through all the pages and return a list of all json objects. 
  Function will return a list of json objects or write to a json file if input filename is provided.
  call examples:
    1) to get data in list object 
    api_to_list(url='http://ditservices/api/v1/analytics/messages/?limit=1000&offset=',offset=0,pagination='True')    
    2) to get data written in a local file
    api_to_list(url='http://ditservices/api/v1/analytics/messages/?limit=1000&offset=',offset=0,pagination='True',output_filename='$HOME/output_json1',tag_output_filename='$HOME/tag_output_json1')      
    3) to parse url without pagination starting at different offset
     api_to_list(url='http://ditservices/api/v1/analytics/messages/?limit=1000&offset=',offset=5000,pagination='False')     
     This will call will return a list of 1000 objects starting from offset 5000.
    4) Below call will scann through all the pages starting from offset 0 and return list of objects
    api_to_list(url='http://ditservices/api/v1/analytics/messages/?limit=1000&offset=')  
  """    
  final_result_list =[]
  while  1:   
      input_url =url + str(offset)
      response = requests.get(input_url, stream=True, timeout=1000 )    
          
      print "status: " + str(response.status_code)   
          
      if response.status_code != 200:    
          print "            Can't pull DIT messages data   "    
          return -1    

      result_list=  json.loads(response.text)[u'data']      
      if  result_list:
          #Append to existing output list
          final_result_list.extend(format_list(result_list))
          
          if  pagination == "True" :
          #Continue paging through api if the value is set.
             offset +=1000
          else :
             break
      else:        
          print "Result is Empty."
          break
  
  if output_filename == "ZZZ":  
      # Output will be returned as list.          
      return final_result_list     
  else:
      if tag_output_filename != "ZZZ" :
          # Open the tag file for writing and call function to write to json files.
          with open(tag_output_filename, 'w') as json_tag_outfile: 
             return write_to_json( final_result_list, output_filename,json_tag_outfile)
      else :  
          return write_to_json( final_result_list, output_filename) 
   
      
 
