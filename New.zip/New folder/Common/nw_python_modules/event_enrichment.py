import platform
import struct
from urlparse import urlparse, parse_qs

import cachetools
import tldextract
import user_agents

import nw_url_check
import nwpyschemas.util as pb_utils

if platform.system() != 'Java':
    import xxhash

# Caching variables for URL and User Agent
useragent_cache = cachetools.LRUCache(50000)
url_cache = cachetools.LRUCache(50000)


def get_sk(val):
    if platform.system() == 'Java':
        return None
    if val is None or val.strip == '':
        return 0
    try:
        xx = xxhash.xxh64(bytes(bytearray(val.strip().lower(), 'utf-8')))
        return struct.unpack('>q', xx.digest())[0]
    except ValueError:
        return None


def get_pb_field_names(pb_fields):
    field_names = set()
    for pb_field in pb_fields:
        if pb_field.message_type:
            field_names.update(get_pb_field_names(pb_field.message_type.fields))
        else:
            field_names.add(pb_field.name)
    return field_names


def get_enriched_parquet_types(java_class_name):
    enriched_types = dict()
    enriched_types['url'] = [
        'optional int64 zdw_Reg_url_sk',
        'optional binary zdw_Reg_final_confirmed_url (UTF8)',
        'optional binary zdw_Reg_final_confirmed_path (UTF8)',
        'optional binary zdw_Reg_final_confirmed_query (UTF8)',
        'optional binary zdw_Reg_utm_src (UTF8)',
        'optional binary zdw_Reg_utm_med (UTF8)',
        'optional binary zdw_Reg_utm_camp (UTF8)',
        'optional binary zdw_Reg_utm_cont (UTF8)',
        'optional binary zdw_Reg_utm_term (UTF8)',
        'optional binary zdw_Reg_utm_hp_ref (UTF8)',
        'optional binary zdw_Reg_url_scheme (UTF8)',
        'optional binary zdw_Reg_url_netloc (UTF8)',
        'optional binary zdw_Reg_url_sub_domain (UTF8)',
        'optional binary zdw_Reg_url_site_nm (UTF8)',
        'optional binary zdw_Reg_url_domain_sfx (UTF8)',
        'optional boolean zdw_Reg_url_is_valid',
        'optional msas zdw_Reg_querystring',
        'optional binary zdw_qs_trk (UTF8)']
    enriched_types['referrer'] = [
        'optional int64 zdw_Ref_url_sk',
        'optional binary zdw_Ref_final_confirmed_url (UTF8)',
        'optional binary zdw_Ref_final_confirmed_path (UTF8)',
        'optional binary zdw_Ref_final_confirmed_query (UTF8)',
        'optional binary zdw_Ref_utm_src (UTF8)',
        'optional binary zdw_Ref_utm_med (UTF8)',
        'optional binary zdw_Ref_utm_camp (UTF8)',
        'optional binary zdw_Ref_utm_cont (UTF8)',
        'optional binary zdw_Ref_utm_term (UTF8)',
        'optional binary zdw_Ref_utm_hp_ref (UTF8)',
        'optional binary zdw_Ref_url_scheme (UTF8)',
        'optional binary zdw_Ref_url_netloc (UTF8)',
        'optional binary zdw_Ref_url_sub_domain (UTF8)',
        'optional binary zdw_Ref_url_site_nm (UTF8)',
        'optional binary zdw_Ref_url_domain_sfx (UTF8)',
        'optional boolean zdw_Ref_url_is_valid',
        'optional msas zdw_Ref_querystring',
        'optional binary zdw_ref_url_search_keyword (UTF8)']
    enriched_types['userAgent'] = [
        'optional int64 zdw_user_agent_sk',
        'optional binary zdw_user_agent (UTF8)',
        'optional boolean zdw_user_agent_is_bot',
        'optional boolean zdw_user_agent_is_email_client',
        'optional boolean zdw_user_agent_is_mobile',
        'optional boolean zdw_user_agent_is_pc',
        'optional boolean zdw_user_agent_is_tablet',
        'optional boolean zdw_user_agent_is_touch_capable',
        'optional binary zdw_user_agent_browser_family (UTF8)',
        'optional binary zdw_user_agent_browser_version_string (UTF8)',
        'optional binary zdw_user_agent_os_family (UTF8)',
        'optional binary zdw_user_agent_os_version_string (UTF8)',
        'optional binary zdw_user_agent_device_family (UTF8)',
        'optional binary zdw_user_agent_device_brand (UTF8)',
        'optional binary zdw_user_agent_device_model (UTF8)',
        'optional binary zdw_user_agent_pretty (UTF8)']
    enriched_types['cookieId'] = [
        'optional int64 zdw_cookieid_sk']

    pb_class_name = java_class_name
    if '$' in java_class_name:
        pb_class_name = java_class_name[java_class_name.index('$')+1:]
    pb_class = pb_utils.load_class(pb_class_name)
    pb_field_names = get_pb_field_names(pb_class.DESCRIPTOR.fields)
    pq_types = set()
    for pb_field_name in pb_field_names:
        if pb_field_name in enriched_types:
            pq_types.update(enriched_types[pb_field_name])

    return pq_types


def get_querystring_key_value(querystring_dict, search_keys):
    """
    Retrieve the first value for a given key from a URL query string
    :param querystring_dict: Dictionary containing the query string parameters
    :param search_keys: the key(s) that the value should be retrieved for
    :return: The first value of the first key
    """
    try:
        for search_key in search_keys:
            if search_key not in querystring_dict:
                continue
            vals = querystring_dict[search_key]
            if isinstance(vals, list):
                return vals[0]
            else:
                return vals
        return ''
    except UnicodeEncodeError:
        return ''


@cachetools.cached(useragent_cache)
def enrich_useragent(user_agent):
    """
    Parses a user agent and retrieve metadata about the agent. Handles facebook agents by ignoring everything after
    the '[' character.
    :param agent:
    :return: Dictionary containing attributes about the agent
    """

    ua = dict()
    if user_agent is None or user_agent.strip() == '':
        return ua

    try:
        ua['zdw_user_agent'] = user_agent.split('[')[0].strip()
    except (ValueError, UnicodeEncodeError):
        try:
            ua['zdw_user_agent'] = user_agent.strip()
        except (ValueError, UnicodeEncodeError):
            ua['zdw_user_agent'] = user_agent

    # Add mobile, bot, and other metadata attributes by parsing the agent
    if ua['zdw_user_agent']:
        ua['zdw_user_agent_sk'] = get_sk(ua['zdw_user_agent'])
        agent = user_agents.parse(ua['zdw_user_agent'])
        ua['zdw_user_agent_is_bot'] = agent.is_bot
        ua['zdw_user_agent_is_email_client'] = agent.is_email_client
        ua['zdw_user_agent_is_mobile'] = agent.is_mobile
        ua['zdw_user_agent_is_pc'] = agent.is_pc
        ua['zdw_user_agent_is_tablet'] = agent.is_tablet
        ua['zdw_user_agent_is_touch_capable'] = agent.is_touch_capable
        ua['zdw_user_agent_browser_family'] = agent.browser.family
        #ua['zdw_user_agent_browser_version'] = agent.browser.version
        ua['zdw_user_agent_browser_version_string'] = agent.browser.version_string
        ua['zdw_user_agent_os_family'] = agent.os.family
        #ua['zdw_user_agent_os_version'] = agent.os.version
        ua['zdw_user_agent_os_version_string'] = agent.os.version_string
        ua['zdw_user_agent_device_family'] = agent.device.family
        ua['zdw_user_agent_device_brand'] = agent.device.brand
        ua['zdw_user_agent_device_model'] = agent.device.model
        try:
            ua['zdw_user_agent_pretty'] = u'{}'.format(agent)
        except UnicodeEncodeError:
            # the User Agent parsing library doesn't handle Unicode correctly when building the "pretty" user
            # agent string.
            pass

    return ua


def query_string_to_dict(qs):
    """
    Translates a URL query string into a dictionary
    :param qs: A query string that was passed as part of a URL
    :return: Dictionary containing the query string keys and values
    """
    qs_dict = dict()

    if len(qs.strip()) == 0:
        return qs_dict

    kvp = parse_qs(qs.replace('?', '&'))

    for key, raw_values in kvp.iteritems():
        scrubbed_values = []
        for raw_value in raw_values:
            scrubbed_values.append(raw_value.replace('\x00', ''))
        qs_dict[key.lower()] = scrubbed_values

    return qs_dict


@cachetools.cached(url_cache)
def enrich_url(url, key_prefix, referral):
    """
    Returns a dictionary with several derived and parsed fields for the specified URL.
    :param url: The url that should be parsed
    :param key_prefix: The prefix that should be added to all returned dictionary keys.
    :param referral: Indicates if the specified URL is a referral URL or not.
    :return: A two-element tuple of a dictionary containing additional values and a set containing Parquet data types
        for the values in the dictionary.
    """
    out_dict = dict()

    if referral:
        parsed_conformed_url = urlparse(url)
    else:
        fixed_url = nw_url_check.url_strip(nw_url_check.fix_nw_url(url))
        parsed_conformed_url = nw_url_check.conform_url(fixed_url)

    try:
        final_conformed_url = nw_url_check.url_strip(nw_url_check.nw_url_join(parsed_conformed_url.scheme,
                                                                              parsed_conformed_url.netloc,
                                                                              parsed_conformed_url.path))
    except UnicodeEncodeError:
        final_conformed_url = nw_url_check.url_strip(url)

    final_conformed_path = nw_url_check.url_strip(parsed_conformed_url.path)
    final_conformed_params = parsed_conformed_url.params
    final_conformed_fragment = parsed_conformed_url.fragment

    if '?' in final_conformed_params:
        params_query = urlparse(final_conformed_params).query.replace('?', '')
    else:
        params_query = final_conformed_params

    if '?' in final_conformed_fragment:
        fragment_query = urlparse(final_conformed_fragment).query.replace('?', '')
    else:
        fragment_query = final_conformed_fragment

    url_query = parsed_conformed_url.query
    final_conformed_query = ''

    if len(url_query) > 0:
        final_conformed_query = url_query

    if len(params_query) > 0:
        if len(url_query) > 0:
            final_conformed_query = final_conformed_query + '&' + params_query
        else:
            final_conformed_query = params_query

    if len(fragment_query) > 0:
        if len(params_query) > 0 or len(url_query) > 0:
            final_conformed_query = final_conformed_query + '&' + fragment_query
        else:
            final_conformed_query = fragment_query

    final_conformed_scheme = parsed_conformed_url.scheme
    final_conformed_netloc = parsed_conformed_url.netloc

    qs_dict = parse_qs(final_conformed_query)
    utm_src = get_querystring_key_value(qs_dict, ['UTM_SRC', 'utm_source'])
    utm_med = get_querystring_key_value(qs_dict, ['UTM_MED', 'utm_medium'])
    utm_camp = get_querystring_key_value(qs_dict, ['UTM_CAMP', 'utm_campaign'])
    utm_cont = get_querystring_key_value(qs_dict, ['UTM_CONT', 'utm_content'])
    utm_term = get_querystring_key_value(qs_dict, ['UTM_TERM', 'utm_term'])
    utm_hp_ref = get_querystring_key_value(qs_dict, ['utm_hp_ref'])

    url_domain = tldextract.extract(final_conformed_netloc)
    final_url_is_valid = nw_url_check.validate_url_struct(final_conformed_url)
    
    out_dict.update({
        '{}_url_sk'.format(key_prefix): get_sk(url),
        '{}_final_confirmed_url'.format(key_prefix): final_conformed_url,
        '{}_final_confirmed_path'.format(key_prefix): final_conformed_path,
        '{}_final_confirmed_query'.format(key_prefix): final_conformed_query,
        '{}_utm_src'.format(key_prefix): utm_src,
        '{}_utm_med'.format(key_prefix): utm_med,
        '{}_utm_camp'.format(key_prefix): utm_camp,
        '{}_utm_cont'.format(key_prefix): utm_cont,
        '{}_utm_term'.format(key_prefix): utm_term,
        '{}_utm_hp_ref'.format(key_prefix): utm_hp_ref,
        '{}_url_scheme'.format(key_prefix): final_conformed_scheme,
        '{}_url_netloc'.format(key_prefix): final_conformed_netloc,
        '{}_url_sub_domain'.format(key_prefix): url_domain.subdomain,
        '{}_url_site_nm'.format(key_prefix): url_domain.domain,
        '{}_url_domain_sfx'.format(key_prefix): url_domain.suffix,
        '{}_url_is_valid'.format(key_prefix): final_url_is_valid
    })

    # Store the query string as a dictionary
    out_dict['{}_querystring'.format(key_prefix)] = query_string_to_dict(final_conformed_query)
    if len(out_dict['{}_querystring'.format(key_prefix)]) == 0:
        out_dict['{}_querystring'.format(key_prefix)] = None

    if referral:
        out_dict['zdw_ref_url_search_keyword'] = get_search_term(
            parsed_conformed_url.netloc, out_dict['{}_querystring'.format(key_prefix)])
    else:
        out_dict['zdw_qs_trk'] = get_querystring_key_value(qs_dict, ['trk'])

    return out_dict


search_engine_map = {
    'q': ['alltheweb', 'aol', 'ask', 'bing', 'google'],
    'p': ['yahoo'],
    'wd': ['baidu'],
    'text': ['yandex']
}

def get_search_term(url_domain, url_qs_dict):
    """
    Fetch the search keyword from the query string on the URL.
    :param url: NerdWallet URL
    :return: keyword that was used in the search
    """

    for search_term_param, search_engines in search_engine_map.iteritems():
        for search_engine in search_engines:
            if search_engine in url_domain:
                if url_qs_dict is not None and search_term_param in url_qs_dict:
                    return url_qs_dict[search_term_param][0]
                else:
                    return '%s unspecified' % search_engine
    return ''


def enrich(in_dict, event_specific_enrichment=None, generic_enrichment=True):
    out_dict = dict()

    if generic_enrichment:
        if 'userAgent' in in_dict:
            out_dict.update(enrich_useragent(in_dict['userAgent']))

        if 'url' in in_dict:
            out_dict.update(enrich_url(in_dict['url'], 'zdw_Reg', referral=False))

        if 'referrer' in in_dict and in_dict['referrer'] and in_dict['referrer'].lower() != 'undefined':
            out_dict.update(enrich_url(in_dict['referrer'], 'zdw_Ref', referral=True))

        if 'cookieId' in in_dict:
            out_dict['zdw_cookieid_sk'] = get_sk(in_dict['cookieId'])

        if 'canonicalURL' in in_dict:
            out_dict['canonicalURL'] = nw_url_check.url_strip(in_dict['canonicalURL'])

    if event_specific_enrichment:
        out_dict.update(event_specific_enrichment(in_dict))

    return out_dict
