import email
import os
import traceback
import pwd

from boto.s3.connection import S3Connection

AWS_PROFILE = None
if pwd.getpwuid(os.getuid()).pw_name != 'airflow':
    AWS_PROFILE = 'nwprod'

conn = S3Connection(profile_name=AWS_PROFILE)


def email_attachment_extract(email_s3_bucket, email_s3_path, archive_s3_path, output_path, proc_email_path, strict=True):
    """
    This function extracts the attachments from emails that were downloaded to s3 bucket
    and saves the downloaded emails in to local input path and extracted attachments to local
    output path. It then archives the processed emails into s3 archive path.
    1) EmailBucket="east1-prod-aflt-airdrop-0"
    2) EmailPath="AffiliateEmails"
    3) ArchivePath="Archive"
    4) output_path='/data/etl/Data/aflt_process_email_attachments/input'
    5) ProcessedEmailPath='/data/etl/Data/aflt_process_email_attachments/output'
    :param email_s3_bucket: str, s3 bucket containing email attachments
    :param email_s3_path: str, s3 folder containing email attachments
    :param archive_s3_path: str, s3 archive folder
    :param output_path: str, local directory to store downloaded email files
    :param proc_email_path: str, local directory to store processed email files
    :param strict: bool, if true function will fail on any exception, otherwise exception will be ignored
    """
    try:
        bucket = conn.get_bucket(email_s3_bucket)
        for key in bucket.list(email_s3_path):
            input_key = key.name.encode('utf-8')
            key_objects = bucket.list(prefix=str(input_key))
            for key_object in key_objects:
                actual_key = str(input_key).split("/", 1)[1]

                # Creating the local file name for the key
                outfile = output_path + '/' + actual_key

                # Download the key to Local File System
                key_object.get_contents_to_filename(outfile)

                # Processing the key to check for attachments
                msg = email.message_from_file(open(outfile))
                for part in msg.walk():
                    if part.get_content_maintype() == 'multipart':
                        continue
                    file_name = part.get_filename()
                    if bool(file_name):
    	                file_path = os.path.join(proc_email_path, file_name)
        	        if not os.path.isfile(file_path):
                        	fp = open(file_path, 'wb')
                        	fp.write(part.get_payload(decode=True))
                        	fp.close()
                        	print file_name + 'File Downloaded'
                    	else:
                        	print 'File Already Exists'

                # Copying the key to Archive directory after the key is downloaded to local
                archive_key = archive_s3_path + '/' + actual_key
                bucket.copy_key(archive_key, email_s3_bucket, input_key)

                # Deleting the key after it is moved to archive
                bucket.delete_key(input_key)
    except Exception, e:
        print('Error extracting email attachment: "{}"'.format(e))
        if strict:
            raise Exception(traceback.format_exc())
        else:
            pass
