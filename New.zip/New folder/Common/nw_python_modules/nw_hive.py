import datetime
import getpass
import json
import logging
import os
import platform
import pwd
import re

import boto3

from TCLIService.ttypes import TOperationState
from urlparse import urlparse

from nw_generic_utils_modules import parse_nw_dns
from pyhive import hive
if platform.system() != 'Java':
    from pyhive.exc import OperationalError
from s3_modules import ensure_clean_s3

logger = logging.getLogger(__name__)

# only log warnings from pyhive to reduce noise
logging.getLogger('pyhive.hive').setLevel(logging.WARNING)

S3_NERDLAKE_BUCKET_NAME = 'east1-prod-nerdlake-0'

reserved_words = {
    'ALL', 'ALTER', 'AND', 'ARRAY', 'AS', 'AUTHORIZATION', 'BETWEEN', 'BIGINT', 'BINARY', 'BOOLEAN', 'BOTH', 'BY',
    'CACHE', 'CASE', 'CAST', 'CHAR', 'COLUMN', 'COMMIT', 'CONF', 'CONSTRAINT', 'CREATE', 'CROSS', 'CUBE', 'CURRENT',
    'CURRENT_DATE', 'CURRENT_TIMESTAMP', 'CURSOR', 'DATABASE', 'DATE', 'DAYOFWEEK', 'DECIMAL', 'DELETE', 'DESCRIBE',
    'DISTINCT', 'DOUBLE', 'DROP', 'ELSE', 'END', 'EXCHANGE', 'EXISTS', 'EXTENDED', 'EXTERNAL', 'EXTRACT', 'FALSE',
    'FETCH', 'FLOAT', 'FLOOR', 'FOLLOWING', 'FOR', 'FOREIGN', 'FROM', 'FULL', 'FUNCTION', 'GRANT', 'GROUP', 'GROUPING',
    'HAVING', 'IF', 'IMPORT', 'IN', 'INNER', 'INSERT', 'INT', 'INTEGER', 'INTERSECT', 'INTERVAL', 'INTO', 'IS', 'JOIN',
    'LATERAL', 'LEFT', 'LESS', 'LIKE', 'LOCAL', 'MACRO', 'MAP', 'MORE', 'NONE', 'NOT', 'NULL', 'NUMERIC', 'OF', 'ON',
    'ONLY', 'OR', 'ORDER', 'OUT', 'OUTER', 'OVER', 'PARTIALSCAN', 'PARTITION', 'PERCENT', 'PRECEDING', 'PRECISION',
    'PRESERVE', 'PRIMARY', 'PROCEDURE', 'RANGE', 'READS', 'REDUCE', 'REFERENCES', 'REGEXP', 'REVOKE', 'RIGHT', 'RLIKE',
    'ROLLBACK', 'ROLLUP', 'ROW', 'ROWS', 'SELECT', 'SET', 'SMALLINT', 'START', 'TABLE', 'TABLESAMPLE', 'THEN', 'TIME',
    'TIMESTAMP', 'TO', 'TRANSFORM', 'TRIGGER', 'TRUE', 'TRUNCATE', 'UNBOUNDED', 'UNION', 'UNIQUEJOIN', 'UPDATE', 'USER',
    'USING', 'UTC_TMESTAMP', 'VALUES', 'VARCHAR', 'VIEWS', 'WHEN', 'WHERE', 'WINDOW', 'WITH'
}


def get_hive_credentials():
    """
    Retrieve the username and password used to connect to Hive
    :return: Two-element tuple of the username and password
    """
    current_username = pwd.getpwuid(os.getuid()).pw_name
    if current_username == "airflow":
        with open("/etc/dwh_secured_tokens/airflow.json") as fh:
            creds = json.load(fh)
        hive_username = creds["active_directory"]["airflow"]["user"]
        hive_password = creds["active_directory"]["airflow"]["password"]
    else:
        hive_username = current_username
        # TODO: Pull this from a protected user keychain
        hive_password = getpass.getpass("Okta Password: ")

    return hive_username, hive_password


def connect(logger=None):
    """
    Retrieve a connection to Hive. Attempts to determine DNS by parsing .inc if present. This allows us to run this
    module on all servers that have a .inc file and different DNS. If os is "Darwin" we'll assume you're running this
    from your local (Mac OSX).
    :param logger: If specified, messages are sent to this logger which is a logger from the logging module.
    :return: The PyHive.Hive connection
    """

    if os.uname()[0] == 'Linux':
        hive_server = parse_nw_dns('/usr/local/bin/nw-emr.inc')
    elif os.uname()[0] == 'Darwin':
        hive_server = 'hive-nerdlake-etl.nerdwallet.io'
    else:
        raise Exception('Unable to determine Hive DNS')
    if logger:
        logger.info('Connecting to Hive server {}'.format(hive_server))
    hive_username, hive_password = get_hive_credentials()
    return hive.connect(
        hive_server,
        auth='LDAP',
        username=hive_username,
        password=hive_password,
        use_ssl=True,
        ssl_opts={"ca_certs": "/etc/truststore/nerdlake-etl/nerdlake-truststore.pem"}
    )


def exec_hive_sql_ddl(conn, sql, mute=False):
    """
    Executes a non-SELECT statement against Hive. We need to use async=True* to run the query asynchronously
        and polling in order to check the state of the running query. This ensures the query completes before
        continuing.
        This will also emit status logs:
            INFO  : Compiling command(queryId=hive_<query_id>): <query>
            INFO  : Semantic Analysis Completed
            INFO  : Returning Hive schema: Schema(fieldSchemas:null, properties:null)
            INFO  : Completed compiling command(queryId=hive_<query_id>); Time taken: 0.006 seconds
            INFO  : Executing command(queryId=hive_<query_id>): <query>
            INFO  : Starting task [Stage-0:DDL] in serial mode
            INFO  : Completed executing command(queryId=hive_<query_id>); Time taken: 0.633 seconds
            INFO  : OK

    *The need for async can be seen in the PyHive docs: https://github.com/dropbox/PyHive#db-api-asynchronous

    :param conn: A Hive connection object
    :param sql: The SQL statement to execute
    """
    if not mute:
        logger.info(sql)

    curs = conn.cursor()
    curs.execute(sql, async=True)
    status = curs.poll().operationState
    while status in (TOperationState.INITIALIZED_STATE, TOperationState.RUNNING_STATE):
        logs = curs.fetch_logs()
        for message in logs:
            logger.debug(message)

        # If needed, an asynchronous query can be cancelled at any time with:
        # cursor.cancel()

        status = curs.poll().operationState
    curs.close()


def get_hive_table_partitions(conn, fq_table_name):
    """
    Retrieves the list of partitions that exist on the specified table.
    :param conn: A Hive connection object
    :param fq_table_name: The fully qualified Hive table name
    :return: A set containing the partition names that exist for the table.
    """
    if "." not in fq_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_table_name))

    table_schema, table_name = fq_table_name.split(".", 1)
    part_sql = "SHOW PARTITIONS `{}`.`{}`".format(table_schema, table_name)

    hive_curs = conn.cursor()
    hive_curs.execute(part_sql)
    parts = set()
    for partition in hive_curs.fetchall():
        parts.add(partition[0])
    hive_curs.close()
    return parts


def get_hive_table_column_metadata(conn, fq_table_name):
    """
    Retrieves metadata for the columns in the specified table.
    :param conn: A Hive connection object
    :param fq_table_name: The fully qualified Hive table name
    :return: A two-element tuple. The first element is a list of dictionary objects, each column in the table is an
    element in the list. Each dictionary object contains 3 keys: name, type, and comment. The second element of the
    tuple is a list containing the names of the columns that the table is partitioned on.
    """
    if "." not in fq_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_table_name))

    describe_sql = "DESCRIBE `{}`".format(fq_table_name)
    hive_curs = conn.cursor()
    hive_curs.execute(describe_sql)
    tbl_columns = []
    tbl_partitioned_columns = []
    row_type = "COLUMN"
    for col_data in hive_curs.fetchall():
        col_name = col_data[0]
        if col_name == "" or col_name is None:
            continue
        if col_name == "# Partition Information":
            row_type = "PARTITION"
            continue
        if col_name[0] == "#":
            continue
        if row_type == "COLUMN":
            this_col = dict()
            this_col['name'] = col_data[0]
            this_col['type'] = col_data[1]
            this_col['comment'] = col_data[2]
            tbl_columns.append(this_col)
        elif row_type == "PARTITION":
            tbl_partitioned_columns.append(col_name)
    hive_curs.close()
    return tbl_columns, tbl_partitioned_columns


def get_hive_table_location(conn, fq_table_name):
    """
    Get the LOCATION clause of the Hive table.
    :param conn: A Hive connection object
    :param fq_table_name: The fully qualified Hive table name
    :return: A string containing the LOCATION clause on the table
    """
    if "." not in fq_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_table_name))

    show_create_tab_sql = "SHOW CREATE TABLE `{}`".format(fq_table_name)
    hive_curs = conn.cursor()
    hive_curs.execute(show_create_tab_sql)
    describe_data = hive_curs.fetchall()
    hive_curs.close()

    next_row_is_location = False
    for row in describe_data:
        if row[0] == "LOCATION":
            next_row_is_location = True
            continue
        if not next_row_is_location:
            continue
        return row[0].lstrip(" '").rstrip(" '")
    return None


def get_hive_table_type(conn, fq_table_name):
    """
    Get the type ('external' or 'managed') of a Hive table.
    :param conn: A Hive connection object
    :param fq_table_name: The fully qualified Hive table name
    :return: A string containing the type of the table ('external' or 'managed')
    """
    if "." not in fq_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_table_name))

    show_create_tab_sql = "SHOW CREATE TABLE `{}`".format(fq_table_name)
    hive_curs = conn.cursor()
    hive_curs.execute(show_create_tab_sql)
    first_line_describe_data = hive_curs.fetchone()
    hive_curs.close()

    if first_line_describe_data[0].upper().startswith('CREATE EXTERNAL TABLE'):
        return 'external'
    elif first_line_describe_data[0].upper().startswith('CREATE TABLE'):
        return 'managed'
    else:
        raise ValueError("Unable to determine table type of '{}'".format(fq_table_name))


def hive_table_exists(conn, fq_table_name):
    """
    Indicates if the Hive table exists or not
    :param conn: A Hive connection object
    :param fq_table_name: The fully qualified Hive table name
    :return: True or False, indicating if the Hive table exists or not
    """
    if "." not in fq_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_table_name))

    schema_name, table_name = fq_table_name.split(".", 1)
    exists_sql = "SHOW TABLES IN `{}`".format(schema_name)
    hive_curs = conn.cursor()
    hive_curs.execute(exists_sql)
    for row in hive_curs.fetchall():
        if str(row[0]).lower() == table_name.lower():
            hive_curs.close()
            return True
    return False


def drop_delete_table(conn, fq_table_name):
    """
    Drops a hive table and, if the table is a managed table, ensures all data in S3 is deleted as well. When we just
    run a stand alone "drop table" in Hive the underlying S3 files do not actually get deleted. The practice has been
    to first run a "delete from" in presto, and then run the "drop table" in hive. This function allows you to skip
    the "delete from" in presto.

    We don't want to delete S3 files for EXTERNAL tables because we can't guarantee that there are no other people
    or processes that depend on these files.

    :param conn: A Hive connection object
    :param fq_table_name: The fully qualified Hive table name
    :return: True or False, indicating if the Hive table exists or not
    """
    if "." not in fq_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_table_name))

    if fq_table_name.split('.')[0].endswith('_data'):
        raise Exception("Schema detected ending in '_data'. This is not allowed.")

    if not hive_table_exists(conn, fq_table_name):
        logger.warning("Table '{}' does not exist. Skipping".format(fq_table_name))
        return

    fq_table_name_type = get_hive_table_type(conn, fq_table_name)
    s3_location = get_hive_table_location(conn, fq_table_name)

    # First drop the table
    drop_table_sql = 'DROP TABLE IF EXISTS {}'.format(fq_table_name)
    hive_curs = conn.cursor()
    hive_curs.execute(drop_table_sql, async=True)
    hive_curs.close()

    if fq_table_name_type == 'external':
        logger.warning('"external" table detected. Table was dropped, but data not deleted from S3.')
        return

    # Then delete underlying S3 data
    logger.debug('"managed" table detected. Deleting files from S3.')
    parsed = urlparse(s3_location)
    s3_bucket = parsed.netloc
    s3_path = parsed.path
    ensure_clean_s3(s3_bucket, s3_path)

    return

def create_timestamped_table(conn, fq_table_name, s3_bucket_name, columns, timestamp=None, file_format='ORC'):
    """
    Creates a timestamped table i.e., a Hive table whose data is written into an S3 subdirectory using a timestamp.
    For example, a table named dwnl_data.foo_f would be stored in S3 location
    s3://bucket_name/dwnl_data/foo_f/2018.03.02.18.45.52/
    :param conn: Hive connection
    :param fq_table_name: Fully qualified table name
    :param s3_bucket_name: Name of the S3 bucket that the table's data should be stored on
    :param columns: List of dictionaries containing the columns that should be created in the table.
    :param timestamp: Optional timestamp that should be used when creating the timestamp subdirectory
    :param file_format: Optional file format name, defaults to ORC
    :return: The SQL that was used to create the table
    """
    if '.' not in fq_table_name:
        raise ValueError('Table name must be fully qualified; no \'.\' in \'{}\''.format(fq_table_name))
    if timestamp is None:
        timestamp = datetime.datetime.now()
    ddl = list()
    ddl.append('CREATE TABLE `{}` ('.format(fq_table_name.lower()))
    for ctr, column in enumerate(columns):
        col_ddl = '    {}`{}` {}'.format(
            '' if ctr == 0 else ',',
            column['name'],
            column['type']
        )
        if column.get('comment', '').strip() != '':
            col_ddl = '{} COMMENT \'{}\''.format(
                col_ddl,
                column['comment'].rstrip().replace('\'', '\'\'')
            )
        ddl.append(col_ddl)
    ddl.append(')')
    ddl.append('STORED AS {}'.format(file_format))
    ddl.append('LOCATION \'s3://{s3_bucket_name}/{fq_table_name}/{timestamp}/\''.format(
        s3_bucket_name=s3_bucket_name,
        fq_table_name=fq_table_name.lower().replace('.', '/'),
        timestamp=timestamp.strftime('%Y.%m.%d.%H.%M.%S')
    ))
    exec_hive_sql_ddl(conn, '\n'.join(ddl))
    return '\n'.join(ddl)


def create_timestamped_staging_table(conn, prod_fq_table_name, stage_fq_table_name):
    """
    Given a timestamped Hive table name, create a staging copy of the table that uses a new timestamped subdirectory.
    The new staging table will be created under the same S3 location as the production table so that the production
    table can be re-pointed to the new subdirectory when it has been populated.
    :param conn: A Hive connection
    :param prod_fq_table_name: Fully qualified Hive table name that is a timestamped table
    :param stage_fq_table_name: Fully qualified Hive table name for the new staging table
    :return:
    """
    prod_location = get_hive_table_location(conn, prod_fq_table_name)
    regex = re.compile(r'^(s3://[^/]+/[^/]+/[^/]+)/(\d\d\d\d\.\d\d\.\d\d\.\d\d\.\d\d\.\d\d)$', re.IGNORECASE)
    match = regex.match(prod_location)
    if not match:
        raise ValueError('{} location doesn\'t look like a standard timestamped table: {}'.format(
            prod_fq_table_name,
            prod_location))
    base_location = match.group(1)
    prod_location_timestamp = match.group(2)

    if hive_table_exists(conn, stage_fq_table_name):
        # TODO: Before dropping make sure the staging table has an expected location
        ddl = 'DROP TABLE `{}`'.format(stage_fq_table_name)
        logger.debug(ddl)
        exec_hive_sql_ddl(conn, ddl)

    staging_datetime = datetime.datetime.now()
    if staging_datetime.strftime('%Y.%m.%d.%H.%M.%S') == prod_location_timestamp:
        staging_datetime = staging_datetime + datetime.timedelta(seconds=1)
    stage_location = '{}/{}/'.format(
        base_location,
        staging_datetime.strftime('%Y.%m.%d.%H.%M.%S')
    )
    ddl = list()
    ddl.append('CREATE TABLE `{}`'.format(stage_fq_table_name))
    ddl.append('LIKE `{}`'.format(prod_fq_table_name))
    ddl.append('STORED AS ORC')
    ddl.append('LOCATION \'{}\''.format(stage_location))
    logger.debug('\n'.join(ddl))
    exec_hive_sql_ddl(conn, '\n'.join(ddl))


def replace_timestamped_table_with_new(conn, prod_fq_table_name, stage_fq_table_name):
    """
    Given a production timestamped table and a staging timestamped table, the production table will have its location
    updated to point to the staging table and then the staging table will be dropped.
    :param conn: Hive connection
    :param prod_fq_table_name: Production table name
    :param stage_fq_table_name: Staging table name
    :return:
    """
    stage_location = get_hive_table_location(conn, stage_fq_table_name)
    notexist_location = '{}/notexist'.format(os.path.dirname(stage_location))
    sqls = [
        'ALTER TABLE {} SET LOCATION \'{}\''.format(prod_fq_table_name, stage_location),
        'ALTER TABLE {} SET LOCATION \'{}\''.format(stage_fq_table_name, notexist_location),
        'DROP TABLE {}'.format(stage_fq_table_name)
        ]
    for sql in sqls:
        logger.debug(sql)
        exec_hive_sql_ddl(conn, sql)


def delete_old_timestamped_s3_directories(conn, fq_table_name, keep_latest_n=3):
    table_location = get_hive_table_location(conn, fq_table_name)
    regex = re.compile(r'^s3://([^/]+)/([^/]+/[^/]+/)\d\d\d\d\.\d\d\.\d\d\.\d\d\.\d\d\.\d\d$')
    match = regex.match(table_location)
    if not match:
        raise ValueError('Location of {} doesn\'t look like a timestamped directory: {}'.format(
            fq_table_name, table_location
        ))
    s3_bucket_name = match.group(1)
    s3_prefix = match.group(2)  # Includes the trailing slash

    # Get all subdirectories under our base location
    subdirectory_names = set()
    s3 = boto3.client('s3')
    list_kwargs = {
        'Bucket': s3_bucket_name,
        'Prefix': s3_prefix
    }
    while True:
        s3_subdirectories = s3.list_objects_v2(**list_kwargs)

        for key in s3_subdirectories['Contents']:
            subkey_name = key['Key'][len(s3_prefix):]
            if '/' not in subkey_name:
                continue
            subdir_name = subkey_name[0:subkey_name.index('/')]
            subdirectory_names.add(os.path.join(s3_prefix, subdir_name))
        list_kwargs['NextContinuationToken'] = s3_subdirectories.get('NextContinuationToken', None)
        if not list_kwargs['NextContinuationToken']:
            break

    # Remove the production location from the set -- we don't want to delete this, ever
    try:
        subdirectory_names.remove(table_location[len(s3_bucket_name) + 6:])
    except KeyError:
        raise ValueError('Couldn\'t find production table location {} in list of subdirectories: {}'.format(
            table_location[len(s3_bucket_name) + 6:],
            subdirectory_names
        ))

    for ctr, subdirectory_name in enumerate(sorted(subdirectory_names, key=lambda s: s.lower(), reverse=True)):
        if ctr < keep_latest_n:
            continue
        if logger:
            logger.debug('Finding keys to delete: {}*'.format(subdirectory_name))
        keys_to_delete = s3.list_objects_v2(
            Bucket=s3_bucket_name,
            Prefix=subdirectory_name
        )
        delete_param = [{'Key': a['Key']} for a in keys_to_delete['Contents']]
        if logger:
            logger.debug('Deleting keys: {}'.format(delete_param))
        s3.delete_objects(
            Bucket=s3_bucket_name,
            Delete={'Objects': delete_param}
        )


def add_missing_columns(conn, table_name, source_columns):
    """
    Adds missing columns to a Hive table
    :param conn: Hive connection
    :param table_name: Hive table name
    :param source_columns: List of columns. Each column should be stored as a dictionary with keys 'name', 'type', and
    optionally 'comment'.
    :return:
    """
    logger.debug('Looking for missing columns in {}'.format(table_name))
    table_columns, table_partitions = get_hive_table_column_metadata(conn, table_name)
    table_column_names = set([col['name'] for col in table_columns])
    columns_to_add = list()
    for source_column in source_columns:
        if source_column['name'] in table_column_names:
            logger.debug('    \'{}\': column already exists'.format(source_column['name']))
            continue
        logger.debug('    \'{}\': add to table'.format(source_column['name']))
        columns_to_add.append(source_column)
    if len(columns_to_add) < 1:
        return
    ddl = list()
    ddl.append('ALTER TABLE `{}` ADD COLUMNS ('.format(table_name))
    for ctr, column in enumerate(columns_to_add):
        ddl.append('    {}`{}` {}'.format(
            '' if ctr == 0 else ',',
            column['name'],
            column['type']
        ))
    ddl.append(')')
    logger.debug('\n'.join(ddl))
    exec_hive_sql_ddl(conn, '\n'.join(ddl))


def drop_partition(conn, fq_table_name, partition_nm, partition_val):
    """
    Drops partition from hive table. Note: If managed table will delete files as well.
    :param conn: A Hive connection object
    :param fq_table_name: The fully qualified Hive table name
    :param partition_nm: The partition name
    :param partition_val: The partition value
    :return: True indicating whether the partition was dropped successfully
    """
    if "." not in fq_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_table_name))

    drop_partition_sql = "ALTER TABLE {} DROP PARTITION ({} = {})".format(fq_table_name, partition_nm, partition_val)
    try:
        exec_hive_sql_ddl(conn, drop_partition_sql)
        logger.info('{}={} dropped from {}'.format(partition_nm, partition_val, fq_table_name))
        return True
    except OperationalError as o:
        logger.error(drop_partition_sql)
        raise o


def exchange_partition(conn, fq_src_table_nm, fq_tgt_table_nm, partition_nm, partition_val, delete_partition=False):
    """
    :param conn: A Hive connection object
    :param fq_src_table_nm: The fully qualified source Hive table name
    :param fq_tgt_table_nm: The fully qualified target Hive table name
    :param partition_nm: The partition name
    :param partition_val: The partition value
    :param delete_partition: Indicator to delete partition from target table before exchanging
    :return: True indicating whether the partition was moved successfully
    """
    if "." not in fq_src_table_nm:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_src_table_nm))
    if "." not in fq_tgt_table_nm:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_tgt_table_nm))

    exchange_sql = """
    ALTER TABLE {}
    EXCHANGE PARTITION ({} = {})
    WITH TABLE {}
    """.format(fq_tgt_table_nm, partition_nm, partition_val, fq_src_table_nm)

    if delete_partition:
        drop_partition(conn, fq_tgt_table_nm, partition_nm, partition_val)

    try:
        exec_hive_sql_ddl(conn, exchange_sql)
        logger.info('{}={} Moved from {} to {}'.format(partition_nm, partition_val, fq_src_table_nm, fq_tgt_table_nm))
        return True
    except OperationalError as o:
        logger.error(exchange_sql)
        raise o


def exchange_all_partitions(conn, fq_src_table_nm, fq_tgt_table_nm, delete_partition=False):
    """
    :param conn: A Hive connection object
    :param fq_src_table_nm: The fully qualified source Hive table name
    :param fq_tgt_table_nm: The fully qualified target Hive table name
    :param delete_partition: Indicator to delete partition before exchanging
    :return:  True indicating whether ALL partition were dropped successfully
    """
    if "." not in fq_src_table_nm:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_src_table_nm))
    if "." not in fq_tgt_table_nm:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_tgt_table_nm))

    src_table_partitions = get_hive_table_partitions(conn, fq_src_table_nm)
    if len(src_table_partitions) == 0:
        print "No partitions in {} to move to {}".format(fq_src_table_nm, fq_tgt_table_nm)
        return
    if any(i.count('=') == 2 for i in src_table_partitions):
        raise ValueError("Sub partitions detected in {}. Do not support tables with subpartitions".format(fq_src_table_nm))

    # TODO for strings I need to add quotes, how can differences between string and non-string be handled?
    partitions = [i.split('=') for i in src_table_partitions]
    for partition in partitions:
        partition_field_nm = partition[0]
        partition_field_val = '\'' + partition[1] + '\''
        exchange_partition(
            conn=conn,
            fq_src_table_nm=fq_src_table_nm,
            fq_tgt_table_nm=fq_tgt_table_nm,
            partition_nm=partition_field_nm,
            partition_val=partition_field_val,
            delete_partition=delete_partition
        )
    return True


def drop_table(conn, fq_table_nm):
    """
    Drops a specified hive table.
    :param conn: Hive connection.
    :param fq_table_nm: The fully qualified table name.
    """
    if "." not in fq_table_nm:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_table_nm))

    schema = fq_table_nm.split('.')[0]
    if "stage" not in schema and "workarea" not in schema:
        raise ValueError("Can only drop tables in stage or workarea schemas. '{}' not in either schema".format(schema))

    drop_table_sql = "DROP TABLE IF EXISTS {}".format(fq_table_nm)

    exec_hive_sql_ddl(conn, drop_table_sql)


def create_table_like(conn, fq_tgt_table_nm, fq_src_table_nm, stored_as_type, location_path):
    """
    Create a table like another hive table.
    :param conn: Hive connection.
    :param fq_tgt_table_nm: Fully qualified name of table to be created.
    :param fq_src_table_nm: Fully qualified name of table ddl being replicated.
    :param stored_as_type: Format you would like to save table files as.
    :param location_path: Location you would like to store table files.
    """
    if "." not in fq_tgt_table_nm:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_tgt_table_nm))
    if "." not in fq_src_table_nm:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_src_table_nm))

    create_table_sql = "CREATE TABLE {} LIKE {}\n".format(fq_tgt_table_nm, fq_src_table_nm)
    create_table_sql += "STORED AS {}\n".format(stored_as_type)
    create_table_sql += "LOCATION {}".format(location_path)

    exec_hive_sql_ddl(conn, create_table_sql)


def alter_table_location(conn, fq_tgt_table_name, location_path):
    """
    Alter a tables location
    :param conn: Hive connection.
    :param fq_tgt_table_name: Fully qualified name of table to be created.
    :param location_path: Location you would like to store table files.
    """
    if "." not in fq_tgt_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_tgt_table_name))

    sql = 'ALTER TABLE {}\n'.format(fq_tgt_table_name)
    sql += 'SET LOCATION {}'.format(location_path)
    exec_hive_sql_ddl(conn, sql)


def msck_repair_table(conn, fq_tgt_table_name):
    """
    Run MSCK repair on target table.
    :param conn: Hive connection.
    :param fq_tgt_table_name: Fully qualified name of table to be repair
    :return:
    """
    if "." not in fq_tgt_table_name:
        raise ValueError("Table name '{}' does not contain a schema name".format(fq_tgt_table_name))

    repair_table_sql = 'MSCK REPAIR TABLE {}'.format(fq_tgt_table_name)

    exec_hive_sql_ddl(conn, repair_table_sql)
