import json


"""
This is a utility file for converting json objects to other data structures. 

This supports json strings which contain values which are dictionaries and sub lists. 

Please contact abhinavasingh16@gmail.com if you have any questions.
"""

class Stack:
    "A container with a last-in-first-out (LIFO) queuing policy."
    def __init__(self):
        self.list = []

    def push(self,item):
        "Push 'item' onto the stack"
        self.list.append(item)

    def pop(self):
        "Pop the most recently pushed item from the stack"
        return self.list.pop()

    def isEmpty(self):
        "Returns true if the stack is empty"
        return len(self.list) == 0

def key_search_helper(json_obj,traversed_keys,flat_keys,all_keys,dictionary_keys,relationships):
	'''
	This is a recursive helper function which uses dfs to traverse a json file and convert it to my
	custom data structure.

	The relationshipp datastructure is {parent:child_keys} examples are below

	So {a:3, b:{c:2,d:{e:3}}}
	relationships = {a:[],b:[c,d],c:[],d:[e],e:[]}

	{a:3, b:{h:[{c:3},{d:4,e:{g:5}}]}}
	relationships = {a:[],b:[h],h:[c,d,e],c:[],d:[],e:[g],g:[]}

	{a:3,b:[{c:3},{d:4,e:{f:4,g:5}}]}
	relationships = {a:[],b:[c,d],c:[],d:[],e:[f,g],f:[],g:[]}

	'''
	working_json = json_obj
	while not traversed_keys.isEmpty():
		entry = traversed_keys.pop()
		#parent Key
		dict_key = entry[0]
		working_json = entry[1]
		#get child keys
		for key in working_json.keys():
			relationships[dict_key].add(key)
			#Handles an embedded dictionary
			if type(working_json[key]) == type({}):
				traversed_keys.push((key,working_json[key]))
				dictionary_keys.append(key)
			#Handles a list of dictionaries
			if type(working_json[key]) == type([]) and len(working_json[key])>=1 and type(working_json[key][0]) == type({}):
				dictionary_keys.append(key)
				for elem in working_json[key]:
					dk,fk,ak,rl = get_all_keys(elem)
					dictionary_keys+=dk
					flat_keys+=fk
					all_keys+=ak
					for rl_key in rl.keys():
						relationships[rl_key] = rl[rl_key]
						if key not in relationships:
							relationships[key] = set(rl_key)
						else:
							relationships[key].add(rl_key)
			#This is a flat key
			else:
				flat_keys.append(key)
				relationships[key] = set()
			all_keys.append(key)
	return dictionary_keys,flat_keys,all_keys,relationships

def get_all_keys(json_obj):
	'''
	This function gets depth first search started 
	so that we can traverse the json object and get all unique keys 

	we input a json object, then we output the following four structures:

	Flat_keys: This is a list of all keys whose values have no children 
	that are lists or dictionaries.

	All_keys: This is a list of all keys. 

	Dictionary Keys: This is a list of keys whose values are dictionaries.

	relationships: This stores parent child relationships between parents and children keys. 
	The struct is described in key_search_helper. 

	top_level_keys: This is a structure described below which maps every level to the keys on that level.

	We are introducing a new data structure to store the keys and their corresponding levels.
	a = {a:3,b:4,c:{d:5,e:[{f:4},{g:2,h:{i:2}}]}}
	levels = {0:[a,b,c],1:[d,e],2:[f,g,h],3:[i]}
	'''
	traversed_keys = Stack()
	flat_keys = []
	all_keys = []
	dictionary_keys = []
	relationships = {}
	top_level_keys = []
	for key in json_obj.keys():
		top_level_keys.append(key)
		relationships[key] = set()
		if type(json_obj[key]) == type({}):
			traversed_keys.push((key,json_obj[key]))
			dictionary_keys.append(key)
		if type(json_obj[key]) == type([]) and len(json_obj[key])>=1 and type(json_obj[key][0]) == type({}):
				#Handling a list of dictionaries
				dictionary_keys.append(key)
				for elem in json_obj[key]:
					dk,fk,ak,rl = get_all_keys(elem)
					dictionary_keys+=dk
					flat_keys+=fk
					all_keys+=ak
					for rl_key in rl.keys():
						relationships[rl_key] = rl[rl_key]
						if key not in relationships:
							relationships[key] = set(rl_key)
						else:
							relationships[key].add(rl_key)
		else:
			flat_keys.append(key)
		all_keys.append(key)
	return key_search_helper(json_obj,traversed_keys,flat_keys,all_keys,dictionary_keys,relationships)

def subString_in_array(string,array):
	'''
	Finds a substring in an array of strings.
	'''
	for elem in array:
		if string in elem:
			return True
	return False

def flatten_to_df(json_obj,old_df=None):
	'''
	This function flattens a json object to a pandas dataframe. 
	'''
	dict_keys,flat_keys,all_keys,relationships = get_all_keys(json_obj)
	generate_col_names = get_col_names(relationships)

def col_names_helper(json_obj,names,keys):
	'''
	a = {a:3,b:4,c:{d:5,e:[{f:4},{g:2,h:{i:2}}]}}
	names = [a,b,c,c_d,c_e,c_d_f,c_d_g,c_d_h,]
	'''
	print(keys.isEmpty())
	while not keys.isEmpty():
		entry = keys.pop()
		key = entry[0]
		value = entry[1]
		for c_key in value.keys():
			name = "{0}_{1}".format(key,c_key)
			names.append(name)
			if type(value[c_key]) == type({}):
				keys.push((name,value[c_key]))
			if type(value[c_key]) == type([]) and len(value[c_key])>=1 and type(value[c_key][0]) == type({}):
				for elem in value[c_key]:
					keys.push((name,elem))
	return names

def get_col_names(json_obj):
	'''
	This is the main function that takes the relationships 
	datastructure and generates a flattened list of all the 
	columns in a table. 
	'''
	names = []
	keys = Stack()
	for key in json_obj:
		names.append(key)
		if type(json_obj[key]) == type({}):
			keys.push((str(key),json_obj[key]))
		if type(json_obj[key]) == type([]) and len(json_obj[key])>=1 and type(json_obj[key][0])==type({}):
			for elem in json_obj[key]:
				keys.push((str(key),elem))
	return set(col_names_helper(json_obj,names,keys))

def order_by_level(name_set):
	'''
	This function orders names by level given a name_set. 
	'''
	leveled_names = {}
	for name in name_set:
		level = len(name.split("_"))
		if level not in leveled_names:
			leveled_names[level] = [name]
		else:
			leveled_names[level].append(name)
	return leveled_names

# def flatten_json(json_obj):
# 	names = get_col_names(json_obj)
# 	foreign_keys,flat_keys,all_keys,rels = get_all_keys(josn_obj)
# 	level_names_struct = order_by_level(names)
# 	dataframe_collection = []
# 	for level in level_names_struct:
# 		level_names = level_names_struct[level]
# 		for name in level_names:
# 			attrs = []
# 			if name not in foreign_keys
# 				attrs.append(name)

if __name__ == "__main__":
	sanity_case = {"a":1, "b":2}
	complex_case = {"glossary": {"title": "example glossary", "GlossDiv": { "title": "S", "GlossList": {"GlossEntry": {"ID": "SGML","SortAs": "SGML","GlossTerm": "Standard Generalized Markup Language","Acronym": "SGML","Abbrev": "ISO 8879:1986","GlossDef": {"para": "A meta-markup language, used to create markup languages such as DocBook.","GlossSeeAlso": ["GML", "XML"]},"GlossSee": "markup"}}}}}
	#zendesk_obj = json.loads(zendesk_case)
	list_case = {
		"id": "0001",
		"type": "donut",
		"name": "Cake",
		"ppu": 0.55,
		"batters":
			{
				"batter":
					[
						{ "id": "1001", "type": "Regular" },
						{ "id": "1002", "type": "Chocolate" },
						{ "id": "1003", "type": "Blueberry" },
						{ "id": "1004", "type": "Devil's Food" }
					]
			},
		"topping":
			[
				{ "id": "5001", "type": "None" },
				{ "id": "5002", "type": "Glazed" },
				{ "id": "5005", "type": "Sugar" },
				{ "id": "5007", "type": "Powdered Sugar" },
				{ "id": "5006", "type": "Chocolate with Sprinkles" },
				{ "id": "5003", "type": "Chocolate" },
				{ "id": "5004", "type": "Maple" }
			]
	}
	'''
	id,type,name,ppu,battersFK,toppingFK

	battersFK,batters_batterFK

	batters_batterFK,batters_batter_id,batters_batter_type

	toppingFK,topping_id,topping_type
	'''
	#final_json = json.loads(final_case)
	dict_keys,flat_keys,all_keys,rels = get_all_keys(list_case)
	#print("dict keys are: {0}".format(dict_keys))
	#print("flat keys are: {0}".format(flat_keys))
	#print("all keys are: {0}".format(all_keys))
	#zendesk_file = open("zendesk.txt","w+")
	#zendesk_file.write(str(rels))
	print(rels)
	names = get_col_names(list_case)
	print("")
	print(names)
	print(order_by_level(names))
	print(dict_keys)


def json_convert_for_redshift(f_in, f_out):
    """ Function to help convert the file with mutiple Json objects \
    in python readable format to Redshift readable format.
    This function's output is readable by Redshift copy command 
    Call method json_convert_for_redshift(f_in ='local_file_in', f_out='local_file_out')"""

    with open(f_in,'rb') as f_read:
        with open(f_out,'w') as f_write:
            json_rows = json.load(f_read)
            for row in json_rows:
                json.dump(row,f_write)
                f_write.write('\n')

def is_json_dict(myjson):
    """
    test if myjson is a json dict - yes: True, no: False
    """
    #try:
    #    json_object = json.loads(myjson)
    #except ValueError, e:
    #    return False
    #return True
    if str(myjson).strip('\n').strip('\r').startswith('{') and str(myjson).strip('\n').strip('\r').endswith('}'):
        return True
    else:
        return False

