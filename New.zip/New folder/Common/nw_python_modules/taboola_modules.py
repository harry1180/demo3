import time
import requests

DEFAULT_RESPONSE_TYPE = 'code'
DEFAULT_GRANT_TYPE = 'authorization_code'
API_CALL_TYPES = ['get', 'post']
MAX_API_TRIES = 10
API_TIMEOUT = 30


def api_retry(func):
    """Decorator for API calls"""
    def retried_func(*args, **kwargs):
        tries = 0
        while True:
            resp = func(*args, **kwargs)
            if not resp.ok and tries < MAX_API_TRIES:
                tries += 1
                time.sleep(API_TIMEOUT)
                continue
            break
        return resp
    return retried_func


@api_retry
def mk_api_call(url, params, headers, call_type='get'):
    """Make API call and return requests object

    Call_type value must be from API_CALL_TYPES
    """
    # Check call type
    if call_type not in API_CALL_TYPES:
        raise ValueError('Provide right value for call_type: {}'.format(str(API_CALL_TYPES)))

    # Make a API requests
    if call_type == 'get':
        return requests.get(url, params=params, headers=headers, timeout=5*60)
    elif call_type == 'post':
        return requests.post(url, params=params, headers=headers, timeout=5*60)


def get_resp_items(respond):
    """Get repond and return iterator of dict"""
    # Return itarator of dict
    jresp = respond.json()
    if 'results' not in jresp:
        raise ValueError('Taboola API respond:  {}'.format(str(jresp)))
    items = jresp['results']
    for item in items:
        if 'timezone' in jresp:
            item['timezone'] = jresp['timezone']

        yield item
