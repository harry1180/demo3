'''Consolidate shared modules from these files: dict_utils.py, modules.py, util.py and s3_modules.py.'''

import boto
import glob
import gzip
import math
import mimetypes
import os
import pwd
import ssl
import StringIO
import time

from boto.s3.connection import Bucket, S3Connection
from boto.s3.key import Key
from datetime import date, datetime, timedelta
from filechunkio import FileChunkIO
from functools import partial

from file_and_path_utils import FileUtils

import platform
if platform.system() != 'Java':
    from multiprocessing import Pool


AWS_PROFILE = None
if pwd.getpwuid(os.getuid()).pw_name != 'airflow':
    AWS_PROFILE = 'nwprod'


def s3_file_download(s3_bucket, s3_path, key, download_path, to_file=True, retry=0, aws_profile=AWS_PROFILE):
    """
    Downloads the S3 object.
    If to_file is True (default: true), downloads the S3 object to the local fs and return the
    path to the file.
    @param s3_bucket     - The S3 bucket
    @param s3_bucket     - The S3 path for specific event data
    @param key           - The key file to download
    @param download_path - The local path will save s3 file
    call examples:
    1) to get data in string object 
    s3_file_download('east1-prod-dwh-s3-0', '', 'manual_loads/DC_KW_SEMRush_Project.csv', \
    'something', to_file=False)
    2) to get data written in a local file
    local_file_nm = s3_file_download('east1-prod-dwh-s3-0', '', 'manual_loads/DC_KW_SEMRush_Project.csv', \
    '/Users/vaibhavjajoo', to_file=True)
    """

    conn = S3Connection(profile_name=aws_profile)
    bucket = conn.get_bucket(s3_bucket)

    key_objects = bucket.list(prefix=str(key))
    for key_object in key_objects:
        key_obj = key_object
    # generate an object for content downloading
    key_object = key_obj

    # You probably shouldn't do this, as it might fill up memory and cause issues
    if not to_file:
        return key_object.get_contents_as_string()

    # Extract the s3 path as a subdirectory and create it in the local directory
    # key_object.key=CCImpressionEvent/2015/09/11/01.protobuf
    s3_sub_path, filename = os.path.split(key_object.key)
    # s3_sub_path=CCImpressionEvent/2015/09/11 filename=01.protobuf

    s3_sub_path_without_s3_path = FileUtils.replace_path(s3_sub_path, s3_path)
    # s3_sub_path_without_s3_path=2015/09/11

    full_path = os.path.join(download_path, s3_sub_path_without_s3_path)
    FileUtils.create_path(full_path)

    # Fetch the object to file, then yield the file name
    file_path = os.path.join(full_path, filename)
    try:
        key_object.get_contents_to_filename(file_path)
    except ssl.SSLError:
        retry += 1
        if retry < 5:
            time.sleep(5)
            s3_file_download(s3_bucket, s3_path, key, download_path, to_file=True, retry=retry)
        else:
            raise TimeoutError 
    # Return the path to the file in the local directory
    return file_path


def s3_file_upload(local_file, s3_bucket, s3_path, s3_file_nm='default', aws_profile=AWS_PROFILE):
    """ Use this function to upload data files to S3. Function will use chunked upload, 
    if the local file size > 50 MB.
    s3_file_upload(local_file, s3_bucket, s3_path, s3_file_nm='default')
    """
    if s3_file_nm == 'default':
        s3_file_nm = os.path.basename(local_file)
    
    source_size = os.stat(local_file).st_size
    chunk_size = 52428800
    
    if source_size > chunk_size:
        print "File size larger than 50 Mb. Iniating chunk upload"
        s3_file_upload_chunk(local_file, s3_bucket, s3_path, s3_file_nm, chunk_size, aws_profile)
        return

    # Set the MIME type which might allow for the file to be opened inside a web browser from the AWS console
    headers = dict()
    mime_type = mimetypes.guess_type(s3_file_nm)[0]
    if mime_type:
        headers['ContentType'] = mime_type
    elif s3_file_nm.lower().endswith('.jsonpaths'):
        headers['ContentType'] = 'application/json'

    conn = S3Connection(profile_name=aws_profile)
    bucket = conn.get_bucket(s3_bucket)
    key_name = s3_file_nm
    full_key_name = os.path.join(s3_path, key_name)
    k = bucket.new_key(full_key_name)
    k.set_contents_from_filename(local_file, headers=headers)
    

def s3_file_upload_chunk(local_file,s3_bucket,s3_path, s3_file_nm='default', chunk_size=52428800, aws_profile=AWS_PROFILE):
    """ Use this fucntion to upload large data files to S3. 
    Preferable greater than 50 MB
    Call method s3_file_upload_chunk(local_file,s3_bucket,s3_path, s3_file_nm='default',chunk_size = 52428800)
    """

    conn = S3Connection(profile_name=aws_profile)
    b = conn.get_bucket(s3_bucket)
    source_size = os.stat(local_file).st_size
    # if file size is smaller than the chunk size, call no chunk upload instead
    if source_size < chunk_size:
        print "File size smaller than the chunk size. Iniating simple upload"
        s3_file_upload(local_file, s3_bucket, s3_path, s3_file_nm)
        return
    
    if s3_file_nm =='default':
        s3_file_nm = os.path.basename(local_file)
        
    mp = b.initiate_multipart_upload(str('/'+s3_path+'/')+s3_file_nm)
    chunk_count = int(math.ceil(source_size / float(chunk_size)))

    for i in range(chunk_count):
        offset = chunk_size * i
        bytes = min(chunk_size, source_size - offset)
        with FileChunkIO(local_file, 'r', offset=offset, bytes=bytes) as fp:
            mp.upload_part_from_file(fp, part_num=i + 1)

    mp.complete_upload()
    ## cleanup the local file
    ##os.remove(local_file_nm)


def s3_parallel_upload(local_files, s3_path, s3_bucket, file_ext=None, num_processes=10):
    """
    Multiprocess upload of local files to S3. Pass in either a list of files or directory. With directory this
     only moves files that are one level deep.
    :param s3_bucket: string, destination bucket
    :param s3_path: string, destination path (directory)
    :param local_files: list, full filepaths OR string, directory path
    :param file_ext: str, extension of files to move from directory

    For more info on how to gracefully kill processes during ctrl+c:
        http://bryceboe.com/2010/08/26/python-multiprocessing-and-keyboardinterrupt/#comment-1221206841
    """

    if isinstance(local_files, list):
        input_list = local_files
    elif os.path.isdir(local_files):
        if file_ext:
            input_list = [os.path.join(local_files, f) for f in os.listdir(local_files) if f.endswith(file_ext)]
        else:
            input_list = [os.path.join(local_files, f) for f in os.listdir(local_files)]
        print('Moving {} files from {} to s3://{}'.format(str(len(input_list)), local_files, os.path.join(s3_bucket, s3_path)))
    else:
        print('No files found to move to S3')
        return

    pool = Pool(processes=num_processes)
    func = partial(s3_single_file_upload, s3_bucket, s3_path)
    try:
        # get() is used as a workaround to allow the KeyboardInterrupt exception to be delivered properly
        # after 24 hours of waiting this function will throw a TimeoutError
        pool.map_async(func, input_list).get(60*60*24)
    except KeyboardInterrupt:
        print("Caught KeyboardInterrupt, terminating workers")
        pool.terminate()
    else:
        pool.close()
    pool.join()


def s3_single_file_upload(s3_bucket, s3_path, local_file):
    """ Use this function to upload data files to S3. Function will use chunked upload,
    if the local file size > 50 MB. This is basically the same function as s3_file_upload() but
    the parameter order is changed to accommodate multiprocessing with s3_parallel_upload().
    """
    s3_file_nm = os.path.basename(local_file)

    source_size = os.stat(local_file).st_size
    chunk_size = 52428800

    if source_size > chunk_size:
        print "File size larger than 50 Mb. Iniating chunk upload"
        s3_file_upload_chunk(local_file, s3_bucket, s3_path, s3_file_nm, chunk_size)
        return

    conn = S3Connection()
    bucket = conn.get_bucket(s3_bucket)
    key_name = s3_file_nm
    full_key_name = os.path.join(s3_path, key_name)
    k = bucket.new_key(full_key_name)
    k.set_contents_from_filename(local_file)


def check_if_key_exist(bucket_nm, keyin, aws_profile=AWS_PROFILE):
    """ call method: check_if_key_exist(out_bucket, out_key_nm)
    User this method to find out if a certain key already exists in the give bucket
    """ 
    conn = boto.connect_s3(profile_name=aws_profile)
    b=conn.get_bucket(bucket_nm)
    k_in=Key(b)
    k_in.key=keyin
    return k_in.exists()


def get_new_s3_files(env, bucket_nm, changed_since, event_name):
    """ call method get_new_s3_files(env, bucket_nm, changed_since, filewildcard)
    Use this function to get list of s3 file keys that:
    - are in env (values = prod, dev')
    - given bucket
    - changed since a particular day 
    - having the said wildcard
    """
    #conn = boto.connect_s3(profile_name=env)
    conn = boto.connect_s3()
    if bucket_nm in [bucket.name for bucket in conn.get_all_buckets()]:
        bucket = conn.get_bucket(bucket_nm)
        key_list=[]
        for item in bucket.list():
            modified_ts = datetime.strptime(item.last_modified, '%Y-%m-%dT%H:%M:%S.%fZ')
        #### if on the name of the event to filter for the event
            if modified_ts > changed_since:
                if event_name in item.key:
                    #print item.key
                    key_list.append(item.key)
        return key_list
    else:
        raise UserWarning('Incorrect Bucket Name %s', bucket_nm )


def date_range(start_date, end_date):
    """
    Returns all dates from 'start_date' to, but not including, 'end_date'.

    :param start_date: start of range
    :param end_date: end of range, non-inclusive
    :return: A Set containing all dates in the specified range, not including the end date
    """
    dates = set()
    for n in range(int((end_date - start_date).days)):
        dates.add(start_date + timedelta(n))
    return dates


def _get_protobuf_s3_files_in_range(bucket_nm, from_dt, to_dt, event_name, ignore_empty=False):
    """
    This function searches the ProtoBuf keys on S3 starting 30 days before the 'from_dt'
    value up to, but not including, the 'to_dt' value. It returns a list of keys (file names)
    that were modified on or after from_dt and before the to_dt value.

    :param bucket_nm: S3 bucket name
    :param from_dt: Starting date to return file names for
    :param to_dt: Ending date (non-inclusive) to return file names for
    :param event_name: Name of the event to find file names for
    :return: Set containing keys (file names) that fall in the specified range
    """

    if not isinstance(from_dt, date):
        raise ValueError("from_dt isn't a datetime.date object")
    if not isinstance(to_dt, date):
        raise ValueError("to_dt isn't a datetime.date object")

    conn = S3Connection()
    bucket = conn.get_bucket(bucket_nm)
    keys_in_range = set()
    for search_date in date_range(from_dt + timedelta(days=-30), to_dt):
        s3_key_prefix = "{}/{}/{:02d}/{:02d}/".format(
            event_name.rstrip("/"),
            search_date.year,
            search_date.month,
            search_date.day
        )
        for item in bucket.list(prefix=s3_key_prefix):
            key_modified_dt = datetime.strptime(item.last_modified, '%Y-%m-%dT%H:%M:%S.%fZ').date()
            if from_dt <= key_modified_dt < to_dt:
                if item.size == 0 and ignore_empty:
                    continue
                keys_in_range.add(item.key)

    return keys_in_range


def get_s3_files_in_range(env, bucket_nm, from_dt, to_dt, file_prefix, scan_type='modified', aws_profile=AWS_PROFILE, ignore_empty=False, strip_prefix_slashes=True):
    """
    Returns a list of S3 keys that fall within the specified date range. Parameter 'scan_type' defines the logic that's
    used to determine how the date range is used to identify the keys.
    - modified: All keys under the specified prefix are examined. Keys that have a modification timestamp within the
          date range are returned.
    - protobuf: All keys starting from 30 days before the specified date range up to, but not including, the end date
          are examined. From this set, keys that have a modification timestamp within the date range are returned.
    - hive: The specified prefix is suffixed with "/dw_eff_dt=YYYY-MM-DD" for each day within the specified date range.
          All keys that have these prefixes are returned.
    - other: The specified prefix is suffixed with "/YYYY/MM/DD" for each day within the specified date range. All keys
          that have these prefixes are returned. Similar to the Protobuf handling, but without a check on the
          modification timestamp of the key.

    :param env: This parameter is unused.
    :param bucket_nm: Name of the S3 bucket that should be searched, e.g. east1-prod-dwh-s3-0
    :param from_dt: Start of the date range that should be searched for
    :param to_dt: End of the date range that should be searched for, non-inclusive
    :param file_prefix: S3 key prefix that should be used when searching for S3 keys
    :param scan_type: Code defining how the files should be searched
    :param aws_profile: optional profile name to pass in to reference aws keys. this is REQUIRED when running
                        using keys generated by `awslogin` command (use "nwprod")
    :param ignore_empty: optional boolean value tgo skip 0 byte (empty) files
    :return: A List of S3 keys that match the specified date range.
    """

    conn = S3Connection(profile_name=aws_profile)
    bucket = conn.get_bucket(bucket_nm)

    if strip_prefix_slashes:
        file_prefix = file_prefix.strip('/')

    from_dt = datetime.strptime(from_dt, '%Y-%m-%d')
    to_dt = datetime.strptime(to_dt, '%Y-%m-%d')

    key_list = []

    if scan_type.lower() == 'modified':
        for item in bucket.list(prefix=file_prefix):
            modified_ts = datetime.strptime(item.last_modified, '%Y-%m-%dT%H:%M:%S.%fZ')
            if modified_ts >= from_dt and modified_ts <= to_dt:
                if file_prefix in item.key and (not ignore_empty or (ignore_empty and item.size > 0)):
                    key_list.append(item.key)
        return key_list

    elif scan_type.lower() == 'protobuf':
        return _get_protobuf_s3_files_in_range(
            bucket_nm=bucket_nm,
            from_dt=from_dt.date(),
            to_dt=to_dt.date(),
            event_name=file_prefix,
            ignore_empty=ignore_empty)

    elif scan_type.lower() == 'hive':
        date_range = [from_dt + timedelta(days=x) for x in range(0, (to_dt-from_dt).days)]
        for date in date_range:
            something = [key_list.append(item.key) for item in bucket.list(prefix=file_prefix + date.strftime("/dw_eff_dt=%Y-%m-%d/"))]
        return key_list

    else:
        date_range = [from_dt + timedelta(days=x) for x in range(0, (to_dt-from_dt).days)]
        for date in date_range:
            something = [key_list.append(item.key) for item in bucket.list(prefix=file_prefix + date.strftime("/%Y/%m/%d/")) if (not ignore_empty or (ignore_empty and item.size > 0))]
        return key_list


def mv_to_s3(from_string, dest_folder, s3_bucket = 'east1-prod-dwh-s3-0', aws_profile=AWS_PROFILE):
    """ Linux style move a file or set of files in a folder or files identified
        using wild cards in a local irectory to S3
        sample call 
        mv_to_s3('/Users/vaibhavjajoo/Data/child*.json', '/manual_loads/vj_uploads/', s3_bucket = 'east1-prod-dwh-s3-0')"""
    file_list = glob.glob(from_string)
    for file_nm in file_list:
        s3_file_upload(file_nm, s3_bucket, dest_folder, s3_file_nm='default', aws_profile=aws_profile)


def list_s3_keys(from_s3_string, s3_bucket, aws_profile=AWS_PROFILE):
    """ List all files in a folder in S3 and returns a list
    sample call:
    list_s3('manual_loads/test', s3_bucket = 'east1-prod-dwh-s3-0') """

    conn = S3Connection(profile_name=aws_profile)
    bucket = conn.get_bucket(s3_bucket)
    key_list = []
    for item in bucket.list(prefix=from_s3_string.strip('/')):
        if item.name.strip('/') != from_s3_string.strip('/'):
            key_list.append(item.name)
    return key_list


def delete_key(from_s3_string, s3_bucket,wildcard_delete='*', aws_profile=AWS_PROFILE):
    """Function will delete all the keys that matches the wild card character
    Sample call:
    delete_key('CCClickEvent/input','east1-stage-dwh-s3-0','test')
    In the above example only files which have test in it gets deleted to delete all the files give * """
    conn = S3Connection(profile_name=aws_profile)
    all_keys = list_s3_keys(from_s3_string, s3_bucket)
    for key in all_keys:
        bucket_nm = Bucket(conn,s3_bucket)
        file_nm=key.rsplit("/",1)[1]
        if wildcard_delete == "*":
            print "Key that is getting deleted "+key
            bucket_nm.delete_key(key)
        elif ( len(wildcard_delete) > 1 and wildcard_delete.startswith("*") and wildcard_delete.endswith("*") ):
            if file_nm.find(wildcard_delete[1:len(wildcard_delete)-1]) != -1:
                print "Key that is getting deleted "+key
                bucket_nm.delete_key(key)
        elif ( len(wildcard_delete) > 1 and wildcard_delete.startswith("*") and wildcard_delete[-1:] != "*") :
            if file_nm.endswith(wildcard_delete[1:len(wildcard_delete)]) :
                print "Key that is getting deleted "+key
                bucket_nm.delete_key(key)
        elif ( len(wildcard_delete) > 1 and wildcard_delete.split()[0][0] != "*" and wildcard_delete.endswith("*") ):
            if file_nm.startswith(wildcard_delete[0:len(wildcard_delete)-1]) :
                print "Key that is getting deleted "+key
                bucket_nm.delete_key(key)
        elif (len(wildcard_delete) > 1 and wildcard_delete.split()[0][0] != "*" and wildcard_delete[-1:] != "*") :
            if file_nm == wildcard_delete :
                print "Key that is getting deleted "+key
                bucket_nm.delete_key(key)

def mv_from_s3(s3_bucket, key, download_file_nm_with_full_path, retry=0):
    """
    Downloads the S3 object.
    If to_file is True (default: true), downloads the S3 object to the local fs and return the
    path to the file.
    @param s3_bucket     - The S3 bucket
    @param key           - The key file to download
    @param download_file_nm_with_full_local_path - The local file will save s3 file
    call examples:
mv_from_s3('east1-prod-dwh-s3-0', 'upload_conversions_google_campaign/dwh_conversions_google_campaign_000.dat', '/data/etl/Data/upload_conversions_google_campaign/dwh_conversions_google_campaign_000.dat', to_file=True)
    """

    conn = S3Connection()
    bucket = conn.get_bucket(s3_bucket)

    key_objects = bucket.list(prefix=str(key))
    for key_object in key_objects:
        key_obj = key_object
    
    # NOTE : If input string used to represent key matches with more than one key in S3. Last occurance will be used as download reference.
    
    #generate an object for content downloading
    key_object = key_obj

    try:
        key_object.get_contents_to_filename(download_file_nm_with_full_path)
    except ssl.SSLError:
        retry += 1
        if retry < 5:
            time.sleep(5)
            s3_file_download(s3_bucket, key, download_file_nm_with_full_path, retry=0)
        else:
            raise TimeoutError
    # Return the path to the file in the local directory
    return download_file_nm_with_full_path    


def s3_file_download_wildcard_search(s3_bucketname, s3bucketFolder, file_search, output_path, s3ArchivePath):
    '''This function searches from the pattern in the keys if the key contains the given 
    file_search string then that key will be downloaded locally. This function accepts 4
    input parameers
    1) s3_bucketname from which we want to download the files
    2) s3bucketFolder where the keys are present
    3) file_search :- name to search in the file
    4) Output path where the key to be downloaded
    5) Path to archive the original file
    '''
    conn = S3Connection()
    bucket = conn.get_bucket(s3_bucketname)
    for key in bucket.list(s3bucketFolder):
        input_key = key.name.encode('utf-8')
        actual_key = str(input_key).split("/")[-1]
        if actual_key == '':
            continue
        else:
            if file_search.lower() in actual_key.lower():
                outfile = os.path.join(output_path, actual_key.lower())
                mv_from_s3(s3_bucketname, input_key, outfile)
                print 'File Downloaded :- ' + outfile
                archive_key = os.path.join(s3ArchivePath, actual_key)
                bucket.copy_key(archive_key, s3_bucketname, input_key)
                bucket.delete_key(input_key)
            else:
                continue

               
def s3_key_copy(key_name, destination_file_full_path, source_bucket='east1-prod-dwh-s3-0', destination_bucket='east1-prod-dwh-s3-0', aws_profile=AWS_PROFILE):
    '''This function copies key object from one S3 bucket to another bucket without copying locally. 
       Also takes care of multipart copy incase of larger files.
       Call Example : 
       s3_key_copy('bluekai_nw_events/dw_eff_dt=2016-07-10/nerdwallet_batch_20160710123444.log.gz', 'nw-bluekai/nerdwallet_batch_20160710123444.log.gz', 'east1-prod-dwh-s3-0', 'nw-bluekai' )

    '''
    c = S3Connection(profile_name=aws_profile)
    destination_bucket_obj = c.get_bucket(destination_bucket)
    source_bucket_obj = c.get_bucket(source_bucket)

    k_obj = source_bucket_obj.get_key(key_name)
    if not k_obj:
        raise Exception("S3 key not found: s3://%s/%s" % (source_bucket, key_name))

    object_size_byte = k_obj.size
    #print "found objectSize of size > 5GB. Size in Bytes - %d" % object_size_byte

    object_size_gb = object_size_byte / math.pow(1024.0, 3.0)
    #print "found objectSize of size > 5GB. Size in GB - %d" % object_size_gb

    if object_size_gb < 5:
        destination_bucket_obj.copy_key(destination_file_full_path, source_bucket, key_name, preserve_acl=False)
        print 'Copied s3://{}/{} to s3://{}/{} (single part)'.format(source_bucket, key_name, destination_bucket, destination_file_full_path)
    else:
        # print "found objectSize of size > 5GB. Size in GB - %d" % object_size_gb
        mp = destination_bucket_obj.initiate_multipart_upload(destination_file_full_path, reduced_redundancy=True)
        psize = 50 * math.pow(2.0, 20.0) # 2^20 = 1 MiB
        bytePosition = 0
        i = 1
        while bytePosition < object_size_byte:
            lastbyte = bytePosition + psize -1
            if lastbyte > object_size_byte:
                lastbyte = object_size_byte - 1
            #print "mp.copy_part_from_key part %d (%d %d)" % (i,bytePosition,lastbyte)
            mp.copy_part_from_key(source_bucket, key_name, i, int(bytePosition),int(lastbyte))
            i = i+1
            bytePosition += psize
        mp.complete_upload()
        print 'Copied s3://{}/{} to s3://{}/{} (multipart, {} > 5GB)'.format(source_bucket, key_name, destination_bucket, destination_file_full_path, object_size_gb)

def list_s3_keys_enhanced(s3_folder, file_suffix='', s3_bucket = 'east1-prod-dwh-s3-0', include_subfolder=True):
    '''
    Use this function to list files in a s3 folder. This fucntion supports listing including/excluding subfolders.
    This funciton excludes the folders from the list output. Only returns list of files.
    
    Inputs to the function:    
    s3_folder: Folder to list
    file_suffix: File name suffix/prefix/part name. Python style, does not support '*'. Default: all files,
    s3_bucket: Defauilt = 'east1-prod-dwh-s3-0'
    include_subfolder: Include or exclude subfolder. Default=True
    
    Call sample: 
    list_s3_keys_enhanced('manual_loads/vjajoo/dw_page_monetizing_hist_f/', 'a_', \
    s3_bucket = 'east1-prod-dwh-s3-0', include_subfolder=True)
    '''
    conn =S3Connection()
    bucket = conn.get_bucket(s3_bucket)
    keys =[]
    for item in bucket.list(prefix=s3_folder.strip('/')):
        #print item.name
        if item.name.endswith('/'):
            #print 'its a folder'
            continue 
        else:
            #print 'its a file'
            file_nm = item.name.split('/')[-1] 
            #print file_nm
            if file_suffix in file_nm:
                key_folder=item.name.rstrip(file_nm)
                #print key_folder
                if key_folder.strip('/') == s3_folder.strip('/'):
                    #print 'in the base folder'
                    keys += [item.name]
                elif include_subfolder:
                    #print 'in subfolder but listing'
                    keys += [item.name]
                #print key_folder
    return keys

def mv_within_s3(source_folder, target_folder, file_suffix, source_bucket='east1-prod-dwh-s3-0',
                 target_bucket='east1-prod-dwh-s3-0', include_subfolder=True, aws_profile=AWS_PROFILE):
    '''
    Use this function to move files within S3 buckets. This function can be used to include/exclude sub folder.
    Function will delete the file moved. 
    Function DOES NOT support linux style widcard '*'. Use python style substrings to look for file names.
    
    Inputs to the function. 
    source_folder: source folder, without the file name
    target_folder: Target folder name wiuthout the file name. File name is picked from the source file name.
    file_suffix: Full file name or Python style. ''
    source_bucket: Default = 'east1-prod-dwh-s3-0'
    target_bucket: Default = 'east1-prod-dwh-s3-0' 
    include_subfolder: Include moving file from sub folder Default=True
    
    
    Sample call
    mv_within_s3(source_folder='manual_loads/vjajoo/dw_page_monetizing_hist_f', \
    target_folder='manual_loads/vjajoo/dw_page_monetizing_hist_f/archive/', \
    file_suffix='.txt', source_bucket = 'east1-prod-dwh-s3-0',  \
    target_bucket = 'east1-prod-dwh-s3-0',include_subfolder=True) 
    
    '''
    if file_suffix =='':
        print 'Please provide file suffix to avoid moving/deleting unbound number of files.'
        return
    
    keys = list_s3_keys_enhanced(s3_folder=source_folder, file_suffix=file_suffix, s3_bucket = source_bucket, include_subfolder=include_subfolder)
    for key_name in keys:
        print 'Copying file: %s' %(key_name)
        file_nm = key_name.split('/')[-1]
        target_file = os.path.join(target_folder,file_nm)
        print 'Target File is %s' %(target_file)
        s3_key_copy(key_name, destination_file_full_path=target_file, source_bucket=source_bucket, destination_bucket=target_bucket)

        conn =S3Connection(profile_name=aws_profile)
        bucket = conn.get_bucket(source_bucket)
        print 'Deleting file: %s' %(key_name)
        bucket.delete_key(key_name)


def ensure_clean_s3(bucket, s3_path, aws_profile=AWS_PROFILE):
    """
    Uset this function to delete all files in a given s3 path
    :param bucket: str, s3 bucket
    :param s3_path: str, s3 path
    :param aws_profile: str, profile_name parameter to be passed to S3Connection()
    ex: ensure_clean_s3('east1-prod-dwh-s3-0', 'sample_path/sample_folder'
    --> this will delete all files in s3://east1-prod-dwh-s3-0/sample_path/sample_folder
    """
    conn = S3Connection(profile_name=aws_profile)
    bucket = conn.get_bucket(bucket)

    if s3_path.startswith('/'):
        s3_path = s3_path[1:]

    existingkeys = []
    for rs in bucket.list(prefix=s3_path):
        existingkeys.append(rs.name)

    if len(existingkeys) > 0:
        print 'Cleaning up s3://{}:'.format(os.path.join(bucket.name, s3_path))
        for key in existingkeys:
            print '  ... {}'.format(key.replace(s3_path, ''))
            bucket.delete_key(key)


def set_key_acl_policy(bucket, key, policy='bucket-owner-full-control', aws_profile=AWS_PROFILE):
    """
    Update permissions of S3 key using acl policy.
    :param bucket: str, s3 bucket
    :param key: str, s3 key path
    :param policy: str, A canned ACL. One of: private, public-read, public-read-write, authenticated-read,
                        bucket-owner-read, bucket-owner-full-control
    :param aws_profile: str, profile_name parameter to be passed to S3Connection()
    """
    # Unable to run awscli. Defaulting to boto library
    s3_conn = S3Connection(profile_name=aws_profile)
    s3_buck = s3_conn.get_bucket(bucket)
    s3_buck.set_acl(acl_or_str=policy, key_name=key)


def s3_head(bucket, key, bytecount, aws_profile=AWS_PROFILE):
    conn = S3Connection(profile_name=aws_profile)
    s3_buck = conn.get_bucket(bucket)
    s3k = s3_buck.get_key(key)
    if s3k is None:
        return ''
    octets = min(bytecount - 1, s3k.size)
    if octets < 1:
        return ''
    if key.endswith('.gz'):
        gz_stream = StringIO.StringIO(s3k.read(octets))
        # we use the same num of bytes to avoid an "IOError: CRC check failed" exception in case the file size
        unzip_str = gzip.GzipFile(fileobj=gz_stream).read(octets)
        gz_stream.close()
        return unzip_str

    return s3k.get_contents_as_string({'Range': 'bytes=0-{}'.format(octets)})

  
def get_s3_top_level_folder_names(bucket_name):
    """
    Retrieves the list of top-level folder names from an S3 bucket.
    :return: Set containing the top-level folder names
    """
    s3 = boto3.client('s3')
    s3_folders = s3.list_objects_v2(
        Bucket=bucket_name,
        Delimiter='/'
    )
    if s3_folders['KeyCount'] < 1:
        return None

    folder_names = set()
    for prefix in s3_folders['CommonPrefixes']:
        folder_names.add(prefix['Prefix'].rstrip('/'))

    return folder_names
