import argparse
import csv
from datetime import datetime
import os

import requests

CHUNK_SIZE = 1024


def get_large_file(url, path_to):
    """Download large file

    E.g.: get_large_file("http://example.com/ex.csv", "/tmp")
    """
    r = requests.get(url, stream=True)
    fn = url.split('/')[-1]
    with open(os.path.join(path_to, fn), 'wb') as fd:
        for chunk in r.iter_content(CHUNK_SIZE):
            fd.write(chunk)


def combine_files(header, fns, path_to):
    """Combine files into generator

    Updated: added ability to hadle a csv files
    which have ',', '\r\n' within its fileds
    """
    for fn in fns:
        with open(os.path.join(path_to, fn), 'rb') as f:
            rows = csv.reader(
                f, quotechar='"', delimiter=',', skipinitialspace=True)
            f.next()
            for row in rows:
                row_fine = [r.replace('\n', '').replace('\r', '') for r in row]
                yield dict(zip(header, row_fine))


def ingest_adv_data(data, adv_data):
    """Add advertiser level data"""
    for row in data:
        row.update(adv_data[int(row['advertiser_id'])])
        yield row
