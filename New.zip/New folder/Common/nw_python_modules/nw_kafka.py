from kafka import KafkaConsumer, TopicPartition


def connect(servers, client_id, max_poll_records, logging=None):
    if logging:
        logging.info('Connecting to Kafka servers {} with client_id {}'.format(' ,'.join(servers), client_id))
    kc = KafkaConsumer(bootstrap_servers=servers,
                       client_id=client_id,
                       group_id=None,  # explicitly no consumer groups
                       enable_auto_commit=False,  # kadu manages checkpoints carefully
                       auto_offset_reset='raise',  # tell me if there's a OffsetOutOfRange error
                       api_version=None,  # please negotiate
                       fetch_min_bytes=0,  # do not block if there's no messages available
                       max_poll_records=max_poll_records)  # TODO do i make this a kadu_param?
    return kc


def get_partitions(kafka_consumer, topic):
    """
    :param kafka_consumer: KafkaConsumer object
    :param topic: Kafka topic
    :return: list of partitions for topic
    """
    partitions = sorted(kafka_consumer.partitions_for_topic(topic))
    return partitions


def get_topic_partitions(partitions, topic):
    """
    :param partitions: list of partitions
    :param topic: Kafka topic
    :return: list of topic partitions
    """
    topic_partitions = [TopicPartition(topic, partition) for partition in partitions]
    return topic_partitions

