import sys
import requests
import json
import pycurl
import os
from nw_generic_utils_modules import convert_csv_to_python_json
from s3_modules import s3_file_upload
from datetime import datetime


def download_file(input_file,output_file) :
   """
   This function downloads the files using pycurl in the specified location and then zips them.
   """
   print "Download File Started"
   print output_file
   try:
      with open(output_file, 'w') as f:
        c = pycurl.Curl()
        c.setopt(c.URL,input_file)
        c.setopt(c.WRITEDATA, f)
        c.perform()
        c.close()
   except Exception,err:
      print "Error in downloading the file"
      print Exception,err
      raise 
 

def flatten_json_record(json_input,json_out_file,json_extra_out_file,json_dict) :
   '''
      Funtion to flatten the json file and create a new json file
   '''
   try :
      print "Start flatenning json file"
      counter =0      
      for input_line in json_input:
         one_dict={}
         counter +=1
         data_item=json.loads(input_line.strip(',\n').strip('[').strip(']'))
         for  key in data_item:
           if key in json_dict.keys()  and data_item[key]:
               inner_json=json.loads(((data_item[key])))
               for inner_key in inner_json:
                  extra_one_dict={}   
                  if  inner_key in json_dict[key].keys() : 
                     one_dict[json_dict[key][inner_key]]=inner_json[inner_key]
                  else :
                     extra_one_dict[inner_key]=inner_json[inner_key]
                     extra_one_dict['key']=key
                     json_extra_out_file.write(json.dumps(extra_one_dict, sort_keys=True)) 
                     json_extra_out_file.write("\n") 
                       
           one_dict[key]=data_item[key]
               
                   
         json_out_file.write(json.dumps(one_dict, sort_keys=True)) 
         json_out_file.write("\n") 
         
         if counter%50000 ==0 :
           print "Lines Processed: %s" %counter

   except Exception,err:
      print Exception,err
      raise                 

     
def get_branch_data (url,in_output_file,dim,json_dict,field_name_list,job_name,source_bucket,in_final_json_file,in_extra_json_file):
   '''
      Main function to get the download the data and flatten it.
   '''
   print 'Starting downloading for %s Dimension.' %dim
   response=requests.get(url)
   
   if response.status_code <> 200:
      print "Error in downloading the file. Error Code %s Error Message %s.Existing" %(response,response.text)
      return -1
   else :    
      try : 
         print 'URL Download completed successfully for %s Dimension.' %dim
         file_list=json.loads(response.text)
         counter=0
         for item_list in file_list[dim] :
         
             counter +=1 
              
             print "convert file names"
             output_file=in_output_file.replace('cnt', str(counter))
             json_file=output_file.replace('.csv','.json')
             final_json_file=in_final_json_file.replace('cnt', str(counter))
             extra_json_file=in_extra_json_file.replace('cnt', str(counter))
             
             print "Start actual file download"             
             download_file(item_list, output_file + '.gz')
             
             print "Starting input file upload to S3 archive bucket"
             s3_file_upload(output_file+'.gz', source_bucket, job_name+'/input/',os.path.basename(output_file)+ str(datetime.now())+'.gz')
                 
             print "unzipping the file"
             os.system("gunzip " + output_file + '.gz')
             
             print "start processing for converting to json"
             convert_csv_to_python_json(field_name_list,',',output_file,json_file)     
             
             print "start flattenning  the json"
             with open (json_file) as json_input ,  open(final_json_file, 'w') as json_out_file , open(extra_json_file,'w') as json_extra_out_file :
                  next(json_input) 
                  flatten_json_record(json_input,json_out_file,json_extra_out_file,json_dict)
             print " flattenning  the json completed for url= %s" %counter   
             
             print "Starting output file upload to S3"
             os.system("gzip " + final_json_file )
             s3_file_upload(final_json_file+'.gz', source_bucket, job_name+'/output/',os.path.basename(final_json_file+'.gz'))
             s3_file_upload(final_json_file+'.gz', source_bucket, job_name+'/archive/',os.path.basename(final_json_file+'.gz')+str(datetime.now()))
             s3_file_upload(extra_json_file, source_bucket, job_name+'/archive/',os.path.basename(extra_json_file)+str(datetime.now()))


         print 'Flatten Json created. No of records in the download url %s'  %counter
      except Exception,err:
         print Exception,err
         return -1          
               
   return 1      






