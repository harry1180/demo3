from requests.auth import HTTPBasicAuth
import getpass
import json
import logging
import os
import pwd

from nw_generic_utils_modules import parse_nw_dns
from pyhive import presto

# only log warnings from pyhive to reduce noise
logging.getLogger('pyhive.presto').setLevel(logging.WARNING)

reserved_words = {
    'ALTER', 'AND', 'AS', 'BETWEEN', 'BY', 'CASE', 'CAST', 'CONSTRAINT', 'CREATE', 'CROSS', 'CUBE', 'CURRENT_DATE',
    'CURRENT_TIME', 'CURRENT_TIMESTAMP', 'CURRENT_USER', 'DEALLOCATE', 'DELETE', 'DESCRIBE', 'DISTINCT', 'DROP', 'ELSE',
    'END', 'ESCAPE', 'EXCEPT', 'EXECUTE', 'EXISTS', 'EXTRACT', 'FALSE', 'FOR', 'FROM', 'FULL', 'GROUP', 'GROUPING',
    'HAVING', 'IN', 'INNER', 'INSERT', 'INTERSECT', 'INTO', 'IS', 'JOIN', 'LEFT', 'LIKE', 'LOCALTIME', 'LOCALTIMESTAMP',
    'NATURAL', 'NORMALIZE', 'NOT', 'NULL', 'ON', 'OR', 'ORDER', 'OUTER', 'PREPARE', 'RECURSIVE', 'RIGHT', 'ROLLUP',
    'SELECT', 'TABLE', 'THEN', 'TRUE', 'UESCAPE', 'UNION', 'UNNEST', 'USING', 'VALUES', 'WHEN', 'WHERE', 'WITH'
}


def get_presto_credentials():
    """
    Retrieve the username and password used to connect to Presto
    :return: Two-element tuple of the username and password
    """
    current_username = pwd.getpwuid(os.getuid()).pw_name
    if current_username == "airflow":
        with open("/etc/dwh_secured_tokens/airflow.json") as fh:
                creds = json.load(fh)
        presto_username = creds["active_directory"]["airflow"]["user"]
        presto_password = creds["active_directory"]["airflow"]["password"]
    else:
        presto_username = current_username
        # TODO: Pull this from a protected user keychain
        presto_password = getpass.getpass("Okta Password: ")

    return presto_username, presto_password


def connect(logger=None):
    """
    Retrieve a connection to Presto. Attempts to determine DNS by parsing .inc if present. This allows us to run this
    module on all servers that have a .inc file and different DNS. If os is "Darwin" we'll assume you're running this
    from your local (Mac OSX).
    :param logger: If specified, messages are sent to this logger which is a logger from the logging module.
    :return: The PyHive.Presto connection
    """
    # presto_server = "nerdlake-etl.east1.prod.nerdwallet.com"
    if os.uname()[0] == 'Linux':
        presto_server = parse_nw_dns('/usr/local/bin/nw-emr.inc')
    elif os.uname()[0] == 'Darwin':
        presto_server = 'presto-nerdlake-etl.nerdwallet.io'
    else:
        raise Exception('Unable to determine Presto DNS')
    if logger:
        logger.info("Connecting to Presto server {}".format(presto_server))
    presto_username, presto_password = get_presto_credentials()
    return presto.connect(
        host=presto_server,
        port=8446,
        protocol="https",
        username=presto_username,
        requests_kwargs={
            'auth': HTTPBasicAuth(presto_username, presto_password),
            'verify': '/etc/truststore/nerdlake-etl/nerdlake-truststore.pem'
        }
    )


def get_scalar_value(conn, sql):
    """
    Execute a SELECT statement against Presto
    :param conn: A Presto connection object
    :param sql: The SQL statement to execute
    :return: A single scalar value
    """
    presto_curs = conn.cursor()
    presto_curs.execute(sql)
    scalar_data = presto_curs.fetchone()
    presto_curs.close()
    if scalar_data:
        scalar_value = scalar_data[0]
    else:
        scalar_value = None
    return scalar_value


def get_column_names(conn, table_name, include_type=False):
    describe_sql = "DESCRIBE {}".format(table_name)
    presto_curs = conn.cursor()
    presto_curs.execute(describe_sql)
    res = presto_curs.fetchall()
    presto_curs.close()

    columns = []
    for col, col_type, extra1, extra2 in res:
        if not include_type:
            columns.append(col)
        else:
            columns.append((col, col_type))

    return columns


def insert_rows(conn, sql):
    presto_curs = conn.cursor()
    presto_curs.execute(sql)
    res = presto_curs.fetchall()
    rows_inserted = res[0][0]
    logging.info('{} rows inserted'.format(rows_inserted))

    return rows_inserted


def delete_from_table(conn, fq_table_name):
    """
    Deletes all records from table
    :param conn: pyhive Presto connection
    :param fq_table_name: The fully qualified Presto table name
    :return:
    """
    delete_sql = "DELETE FROM {}".format(fq_table_name)
    presto_curs = conn.cursor()
    presto_curs.execute(delete_sql)
    presto_curs.close()