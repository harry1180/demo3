import datetime
import os
import uuid

from excelutils import getcsvinfo, getexcelinfo, getxmlinfo, getjsoninfo
from redshift_modules import exec_query


TRANS_LOG_SCHEMA = 'dw_report'
TRANS_LOG_TABLE = 'dw_aflt_tran_log'


def get_tran_file_info(input_file, dw_eff_dt, file_type):
    """
    Get number of records and max date value from file.
    """
    if file_type in ('xlsx', '.xlsx'):
        return getexcelinfo(input_file, dw_eff_dt=dw_eff_dt)
    elif file_type in ('xml', '.xml'):
        return getxmlinfo(input_file, dw_eff_dt=dw_eff_dt)
    elif file_type in ('csv', '.csv'):
        return getcsvinfo(input_file, dw_eff_dt=dw_eff_dt)
    elif file_type in ('json', '.json'):
        return getjsoninfo(input_file, dw_eff_dt=dw_eff_dt)


def clean_record_date(record_date):
    """
    Make sure record_date is in the expected date format
    :param record_date: date value of single record from stage table
    :return: str, date string
    """
    if isinstance(record_date, str):
        if len(record_date) > 10:
            return record_date[:10]
	else:
            return record_date
    else:
        return datetime.datetime.strftime(record_date, '%Y-%m-%d')


def get_tran_stage_info(schema_name, table_name, dw_eff_dt, prog_nm, prog_is_const=False):
    """
    Get number of records and max date value grouped by program name from
    affiliate stage table. This function is a utility to easily get the
    required fields for adding/updating a log entry.

    :param schema_name: str, name of staging schema
    :param table_name: str, name of staging table
    :param dw_eff_dt: str, name of column containing date values
    :param prog_nm: str, name of column containing program/partner
    :param prog_is_const: bool, set to True if the stage table does not contain a column with program name,
                          and instead use aflt_network_nm from network table.
    :return: [(program name, max date, record count),...]
    """
    tran_info = []
    if prog_is_const:
        query = """
                SELECT '{prog_nm}' AS prog_nm, count({dw_eff_dt}) AS record_cnt, max({dw_eff_dt}) AS max_date
                FROM {schema}.{table}
                GROUP BY 1;
            """.format(prog_nm=prog_nm, dw_eff_dt=dw_eff_dt, schema=schema_name, table=table_name)
    else:
        query = """
            SELECT {prog_nm} AS prog_nm, count({dw_eff_dt}) AS record_cnt, max({dw_eff_dt}) AS max_date
            FROM {schema}.{table}
            GROUP BY 1;
        """.format(prog_nm=prog_nm, dw_eff_dt=dw_eff_dt, schema=schema_name, table=table_name)
    results = exec_query(query)
    for result in results:
        result['max_date'] = clean_record_date(result['max_date'])
        tran_info.append((result['max_date'], result['record_cnt'], str(result['prog_nm']).replace("'", "\\'")))
    return tran_info


def insert_log(aflt_network_id, input_file=None, lender=None):
    """
    Inserts new entry into master transaction log table. There are currently two types of scenarios:
        1. Direct Partner - Most direct partners send physical files on a regular basis that contains
        transaction data. If input_file parameter is specified, this function will parse the file and
        extract the necessary data to be inserted into the log table.

        2. Affiliate Network - Most affiliate networks send transaction data via an API rather
        than a physical file. This means there is no file count value calculated, and instead we use
        stage count value when inserting new rows into the table. For network jobs, this function
        should be called after the staging table has been loaded. Each individual partner or program
        within the network is inserted as a separate row into the table.

    :param aflt_network_id: id from affiliate network table
    :param input_file: str, optional: full path to raw transactions file that is being processed
    """
    try:
        tran_meta = AffiliateMetaData(aflt_network_id).data
        network = False
        if input_file:
            cnt_type = 'file_cnt'
            tran_data = [get_tran_file_info(input_file, tran_meta['src_dt_col_nm'], tran_meta['src_file_type'])]
        else:
            network = True
            cnt_type = 'stage_cnt'
            if tran_meta['stage_prog_nm']:
                tran_data = get_tran_stage_info(tran_meta['stage_schema_nm'], tran_meta['stage_table_nm'],
                                                tran_meta['src_dt_col_nm'], tran_meta['stage_prog_nm'])
            else:
                tran_data = get_tran_stage_info(tran_meta['stage_schema_nm'], tran_meta['stage_table_nm'],
                                                tran_meta['src_dt_col_nm'], tran_meta['aflt_network_nm'], True)

        # In the event of no transaction data, print warning and exit
        if len(tran_data) == 0:
            print('Warning: No transaction data found, unable to add to log table')
            return False

        else:
            values = []
            for entry in tran_data:
                max_date, record_cnt, prog_nm = entry
                if network:
                    file_name = '{partner}_{max_date}'.format(partner=prog_nm.replace(' ', '_'), max_date=max_date)
                else:
                    file_name = os.path.splitext(os.path.basename(input_file))[0]
                    if lender:
                        prog_nm = lender
                    else:
                        prog_nm = file_name.split('_')[0]
                log_id = uuid.uuid1()
                values.append("(current_timestamp, '{0}', '{1}', '{2}', {3}, '{4}', {5}, '{6}')\n".format(log_id,
                                                                                                          file_name,
                                                                                                          max_date,
                                                                                                          record_cnt,
                                                                                                          'Processing',
                                                                                                          aflt_network_id,
                                                                                                          prog_nm))

            query = """
                    insert into {schema}.{table}
                    (dw_load_ts, log_id, src_filename, src_file_received_dt, {cnt_type}, etl_status, aflt_id, prog_nm)
                    """.format(schema=TRANS_LOG_SCHEMA, table=TRANS_LOG_TABLE, cnt_type=cnt_type)
            query += ' VALUES {};'.format(','.join(values))
            exec_query(query)
            return True
    except Exception as e:
        print e
        print('Error: Could not add transaction file to log table')
        return False


def update_log_cnt(aflt_network_id, file_path, lender, cnt_type):
    """
    Update warn_cnt column on log table based on number of rows in warning file

    :param aflt_network_id: id from affiliate network table
    :param file_path: str, path of file to count
    """
    CNT_TYPES = {'error': 'error_cnt', 'warning': 'warn_cnt'}
    try:
        tran_meta = AffiliateMetaData(aflt_network_id).data
        _, cnt_value, _ = get_tran_file_info(file_path, tran_meta['src_dt_col_nm'], os.path.splitext(file_path)[1])

        query = """
        update {log_schema}.{log_table}
        set {cnt_type} = {cnt_value}
        where log_id = (
            select log_id from {log_schema}.{log_table} b
            where b.aflt_id = {meta_id} and prog_nm = '{lender}' and etl_status = 'Processing' and {cnt_type} is null
            order by b.dw_load_ts DESC limit 1
        );
        """.format(log_schema=TRANS_LOG_SCHEMA, log_table=TRANS_LOG_TABLE, cnt_value=cnt_value,
                   cnt_type=CNT_TYPES.get(cnt_type), meta_id=aflt_network_id, lender=lender)
        exec_query(query)
        return True
    except:
        print('Error: Could not update stage_cnt for meta_id: {}'.format(aflt_network_id))
        return False


def update_log_stage_cnt(aflt_network_id):
    """
    Update stage_cnt column on log table once the staging data is loaded. This function is
    only meant for direct partners with physical transaction files. This is because the
    stage_cnt column is already filled in for affiliate networks in the insert_log() function.

    :param aflt_network_id: id from affiliate network table
    """
    try:
        tran_meta = AffiliateMetaData(aflt_network_id).data

        query = """
        update {log_schema}.{log_table}
        set stage_cnt = (
            select count({date_col}) from {stage_schema}.{stage_table}
        )
        where log_id = (
            select log_id from {log_schema}.{log_table} b
            where b.aflt_id = {meta_id} and etl_status = 'Processing' and stage_cnt is null
            order by b.dw_load_ts DESC limit 1
        );
        """.format(log_schema=TRANS_LOG_SCHEMA, log_table=TRANS_LOG_TABLE,
                   date_col=tran_meta['src_dt_col_nm'], stage_schema=tran_meta['stage_schema_nm'],
                   stage_table=tran_meta['stage_table_nm'], meta_id=aflt_network_id)
        exec_query(query)
    except:
        print('Error: Could not update stage_cnt for meta_id: {}'.format(aflt_network_id))


class AffiliateMetaData(object):

    _TRANS_META_SCHEMA = 'dw_report'
    _TRANS_META_TABLE = 'dw_aflt_network_d'
    _TRANS_META_FIELDS = ['aflt_network_id', 'aflt_network_nm', 'src_dt_col_nm', 'src_file_type', 'stage_schema_nm',
                          'stage_table_nm', 'stage_prog_nm']

    def __init__(self, aflt_id):
        self.aflt_id = aflt_id
        self.data = self._retrieve_metadata()


    def _retrieve_metadata(self):
        """
        Retrieve data about transactions file from affiliate network table
        :return: dict, affiliate metadata
        """
        select_fields = ','.join(self._TRANS_META_FIELDS)
        select_query = 'SELECT {0} FROM {1}.{2}'.format(select_fields, self._TRANS_META_SCHEMA, self._TRANS_META_TABLE)
        where_clause = 'WHERE curr_in=1 and aflt_network_id={0};'.format(self.aflt_id)
        full_query = '{0} {1}'.format(select_query, where_clause)
        results = exec_query(full_query)
        if len(results) == 1:
            return results[0]
        elif len(results) == 0:
            raise Exception("No matching metadata entry found for aflt id: {0}".format(self.aflt_id))
        else:
            raise Exception("Multiple matching metadata entries found for aflt id: {0}".format(self.aflt_id))
