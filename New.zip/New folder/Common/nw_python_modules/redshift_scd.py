from datetime import timedelta
import logging
import sys
import textwrap

import redshift_modules

# Audit fields get ignored when doing row comparisons for SCD
audit_fields = {'dw_load_ts', 'dw_load_nm', 'dw_last_updt_nm', 'dw_last_updt_ts', 'dw_last_updt_tx'}

# Used for quoting field names when building SQL
redshift_reserved_keywords = {
    'aes128',
    'aes256',
    'all',
    'allowoverwrite',
    'analyse',
    'analyze',
    'and',
    'any',
    'array',
    'as',
    'asc',
    'authorization',
    'backup',
    'between',
    'binary',
    'blanksasnull',
    'both',
    'bytedict',
    'bzip2',
    'case',
    'cast',
    'check',
    'collate',
    'column',
    'constraint',
    'create',
    'credentials',
    'cross',
    'current_date',
    'current_time',
    'current_timestamp',
    'current_user',
    'current_user_id',
    'default',
    'deferrable',
    'deflate',
    'defrag',
    'delta',
    'delta32k',
    'desc',
    'disable',
    'distinct',
    'do',
    'else',
    'emptyasnull',
    'enable',
    'encode',
    'encrypt     ',
    'encryption',
    'end',
    'except',
    'explicit',
    'false',
    'for',
    'foreign',
    'freeze',
    'from',
    'full',
    'globaldict256',
    'globaldict64k',
    'grant',
    'group',
    'gzip',
    'having',
    'identity',
    'ignore',
    'ilike',
    'in',
    'initially',
    'inner',
    'intersect',
    'into',
    'is',
    'isnull',
    'join',
    'leading',
    'left',
    'like',
    'limit',
    'localtime',
    'localtimestamp',
    'lun',
    'luns',
    'lzo',
    'lzop',
    'minus',
    'mostly13',
    'mostly32',
    'mostly8',
    'natural',
    'new',
    'not',
    'notnull',
    'null',
    'nulls',
    'off',
    'offline',
    'offset',
    'oid',
    'old',
    'on',
    'only',
    'open',
    'or',
    'order',
    'outer',
    'overlaps',
    'parallel',
    'partition',
    'percent',
    'permissions',
    'placing',
    'primary',
    'raw',
    'readratio',
    'recover',
    'references',
    'respect',
    'rejectlog',
    'resort',
    'restore',
    'right',
    'select',
    'session_user',
    'similar',
    'snapshot ',
    'some',
    'sysdate',
    'system',
    'table',
    'tag',
    'tdes',
    'text255',
    'text32k',
    'then',
    'timestamp',
    'to',
    'top',
    'trailing',
    'true',
    'truncatecolumns',
    'union',
    'unique',
    'user',
    'using',
    'verbose',
    'wallet',
    'when',
    'where',
    'with',
    'without',
}

logger = logging.getLogger('redshift_scd')


def _step1_expire_deleted(conn, source_table, target_table, target_cols, key_fields, scd_date, scd_true_value,
                          scd_false_value, simulate=False):
    """
    Expire records that are no longer in our source table.

    Both of the SQLs in this step should execute successfully, or neither should. We don't commit the changes to the
    database until the second SQL executes successfully.

    :param conn:
    :param source_table:
    :param target_table:
    :param key_fields:
    :param scd_date:
    :param scd_false_value:
    :return:
    """

    # Update records that aren't in our source table with an expiration date.
    sql = 'UPDATE {}\n'.format(target_table)
    sql += 'SET dw_expr_dt = DATE \'{}\',\n'.format((scd_date - timedelta(days=1)).strftime('%Y-%m-%d'))
    sql += '    curr_in = {},\n'.format(scd_false_value)
    sql += '    dw_last_updt_ts = SYSDATE\n'
    sql += 'FROM {} scd\n'.format(target_table)
    sql += 'WHERE scd.dw_expr_dt = DATE \'9999-12-31\'\n'
    sql += '  AND scd.del_in = {}\n'.format(scd_false_value)
    sql += '  AND NOT EXISTS (\n'
    sql += '          SELECT True\n'
    sql += '          FROM {} stg\n'.format(source_table)

    join_clauses = list()
    for key_field in sorted(key_fields):
        join_clauses.append('stg.{field_name} = scd.{field_name}'.format(field_name=key_field))
    sql += '          WHERE ' + '\n            AND '.join(join_clauses)
    sql += '\n      )'
    logger.debug('_step1_expire_deleted SQL, part 1/2:\n\n' + sql + '\n')
    if not simulate:
        with conn.cursor() as curs:
            logger.info('Step 1.1: Expire deleted records')
            curs.execute(sql)
            logger.info('    => {} records affected'.format(curs.rowcount))

            # If we didn't expire any records, don't try to create deletion placeholders
            if curs.rowcount == 0:
                return

    # Add the expired/deleted records back in the table with 'del_in = True'
    non_audit_field_names = list()
    for target_col in [c['name'] for c in target_cols]:
        if target_col in audit_fields:
            continue
        if target_col in ['dw_eff_dt', 'dw_expr_dt', 'curr_in', 'del_in']:
            continue
        if target_col in redshift_reserved_keywords:
            non_audit_field_names.append('"{}"'.format(target_col))
        else:
            non_audit_field_names.append(target_col)

    sql = 'INSERT INTO {} (\n'.format(target_table)
    field_list = ', '.join(non_audit_field_names) + ', dw_eff_dt, dw_expr_dt, curr_in, del_in, dw_load_ts'
    sql += '    ' + '\n    '.join(textwrap.wrap(field_list, 116))
    sql += '\n)\n'

    sql += 'SELECT\n'
    field_list = ', '.join(non_audit_field_names)
    field_list += ', DATE \'{}\' AS dw_eff_dt'.format(scd_date.strftime('%Y-%m-%d'))
    field_list += ', DATE \'9999-12-31\' AS dw_expr_dt'
    field_list += ', {} AS curr_in'.format(scd_true_value)
    field_list += ', {} AS del_in'.format(scd_true_value)
    field_list += ', SYSDATE AS dw_load_ts'
    sql += '    ' + '\n    '.join(textwrap.wrap(field_list, 116))
    sql += '\nFROM\n    {}\n'.format(target_table)
    sql += 'WHERE dw_expr_dt = DATE \'{}\'\n'.format((scd_date - timedelta(days=1)).strftime('%Y-%m-%d'))
    sql += '  AND del_in = {}\n'.format(scd_false_value)
    sql += '  AND NOT EXISTS (\n'
    sql += '          SELECT True\n'
    sql += '          FROM {} tgt\n'.format(target_table)

    join_clauses = list()
    for key_field in sorted(key_fields):
        join_clauses.append('tgt.{field_name} = {target_table}.{field_name}'.format(
            field_name=key_field,
            target_table=target_table))
    sql += '          WHERE ' + '\n            AND '.join(join_clauses)
    sql += '\n            AND dw_expr_dt = DATE \'9999-12-31\'\n'
    sql += '            AND del_in = {}\n'.format(scd_true_value)
    sql += '      )'

    logger.debug('_step1_expire_deleted SQL, part 2/2:\n\n' + sql + '\n')
    if not simulate:
        with conn.cursor() as curs:
            logger.info('Step 1.2: Create deletion placeholders')
            curs.execute(sql)
            logger.info('    => {} records affected'.format(curs.rowcount))

    if not simulate:
        conn.commit()


def _step2_expire_deleted_placeholders(conn, source_table, target_table, key_fields, scd_date, scd_true_value,
                                       scd_false_value, simulate=False):
    """
    If there is a current deletion placeholder in our target table for a record that's in our staging table, this means
    that a previously deleted record has been added back to the source. In this case, we need to expire the deletion
    placeholder record.

    :return:
    """
    sql = 'UPDATE {}\n'.format(target_table)
    sql += 'SET dw_expr_dt = DATE \'{}\',\n'.format((scd_date - timedelta(days=1)).strftime('%Y-%m-%d'))
    sql += '    curr_in = {},\n'.format(scd_false_value)
    sql += '    dw_last_updt_ts = SYSDATE\n'
    sql += 'FROM {} scd\n'.format(target_table)
    sql += 'INNER JOIN {} stg\n'.format(source_table)

    join_clauses = list()
    for key_field in sorted(key_fields):
        join_clauses.append('stg.{field_name} = scd.{field_name}'.format(field_name=key_field))
    sql += '    ON ' + '\n    AND '.join(join_clauses)
    sql += '\nWHERE scd.dw_expr_dt = DATE \'9999-12-31\'\n'
    sql += '  AND scd.del_in = {}'.format(scd_true_value)

    logger.debug('_step2_expire_deleted_placeholders:\n\n' + sql + '\n')
    if not simulate:
        with conn.cursor() as curs:
            logger.info('Step 2: Expire deletion placeholder records')
            curs.execute(sql)
            logger.info('    => {} records affected'.format(curs.rowcount))
            conn.commit()


def _step3_expire_updated(conn, source_table, source_cols, target_table, target_cols, key_fields, scd_date, scd_false_value,
                          ignore_fields_lowercase=None, simulate=False):
    """
    Expire records that don't match our source table.

    :param conn:
    :param source_table:
    :param source_cols:
    :param target_table:
    :param key_fields:
    :param scd_date:
    :param scd_false_value:
    :return:
    """
    sql = 'UPDATE {}\n'.format(target_table)
    sql += 'SET dw_expr_dt = DATE \'{}\',\n'.format((scd_date - timedelta(days=1)).strftime('%Y-%m-%d'))
    sql += '    curr_in = {},\n'.format(scd_false_value)
    sql += '    dw_last_updt_ts = SYSDATE\n'
    sql += 'FROM {} scd\n'.format(target_table)
    sql += 'INNER JOIN {} stg\n'.format(source_table)

    join_clauses = list()
    for key_field in sorted(key_fields):
        join_clauses.append('stg.{field_name} = scd.{field_name}'.format(field_name=key_field))
    sql += '    ON ' + '\n    AND '.join(join_clauses)
    sql += '\n    AND scd.dw_expr_dt = DATE \'9999-12-31\'\n'
    sql += 'WHERE '

    # Build a list of the clauses that will compare all columns across both tables. Handle NULLs using 'IS NULL' checks
    # instead of COALESCE to ensure a 100% accurate comparison in all cases. If both columns are NULL then this is
    # treated as if they are equal.
    compare_clauses = list()
    for source_col in source_cols:
        field_name = source_col['name']
        if field_name in key_fields:
            continue
        if field_name in audit_fields:
            continue
        if ignore_fields_lowercase and field_name in ignore_fields_lowercase:
            continue
        if field_name in redshift_reserved_keywords:
            field_name = '"{}"'.format(field_name)

        source_nullable = source_col['nullable']
        target_nullable = True
        for target_col in target_cols:
            if target_col['name'] != source_col['name']:
                continue
            target_nullable = target_col['nullable']
            break

        this_clause = 'stg.{field_name} <> scd.{field_name}'.format(field_name=field_name)
        compare_clauses.append(this_clause)

        if source_nullable and target_nullable:
            this_clause = '(stg.{field_name} IS NULL AND scd.{field_name} IS NOT NULL)'.format(field_name=field_name)
            compare_clauses.append(this_clause)

            this_clause = '(stg.{field_name} IS NOT NULL AND scd.{field_name} IS NULL)'.format(field_name=field_name)
            compare_clauses.append(this_clause)

        elif source_nullable:
            this_clause = 'stg.{field_name} IS NULL'.format(field_name=field_name)
            compare_clauses.append(this_clause)

        elif target_nullable:
            this_clause = 'scd.{field_name} IS NULL'.format(field_name=field_name)
            compare_clauses.append(this_clause)

    sql += '\n   OR '.join(compare_clauses)

    logger.debug('_step3_expire_updated SQL:\n\n' + sql + '\n')
    if not simulate:
        with conn.cursor() as curs:
            logger.info('Step 3: Expire updated records')
            curs.execute(sql)
            logger.info('    => {} records affected'.format(curs.rowcount))
            conn.commit()


def _step4_insert_new_updated(conn, source_table, source_cols, target_table, key_fields, scd_date, scd_true_value,
                              scd_false_value, simulate=False):
    """
    Copy records from our source to target if they are not in our target table.

    At a glance this looks like it would only handle new records, but because we have already expired modified records,
    this SQL also copies the new version of modified records to the target table.

    :param conn:
    :param source_table:
    :param source_cols:
    :param target_table:
    :param key_fields:
    :param scd_date:
    :param scd_true_value:
    :return:
    """
    non_audit_field_names = list()
    for source_col in [c['name'] for c in source_cols]:
        if source_col in audit_fields:
            continue
        if source_col in redshift_reserved_keywords:
            non_audit_field_names.append('"{}"'.format(source_col))
        else:
            non_audit_field_names.append(source_col)

    sql = 'INSERT INTO {} (\n'.format(target_table)
    col_list = ', '.join(non_audit_field_names)
    col_list += ', curr_in, del_in, dw_eff_dt, dw_expr_dt, dw_load_ts'
    sql += '    ' + '\n    '.join(textwrap.wrap(col_list, 116))
    sql += '\n)\n'
    sql += 'SELECT\n'

    col_list = 'stg.' + ', stg.'.join(non_audit_field_names)
    col_list += ', {} AS curr_in'.format(scd_true_value)
    col_list += ', {} AS del_in'.format(scd_false_value)
    col_list += ', NVL2(scd_expired.{field_name}, DATE \'{scd_date}\', DATE \'1900-01-01\') AS dw_eff_dt'.format(
        field_name=key_fields[0], scd_date=scd_date.strftime('%Y-%m-%d'))
    col_list += ', DATE \'9999-12-31\' AS dw_expr_dt'
    col_list += ', SYSDATE AS dw_load_ts'

    sql += '    ' + '\n    '.join(textwrap.wrap(col_list, 116))
    sql += '\nFROM\n'
    sql += '    {} stg\n'.format(source_table)
    sql += 'LEFT OUTER JOIN\n'
    sql += '    {} scd_expired\n'.format(target_table)

    join_clauses = list()
    for key_field in sorted(key_fields):
        join_clauses.append('stg.{field_name} = scd_expired.{field_name}'.format(
            field_name=key_field,
            target_table=target_table))
    sql += '    ON  ' + '\n    AND '.join(join_clauses)
    sql += '\n    AND scd_expired.dw_expr_dt = DATE \'{}\'\n'.format(
        (scd_date - timedelta(days=1)).strftime('%Y-%m-%d'))

    sql += 'WHERE NOT EXISTS (\n'
    sql += '    SELECT True\n'
    sql += '    FROM {} scd\n'.format(target_table)

    join_clauses = list()
    for key_field in sorted(key_fields):
        join_clauses.append('scd.{field_name} = stg.{field_name}'.format(
            field_name=key_field,
            target_table=target_table))
    sql += '    WHERE ' + '\n      AND '.join(join_clauses)
    sql += '\n      AND scd.dw_expr_dt = DATE \'9999-12-31\'\n'
    sql += '    )'

    logger.debug('_step4_insert_new_updated SQL:\n\n' + sql + '\n')
    if not simulate:
        with conn.cursor() as curs:
            logger.info('Step 4: Inserting new/updated records')
            curs.execute(sql)
            logger.info('    => {} records affected'.format(curs.rowcount))
            conn.commit()


def validate_pk(conn, fq_table_name, key_fields, filter_on_unexpired):
    quoted_field_names = list()
    for key_field in [k.lower() for k in key_fields]:
        if key_field in redshift_reserved_keywords:
            quoted_field_names.append('"{}"'.format(key_field))
        else:
            quoted_field_names.append(key_field)
    sql = 'SELECT {}\n'.format(', '.join(quoted_field_names))
    sql += 'FROM {}\n'.format(fq_table_name)
    if filter_on_unexpired:
        sql += 'WHERE dw_expr_dt = DATE \'9999-12-31\'\n'
    sql += 'GROUP BY {}\n'.format(', '.join(quoted_field_names))
    sql += 'HAVING COUNT(*) > 1\n'
    sql += 'LIMIT 5'
    with conn.cursor() as curs:
        logger.info('Validating nPK ({}) on {}'.format(', '.join(quoted_field_names), fq_table_name))
        curs.execute(sql)
        row = curs.fetchone()
        if not row:
            logger.info('    => No duplicates found')
            return True

        logger.error('Duplicate records found, showing first five:')
        while row:
            row_display = ''
            for i, quoted_field_name in enumerate(quoted_field_names):
                if len(row_display) > 0:
                    row_display += ', '
                row_display += '{} => [{}]'.format(quoted_field_name, row[i])
            logger.error('    ' + row_display)
            row = curs.fetchone()

        return False


def merge(fq_source_table_name, fq_target_table_name, key_fields, scd_date, ignore_fields=None, skip_deletes=False,
          simulate=False, conn=None):
    """
    Performs an SCD type 2 merge from a source table to a target table.

    :param fq_source_table_name: Source table name
    :param fq_target_table_name: Target SCD table name
    :param key_fields: Primary key fields in the source table
    :param scd_date: Date that is used to set the effective and expiration dates
    :param ignore_fields: Fields to ignore when comparing the source and target tables
    :param skip_deletes: Skip steps that expire records that are not in the source table
    :param simulate: Don't execute any SQL that changes the database
    :param conn: Redshift connection
    :return:
    """
    close_connection = False
    if not conn:
        close_connection = True
        conn = redshift_modules.redshift_connect()

    conn.set_session(autocommit=False)

    source_cols = redshift_modules.get_table_columns(conn, fq_source_table_name)
    if not source_cols:
        raise ValueError(fq_source_table_name + ': No columns found')

    target_cols = redshift_modules.get_table_columns(conn, fq_target_table_name)
    if not target_cols:
        raise ValueError(fq_target_table_name + ': No columns found')

    # Make sure all columns in our source table are also in our production table
    source_col_names = set([c['name'] for c in source_cols])
    target_col_names = set([c['name'] for c in target_cols])
    missing_cols = source_col_names.difference(target_col_names)
    if missing_cols:
        raise ValueError('{}: missing columns: {}'.format(fq_target_table_name, ', '.join(sorted(missing_cols))))

    key_fields_lowercase = [k.lower() for k in key_fields]
    ignore_fields_lowercase = None
    if ignore_fields:
        ignore_fields_lowercase = [k.lower() for k in ignore_fields]

    # Make sure our key fields exist in both the source and target tables
    missing_key_fields = set(key_fields_lowercase).difference(set(source_col_names))
    if missing_key_fields:
        raise ValueError('{}: missing key field(s): {}'.format(
            fq_source_table_name,
            ', '.join(sorted(missing_key_fields))))

    missing_key_fields = set(key_fields_lowercase).difference(set(target_col_names))
    if missing_key_fields:
        raise ValueError('{}: missing key field(s): {}'.format(
            fq_target_table_name,
            ', '.join(sorted(missing_key_fields))))

    # Figure out what data type our CURR_IN column uses
    curr_in_col = None
    for target_col in target_cols:
        if target_col['name'] == 'curr_in':
            curr_in_col = target_col
            break
    if not curr_in_col:
        raise ValueError('{}.curr_in: No such field'.format(fq_target_table_name.lower()))
    if curr_in_col['type'] in ('smallint', 'integer', 'bigint'):
        scd_true_val = '1'
        scd_false_val = '0'
    elif curr_in_col['type'] == 'character varying':
        scd_true_val = "'True'"
        scd_false_val = "'False'"
    elif curr_in_col['type'] == 'boolean':
        scd_true_val = "True"
        scd_false_val = "False"
    else:
        raise ValueError('{}.curr_in: Unexpected data type {}'.format(fq_target_table_name, curr_in_col['type']))

    if not validate_pk(conn, fq_source_table_name, key_fields, False):
        logger.error('Source table contains duplicates')
        sys.exit(1)
    if not validate_pk(conn, fq_target_table_name, key_fields, True):
        logger.error('SCD table contains duplicates')
        sys.exit(1)

    if not skip_deletes:
        _step1_expire_deleted(conn, fq_source_table_name, fq_target_table_name, target_cols, key_fields_lowercase,
                              scd_date, scd_true_val, scd_false_val, simulate)

        _step2_expire_deleted_placeholders(conn, fq_source_table_name, fq_target_table_name, key_fields, scd_date,
                                           scd_true_val, scd_false_val, simulate)

    _step3_expire_updated(
        conn=conn,
        source_table=fq_source_table_name,
        source_cols=source_cols,
        target_table=fq_target_table_name,
        target_cols=target_cols,
        key_fields=key_fields_lowercase,
        scd_date=scd_date,
        scd_false_value=scd_false_val,
        ignore_fields_lowercase=ignore_fields_lowercase,
        simulate=simulate)

    _step4_insert_new_updated(conn, fq_source_table_name, source_cols, fq_target_table_name, key_fields_lowercase,
                              scd_date, scd_true_val, scd_false_val, simulate)

    analyze_sql = 'ANALYZE ' + fq_target_table_name
    logger.info(analyze_sql)
    redshift_modules.exec_query(analyze_sql, conn=conn)

    if close_connection:
        conn.close()
