import copy
import hmac
import hashlib
import json
import logging
import requests
import time

from functools import wraps
from time import sleep

PAUSE_TIME = 30
API_ATTEMPTS = 5

# Log Config
logging.basicConfig(level=logging.INFO)


def get_next_url(res):
    try:
        next_url = res["paging"]["next"]
    except KeyError:
        next_url = None
    return next_url


def api_retry(func):
    """Decorator for API calls"""
    def retried_func(*args, **kwargs):
        tries = 0
        while True:
            resp = func(*args, **kwargs)
            if not resp.ok and tries < API_ATTEMPTS:
                print resp.text
                tries += 1
                time.sleep(PAUSE_TIME)
                continue
            break
        return resp
    return retried_func


class GraphAPI(object):

    # Graph API url
    base_url = 'https://graph.facebook.com/v3.0/'

    def __init__(self, access_token=None, app_secret=None, appsecret_proof=None):

        if access_token is None or app_secret is None:
            raise GraphAPIError("Missing access token or app_secret")

        self.access_token = access_token
        self.app_secret = app_secret

        if appsecret_proof is None:
            logging.debug("Missing appsecret_proof, generating a new one...")
            self.appsecret_proof = self._gen_new_hash()
        else:
            self.appsecret_proof = appsecret_proof

    def _gen_new_hash(self):
        return hmac.new(self.app_secret,
                        self.access_token,
                        hashlib.sha256).hexdigest()

    def _add_auth_param(self, params=None):
        if params is None:
            params_auth = {}
        else:
            params_auth = copy.deepcopy(params)
        params_auth["access_token"] = self.access_token
        params_auth["appsecret_proof"] = self.appsecret_proof
        return params_auth


    def _next_request(self, url, params=None):
        logging.debug("Fetching next page")
        res = self._mk_request(url, params=params).text.encode('utf-8')

        # convert to json
        response = json.loads(res)
        if not self._is_error(response):
            return response, get_next_url(response)

        GraphAPIError(response)

    def _is_error(self, res):
        try:
            error = res['error']
        except KeyError:
            return False
        return True

    @api_retry
    def _mk_request(self, url, params):
        return requests.get(url, params=params, timeout=60)


    def request(self, end_points=None, params=None, paginate=None):

        logging.debug("Inside request")

        if params is None:
            params = {}

        # check if access_token is present in params
        if "access_token" not in params or "appsecret_proof" not in params:
            params = self._add_auth_param(params)

        if paginate:
            return self._next_request(paginate, params=params)

        url = self.base_url
        if end_points is not None:
            url = self.base_url + '/'.join(end_points)

        logging.debug("Request sent to ".format(url))
        res = self._mk_request(url, params=params).text.encode('utf-8')

        response = json.loads(res)
        if not self._is_error(response):
            return response, get_next_url(response)

        GraphAPIError(response)


class GraphAPIError(Exception):
    def __init__(self, result):
        self.result = result
        self.code = None

        try:
            self.message = result["error"]["message"]
            self.code = result["error"].get("code")
            if not self.type:
                self.type = result["error"].get("type", "")
        except:
            self.message = result

        Exception.__init__(self, self.message)
