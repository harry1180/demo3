import os
import os.path

class FileUtils:
    @staticmethod
    def create_path(path):
        """
        Creates a directory structure for the given path on the local fs.
        """
        if not os.path.exists(path):
            try:
                os.makedirs(path)
            except OSError as e:
                print e

    @staticmethod
    def replace_path(path, sub_path):
        """
        Given the path, remove the colliding sub_path.

        @param path - The original path that contains the sub_path
        @param sub_path - A sub_path of path
        """
        # Add trailing slash if none
        sub_path = os.path.join(sub_path, '')

        return path.replace(sub_path, "")

