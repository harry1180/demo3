import sys, os
from urlparse import urlparse
from urlparse import parse_qs
from user_agents import parse
from datetime import date
from datetime import datetime
from datetime import timedelta
from nw_url_check import *
import tldextract
import logging
import fileinput
import glob
import json
#import ipdb
import yaml
logging.basicConfig()


sample_record = {
    "cookieId": "eddc596d",
    "environment": 2,
    "eventName": 1,
    "guid": "12a6c62518264360bb5051534fcfea75",
    "ip": "71.162.204.62",
    "pageviewId": "0nh43muq67bn",
    "referrer": "https://www.google.com/",
    "timestamp": 1435787980408,
    "url": "http://www.nerdwallet.com/finance/question/my-credit-limit-is-300-can-i-spend-150-once-pay-it-back-within-time-spend-200-again-pay-it-back-within-the-same-month-does-that--9155",
    "userAgent": "Mozilla/5.0 (iPhone; CPU iPhone OS 8_3 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12F70 Safari/600.1.4",
    "userId": "guest",
    "userType": 1
}





def json_extract_row(source_record,extract_field):
    """ Call this meathod to extract a desided field from the dictonary that is passed. This meathod will accept two parameters as Input
    1) Source Record which is nothing but an input dictonary
    2) The field that needs to be extracted. The name of the field needs to be exactly the same as the key value in the dictonary
    """
    try:
        return source_record[extract_field]
    except KeyError:
        return ''





def parse_useragent(input_user_agent):
    """ Call this meathod to extract the actual useragent. At present this function splits the useragent on [, to remove facebook details
    1) It accepts useragent as an input
    """
    ua_dict = {}
    try:
        ua_dict.update({'dw_user_agent':input_user_agent.split('[')[0].strip(' ')})
        return ua_dict
    except ValueError:
        ua_dict.update({'ua':input_user_agent})
        return ua_dict
    except UnicodeEncodeError:
        ua_dict.update({'ua':input_user_agent})
        return ua_dict




keys = {'dw_ref_keys':['REF_KEY','REF_PAGE']}
tags= {'dw_utm_tags':['UTM_SRC','UTM_MED', 'UTM_CAMP', 'UTM_CONT', 'UTM_TERM']}
UTM_MEDS={'dw_utm_meds':['UTM_MED','utm_medium']}
UTM_HP_REFS={'dw_utm_hp_refs':['utm_hp_ref']}
UTM_SRSS={'dw_utm_srss':['UTM_SRC','utm_source']}
UTM_TERMS={'dw_utm_terms':['UTM_TERM','utm_term']}
UTM_CONTS={'dw_utm_conts':['UTM_CONT','utm_content']}
UTM_CAMPS={'dw_utm_camps':['UTM_CAMP','utm_campaign']}
REF_PAGS={'dw_ref_pags':['REF_PAG']}
REF_KEYS={'dw_ref_keys':['REF_KEY']}






def get_utm_key_value(input_list,search):
    """Call this meathod to extract UTM_CODES. This meathod accepts two inputs
    1) Input Dict of UTM codes that were parsed from URL
    2) Search Dict. This dict is already hardcoded in the main funtion file. If the list need to be edited to the path to edit this file
    """
    try:
        for value in search.values()[0]:
            for key in input_list.keys():
                if value == key:
                    out_utm = input_list[key]
                    if isinstance(out_utm,list):
                        return out_utm[0]
                    else:
                        return out_utm
        return ''
    except UnicodeEncodeError:
        return ''




def parse_url_confirmed_utm(input_url,url_type):
    """Call this meathod to extract the utm codes and confirmed url in Dict format. This meathod will internally call the get_utm_key_value meathod. It requires 2 inputs
    1) Input URL. The url need to be passed a the first parameter
    2) We need to tell if this a regular or referral url. You need to makesure to specify regular collectly as Reg. If this is not apecified it will default it to Referral
    """
#    input_url.encode('ascii', 'ignore')
    dw_url_utm_parse_dict = {}
    dw_ref_utm_parse_dict = {}
    if url_type == 'Reg':
        fixed_url = url_strip(fix_nw_url(input_url))
        parsed_confirmed_url = conform_url(fixed_url)
    else :
        parsed_confirmed_url = urlparse(input_url)
    try:
        final_confirmed_url = url_strip(nw_url_join(parsed_confirmed_url.scheme,parsed_confirmed_url.netloc,parsed_confirmed_url.path))
    except UnicodeEncodeError:
        final_confirmed_url = url_strip(input_url)
    final_confirmed_path = url_strip(parsed_confirmed_url.path)
    final_confirmed_query = parsed_confirmed_url.query
    final_confirmed_scheme = parsed_confirmed_url.scheme
    final_confirmed_netloc = parsed_confirmed_url.netloc
    qs_dict=parse_qs(final_confirmed_query)
    utm_src=get_utm_key_value(qs_dict,UTM_SRSS)
    utm_med=get_utm_key_value(qs_dict,UTM_MEDS)
    utm_camp=get_utm_key_value(qs_dict,UTM_CAMPS)
    utm_cont=get_utm_key_value(qs_dict,UTM_CONTS)
    utm_term=get_utm_key_value(qs_dict,UTM_TERMS)
    utm_hp_ref=get_utm_key_value(qs_dict,UTM_HP_REFS)
    url_sub_domain=tldextract.extract(parsed_confirmed_url.netloc).subdomain
    url_site_nm=tldextract.extract(parsed_confirmed_url.netloc).domain
    url_domain_sfx=tldextract.extract(parsed_confirmed_url.netloc).suffix
    final_url_is_valid = validate_url_struct(final_confirmed_url)
    if url_type == 'Reg':
        url_dict = {'final_confirmed_url':final_confirmed_url,
                    'final_confirmed_path':final_confirmed_path,
                    'final_confirmed_query':final_confirmed_query,
                    'dw_utm_src':utm_src,
                    'dw_utm_med':utm_med,
                    'dw_utm_camp':utm_camp,
                    'dw_utm_cont':utm_cont,
                    'dw_utm_term':utm_term,
                    'dw_utm_hp_ref':utm_hp_ref,
                    'dw_url_scheme':final_confirmed_scheme,
                    'dw_url_netloc':final_confirmed_netloc,
                    'dw_url_sub_domain':url_sub_domain,
                    'dw_url_site_nm':url_site_nm,
                    'dw_url_domain_sfx':url_domain_sfx,
                    'dw_url_is_valid':final_url_is_valid}
        dw_url_utm_parse_dict.update(url_dict)
        return dw_url_utm_parse_dict
    else:
        ref_dict = {'ref_final_confirmed_url':final_confirmed_url,
                    'ref_final_confirmed_path':final_confirmed_path,
                    'ref_final_confirmed_query':final_confirmed_query,
                    'ref_dw_utm_src':utm_src,
                    'ref_dw_utm_med':utm_med,
                    'ref_dw_utm_camp':utm_camp,
                    'ref_dw_utm_cont':utm_cont,
                    'ref_dw_utm_term':utm_term,
                    'ref_dw_utm_hp_ref':utm_hp_ref,
                    'ref_dw_url_scheme':final_confirmed_scheme,
                    'ref_dw_url_netloc':final_confirmed_netloc,
                    'ref_dw_url_sub_domain':url_sub_domain,
                    'ref_dw_url_site_nm':url_site_nm,
                    'ref_dw_url_domain_sfx':url_domain_sfx,
                    'ref_dw_url_is_valid':final_url_is_valid}
        dw_ref_utm_parse_dict.update(ref_dict)
        return dw_ref_utm_parse_dict






def parse_page_event_record(input_record):
    """This meathod is a wrapper of all the below meathod. It accepts only one parameter. i.e Input Dict.
    1) json_extract_row
    2) parse_useragent
    3) parse_url_confirmed_utm
    It call the above meathod and will spit out the Dictonary with all the values that are needed for Page view event
    """
    parsed_page_dict = {}
    src_user_agent = json_extract_row(input_record,'userAgent')
    src_url = json_extract_row(input_record,'url')
    ref_url = json_extract_row(input_record,'referrer')
    useragent_dict = parse_useragent(src_user_agent)
    src_url_dict = parse_url_confirmed_utm(src_url,'Reg')
    ref_url_dict = parse_url_confirmed_utm(ref_url,'Ref')
    parsed_page_dict.update(input_record)
    parsed_page_dict.update(useragent_dict)
    parsed_page_dict.update(src_url_dict)
    parsed_page_dict.update(ref_url_dict)
    return parsed_page_dict
