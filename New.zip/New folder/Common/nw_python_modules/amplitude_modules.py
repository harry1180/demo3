import sys
import csv
import json
import requests
import time

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

sys.path.append('/data/etl/Common/nw_python_modules/json_modules')
from json_utils import is_json_dict


def generate_nested_json_dict(input_json_dict, amp_data_dict_template, nested_json_dict_key):
    """ 
    Call method:
    generate_nested_json_dict('input_json_dict', 'amplitude_json_dict_mapping', 'amplitude_nested_json_dict_key')
    Use this function to assign values to nested keys at Amplitude json dict, like 'event_properties'
    """
    output_dict = amp_data_dict_template[nested_json_dict_key].copy()
    for amp_data_dict_key in amp_data_dict_template[nested_json_dict_key].keys():
        for input_dict_key in input_json_dict.keys():
            if input_dict_key == amp_data_dict_template[nested_json_dict_key][amp_data_dict_key]:
                output_dict.update({amp_data_dict_key:input_json_dict[input_dict_key]}) 
    return output_dict


def set_none_to_output_key(i_json_dict, i_key_name, o_key_name):
    """ 
    Call method:
    set_none_to_output_key('input_json_dict', 'input_json_dict_key_name', 'output_key_name')
    Use this function to set None/null value to a specific output key
    """
    if i_json_dict[i_key_name] is None:
        return {o_key_name:None}
    elif (i_json_dict[i_key_name].lower() == 'guest' or i_json_dict[i_key_name].strip(' ') == ""):
        return {o_key_name:None}    


def convert_csv_to_amp_json(csv_file, field_name_list, json_file, amp_data_dict):
    """ 
    Call method:
    convert_csv_to_amp_json(csv_file='nerdwallet_output_csv_file', field_name_list='nerdwallet_output_file_field_list', json_file='amplitude_api_format_json_file', amp_data_dict='amplitude_json_dict_mapping')
    Use this function to send convert csv file to json-dict data following Amplitude api and json-dict format
    """
    csv_file_handle  = open(csv_file, 'r')
    json_file_handle = open(json_file, 'w')

    reader = csv.DictReader( csv_file_handle, field_name_list )
    
    cnt_of_read = 0 
    cnt_of_cvrt = 0 
    
    for nw_dict in reader:
        amp_dict     = amp_data_dict.copy()
        cnt_of_read += 1 
 
        for nw_dict_key in nw_dict.keys():
            for amp_dict_key in amp_data_dict.keys():
                if nw_dict_key == amp_data_dict[amp_dict_key]:
                    if nw_dict[nw_dict_key] is None:
                        amp_dict.update(set_none_to_output_key(nw_dict, nw_dict_key, amp_dict_key))
                    elif (nw_dict[nw_dict_key].lower() == 'guest' or nw_dict[nw_dict_key].strip(' ') == ""):
                        amp_dict.update(set_none_to_output_key(nw_dict, nw_dict_key, amp_dict_key))
                    else:
                        amp_dict.update({amp_dict_key:nw_dict[nw_dict_key]})
                elif is_json_dict(amp_data_dict[amp_dict_key]):
                    amp_nested_dict = generate_nested_json_dict(nw_dict, amp_data_dict, amp_dict_key)
                    amp_dict.update({amp_dict_key:amp_nested_dict})
                else:
                    ##keep default values like event name at the key 'event_type'
                    #amp_dict.update({amp_dict_key:amp_data_dict[amp_dict_key]})
                    pass
        
        json.dump(amp_dict, json_file_handle, sort_keys=True)
        json_file_handle.write("\n")
        cnt_of_cvrt += 1
        if cnt_of_cvrt % 900 == 0:
            print "Progress update - read lines: " + str(cnt_of_read) 
            print "Progress update - cvrt lines: " + str(cnt_of_cvrt)
        amp_dict     = {}
    
    csv_file_handle.close()
    json_file_handle.close()
    print "----------------- read lines: " + str(cnt_of_read) 
    print "----------------- cvrt lines: " + str(cnt_of_cvrt)
    print "Progress update - converting csv to json Completed."


def send_data_to_amplitude(amp_api_url, amp_api_key, input_json_file, data_type, unsent_json_file):
    """ 
    Call method:
    send_event_data_to_amplitude('https://api.amplitude.com/httpapi', 'amplitude_api_key', 'amplitude_api_format_json_file', 'event', 'amplitude_api_format_json_file.unsent')
    Use this function to send json-dict data to Amplitude line by line;
    @data_type can be 'event', 'identification', etc, according to Amplitude
    """
    cnt_of_read = 0 
    cnt_of_sent = 0 
    
    unsent_json_file_handle = open(unsent_json_file, 'w')

    sess = requests.Session()
    with open(input_json_file) as f:
        for line in f:
            cnt_of_read += 1 
            amp_data = data_type + '=[' + line.strip('\n') + ']'
            #amp_data = 'event=[' + str(json.loads(line)) + ']' # dont work coz None as a value
            #print amp_data
            try:
                r = sess.post(amp_api_url, params=amp_api_key, data=amp_data)
                if r.status_code == 200:
                    cnt_of_sent += 1
                else:
                    # stop print line to log since it will be recorded at the .unsent file
                    #print "Failed to load " + line.strip('\n')
                    print "Return    code " + str(r.status_code)
                    print "Return message " + r.text
                    print "Re-try in 1 second "
                    time.sleep(1)
                    r = sess.post(amp_api_url, params=amp_api_key, data=amp_data)
                    if r.status_code == 200:
                        cnt_of_sent += 1
                    else:
                        print "Return    code " + str(r.status_code)
                        print "Return message " + r.text
                        ## keep record of unsent json-dict for outside processing, like using curl to post
                        unsent_json_file_handle.write(line)
                        
            except requests.exceptions.MissingSchema:
                print 'Exception MissingSchema'
                unsent_json_file_handle.write(line)
            except requests.exceptions.URLRequired:
                print 'Exception URLRequired'
                unsent_json_file_handle.write(line)
            except requests.exceptions.Timeout:
                print 'Exception Timeout'
                unsent_json_file_handle.write(line)
            except requests.exceptions.HTTPError:
                print 'Exception HTTPError'
                unsent_json_file_handle.write(line)
            except requests.exceptions.ConnectionError:
                print 'Exception ConnectionError'
                unsent_json_file_handle.write(line)
            except requests.exceptions.TooManyRedirects:
                print 'Exception TooManyRedirects'
                unsent_json_file_handle.write(line)
            except urllib3.exceptions.LocationParseError:
                print 'Exception LocationParseError'
                unsent_json_file_handle.write(line)
            except:
                print 'Exception Happens'
                unsent_json_file_handle.write(line)
            
            if cnt_of_sent % 900 == 0:
                print "Progress update - read lines: " + str(cnt_of_read) 
                print "Progress update - sent lines: " + str(cnt_of_sent) 
                time.sleep(2)

    print "Read from file " + input_json_file + " -- Summary --" 
    print "Total read lines: " + str(cnt_of_read) 
    print "Total sent lines: " + str(cnt_of_sent)
    unsent_json_file_handle.close()
