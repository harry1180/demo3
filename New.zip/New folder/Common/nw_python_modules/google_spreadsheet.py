import codecs
import datetime
import httplib2
import os
import re
import six
import string
import csv
import logging

from apiclient import discovery
from oauth2client.file import Storage

import s3_modules
import redshift_modules
from redshift_modules import exec_query
import unicode_csv


# Regex to capture spreadsheet ID
RE_GOOGLE_URL_ID = re.compile(r'.+/spreadsheets/d/([a-zA-Z0-9-_]+)')

# API Resource Constants
DISCOVERY_URL = 'https://sheets.googleapis.com/$discovery/rest?version=v4'
SERVICE_NAME = 'sheets'
SERVICE_VERSION = 'v4'

# Creds
GS_CREDS_FILE = '/etc/dwh_secured_tokens/gs_credentials.json'
# not a typo, the "K" should be capital for s3_prod_secret_Key
S3_SECRET_KEY = redshift_modules.fetch_creds('s3_prod_secret_Key').strip()
S3_ACCESS_KEY = redshift_modules.fetch_creds('s3_prod_access_key').strip()
S3_LOAD_CREDS = redshift_modules.fetch_creds('s3_prod_load_creds').strip()

# Disable info level messages from google api
logging.getLogger('googleapiclient.discovery').setLevel(logging.WARNING)


def _write_to_csv(writer_obj, contents, format_fields=True, remove_fields=[], header_fields=None,
                  skipheader=False, skiprows=0):
    for i, values in enumerate(contents):

        # Skip all rows specified by 'skiprows'
        if i < skiprows:
            continue

        # Special handling for first row of gs after 'skiprows' no. of rows
        if i == skiprows:

            # If no gs_header passed in, assume first gs row is gs_header, otherwise
            # specify gs_header parameter (must be same length as values)
            if not header_fields:
                header_fields = values

            # Optionally skip writing the header to file
            if skipheader:
                continue

            if format_fields:
                out_header = [redshift_modules.format_sql_column(field) for field in header_fields if
                              field not in remove_fields]
            else:
                out_header = [str(field) for field in header_fields if field not in remove_fields]

            # Write header for output file
            writer_obj.writerow(out_header)
            continue

        # add trailing empty cells
        diff = len(header_fields) - len(values)
        values += [''] * diff
        row = []
        for num, entry in enumerate(header_fields):
            if entry not in remove_fields:
                row.append(values[num].replace('"', '\\"').replace('\n', ''))

        writer_obj.writerow(row)


def get_id_from_url(url):
    """
    Parses sheet ID from google spreadsheet URL

        Input: https://docs.google.com/spreadsheets/d/1_1RJR76cJcf9BL4gHJf_wnE6RmNTNLghFgGvciSro/
        Return: 1_1RJR76cJcf9BL4gHJf_wnE6RmNTNLghFgGvciSro

    :param url: string, spreadsheet URL
    :return: string, spreadsheet ID
    """

    # TODO: error handling
    return RE_GOOGLE_URL_ID.match(url).group(1)


def gs_to_csv(url, file_out, worksheet=None, gs_header=None, remove_fields=[], format_fields=True, delimiter='\t',
              skiprows=0, append=False):
    """
    Convert Google spreadsheet to CSV with unicode support. By default, the Google spreadsheet API returns
    contents of spreadsheet with UTF-8 encoding. Therefore, this method assumes that the data is UTF-8.

    :param url: Spreadsheet url
    :param file_out: string, file path of output csv (defaults to gid.txt)
    :param worksheet: string/list, name(s) of worksheet to parse. If None, all sheets will be read in and appended to
    the same output file. This assumes that each sheet has the same format.
    :param gs_header: list, list of column headers (optional -- if not used,
    it is assumed that headers are the first row in spreadsheet)
    :param remove_fields: list, names of column headers not to include in csv
    :param format_fields: bool, True: make header fields sql compliant (i.e. "First Name" --> "first_name")
                                False: leave header fields as is in sheet
    :param delimiter: delimiter for output file
    :param skiprows: int, number of rows before the header row that you wish to skip (defaults to 0)
    :param append: bool, True: all specified worksheets will be appened to same output file
                         False: each specified worksheet will have it's own file

    Sample Calls:
        gs_to_csv(url=URL, file_out='/path/to/output.txt', worksheet='Sheet1', remove_fields=["Email"], skiprows=1)

        gs_to_csv(url=URL, file_out='/path/to/output.txt', worksheet=['Sheet1', 'Sheet1'], append=True)
            --> output files from this call will look like
                    /path/to/output_Sheet1.txt
                    /path/to/output_Sheet2.txt
    """

    # Validation
    assert isinstance(url, six.string_types)
    assert isinstance(format_fields, bool)
    assert isinstance(append, bool)
    assert isinstance(remove_fields, list)
    assert isinstance(skiprows, int)
    if gs_header:
        assert isinstance(gs_header, list)

    # Read in google spreadsheet
    gspread = GoogleSpreadsheet(url)

    if isinstance(worksheet, six.string_types):
        gs_data = {worksheet: gspread.read(worksheet)}
        append = True
    elif isinstance(worksheet, list):
        gs_data = {}
        for sheet in worksheet:
            gs_data[sheet] = gspread.read(sheet)
    elif worksheet is None:
        # read in all worksheets
        gs_data = {}
        all_sheets = [s['title'] for s in gspread.sheets]
        for sheet in all_sheets:
            gs_data[sheet] = gspread.read(sheet)
    else:
        raise GoogleSpreadsheetException('Invalid value for argument "worksheet"')

    if append:
        # Output contents of sheets(s) to the same CSV
        skip_header = False
        with open(file_out, mode='w') as output:
            csv_writer = unicode_csv.UnicodeWriter(output, delimiter=delimiter, quoting=csv.QUOTE_ALL, escapechar='\\')
            for sheetname, content_block in gs_data.iteritems():
                _write_to_csv(csv_writer, content_block, format_fields=format_fields,
                              remove_fields=remove_fields, header_fields=gs_header,
                              skipheader=skip_header, skiprows=skiprows)
                skip_header = True
    else:
        # Output contents of sheets(s) to separate CSVs
        # CSVs are named by taking the original input parameter and appending sheet name
        for sheetname, content_block in gs_data.iteritems():
            file_out_dir = os.path.dirname(file_out)
            file_out_name, file_out_ext = os.path.splitext(os.path.basename(file_out))
            file_out_new = os.path.join(file_out_dir, u'{}_{}_{}'.format(file_out_name, sheetname, file_out_ext))

            with open(file_out_new, mode='w') as output:
                csv_writer = unicode_csv.UnicodeWriter(output, delimiter=delimiter, quoting=csv.QUOTE_ALL, escapechar='\\')
                _write_to_csv(csv_writer, content_block, format_fields=format_fields,
                              remove_fields=remove_fields, header_fields=gs_header,
                              skiprows=skiprows)


def gs_to_table(url, schema, table, file_out_dir, delete_flag=False, s3_bucket='east1-prod-dwh-s3-0', s3_path='google_spreadsheet_upload',
                worksheet='Sheet1', gs_header=None, remove_fields=[], ):
    """
    Function to copy google spreadsheet to redshift table. As of now functionality is limited
    to append all contents of a specific worksheet to a table. Spreadsheet contents get output as
    CSV and stored on S3 before being loaded to table.

    :param url: str, Google Spreadsheet URL
    :param schema: str, redshift schema name
    :param table: str, redshift table name
    :param file_out_dir: str, location where to store the intermediate output CSV file
    :param worksheet: str, Name of worksheet to copy into table (default is 'Sheet1')
    :param gs_header: list, Optional names of columns on spreadsheet -- default is None and
    assumes the header is in the first row of the spreadsheet. If provided, the first row will
    be included in the data. The number of fields in the header list must be equal to the number
    of columns on the spreadsheet.
    :param remove_fields: list, Optional list of fields to exclude from the spreadsheet. Any fields
    in this list will not be included in the table. This should be used for any personally
    identifiable data. The names of fields must match to how they appear on the spreadsheet.
    :param s3_bucket: str, name of s3 bucket to store intermediate csv file
    :param s3_path: str, name of s3 folder to store intermediate csv file

    Example Call:
    url = "https://docs.google.com/spreadsheets/d/1_1RJR76cJcf9BL4gdtMRrRwnE6RmNTNLghFgGvciSro/edit?asdfwerasc"
    remove = ["Email Address"]
    gs.gs_to_table(url=url, worksheet='Sheet1', file_out_dir='/path/to/directory', remove_fields=remove,
                   gs_header=None, s3_bucket='east1-prod-dwh-s3-0', s3_path='google_spreadsheet_upload')
    """
    # Build s3 path
    s3_full_path = 's3://{}'.format(os.path.join(s3_bucket, s3_path))

    # Validate
    valid_table = redshift_modules.table_exists(schema=schema, table=table)
    if not valid_table:
        raise GoogleSpreadsheetException('Table must exist for loading spreadsheet')

    # define local temporary file
    local_file_name = '{}_{}.txt'.format(get_id_from_url(url), worksheet)
    file_out = os.path.join(file_out_dir, local_file_name)

    # clean up old local file if already exists
    if os.path.isfile(file_out):
        os.remove(file_out)

    # Convert gs to csv
    gs_to_csv(url, worksheet=worksheet, file_out=file_out, gs_header=gs_header, remove_fields=remove_fields)

    # move to s3
    s3_modules.s3_file_upload(local_file=file_out, s3_bucket=s3_bucket, s3_path=s3_path)
    
    # delete from table if specified
    if delete_flag:
        print "delete flag is set as ",delete_flag
        try:
            exec_query("delete from "+schema+"."+table)
        except Exception, e:
            print "--- WARNING --- deleting failed for "+schema+"."+table
            raise Exception(e)
            print str(e)
 
    # construct copy query
    copy_prefix = "copy {schema}.{table} from '{s3_path}/{file}'".format(schema=schema,
                                                                         table=table,
                                                                         s3_path=s3_full_path,
                                                                         file=local_file_name)
    creds_prefix = "credentials {load_creds}".format(load_creds=S3_LOAD_CREDS)
    options_prefix = "DELIMITER '\\t' DATEFORMAT AS 'auto' REMOVEQUOTES TRUNCATECOLUMNS ACCEPTINVCHARS BLANKSASNULL EMPTYASNULL IGNOREHEADER 1 COMPUPDATE ON ESCAPE FILLRECORD"
    query_stage_load = "{copy} {creds} {options};".format(copy=copy_prefix, creds=creds_prefix, options=options_prefix)

    # copy data from s3 to redshift
    redshift_modules.exec_query(query_stage_load)

    # clean up local file
    if os.path.isfile(file_out):
        os.remove(file_out)


def table_to_gs(url, sql_query, worksheet='Sheet1', value_format='RAW', gs_header_order=None):
    """
    Wrapper function to move the contents of a SQL Select query to a google spreadsheet.
    :param url: str, Google Spreadsheet URL
    :param sql_query: str, SQL select query
    :param worksheet: str, Name of worksheet to copy into table (default is 'Sheet1')
    :param value_format: string ['RAW' or 'USER_ENTERED'] -- Default: 'RAW'
            RAW: The input is not parsed and is simply inserted as a string, so the input "=1+2" places
                the string "=1+2" in the cell, not a formula.
            USER_ENTERED: The input is parsed exactly as if it were entered into the Google Sheets UI,
                so "Mar 1 2016" becomes a date, and "=1+2" becomes a formula. Formats may also be inferred,
                so "$100.15" becomes a number with currency formatting.
    :param gs_header_order: list, optional parameter to pass in ordered list of header fields -- NOTE: these field names must
    match the names of the columns returned by the select query.
    """

    # validate query
    if redshift_modules.query_types(sql_query)[-1] != 'select':
        raise GoogleSpreadsheetException('SQL must be a SELECT query only!')

    # Get data from table
    table_contents = redshift_modules.exec_query(sql_query, nan_to_null=True)

    # verify size constraints
    if not table_contents:
        logging.warning('No results returned from query. Nothing to load to spreadsheet.')
        return
    elif len(table_contents[0]) > 256 or (len(table_contents[0]) * len(table_contents)) > 400000:
        logging.error('Each Google Spreadsheet has a limit of 400,000 cells, with a maximum of 256 columns per sheet.')
        raise GoogleSpreadsheetException('Query results over size limit.')

    # Build list of lists to write to spreadsheet [[col1, col2, col3], [val1, val2, val3], ...]
    gs_values = []
    if not gs_header_order:
        gs_header_order = table_contents[0].keys()
    gs_values.append(gs_header_order)
    for row in table_contents:
        for field, value in row.iteritems():
            if type(value) in (datetime.date, datetime.datetime):
                row[field] = datetime.datetime.strftime(value, '%Y-%m-%d')
        gs_values.append([row[k] for k in gs_header_order])

    # call Google Spreadsheet module to write contents to spreadsheet
    GoogleSpreadsheet(url).write(gs_values, worksheet=worksheet, value_format=value_format)


class GoogleSpreadsheetException(Exception):
    pass


class GoogleSpreadsheet(object):
    """
    Class to interact with Google Spreadsheet. To initialize an instance of this class
    you need to pass in a valid Google Spreadsheet url. For authentication you need to
    have the $gs_auth_file env variable set and make sure that file exists.

    :param url: google spreadsheet id

    Sample Call (using fake URL):

    # Initialize class
    url = "https://docs.google.com/spreadsheets/d/1_1RJR76cJcf9BL4gdtMRrRwnE6RmNTNLghFgGvciSro/edit?asdfwerasc"
    spreadsheet = GoogleSpreadsheet(url)

    # Read in spreadsheet --> values will be a list of lists (rows) from the spreadsheet
    values = spreadsheet.read()
    """


    def __init__(self, url):

        # Set public attributes
        self.url = url
        self.gid = get_id_from_url(url)

        # Set private attributes
        self._service = self._authorize()
        self._properties = self._properties()

        self.sheets = [sheet['properties'] for sheet in self._properties['sheets']]


    def _authorize(self):
        """
        Authorize to interact with spreadsheet. OAuth 2.0 is the authorization
        protocol used by Google APIs.
        :param credentials: oauth2 object
        """
        if not os.path.exists(GS_CREDS_FILE):
            raise GoogleSpreadsheetException('Credentials file not found!')
        store = Storage(GS_CREDS_FILE)
        credentials = store.get()
        http = credentials.authorize(httplib2.Http())
        return discovery.build(SERVICE_NAME, SERVICE_VERSION, http=http, discoveryServiceUrl=DISCOVERY_URL)


    def read(self, worksheet):
        """
        Method to read in all contents of spreadsheet.
        :param worksheet: string, name of worksheet
        :return: list containing rows of data from spreadsheet
        """

        # Data
        contents = self._service.spreadsheets().values().get(spreadsheetId=self.gid, range=worksheet).execute()
        return contents['values']


    def write(self, values, worksheet, value_format='RAW', start_col='a', start_row='1', end_col=None, end_row=None):
        """
        Write contents to worksheet. This will overwrite any existing values on the worksheet
        that overlap with the given or determined data range.

        :param values: list of lists, matrix of data values to write
        :param worksheet: str, name of worksheet (i.e. tab name) --> this worksheet must already exist
        :param value_format: string ['RAW' or 'USER_ENTERED'] -- Default: 'RAW'
            RAW: The input is not parsed and is simply inserted as a string, so the input "=1+2" places
                the string "=1+2" in the cell, not a formula.
            USER_ENTERED: The input is parsed exactly as if it were entered into the Google Sheets UI,
                so "Mar 1 2016" becomes a date, and "=1+2" becomes a formula. Formats may also be inferred,
                so "$100.15" becomes a number with currency formatting.
        :param start_col: str, default ('a'), name of column where data should begin
        :param start_row: str, default ('1'), row number where data should begin
        :param end_col: str, optional, set column where data should end
        :param end_row: str, optional, set row where data should end
        """
        # Verify value_format parameter
        value_format = value_format.upper()
        if value_format not in ['RAW', 'USER_ENTERED']:
            raise GoogleSpreadsheetException('value_format must be one of [\'RAW\', \'USER_ENTERED\']')

        # Verify that values are list of lists
        if not all(isinstance(v, list) for v in values):
            raise GoogleSpreadsheetException('Values must be a list of list in order to write to spreadsheet')

        # Build range string by examining size of incoming values.
        # Google Sheets API requires a valid range to insert data into a spreadsheet (i.e. 'A1:AB:256')
        if not end_col:
            if len(values[0]) <= 26:
                end_col = string.lowercase[len(values[0]) - 1]
            else:
                leading_char = string.lowercase[(len(values[0]) / 26) - 1]
                trailing_char = string.lowercase[(len(values[0]) % 26) - 1]
                end_col = '{}{}'.format(leading_char, trailing_char)
        if not end_row:
            end_row = str(len(values))
        range_str = '{worksheet}!{start_col}{start_row}:{end_col}{end_row}'.format(worksheet=worksheet,
                                                                                   start_col=start_col,
                                                                                   start_row=start_row,
                                                                                   end_col=end_col,
                                                                                   end_row=end_row)

        body = {'values': values}
        self._service.spreadsheets().values().update(spreadsheetId=self.gid, valueInputOption=value_format,
                                                     range=range_str, body=body).execute()


    def add_worksheet(self, title):
        """
        Add a worksheet to an already existing spreadsheet.
        :param title: title of worksheet (i.e. tab name)
        """

        # Build body
        body = {
            'requests': [
                {
                    'addSheet':
                        {
                            'properties':
                                {
                                    'title': title
                                }
                        }
                }
            ]
        }
        self._service.spreadsheets().batchUpdate(spreadsheetId=self.gid, body=body).execute()


    def sheet_exists(self, worksheet):
        """
        Check if worksheet exists on spreadsheet.
        :param worksheet: str, name of worksheet
        """
        for sheet in self.sheets:
            if sheet['title'].lower() == worksheet.lower():
                return True
        return False


    def _properties(self):
        """
        Method to get spreadsheet properties
        :return: dictionary containing properties
        """

        # Meta Data
        return self._service.spreadsheets().get(spreadsheetId=self.gid).execute()
