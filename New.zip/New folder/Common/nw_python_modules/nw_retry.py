import requests
import time
from functools import wraps


REQUEST_EXCEPTIONS = (requests.RequestException, requests.ConnectionError, requests.HTTPError,
                      requests.URLRequired, requests.TooManyRedirects, requests.ConnectTimeout,
                      requests.ReadTimeout, requests.Timeout, requests.exceptions.SSLError)


def nw_retry(exception_to_check, tries=3, delay=3, backoff=2, logger=None, conditional_retry_callback=None):
    """Retry a function using an exponential backoff.

    original from: http://www.saltycrane.com/blog/2009/11/trying-out-retry-decorator-python/

    :param exception_to_check: Exception or tuple, the exception to check. may be a tuple of exceptions to check
    :param tries: int, number of times to try (not retry) before giving up
    :param delay: int, initial delay between retries in seconds
    :param backoff: int, backoff multiplier e.g. value of 2 will double the delay each retry
    :param logger: logger to use. If None, print
    :param conditional_retry_callback: Function used to indicate if a retry should be attempted
    :type logger: logging.Logger instance
    """

    def deco_retry(f):

        @wraps(f)
        def f_retry(*args, **kwargs):
            mtries, mdelay = tries, delay
            while mtries > 1:
                try:
                    return f(*args, **kwargs)
                except exception_to_check as e:
                    if conditional_retry_callback is not None:
                        if not callable(conditional_retry_callback):
                            raise ValueError('nw_retry.conditional_retry_callback must be a callable function')
                        if not conditional_retry_callback(e):
                            raise e
                    msg = "%s, Retrying in %d seconds..." % (str(e).rstrip(), mdelay)
                    if logger:
                        logger.warning(msg)
                    else:
                        print msg
                    time.sleep(mdelay)
                    mtries -= 1
                    mdelay *= backoff
            return f(*args, **kwargs)

        return f_retry  # true decorator

    return deco_retry
