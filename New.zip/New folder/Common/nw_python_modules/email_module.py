from email.MIMEMultipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.MIMEText import MIMEText
from email.mime.text import MIMEText
from subprocess import Popen, PIPE
from os.path import basename


def attach_file(msg, attachment):
    """
    Add file as attachment to email message
    :param msg: MIMEMultipart object
    :param attachment: str, path of file to attach
    """
    filename = attachment
    with open(filename, "rb") as fil:
        part = MIMEApplication(
            fil.read(),
            Name=basename(filename)
        )
        part['Content-Disposition'] = 'attachment; filename="%s"' % basename(filename)
        msg.attach(part)


def send_email(email_info):
    """
    Send email using email info template dictionary
    :param email_info: dict
        email_info = {
                        "from": ,
                        "to": ,
                        "subject": "",
                        "body": "",
                        "attachment": ""
                     }

    """
    msg = MIMEMultipart()

    # email send info
    msg['From'] = email_info['from']
    msg['To'] = email_info['to']
    msg['Subject'] = email_info['subject']
    msg.attach(MIMEText(email_info['body']))

    # attach file
    email_attachment = email_info['attachment']
    if email_attachment:
        if isinstance(email_attachment, list):
            for part in email_attachment:
                attach_file(msg, part)
        else:
            attach_file(msg, email_attachment)
    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    p.communicate(msg.as_string())
