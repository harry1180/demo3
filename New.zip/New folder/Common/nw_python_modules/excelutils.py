import datetime
import sys
import xml.etree.ElementTree as ET

import ujson
import pandas as pd

reload(sys)

def excel2csv(input_excel_file,output_csv_file,skip_header=1):
     '''This function accepts three inputs 
     1) Input excel file 
     2) Output csv file 
     3) Skip header (by default the header is not skipped)
     The index value from the pandas is set to false in the function.
     Default delimiter is tab
     '''
     xl = pd.ExcelFile(input_excel_file)
     sheet_name=xl.sheet_names[0]
     df = xl.parse(sheet_name)
     #To print the data frame on screen enable the below line
     #print df
     df.to_csv(output_csv_file,index=False,sep='\t',header=skip_header,encoding='utf-8')


def excel2json(input_excel_file, output_json_file, skiprows=0, skiprowsb4header=0, ignoreheadercase=False,
               sheet_name=None, encoding='utf-8', new_map=False):
    """
    Convert excel file to file containing rows of JSON.
    :param input_excel_file: str, path to input excel file
    :param output_json_file: str, path to output json file
    :param skiprows: int, how many rows in excel file to skip
    :param skiprowsb4header: int, how many rows to skip before header row
    :param ignoreheadercase: bool, if True all headers will be converted to lowercase
    :param sheet_name: str, name of excel sheet to convert (default to first sheet in file)
    :param encoding: str, encoding of excel file
    """
    xl = pd.ExcelFile(input_excel_file, encoding=encoding)
    if not sheet_name:
        sheet_name = xl.sheet_names[0]
    df = xl.parse(sheet_name, skiprows=skiprowsb4header)
    df = df.fillna('')
    
    # lowercase col names
    if ignoreheadercase:
        df.columns = [str(col.encode('utf-8')).lower().strip() if col else col for col in df.columns]

    # Convert data frame to list of dicts
    dict_rows = []
    if not df.empty:
        if new_map:
            dict_rows = df.applymap(lambda x: str(x) if type(x) is not unicode else x).T.to_dict().values()
        else:
        	dict_rows = df.applymap(str).T.to_dict().values()
    
    # If no rows in excel file, output empty JSON file -- S3 Copy command will insert 0 rows successfully
    with open(output_json_file, 'a') as outfile:
        for item in dict_rows[skiprows:]:
            ujson.dump(item, outfile)
            outfile.write('\n')


def csv2json(input_excel_file,output_json_file,skiprows=0,skiprowsb4header=0,ignoreheadercase=False,defaultencoding=False):
    if defaultencoding:
         sys.setdefaultencoding("utf-8")
    pdcsv = pd.read_csv(input_excel_file,parse_dates=[0],skiprows=skiprowsb4header)    
    if ignoreheadercase:
        pdcsv.columns=[x.encode('utf-8') for x in pdcsv.columns]
        pdcsv.columns=map(str.lower,pdcsv.columns)
    csvdf = pdcsv.fillna('')
    csv_dict_rows = [ 
        dict([(str(colname).strip(), row[i]) for i,colname in enumerate(csvdf.columns)])
        for row in csvdf.values
        ]
    with open(output_json_file, 'a') as outfile:
        for item in csv_dict_rows[skiprows:]:
            ujson.dump(item,outfile)
            outfile.write('\n')


def getexcelinfo(input_excel_file, header_row_pos=0, dw_eff_dt=False):
    """
    Extract record count and maximum date value from xml transaction file
    :param input_excel_file: str, path to transaction file
    :param header_row_pos: int, what row the header is on
    :param dw_eff_dt: str, field name for date values to extract
    :return: (max date, record count)
    """
    pd_excel = pd.ExcelFile(input_excel_file)
    sheet_name = pd_excel.sheet_names[0]
    df = pd_excel.parse(sheet_name, skiprows=header_row_pos)
    df = df.fillna('')
    if dw_eff_dt:
        print "'"+input_excel_file+"',"
        print str(df[dw_eff_dt].count())+","
        print "'"+str(pd.to_datetime(df[dw_eff_dt], errors='coerce').max())[:10]+"'"
        return str(pd.to_datetime(df[dw_eff_dt], errors='coerce').max())[:10],  df[dw_eff_dt].count(),  input_excel_file


def getcsvinfo(input_csv_file, skiprows=0, header_row_pos=0, dw_eff_dt=False):
    """"
    Extract record count and maximum date value from csv transaction file
    :param input_csv_file: str, path to transaction file
    :param header_row_pos: int, what row the header is on
    :param dw_eff_dt: str, field name for date values to extract
    :return: (max date, record count)
    """
    pd_csv = pd.read_csv(input_csv_file, parse_dates=[0], skiprows=header_row_pos)
    df = pd_csv.fillna('')
    if dw_eff_dt:
        print "'" + input_csv_file + "',"
        print str(df[dw_eff_dt].count())+","
        print "'"+str(pd.to_datetime(df[dw_eff_dt], errors='coerce').max())[:10]+"'"
        return str(pd.to_datetime(df[dw_eff_dt], errors='coerce').max())[:10], df[dw_eff_dt].count(), input_csv_file


def getxmlinfo(input_xml_file, dw_eff_dt):
    """
    Extract record count and maximum date value from xml transaction file, where the field is given via xpath.
    :param input_xml_file: str, path to file
    :param dw_eff_dt: str, xpath of field to parse containing date
    :return: (max date, record count)
    """
    results = []
    try:
        root = ET.parse(input_xml_file)
    except ET.ParseError:
        raise Exception('Unable to parse XML file: {0}'.format(input_xml_file))
    for elem in root.findall(dw_eff_dt):
        results.append(datetime.datetime.strptime(elem.text[:10], '%Y-%m-%d'))
    max_date_str = datetime.datetime.strftime(max(results), '%Y-%m-%d')
    cnt = str(len(results))
    return max_date_str, cnt, input_xml_file


def getjsoninfo(input_json_file, dw_eff_dt):
    """
    Extract record count and maximum date value from json transaction file (must be a redshift formatted JSON).
    :param input_json_file: str, path to file
    :param dw_eff_dt: str, field name for date values to extract
    :return: (max date, record count, file_name)
    """
    results = []
    with open(input_json_file) as file_in:
        for row in file_in:
            try:
                date_str = ujson.loads(row)[dw_eff_dt]
            except:
                print row
            # no value for dw_eff_dt, set to minimum
            if not date_str:
                results.append(datetime.datetime.min)
                continue
            # try either date or timestamp
            try:
                results.append(datetime.datetime.strptime(date_str, '%Y-%m-%d'))
            except ValueError:
                results.append(datetime.datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S'))
    max_date_str = datetime.datetime.strftime(max(results), '%Y-%m-%d')
    cnt = str(len(results))
    return max_date_str, cnt, input_json_file
