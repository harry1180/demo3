'''
Created on Aug 14, 2017

@author: ramkarunanidhi
'''
from redshift_modules import exec_query
import pandas as pd
import numpy as np
import re
import sqlalchemy
import json
import sys
from excelutils import  csv2json
from s3_modules import s3_file_upload 
import os
import time
import argparse
from datetime import datetime


NON_PIVOT_COLUMN=['user_id','dw_eff_dt']
PIVOT_COLUMN_NM='catg_nm'
IF_VAL='tier_nm'
ELSE_VAL='Null'

def alter_table(col_list,dest_table,dest_schema='dw_report', col_type='varchar(1000)'):
    dest_col_list=exec_query("SELECT a.column FROM pg_table_def a WHERE tablename = '{0}' AND schemaname = '{1}'".format(dest_table,dest_schema))
    dest_col_list=[col['column'].lower() for col in dest_col_list]
    alter_list=["ALTER TABLE {0}.{1} ADD COLUMN {2} {3}".format(dest_schema,dest_table,col,col_type) for col in col_list if col.lower() not in dest_col_list]
    map(exec_query,alter_list)


def pivot(table_nm,non_pivot_column,pivot_column_nm,if_val=None,else_val=None,return_col_list=False):
    sql_start="SELECT {0},".format(','.join(non_pivot_column))
    sql_end=" FROM {0} GROUP BY {1}".format(table_nm,','.join(non_pivot_column))
    dist_values=exec_query('SELECT {0} FROM {1} GROUP BY 1'.format(pivot_column_nm,table_nm))  
    col_list=[value for val in dist_values for key,value in val.iteritems()]
    sql_middle= ',\n'.join(["MAX(CASE WHEN {0}='{1}' THEN {2} ELSE {3} END) AS {1}".format(key,value,if_val,else_val) for val in dist_values for key,value in val.iteritems() ])
    if return_col_list:
	return sql_start+sql_middle+sql_end,non_pivot_column+col_list
    return sql_start+sql_middle+sql_end

def load_segment_stage(rules_tbl,field_nm,dest_table,cadence,user_type):  
    sql="SELECT 'INSERT INTO {dest_table} SELECT '''|| {seg_fld}  || ''' as {seg_fld},*  FROM ('|| sql_tx ||') a' as sql FROM {tbl} WHERE cdnc_cd='{cd}' AND usr_type_cd='{user_t}' and curr_in=1 and del_in=0;".format(dest_table=dest_table,seg_fld=field_nm,tbl=rules_tbl,cd=cadence,user_t=user_type) 
    print sql
    for i in exec_query(sql):
        print 'Insert into the Segment Stage table Started at {0}'.format(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
        exec_query(i['sql'])
        print 'Insert into the Segment Stage table Completed at {0}'.format(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))

def load_profile_stage(profile_tbl,segment_tbl,dest_table,cadence):
    profiles=exec_query("SELECT * FROM {0}".format(profile_tbl))
    
    print 'Delete profile Stage table Started at {0}'.format(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    exec_query("DELETE FROM {0}".format(dest_table))
    print 'Delete profile Stage table Completed at {0}'.format(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")) 
      
    for profile in profiles:
        and_segments = "({0})".format(' INTERSECT\n '.join([" SELECT user_id FROM {0} WHERE dw_sgmt_id='{1}' ".format(segment_tbl,segment) for segment in profile['and_segments'].split(',')]))
        or_segments = "({0})".format(' UNION\n '.join([" SELECT user_id FROM {0} WHERE dw_sgmt_id='{1}' ".format(segment_tbl,segment) for segment in profile['or_segments'].split(',')]))
        final_segments = "SELECT '{0}',user_id FROM ({1}) GROUP BY 1,2".format(profile['dw_prfl_id'],' UNION\n '.join([and_segments,or_segments]))
        
        print 'Insert into profile Stage table Started at {0}'.format(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
        exec_query('INSERT INTO {0} {1}'.format(dest_table,final_segments))
        print 'Insert into profile Stage table Completed at {0}'.format(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))


def load_segment_flat(pivot_table,dest_flat_stage,dest_flat_prod):
    print 'Construct query to pivot segment table'
    sql,col_list = pivot(pivot_table,NON_PIVOT_COLUMN,PIVOT_COLUMN_NM,IF_VAL,ELSE_VAL,return_col_list=True)
    print 'Run alter statements to add new columns to segment flat stage table'
    alter_table(col_list,dest_schema=dest_flat_stage.split('.')[0],dest_table=dest_flat_stage.split('.')[1])
    print 'Run alter statements to add new columns to segment flat prod table'
    alter_table(col_list,dest_schema=dest_flat_prod.split('.')[0],dest_table=dest_flat_prod.split('.')[1])
    print 'Delete from segment flat stage table'
    exec_query('DELETE FROM {0}'.format(dest_flat_stage))

    print 'Insert into segment flat stage table started at {0}'.format(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    print 'INSERT INTO {0} ({1}) {2}'.format(dest_flat_stage,',\n'.join(col_list),sql)
    exec_query('INSERT INTO {0} ({1}) {2}'.format(dest_flat_stage,',\n'.join(col_list),sql))
    print 'Insert into segment flat stage table completed at {0}'.format(datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))

    insert_prod_sql='INSERT INTO {0} ({5}) SELECT {1} FROM {2} a  LEFT JOIN {0} b ON {3} WHERE {4}'.format(dest_flat_prod, ',\n'.join(['a.'+col for col in col_list]), dest_flat_stage,' AND \n'.join([ 'a.'+col+'=b.'+col for col in NON_PIVOT_COLUMN ]), ' AND '.join(['b.'+col+' is null' for col in NON_PIVOT_COLUMN]),',\n'.join(col_list)  )

    print 'Insert into segment flat prod table started at {0}'.format( datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    exec_query(insert_prod_sql)
    print 'Insert into segment flat prod table completed at {0}'.format( datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))

if __name__ == '__main__':
    # Get the command line variables
    parser = argparse.ArgumentParser(description = 'Segmentation Engine')
    parser.add_argument('-t','--task',help = 'Choose the task you want to perform; segment stage load vs flat table load vs profile load', type = str, required = True, choices = ['stage','flatten','profile'])
    parser.add_argument('-p','--param',help = 'Parameters to run the segment stage load or flat table load', required = True, nargs = '+' )
        
    args=parser.parse_args()
    print args.task,args.param   
    if args.task == 'stage':
    	rules_tbl = args.param[0]
    	field_nm = args.param[1]
    	dest_table = args.param[2]
   	cadence = args.param[3]
   	user_type= args.param[4]
        load_segment_stage(rules_tbl,field_nm,dest_table,cadence,user_type)
    elif args.task == 'flatten':
        pivot_table_nm = args.param[0]
    	dest_flat_prod = args.param[1]
    	dest_flat_stage = args.param[2]
        load_segment_flat(pivot_table_nm,dest_flat_stage,dest_flat_prod)
    elif args.task == 'profile':
	profile_tbl = args.param[0]
        segment_tbl = args.param[1]
        dest_table  = args.param[2]
        cadence = args.param[3]
        load_profile_stage(profile_tbl,segment_tbl,dest_table,cadence)
