import httplib
import requests
import re
import urllib3
from pprint import *
import datetime
import urlparse
from urlparse import urlparse
from urlparse import parse_qs
from user_agents import parse
from datetime import timedelta
import sys, os
from datetime import date
from datetime import datetime
import tldextract
import logging
import glob
import json
from urlparse import urlparse, urljoin
from django.core.validators import URLValidator
from django.core.exceptions import ValidationError

#################################### initializing variables ####################################
#Below details are used for URL parsings
base_url = 'https://www.nerdwallet.com'
valid_url_schemes=['http','https']
valid_nw_domains = ['www.nerdwallet.com','www.travelnerd.com','bitly.com']
http_domain='www.travelnerd.com'
extensions = ['.jpg','.png','.gif','.css','.ttf','.svg','.xml']

#Below code is used for UTM parsings
keys = {'dw_ref_keys':['REF_KEY','REF_PAGE']}
tags= {'dw_utm_tags':['UTM_SRC','UTM_MED', 'UTM_CAMP', 'UTM_CONT', 'UTM_TERM']}
UTM_MEDS={'dw_utm_meds':['UTM_MED','utm_medium']}
UTM_HP_REFS={'dw_utm_hp_refs':['utm_hp_ref']}
UTM_SRSS={'dw_utm_srss':['UTM_SRC','utm_source']}
UTM_TERMS={'dw_utm_terms':['UTM_TERM','utm_term']}
UTM_CONTS={'dw_utm_conts':['UTM_CONT','utm_content']}
UTM_CAMPS={'dw_utm_camps':['UTM_CAMP','utm_campaign']}
REF_PAGS={'dw_ref_pags':['REF_PAG']}
REF_KEYS={'dw_ref_keys':['REF_KEY']}

USER_AGENT = {'user-agent': 'NerdWallet dwh bot'}

IDENTITY_APP = 'nerdwallet web'
IDENTITY_APP_URL_BASE = 'https://identity.nerdwallet.com/api/v1'
CLIENT_ID = 'dwh_scraper'
EMAIL = 'dwh@nerdwallet.com'
PASSWORD = '5pvXn2KtLiDvtrEL'
LOGIN_PARAMS = {'app': IDENTITY_APP, 'email': EMAIL, 'password': PASSWORD, 'remember_me': False}
APP_GET_URL  = IDENTITY_APP_URL_BASE + '/init_csrf_session?caller_client_id=' + CLIENT_ID
APP_POST_URL = IDENTITY_APP_URL_BASE + '/login?caller_client_id=' + CLIENT_ID

####################################       methods          ####################################

def connect_nw_identity():
    s = requests.Session()
    s.get(APP_GET_URL)
    #s.post(APP_POST_URL)
    s.post(APP_POST_URL, data=json.dumps(LOGIN_PARAMS), headers={'content-type': 'application/json'})
    return s


def get_urltext(s, url):
    try:
        if url.startswith('mobile'):
            return [url,200]
	else:
            r = s.get(url, headers = USER_AGENT, allow_redirects=True, timeout=(5, 5))
            return [r.text,r.status_code]
    except:
        return ["bad url", '404']


def get_desturl(s, url):
    try:
        if url.startswith('mobile'):
	    return [url,200,0]
        else:
            r = s.head(url, headers = USER_AGENT, allow_redirects=True, timeout=(5, 5))
            return [r.url,r.status_code,r.elapsed.total_seconds()]
    except requests.exceptions.MissingSchema:
        return [url,404,0]
    except requests.exceptions.URLRequired:
        return [url,404,0]
    except requests.exceptions.Timeout:
        # return 444 for caller to decide what action would be taken
        return [url,444,0]
    except requests.exceptions.HTTPError:
        return [url,404,0]
    except requests.exceptions.ConnectionError:
        return [url,404,0]
    except requests.exceptions.TooManyRedirects:
        return [url,404,0]
#    except urllib3.exceptions.LocationParseError:
#        return [url,404,0]
    except:
        return [url,404,0]


def django_validate_url_struct(url):
    val = URLValidator()
    try:
        val(url)
        return (True)
    except ValidationError, e:
        return(False)

def validate_url_struct(url):
     if  [extension for extension in extensions if url.endswith(extension)]:
         return False
     regex = re.compile(
         r'^(?:http|ftp)s?://' # http:// or
         r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|' #domain... 
         r'localhost|' #localhost...
         r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})' # ...or ip
         r'(?::\d+)?' # optional port
         r'(?:/?|[/?]\S+)$', re.IGNORECASE)
     if regex.match(url):
         return True
     else:
         return False


def url_strip(url,iter_num = 0):
    if url.strip('/').strip('.').strip('-').strip('(').strip(')').strip('\'').strip('\"').strip(' ').strip('+').strip('[').strip('*').strip('?').strip('&') == url:
        #url=url.rstrip('/').lstrip('/').rstrip('.')
        ##url_strip(url.rstrip('/').lstrip('/').rstrip('.'))
        if not (url.split('/')[-1].isdigit() and len(url.split('/')[-1])==13):
### check and remove if the last part of the URL is a 13 digit number, generally a timestamp
            return url
        else:
            return url_strip(url.rstrip(url.split('/')[-1]))
    else:
        if iter_num > 30:
            return url
        else:
            iter_num +=1 
            return url_strip(url.strip('/').strip('.').strip('-').strip('(').strip(')').strip('\'').strip('\"').strip(' ').strip('+').strip('[').strip('*').strip('?').strip('&'), iter_num)


def nw_url_join(scheme, netloc, path):
    """
    Builds a full URL using the specified pieces.
    :param scheme: The protocol, typically 'http' or 'https'
    :param netloc: The network location, also called the domain
    :param path: The path of the resource
    :return: A full URL. If any of the parameters are Unicode, then a Unicode string is returned.
    """
    if scheme != '' and netloc != '':
        joined_url = u'{scheme}://{netloc}/{path}'.format(
            scheme=scheme.rstrip(':/'),
            netloc=netloc,
            path=path.lstrip('/'))
    else:
        if netloc != '':
            joined_url = u'{netloc}/{path}'.format(
                netloc=netloc,
                path=path.lstrip('/'))
        else:
            joined_url = path

    # This probably isn't Python 3 compatible/safe
    if isinstance(scheme, unicode) or isinstance(netloc, unicode) or isinstance(path, unicode):
        return joined_url
    else:
        # None of the parameters were Unicode so downgrade the string from
        # Unicode to ASCII when returning it. This can't throw a Unicode
        # exception because we wouldn't have any non-ASCII characters as input.
        return str(joined_url)


def fix_nw_url(url):
#    if url.startswith('/'): ### re.match(r'^/',url):
#        url=url[1:len(url)] ### remov leading / for all paths or urls
  try:

    url=url_strip(url)
    parsed=urlparse(url)
    if  not validate_url_struct(url):
        ### try and fix url only if it appears to be invalid strcuture
        if (parsed.scheme not in valid_url_schemes) and (parsed.netloc =='') and [domain for domain in valid_nw_domains if domain in parsed.path]:
        ### handle a case where url is like 'www.nerdwallet.com' -- no scheme but has a domain name
        ### urlparse puts the domain name in the path instead of netloc. Hence can not use urljoin
        ### handle sample input like 'credit-union/zip/www.nerdwallet.com/credit-union/zip/salem-al'
#             return('http://'+url)
             domain_in_path= [domain for domain in valid_nw_domains if domain in parsed.path]
             paths=url.rsplit(domain_in_path[0])
             last_path=url_strip(paths[-1])
	     ### split the url path on domain name and take the remaining path after the domain name
	     if http_domain in domain_in_path:
	         return('http://'+domain_in_path[0] + '/' + last_path) 
	     else:
             	 return('https://'+ domain_in_path[0] + '/' + last_path)
        if (parsed.scheme not in valid_url_schemes) and (parsed.netloc =='') and not [domain for domain in valid_nw_domains if domain in parsed.path]:
             return urljoin(base_url,url)
        else:
             return url
    else:
        return url
  except:
    sys.stderr.write('this kitten has exploded in fix_nw_url: {}\n'.format(url))
    return "nerdwallet://exploding-kittens.owasp.biz#kittenstew"


def conform_url(url):
    parsed=urlparse(url)
    return parsed

def http_status_code_check(status_code):
    if int(status_code)/100 in [1,2]:
        return 'Success'
    elif int(status_code)/100 == 3:
        return 'Redirect'
    elif int(status_code)/100 == 4:
        return 'Client Error'
    elif int(status_code)/100 == 5:
        return 'Server Error'
    else:
        return ('Unknown status code')

def get_search_kw(url):
    """Function to fetch Keyword from the query text for known search engines.
    call method: kw_string = get_search_kw(url)
    """
    search_engine_map = {'q': ['alltheweb','aol','ask','bing','google'],'p': ['yahoo'],'wd': ['baidu'],'text': ['yandex']}
    keyword =''
    url_parsed = urlparse.urlparse(url)
    domain_nm = url_parsed.netloc
    for key, value in search_engine_map.iteritems():
        for se in value:
            if  se in domain_nm:
                try: 
                    keyword = urlparse.parse_qs(url_parsed.query)[key][0]
                except KeyError:
                    keyword = '%s unspecified' %se 
    return keyword

def fetch_dict_key(input_dict,key_field):
    """ Call this meathod to extract a desided field from the dictonary that is passed. This meathod will accept two parameters as Input
    1) Source Record which is nothing but an input dictonary
    2) The field that needs to be extracted. The name of the field needs to be exactly the same as the key value in the dictonary
    """
    output_str=''
    try:
        if ( input_dict.has_key(key_field) ):
            output_str=input_dict[key_field]

    except KeyError:
        print 'exception - fetching dict key'

    return output_str



def parse_useragent(input_user_agent):
    """ Call this meathod to extract the actual useragent. At present this function splits the useragent on [, to remove facebook details
    1) It accepts useragent as an input
    """
    ua_dict = {}
    try:
        ua_dict.update({'zdw_user_agent':input_user_agent.split('[')[0].strip(' ')})
        return ua_dict
    except ValueError:
        ua_dict.update({'zdw_user_agent':input_user_agent})
        return ua_dict
    except UnicodeEncodeError:
        ua_dict.update({'zdw_user_agent':input_user_agent})
        return ua_dict


def parse_errorMessages(input_errorMessages):
    """ Call this meathod to extract the actual useragent. At present this function splits the useragent on [, to remove facebook details
    1) It accepts useragent as an input
    """
    errorMessages_dict = {}
    errorMessages_tx = ''
    for s in input_errorMessages:
        errorMessages_tx = errorMessages_tx + s
    errorMessages_dict.update({'zdw_errorMessages':errorMessages_tx})
    return errorMessages_dict

def get_utm_key_value(input_list,search):
    """Call this meathod to extract UTM_CODES. This meathod accepts two inputs
    1) Input Dict of UTM codes that were parsed from URL
    2) Search Dict. This dict is already hardcoded in the main funtion file. If the list need to be edited to the path to edit this file
    """
    try:
        for value in search.values()[0]:
            for key in input_list.keys():
                if value == key:
                    out_utm = input_list[key]
                    if isinstance(out_utm,list):
                        return out_utm[0]
                    else:
                        return out_utm
        return ''
    except UnicodeEncodeError:
        return ''      


def parse_url_confirmed_utm(input_url,url_type):
    """Call this meathod to extract the utm codes and confirmed url in Dict format. This meathod will internally call the get_utm_key_value meathod. It requires 2 inputs
    1) Input URL. The url need to be passed a the first parameter
    2) We need to tell if this a regular or referral url. You need to makesure to specify regular collectly as Reg. If this is not apecified it will default it to Referral
    """
#    input_url.encode('ascii', 'ignore')
    dw_url_utm_parse_dict = {}
    dw_ref_utm_parse_dict = {}
    if url_type == 'Reg':
        fixed_url = url_strip(fix_nw_url(input_url))
        parsed_confirmed_url = conform_url(fixed_url)
    else :
        parsed_confirmed_url = urlparse(input_url)
    try:
        final_confirmed_url = url_strip(nw_url_join(parsed_confirmed_url.scheme,parsed_confirmed_url.netloc,parsed_confirmed_url.path))
    except UnicodeEncodeError:
        final_confirmed_url = url_strip(input_url)
    if input_url.startswith('mobile'):
	final_confirmed_path=input_url
    else:
    	final_confirmed_path = url_strip(parsed_confirmed_url.path)
    final_confirmed_query = parsed_confirmed_url.query
    final_confirmed_scheme = parsed_confirmed_url.scheme
    final_confirmed_netloc = parsed_confirmed_url.netloc
    qs_dict=parse_qs(final_confirmed_query)
    utm_src=get_utm_key_value(qs_dict,UTM_SRSS)
    utm_med=get_utm_key_value(qs_dict,UTM_MEDS)
    utm_camp=get_utm_key_value(qs_dict,UTM_CAMPS)
    utm_cont=get_utm_key_value(qs_dict,UTM_CONTS)
    utm_term=get_utm_key_value(qs_dict,UTM_TERMS)
    utm_hp_ref=get_utm_key_value(qs_dict,UTM_HP_REFS)
    url_sub_domain=tldextract.extract(parsed_confirmed_url.netloc).subdomain
    url_site_nm=tldextract.extract(parsed_confirmed_url.netloc).domain
    url_domain_sfx=tldextract.extract(parsed_confirmed_url.netloc).suffix
    final_url_is_valid = validate_url_struct(final_confirmed_url)
    if url_type == 'Reg':
        url_dict = {'zdw_Reg_final_confirmed_url':final_confirmed_url,
                    'zdw_Reg_final_confirmed_path':final_confirmed_path,
                    'zdw_Reg_final_confirmed_query':final_confirmed_query,
                    'zdw_Reg_utm_src':utm_src,
                    'zdw_Reg_utm_med':utm_med,
                    'zdw_Reg_utm_camp':utm_camp,
                    'zdw_Reg_utm_cont':utm_cont,
                    'zdw_Reg_utm_term':utm_term,
                    'zdw_Reg_utm_hp_ref':utm_hp_ref,
                    'zdw_Reg_url_scheme':final_confirmed_scheme,
                    'zdw_Reg_url_netloc':final_confirmed_netloc,
                    'zdw_Reg_url_sub_domain':url_sub_domain,
                    'zdw_Reg_url_site_nm':url_site_nm,
                    'zdw_Reg_url_domain_sfx':url_domain_sfx,
                    'zdw_Reg_url_is_valid':final_url_is_valid}
        dw_url_utm_parse_dict.update(url_dict)
        return dw_url_utm_parse_dict
    else:
        ref_dict = {'zdw_Ref_final_confirmed_url':final_confirmed_url,
                    'zdw_Ref_final_confirmed_path':final_confirmed_path,
                    'zdw_Ref_final_confirmed_query':final_confirmed_query,
                    'zdw_Ref_utm_src':utm_src,
                    'zdw_Ref_utm_med':utm_med,
                    'zdw_Ref_utm_camp':utm_camp,
                    'zdw_Ref_utm_cont':utm_cont,
                    'zdw_Ref_utm_term':utm_term,
                    'zdw_Ref_utm_hp_ref':utm_hp_ref,
                    'zdw_Ref_url_scheme':final_confirmed_scheme,
                    'zdw_Ref_url_netloc':final_confirmed_netloc,
                    'zdw_Ref_url_sub_domain':url_sub_domain,
                    'zdw_Ref_url_site_nm':url_site_nm,
                    'zdw_Ref_url_domain_sfx':url_domain_sfx,
                    'zdw_Ref_url_is_valid':final_url_is_valid}
        dw_ref_utm_parse_dict.update(ref_dict)
        return dw_ref_utm_parse_dict                                           
