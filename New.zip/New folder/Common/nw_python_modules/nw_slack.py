
import json
import requests
import sys


def send_message(channel,text):
# Set the webhook_url to the one provided by Slack when you create the webhook at https://my.slack.com/services/new/incoming-webhook/
    webhook_url = 'https://hooks.slack.com/services/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'
    data = dict()
    data['channel']=channel
    data['text']=text
    slack_data =json.dumps(data)
    response = requests.post(
        webhook_url,slack_data,
        headers={'Content-Type': 'application/json'}
    )
    response.raise_for_status()
# Calling the above function example nw_slack.send_message("UAA9M8NAK","Testing out slack module"). First arg is a slack channel_name & second arg is the text to be sent
# **By default the channel is #dwh-team & the user name is Airflow**


def send_message_dict(**kwargs):
# Set the webhook_url to the one provided by Slack when you create the webhook at https://my.slack.com/services/new/incoming-webhook/
    valid_args = ['token','channel','text','as_user','attachments','icon_emoji','icon_url','link_names','mrkdwn','parse','reply_broadcast','thread_ts','unfurl_links','unfurl_media','username']
    entered_keys = kwargs.keys()
    if all(elem in valid_args for elem in entered_keys):
    	webhook_url = 'https://hooks.slack.com/services/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'
    	slack_data =json.dumps(kwargs)
    	response = requests.post(
        	webhook_url,slack_data,
        	headers={'Content-Type': 'application/json'}
    	)
	response.raise_for_status()
    else:
    	print "Not a valid API arguments,please refer to https://api.slack.com/methods/chat.postMessage. Valid arguments are :-", valid_args
# Refer to the list of arguments that can be passed - https://api.slack.com/methods/chat.postMessage
# Calling this module example nw_slack.send_message_dict(username='Naveen',channel="UAA9M8NAK",text="Testing out slack").
#  **By default the channel is #dwh-team & the user name is Airflow**
