import paramiko
from stat import S_ISDIR
import sys
import os
from s3_modules import s3_file_upload


def connect(sftp_url,sftp_user,sftp_pass):
    ssh = paramiko.SSHClient()
    # automatically add keys without requiring human intervention
    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    ssh.connect(sftp_url, username=sftp_user, password=sftp_pass)
    ftp = ssh.open_sftp()
    ftp.keep_this = ssh
    return ftp

def download_file(ftp,remote_dir, local_dir,s3_bucket,s3_folder,decrypt=None,output_format=None,output_nm=None):
    if not os.path.exists(local_dir):
    	os.makedirs(local_dir)
    dir_items = ftp.listdir_attr(remote_dir)
    for item in dir_items:
        remote_path = os.path.join(remote_dir,item.filename)         
        local_path = os.path.join(local_dir, os.path.basename(item.filename))
        if S_ISDIR(item.st_mode):
            download_file(ftp,remote_path, local_dir,s3_bucket,s3_folder,decrypt,output_format,output_nm)
        else:
            if output_nm:
            	local_path = local_path.replace(*output_nm)
            ftp.get(remote_path, local_path)
            print local_path
            s3_file_upload(local_path, s3_bucket, s3_folder)
            if decrypt:
            	decrypt_pgp(local_path,s3_bucket,s3_folder,output_format)

def decrypt_pgp(input_file, s3_bucket, s3_folder,output_format):
        os.system('grep dataops_gnupg_key /etc/gnupg-dataops.ctrl | cut -d= -f2 | gpg --batch --passphrase-fd 0 --homedir /etc/dwh_secured_tokens/gnupg/ --output {0} --decrypt {1}'.format(input_file.replace('pgp',output_format),input_file))
        print('Moving the Raw file to S3 Started')
        s3_file_upload(input_file.replace('pgp',output_format), s3_bucket, s3_folder)
        print('Moving the Raw file to S3 Completed')
            
