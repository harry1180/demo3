from datetime import datetime
import json
import logging
import os
import re
import sys
from urlparse import urlparse

from boto.s3.connection import S3Connection
import pandas.io.sql as psql
import psycopg2

from s3_modules import get_s3_files_in_range
from nw_retry import nw_retry


logr = logging.getLogger(__name__)

reserved_words = {
    'AES128', 'AES256', 'ALL', 'ALLOWOVERWRITE', 'ANALYSE', 'ANALYZE', 'AND', 'ANY', 'ARRAY', 'AS', 'ASC',
    'AUTHORIZATION', 'BACKUP', 'BETWEEN', 'BINARY', 'BLANKSASNULL', 'BOTH', 'BYTEDICT', 'BZIP2', 'CASE', 'CAST',
    'CHECK', 'COLLATE', 'COLUMN', 'CONSTRAINT', 'CREATE', 'CREDENTIALS', 'CROSS', 'CURRENT_DATE', 'CURRENT_TIME',
    'CURRENT_TIMESTAMP', 'CURRENT_USER', 'CURRENT_USER_ID', 'DEFAULT', 'DEFERRABLE', 'DEFLATE', 'DEFRAG', 'DELTA',
    'DELTA32K', 'DESC', 'DISABLE', 'DISTINCT', 'DO', 'ELSE', 'EMPTYASNULL', 'ENABLE', 'ENCODE', 'ENCRYPT',
    'ENCRYPTION', 'END', 'EXCEPT', 'EXPLICIT', 'FALSE', 'FOR', 'FOREIGN', 'FREEZE', 'FROM', 'FULL', 'GLOBALDICT256',
    'GLOBALDICT64K', 'GRANT', 'GROUP', 'GZIP', 'HAVING', 'IDENTITY', 'IGNORE', 'ILIKE', 'IN', 'INITIALLY', 'INNER',
    'INTERSECT', 'INTO', 'IS', 'ISNULL', 'JOIN', 'LEADING', 'LEFT', 'LIKE', 'LIMIT', 'LOCALTIME', 'LOCALTIMESTAMP',
    'LUN', 'LUNS', 'LZO', 'LZOP', 'MINUS', 'MOSTLY13', 'MOSTLY32', 'MOSTLY8', 'NATURAL', 'NEW', 'NOT', 'NOTNULL',
    'NULL', 'NULLS', 'OFF', 'OFFLINE', 'OFFSET', 'OID', 'OLD', 'ON', 'ONLY', 'OPEN', 'OR', 'ORDER', 'OUTER', 'OVERLAPS',
    'PARALLEL', 'PARTITION', 'PERCENT', 'PERMISSIONS', 'PLACING', 'PRIMARY', 'RAW', 'READRATIO', 'RECOVER',
    'REFERENCES', 'RESPECT', 'REJECTLOG', 'RESORT', 'RESTORE', 'RIGHT', 'SELECT', 'SESSION_USER', 'SIMILAR', 'SNAPSHOT',
    'SOME', 'SYSDATE', 'SYSTEM', 'TABLE', 'TAG', 'TDES', 'TEXT255', 'TEXT32K', 'THEN', 'TIMESTAMP', 'TO', 'TOP',
    'TRAILING', 'TRUE', 'TRUNCATECOLUMNS', 'UNION', 'UNIQUE', 'USER', 'USING', 'VERBOSE', 'WALLET', 'WHEN', 'WHERE',
    'WITH', 'WITHOUT'}

def load_creds(cred_file_nm=None):
    """
    load credentials file items into a dictionary
    - skip commented lines
    - for duplicated lines, use the latter appearance
    """
    if cred_file_nm is None:
        try:
            cred_file_dir=os.environ['dwh_credentials_file_dir']
            logr.debug("parsing %s",cred_file_dir)
            cred_file_nm=cred_file_dir+'/credentials.ctrl'
        except:
            logr.warn( "unable to locate user credentials file. trying to use etl user creds file")
            cred_file_nm='/data/etl/Common/credentials.ctrl'
    logr.info("Loading credentials %s",cred_file_nm)
    creds = dict()
    with open(str(cred_file_nm)) as ifp:
        for line in ifp:
            line = line.strip()
            if line.startswith('#'):
                continue
            if "=" in line:
                k,v = line.split('=',1)
                creds[k.strip()] = v.strip().replace('"',"")
    return creds


def fetch_creds(input_var_name,cred_file_nm=None):
    """ 
    return input_var_name from credential file
    if a list is given, a list is returned
    """
    creds = load_creds(cred_file_nm)
    if isinstance(input_var_name,(list,tuple)):
        return [creds[x] for x in input_var_name]
    else:
        return creds[input_var_name]


def redshift_connect(cred_file_nm=None, input_db='psql', autocommit=True, strings_as_unicode=False):
    """
    connect to redshift, return the conn
    if cred_file_nm is a dict, treat it as the creds, else load the creds
    """
    logr.info("Connecting to Redshift using input_db=%s", input_db)
    input_db = input_db.lower()
    assert input_db in 'identity superuser psql redshift'.split()
    if input_db == 'redshift':  # for backward compatibility
        input_db = 'psql'
    
    # get creds and switch set
    if isinstance(cred_file_nm, dict):
        creds = cred_file_nm
    else:
        creds = load_creds(cred_file_nm)
    dbcreds = {
        'dbname':   input_db + '_prod_database',
        'port':     input_db + '_prod_port',
        'user':     input_db + '_prod_username',
        'password': input_db + '_prod_password',
        'host':     input_db + '_prod_dbHost'
        }
    dbcreds = dict([k, creds[v]] for k, v in dbcreds.items())

    raw_conn_string = "dbname='{dbname}' port='{port}' user='{user}' password='{password}' host='{host}'".format(
        **dbcreds)
    conn_string = raw_conn_string.replace('\n', "")
    conn = psycopg2.connect(conn_string)
    if autocommit:
        conn.autocommit = True
    if sys.version_info[0] < 3 and strings_as_unicode:  # Remove this when running on Python 3
        psycopg2.extensions.register_type(psycopg2.extensions.UNICODE, conn)
    return conn


def query_decomment(qry):
    """ 
    remove all comments from a query
    TODO: how about psql commands like \echo
    """
    qryc = re.sub(r"/\*.*?\*/"," ",qry, re.M, re.DOTALL)  # c-type comments
    qryc = re.sub(r"--.*"," ",qryc) # one-line comments
    #TODO: check for -- within quotes
    return qryc


def query_types(qry):
    """ return the first token for all statements in a query string
    * clean out comments
    * split into statements
    * return first token (lowercase)
    ALERT: this does NOT handle WITH clauses
    """
    qryc = query_decomment(qry) # remove comments
    qryc = qryc.strip()
    while qryc[-1] == ';': # remove final semicolons
        qryc = qryc[:-1]
    ql = qryc.split(';') # split into statements
    qtypes = []
    for q in ql: # get first token in each statement
        q = q.strip()
        if q == '':
            continue
        qt = q.split(None,1)[0].lower()
        qtypes.append(qt)
    return qtypes
    

def exec_query(run_query, DB='redshift', user=None, conn=None, mute=False, nan_to_null=False, variables=None):
    """
    connect to redshift (using DB set) and execute a query
    Call example :
    run_query="INSERT INTO dw_report.ctl_file_stats values ( '/data/etl/Data/bluekai_events/output/2016/03/07/nerdwallet_batch_events_2016030721.json', 'bluekai_events' , '2016-04-01' , '00' , 100, 100 , 0, getdate() ) ;"
    fb_custom_audience_groups=exec_query(run_query)

    variable_query = "select count(*) from :stagedb.dw_aflt_tran_banking_s where 1=:one"
    results = exec_query(SQL, variables={'one': '1'})

    args:
    * when conn is specified, use it, else create and close a connection -- best practice is to repeatedly use an open conn
    * Db and user are a weird way to specify which credentials to use
    * When mute is True, no print statements are run -- useful for setting shell variables to query results
    * When nan_to_null is True, all NaN values in the query results will be converted to empty string
    * variables: optional dictionary where key is SQL variable and value is value to replace variable in sql.
    """
    if DB == 'Identity':
        input_db = 'identity'
    elif user == 'superuser':
        input_db = 'superuser'
    else:
        input_db = 'psql'
    if not mute:
        print "Executing the Query from Database:- " + input_db

    useconn = conn or redshift_connect(input_db=input_db)

    # Set sql variables
    sql_variables = {}
    if variables:
        if not isinstance(variables, dict):
            raise Exception('"variables" parameter must be of type Dictionary')
        sql_variables = variables
    try:
        sql_variables['stagedb'] = os.environ['stagedb']
        sql_variables['reportdb'] = os.environ['reportdb']
        sql_variables['pudstagedb'] = os.environ['pudstagedb']
        sql_variables['pudreportdb'] = os.environ['reportdb']
    except KeyError as e:
        print('WARNING: Could not get redshift schema environment variables.')

    with useconn.cursor() as redshift_cursor:
        for replace_variable, replace_value in sql_variables.iteritems():
            sql_replace_tmp = run_query.replace(':\'{}\''.format(replace_variable), redshift_cursor.mogrify('%s', [replace_value]))
            sql_replace = sql_replace_tmp.replace(':{}'.format(replace_variable), u'{}'.format(replace_value))
            run_query = sql_replace

    qt = query_types(run_query)
    if 'drop' in qt:
        raise RuntimeError, "DROP statements not allowed in this function"

    ##
    ## WARNING: we should remove this and use a different function when we
    ## want results returned
    ## query type is not reliable due to comments and WITH statements
    ## left in place for backwards compatability
    ##
    query_type = qt[-1]
    if query_type == 'select':
        df = psql.read_sql_query(run_query, useconn)
        if nan_to_null:
            df = df.fillna('')
        list_of_dicts = df.to_dict('records')
        if not mute:
            print "Query executed successfully. Answer set is a list of dicts"
        return list_of_dicts
    ##
    ## END WARNING
    ## 

    # if query type is insert,update,del
    useconn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
    # do we ever not autocommit?  if not, we should bake this into the connection!!
    cur = useconn.cursor()
    cur.execute(run_query)
    # Make the changes to the database persistent
    useconn.commit()  # doesn't autocommit do that?

    # Close communication with the database
    cur.close()
    useconn.close()


def get_select_sql(fq_table_name, columns, table_filter=None, translate_tsv_breaking_characters=True, delimiter=u'\t'):
    """
    Builds a SELECT statement for a Redshift table that will pull all of the requested fields, applying an optional
    filter. Handles translation of null characters and, optionally, other CSV-breaking control characters.

    :param fq_table_name: Fully qualified table name.
    :param table_filter: Optional filter to be applied when selecting data from the table
    :param columns: List of columns, each column represented as a dictionary
    :param translate_tsv_breaking_characters: Translate control characters that would break parsing of the CSV file
    format to their Unicode control picture character equivalents.
    :param sql_dialect: Indicates which dialect of SQL should be used,
    :return:
    """

    # Build the list of characters that we want to translate to their Unicode control picture character equivalents
    # while retrieving data.
    translate_from = u''
    translate_to = u''
    if translate_tsv_breaking_characters:
        translate_from += u'\\n\\r'
        translate_to += u'\u240A\u240D'
        if delimiter == u'\t':
            translate_from += u'\\t'
            translate_to += u'\u2409'
        elif delimiter == u'|':
            translate_from += u'|'
            translate_to += u'\u00a6'
        elif delimiter == u',':
            translate_from += u','
            translate_to += u'\ufe50'
    if translate_from == u'':
        translate_from = u'CHR(0)'
    else:
        translate_from = u"CHR(0) || '{}'".format(translate_from)
    translate_to = u"'\u2400{}'".format(translate_to)

    # Build the list of columns for our SELECT statement. This includes translating control characters to their Unicode
    # control picture character equivalents as well as handling date and timestamp formatting.
    # Note: The resulting SQL string contains Unicode characters. If you are making changes to this code, please be sure
    #       to use the 'u' prefix in front of your strings to preserve the Unicode. Unless we've finally upgraded to
    #       Python 3 in which case you can remove the 'u' prefix and remove this note.
    fields = list()
    for column in columns:
        if column['type'] in ('character varying', 'character'):
            fields.append(u'TRANSLATE("{col_name}", {source_chars}, {dest_chars}) as "{col_name}"'.format(
                col_name=column['name'], source_chars=translate_from, dest_chars=translate_to))
        else:
            fields.append(u'"{}"'.format(column['name']))

    fields.append(u"CAST(CURRENT_TIMESTAMP AS TIMESTAMP(3)) AS extract_ts")

    # Build our SELECT statement
    sql = u"SELECT\n"
    sql += u"    " + u",\n    ".join(fields)
    sql += u"\nFROM\n    {}".format(fq_table_name)
    if table_filter:
        sql += u"\nWHERE\n    {}".format(table_filter)
    return sql


def get_tsv_unload_sql(select_sql, s3_bucket, s3_key_path, delimiter=u'\t', parallel=True):
    """
    Returns a formatted UNLOAD command that will unload this table in a tab-separated format that can be safely read
    with the org.apache.hadoop.hive.serde2.OpenCSVSerde SerDe. The token %s is included in the string for credentials
    substitution.

    :param select_sql: The SELECT statement that should be unloaded.
    :param s3_bucket: Name of the S3 bucket that the data should be unloaded onto.
    :param s3_key_path: S3 key path that the files should be written to.
    :param delimiter: Character to use for the field delimiter
    :param conn: Optional Redshift connection, for safer quoting
    :param parallel: Indicates if Redshift should use parallelism when unloading the data. Defaults to True.
    :return: An UNLOAD SQL command that can be executed on Redshift
    """

    # Build our UNLOAD command
    sql = u"UNLOAD ('\n\n"
    sql += select_sql.strip(u'\n').replace(u"'", u"''")
    sql += u"\n\n    ')\n"
    sql += u"TO 's3://{bucket}/{key_path}/'".format(  # The trailing '/' is important on this path
        bucket=s3_bucket,
        key_path=s3_key_path.strip(u'/'),
    )
    sql += u"\nCREDENTIALS %s"

    escaped_delimiter = delimiter.replace(u"'", u"''")
    escaped_delimiter = escaped_delimiter.replace(u'\t', u'\\t')
    escaped_delimiter = escaped_delimiter.replace(u'\r', u'\\r')
    escaped_delimiter = escaped_delimiter.replace(u'\n', u'\\n')
    sql += u"\nDELIMITER '{}'".format(escaped_delimiter)

    if not parallel:
        sql += u'\nPARALLEL OFF'

    return sql


def unload_query(sql_query, aws_access, aws_secret, s3_path, wildcard_prefix, s3_bucket='east1-prod-dwh-s3-0'):
    """
    Run unload to export select statement to file
    :param sql_query: select query to output to file
    :param aws_access: aws access key
    :param aws_secret: aws secret key
    :param wildcard_prefix: wildcard prefix of file
    :param s3_path: s3 path where output file will be stored
    :param s3_bucket: s3 bucket
    """

    query_type = query_types(sql_query)[-1]
    if query_type != 'select':
        raise Exception('Query must be of type "SELECT" to use in unload')

    # escape single quotes
    sql_query = sql_query.replace("\'", "\\'")

    # build S3 output file path
    output_file_path = os.path.join(s3_bucket, s3_path, wildcard_prefix)

    # build full unload query
    unload_str = "UNLOAD ('{0}') TO 's3://{1}'".format(sql_query, output_file_path)
    creds_str = "credentials 'aws_access_key_id={0};aws_secret_access_key={1}'".format(aws_access, aws_secret)
    params_str = "PARALLEL OFF DELIMITER '\t'"
    full_qery = '{unload} {creds} {params};'.format(unload=unload_str, creds=creds_str, params=params_str)

    # execute unload query
    exec_query(full_qery)


def generate_manifest_file(env,source_bucket, source_path, source_file_name, manifest_dest_path, start_date_time, end_date_time,scan_type='modified', dest_bucket=None, empty_list_ovrd=True):
    """Function will create a manifest file for each file/table (also wild card character)

    Sample call:
    generate_manifest_file('Prod','east1-prod-dwh-s3-0', 'trueffect/input', 'nw001_trupath_nerdwallet', 'trueffect/manifest', '2015-10-12', '2016-02-01', 'modified', 'east1-prod-dwh-s3-0')
    """

    # initializing manifest variables
    manifest_file_json_stream=""
    manifest_header="""{
    "entries":
    [
                      """
    manifest_footer="""
    ]
    }"""

    manifest_file_list=[]

    # fetch keys and generate manifest json

    for key in get_s3_files_in_range(env, source_bucket, start_date_time, end_date_time, source_path, scan_type):
        if source_file_name in str(key):
            #print "{\"url\":\"s3://"+source_bucket+"/"+key+"\", \"mandatory\":true},"
            manifest_file_list.append("{\"url\":\"s3://"+source_bucket+"/"+key+"\", \"mandatory\":true}")

    file_count=len(manifest_file_list)
    print "source file name :",source_file_name
    print "Total number of files to load : ",file_count

    #print manifest_header
    manifest_file_json_stream= manifest_file_json_stream + manifest_header

    if empty_list_ovrd==True and file_count==0:
        empty_file_nm = 'json/touch/empty_file.json'
        manifest_file_list.append("{\"url\":\"s3://"+source_bucket+"/"+empty_file_nm+"\", \"mandatory\":true}")

    manifest_file_json_stream= manifest_file_json_stream+""" , \n""".join(manifest_file_list)

    #print manifest_footer
    manifest_file_json_stream= manifest_file_json_stream + manifest_footer

    #print manifest_file_json_stream
    conn = S3Connection()
    if dest_bucket == None:
        dest_bucket = source_bucket
    
    bucket = conn.get_bucket(dest_bucket)
        
    manifest_key_name=manifest_dest_path+"/"+source_file_name+"_manifest.json"
    k = bucket.new_key(manifest_key_name)
    k.set_contents_from_string(manifest_file_json_stream)
    
    print "Manifest file uploaded @ s3://"+dest_bucket+'/'+manifest_key_name


def generate_manifest_file2(event_s3_url_prefix, manifest_s3_url, start_date_time, end_date_time, scan_type='modified'):
    """
    Generates a manifest file for use in a Redshift COPY command
    :param event_s3_url_prefix:
    :param manifest_s3_url:
    :param start_date_time:
    :param end_date_time:
    :param scan_type:
    :return:
    """
    event_s3_url = urlparse(event_s3_url_prefix)
    source_s3_files = get_s3_files_in_range(
        env=None,
        bucket_nm=event_s3_url.netloc,
        from_dt=start_date_time.strftime('%Y-%m-%d'),
        to_dt=end_date_time.strftime('%Y-%m-%d'),
        file_prefix=event_s3_url.path[1:],
        strip_prefix_slashes=False,
        scan_type=scan_type)

    manifest_entries = list()
    for key in source_s3_files:
        this_entry = dict()
        this_entry['url'] = 's3://{bucket}/{key}'.format(bucket=event_s3_url.netloc, key=key)
        this_entry['mandatory'] = True
        manifest_entries.append(this_entry)
        print(this_entry['url'])
    print "Total number of files to load : ", len(manifest_entries)

    # If the list is empty, add a dummy 0-byte file to the manifest to prevent failures
    if len(manifest_entries) < 1:
        this_entry = dict()
        this_entry['url'] = 's3://{bucket}/json/touch/empty_file.json'.format(bucket=event_s3_url.netloc)
        this_entry['mandatory'] = True
        manifest_entries.append(this_entry)

    manifest = {'entries': manifest_entries}

    # print manifest_file_json_stream
    conn = S3Connection()
    manifest_s3_url_parsed = urlparse(manifest_s3_url)
    bucket = conn.get_bucket(manifest_s3_url_parsed.netloc)
    k = bucket.new_key(manifest_s3_url_parsed.path[1:])
    k.set_contents_from_string(json.dumps(manifest, indent=4))

    print 'Manifest file uploaded to ' + manifest_s3_url


def generate_specific_manifest_file(env, source_bucket, source_file_name, dest_bucket, manifest_dest_path, start_date_time, end_date_time, scan_type='modified'):
    """Function will create a manifest file for each file/table
    Sample call:
    generate_specific_manifest_file('Prod','nw-event-data-prod', 'counts.json', 'east1-prod-dwh-s3-0', 'load_json/manifest', '2016-04-01', '2016-05-01', 'modified')
    generate_specific_manifest_file('Prod','east1-prod-dwh-s3-0', 'click_event_insurance_s/archive', 'east1-prod-dwh-s3-0', 'load_json/manifest', '2016-04-01', '2016-05-01', 'created')
    """
    
    # initializing manifest variables
    manifest_file_json_stream=""
    manifest_header="""{  
    "entries": 
    [ 
                      """
    manifest_footer="""
    ]
    }"""
    
    manifest_file_list=[]
    
    # fetch keys and generate manifest json
    
    #for key in get_s3_files_in_range(env, source_bucket, start_date_time, end_date_time, source_path, scan_type):
        #if source_file_name in str(key):
    
    conn = S3Connection()
    bucket = conn.get_bucket(source_bucket)
    key_objects = bucket.list()
    
    for key_obj in key_objects:
        #if str(key_obj.key).endswith(source_file_name):
        if source_file_name in str(key_obj.key):
            #print key_obj.key
            add_flag=False
            from_dt = datetime.strptime(start_date_time, '%Y-%m-%d')
            to_dt = datetime.strptime(end_date_time, '%Y-%m-%d')
    
            if scan_type.lower() == 'modified':
                modified_ts = datetime.strptime(key_obj.last_modified, '%Y-%m-%dT%H:%M:%S.%fZ')
                if modified_ts >= from_dt and modified_ts <= to_dt:
                    add_flag=True
            else:
                #'created', folder structure like 2016/04/13
                #minusworld/2016/04/12/14.json
                #BrokersClickEvent/2016/04/13/counts.json
                begin_date_number = int(start_date_time.replace('-', '').replace('/', ''))
                end_date_number = int(end_date_time.replace('-', '').replace('/', ''))
                file_split=key_obj.key.split('/')
                file_date_number = int(file_split[1]+file_split[2]+file_split[3])
                if file_date_number >= begin_date_number and file_date_number <= end_date_number:
                    add_flag=True

            if add_flag == True:
                manifest_file_list.append("{\"url\":\"s3://"+source_bucket+"/"+str(key_obj.key)+"\", \"mandatory\":true}")
                print 'Added s3://' + source_bucket + '/' + str(key_obj.key)

    file_count=len(manifest_file_list)
    #print "source file name :",source_file_name
    print "Total number of files to load : ",file_count
    
    #print manifest_header
    manifest_file_json_stream= manifest_file_json_stream + manifest_header
    
    ctr=1
    for f in sorted(manifest_file_list):
        if ctr<file_count:
            #print f,","
            manifest_file_json_stream=manifest_file_json_stream+f+""" ,
            """
        if ctr==file_count:
            #print f
            manifest_file_json_stream=manifest_file_json_stream+f
        ctr+=1
    
    #print manifest_footer
    manifest_file_json_stream= manifest_file_json_stream + manifest_footer
    
    #print manifest_file_json_stream
    conn = S3Connection()
    bucket = conn.get_bucket(dest_bucket)
    manifest_key_name=manifest_dest_path+"/manifest.json"
    k = bucket.new_key(manifest_key_name)
    k.set_contents_from_string(manifest_file_json_stream)
    
    print "Manifest file uploaded @ s3://"+dest_bucket+'/'+manifest_key_name 


def timer(start,end):
    hours, rem = divmod(end-start, 3600)
    minutes, seconds = divmod(rem, 60)
    print("\n --------------------------------> Elapsed Time : "+"{:0>2}:{:0>2}:{:05.2f}".format(int(hours),int(minutes),seconds))+"<--------------------------------\n"


def generate_hive_json_ddl(local_ddl_path, destination_bucket, destination_path, schema_list):
    """ Function will generate a DDL file for JSON table.
    local_ddl_path: the path where the DDL file will be saved
    destination_bucket: the source bucket of the JSON files
    destination_path: the source path of the JSON files
    schema_list: a list including table's field names

    Sample call:
    generate_json_ddl('/home/rqiu/emr_click_event_generic_s/ddl', 'east1-prod-dwh-hdfs-0', 'click_event_generic_s', ["affiliateId", "applicationId", ..., "zzz_validated_url"])
    """

    local_ddl_filename = os.path.join(local_ddl_path,destination_path + "_json_ddl.sql")
    # e.g. /home/rqiu/emr_click_event_generic_s/ddl/click_event_generic_s_json_ddl.sql

    json_table_name = "ha_stage." + destination_path + "_json"
    # e.g. ha_stage.click_event_generic_s_json

    file_location = "s3n://" + destination_bucket + "/" + destination_path
    # e.g. s3n://east1-prod-dwh-hdfs-0/click_event_generic_s

    schema_list.sort()
    with open(local_ddl_filename, 'w') as outfile:
        # Add Serde jar to parse JSON files
        outfile.write("ADD JAR s3n://east1-prod-dwh-hdfs-0/hive-json-serde-0.3.jar;" + '\n')
        # Drop existing table
        outfile.write("DROP TABLE " + json_table_name + ";\n")
        # Create new table based on up-to-date schema
        outfile.write("CREATE EXTERNAL TABLE IF NOT EXISTS " + json_table_name + " (\n")
        count_line = 1
        for element in schema_list:
            if count_line == 1:
                outfile.write(element + " string\n")
            elif count_line != len(schema_list):
                outfile.write(", " + element + " string\n")
            else:
                outfile.write(", " + element + " string")
            count_line = count_line + 1
        outfile.write(") PARTITIONED BY(dw_eff_dt string)" + '\n')
        outfile.write("ROW FORMAT" + '\n')
        outfile.write("serde 'org.apache.hadoop.hive.contrib.serde2.JsonSerde'"  + '\n')
        outfile.write("with serdeproperties ("  + '\n')
        count_line = 1
        for element in schema_list:
            if count_line == 1:
                outfile.write("\"" + element + "\" = \"" + element.lower() + "\"\n")
            elif count_line != len(schema_list):
                outfile.write(", " + "\"" + element + "\" = \"" + element.lower() + "\"\n")
            else:
                outfile.write(", " + "\"" + element + "\" = \"" + element.lower() + "\"")
            count_line = count_line + 1
        outfile.write(") LOCATION \'" + file_location + "\';")


def generate_hive_orc_ddl(local_ddl_path, destination_bucket, destination_path, schema_list):
    """ Function will generate a DDL file for ORC table.
    local_ddl_path: the path where the DDL file will be saved
    destination_bucket: the bucket where the ORC files will be saved
    destination_path: the source path where the ORC files will be saved
    schema_list: a list including table's field names

    Sample call:
    generate_json_ddl('/home/rqiu/emr_click_event_generic_s/ddl', 'east1-prod-dwh-hdfs-0', 'click_event_generic_s', ["affiliateId", "applicationId", ..., "zzz_validated_url"])
    """

    local_ddl_filename = os.path.join(local_ddl_path,destination_path + "_orc_ddl.sql")
    # e.g. /home/rqiu/emr_click_event_generic_s/ddl/click_event_generic_s_orc_ddl.sql

    orc_table_name = "ha_stage." + destination_path + "_orc"
    # e.g. ha_stage.click_event_generic_s_orc

    file_location = "s3n://" + destination_bucket + "/" + destination_path + "_orc"
    # e.g. s3n://east1-prod-dwh-hdfs-0/click_event_generic_s

    schema_list.sort()
    with open(local_ddl_filename, 'w') as outfile:
        # Add dynamic partition configurations
        outfile.write("SET hive.exec.dynamic.partition=true;" + '\n')
        outfile.write("SET hive.exec.dynamic.partition.mode=non-strict;" + '\n')
        # Drop existing table
        outfile.write("DROP TABLE " + orc_table_name + ";\n")
        # Create new table based on up-to-date schema
        outfile.write("CREATE EXTERNAL TABLE IF NOT EXISTS " + orc_table_name + "(\n")
        count_line = 1
        for element in schema_list:
            if count_line == 1:
                outfile.write(element + " string\n")
            elif count_line != len(schema_list):
                outfile.write(", " + element + " string\n")
            else:
                outfile.write(", " + element + " string")
            count_line = count_line + 1
        outfile.write(") PARTITIONED BY(dw_eff_dt string)" + '\n')
        outfile.write("STORED AS ORC" + '\n')
        outfile.write("LOCATION \'" + file_location + "\';")


def format_sql_column(raw_string):
    """
    Convert strings to acceptable sql column names.
        - Replaces spaces with underscores "_"
        - Removes any non alpha numeric characters
        - lowercase
    :param raw_string: string, input
    :return: string, acceptable sql column format

    Sample call:
    format_sql_columns("My SQL Column") --> "my_sql_column"
    """
    raw_string = raw_string.replace(' ', '_')
    return ''.join(letter.lower() for letter in raw_string if letter.isalnum() or letter == "_")


def table_exists(schema, table, conn=None):
    """
    Check if a table exists.
    :param schema: str, name of schema
    :param table: str, name of table
    :param conn: Redshift connection to use (optional)
    :return: bool, True if table exists, False if table does not exist
    """

    table_exists_query = """
        SELECT EXISTS (
        SELECT 1
        FROM   information_schema.tables
        WHERE  table_schema = '{schema}'
        AND    table_name = '{table}'
        ) as exists;
    """.format(schema=schema, table=table)
    return exec_query(table_exists_query, conn=conn)[0]['exists']


def _retry_vacuum(ex):
    # If we get a 'VACUUM already running' error message, wait for a short while and try again
    return ex.pgcode == '0A000'


@nw_retry(psycopg2.Error, tries=3, delay=5, backoff=1, conditional_retry_callback=_retry_vacuum)
def _vacuum_table(conn, fq_table_name, ignore_owner_failure=False, vacuum_option=None, threshold=None):
    # Vacuum the table and retry if we conflict with another vacuum
    sql = 'VACUUM '
    if vacuum_option:
        sql += vacuum_option + ' '
    sql += fq_table_name
    if threshold is not None:
        sql += ' TO {} PERCENT'.format(threshold)
    logr.debug(sql)

    with conn.cursor() as curs:
        try:
            curs.execute(sql)
        except psycopg2.Error as ex:
            if ex.pgcode == 'XX000' and ignore_owner_failure:
                logr.warn('{}: {} {}'.format(sql, ex.pgcode, '' if ex.pgerror is None else ex.pgerror.rstrip()))
            else:
                logr.error('{}: {} {}'.format(sql, ex.pgcode, '' if ex.pgerror is None else ex.pgerror.rstrip()))
                raise ex


def vacuum_table(conn, fq_table_name, analyze_after_vacuum=True, ignore_owner_failure=False, vacuum_option=None,
                 threshold=None):
    """
    Vacuums a table, retrying if encounters a 'VACUUM already running' error.
    :param conn: Redshift connection
    :param fq_table_name: Fully qualified Redshift table name
    :param analyze_after_vacuum: Analyze the table after vacuuming it.
    :param ignore_owner_failure: Ignore and don't retry if the vacuum fails because the user is not the owner.
    :return:
    """
    if '.' not in fq_table_name:
        raise ValueError('Redshift table \'{}\' must be formatted \'schema.table_name\''.format(fq_table_name))

    # Vacuum the table and retry if we conflict with another vacuum
    _vacuum_table(conn, fq_table_name, ignore_owner_failure=ignore_owner_failure, vacuum_option=vacuum_option,
                  threshold=threshold)

    if analyze_after_vacuum:
        sql = 'ANALYZE ' + fq_table_name
        logr.debug(sql)
        with conn.cursor() as curs:
            try:
                curs.execute(sql)
            except psycopg2.Error as ex:
                if ex.pgcode == 'XX000' and ignore_owner_failure:
                    logr.warn('{}: {} {}'.format(sql, ex.pgcode, '' if ex.pgerror is None else ex.pgerror.rstrip()))
                else:
                    logr.error('{}: {} {}'.format(sql, ex.pgcode, '' if ex.pgerror is None else ex.pgerror.rstrip()))
                    raise ex


def tables_to_vacuum_delete(conn, schema, minimum_record_count=1000000):
    """
    Get a list of tables that need to be vacuumed with the DELETE ONLY option.
    :param conn: Redshift connection
    :param schema: Schema to pull the list of tables for. If not specified, all tables across all schemas will be
    returned.
    :return: A list of tables that need to be vacuumed.
    """

    # Get the OID for the specified schema
    sql = 'SELECT oid FROM pg_namespace WHERE nspname = %s'
    with conn.cursor() as curs:
        logr.debug(curs.mogrify(sql, [schema.lower()]))
        curs.execute(sql, [schema.lower()])
        row = curs.fetchone()
        if not row:
            raise Exception('Schema \'{}\' not found'.format(schema))
        schema_oid = row[0]

    # Get a list of tables without sort keys and that have more than 1,000,000 rows
    sql = '''
        select
            trim(trailing from tbl.relname) AS table_name,
            rowcount.estimated_rows
        from
            pg_class tbl
        left outer join
            pg_attribute sortkeyfirstfield
            on tbl.oid = sortkeyfirstfield.attrelid
            and sortkeyfirstfield.attsortkeyord = 1
        inner join
            (
                select id, sum(rows) as estimated_rows
                from stv_tbl_perm a
                group by id
            ) rowcount
            on tbl.oid = rowcount.id
        where
            tbl.relnamespace = %s
            and rowcount.estimated_rows > %s
            and sortkeyfirstfield.attrelid is null
        order by 1
        '''

    large_tables = dict()
    with conn.cursor() as curs:
        logr.debug(curs.mogrify(sql, [schema_oid, minimum_record_count]))
        curs.execute(sql, [schema_oid, minimum_record_count])
        rows = curs.fetchall()
        for row in rows:
            large_tables['{}.{}'.format(schema.lower(), row[0])] = row[1]

    # For each table, count the number of records and compare it with the purported number of records
    tables_to_vacuum = set()
    for table_name in sorted(large_tables.keys()):
        logr.info('Checking if {} needs to be vacuumed'.format(table_name))
        logr.info('    Row count from STV_TBL_PERM: {:,}'.format(large_tables[table_name]))
        sql = 'SELECT COUNT(*) FROM ' + table_name
        with conn.cursor() as curs:
            logr.debug(sql)
            curs.execute(sql)
            actual_row_count = curs.fetchone()[0]
            logr.info('    Actual row count:            {:,}'.format(actual_row_count))
            pct_diff = float(actual_row_count) / float(large_tables[table_name])
            if pct_diff < 0.9:
                tables_to_vacuum.add(table_name)

    return tables_to_vacuum


def tables_to_vacuum(conn, schema=None):
    """
    Get a list of tables that need to be vacuumed.
    :param conn: Redshift connection
    :param schema: Schema to pull the list of tables for. If not specified, all tables across all schemas will be
    returned.
    :return: A list of tables that need to be vacuumed.
    """
    sql = 'SELECT schemaname || \'.\' || tablename '
    sql += 'FROM dw_dba.v_space_used_per_tbl '
    sql += 'WHERE recommendation = \'VACUUM recommended\' '

    if schema:
        sql += 'AND schemaname = %s '

    sql += 'ORDER BY unsorted_rowcount DESC'
    with conn.cursor() as curs:
        logr.debug(curs.mogrify(sql, [schema.lower()] if schema else None))
        curs.execute(sql, [schema.lower()] if schema else None)
        rows = curs.fetchall()
        return [row[0] for row in rows]


def get_data_schemas(conn):
    """
    Gets the list of non-internal schemas in Redshift.

    :param conn:
    :return:
    """
    sql = 'SELECT nspname FROM pg_namespace WHERE nspowner <> 1'
    schemas = set()
    with conn.cursor() as curs:
        curs.execute(sql)
        for row in curs:
            schemas.add(row[0])
    return schemas


def purge_table(conn, table_name):
    """
    Purge the contents of the table using TRUNCATE if possible, otherwise using DELETE.
    :param conn:
    :param table_name:
    :return:
    """

    # Try TRUNCATE
    sql = 'TRUNCATE TABLE ' + table_name
    logr.info(sql)
    with conn.cursor() as curs:
        try:
            curs.execute(sql)
            return
        except psycopg2.Error as ex:
            # Any error other than 'permission denied' logs an error and throws an exception
            if ex.pgcode != '42501':
                logr.error('{} {}'.format(ex.pgcode, '' if ex.pgerror is None else ex.pgerror.rstrip()))
                raise ex
            logr.warn('{} {}'.format(ex.pgcode, '' if ex.pgerror is None else ex.pgerror.rstrip()))

    # Try DELETE
    sql = 'DELETE FROM ' + table_name
    logr.info(sql)
    with conn.cursor() as curs:
        try:
            curs.execute(sql)
        except psycopg2.Error as ex:
            # Log a message that includes the Redshift error code
            logr.error('{} {}'.format(ex.pgcode, '' if ex.pgerror is None else ex.pgerror.rstrip()))
            raise ex


def get_table_columns(conn, table_name):
    """
    Gets an array of dictionaries describing the columns in the table.
    :param conn:
    :param table_name:
    :return:
    """
    sql = '''SELECT column_name, data_type, is_nullable, numeric_precision, numeric_scale
    FROM information_schema.columns
    WHERE table_schema = %s and table_name = %s
    ORDER BY ordinal_position'''
    cols = list()
    with conn.cursor() as curs:
        curs.execute(sql, table_name.split('.'))
        for row in curs.fetchall():
            this_col = {
                'name': row[0],
                'type': row[1],
                'nullable': row[2] == 'YES'
            }
            if row[3] is not None:
                this_col['precision'] = row[3]
            if row[4] is not None:
                this_col['scale'] = row[4]
            cols.append(this_col)

    # Get column comments
    sql = 'SELECT oid FROM pg_catalog.pg_namespace WHERE nspname = %s'
    with conn.cursor() as curs:
        curs.execute(sql, [table_name.split('.')[0].lower()])
        row = curs.fetchone()
        if not row:
            return cols
        schema_oid = row[0]

    sql = 'SELECT oid FROM pg_class WHERE relname = %s and relnamespace = %s'
    with conn.cursor() as curs:
        curs.execute(sql, [table_name.split('.')[1].lower(), schema_oid])
        row = curs.fetchone()
        if not row:
            return cols
        table_oid = row[0]

    sql = 'SELECT objsubid, description FROM pg_catalog.pg_description WHERE objoid = %s AND objsubid > 0'
    with conn.cursor() as curs:
        curs.execute(sql, [table_oid])
        for row in curs:
            column_position, column_desc = row
            if not column_desc:
                continue
            if column_desc.strip() == '':
                continue
            cols[column_position - 1]['description'] = column_desc.strip()

    return cols


def recreate_redshift_table(conn, fq_table_name, ddl):
    """
    Creates a Redshift table, optionally dropping the table if it already exists. The schema must be DW_WORKAREA or must
    end in _STAGE.
    :param conn: Redshift connection
    :param fq_table_name: Fully qualified table name
    :param ddl: The CREATE TABLE statement that creates the table
    :return:
    """
    schema, table_name = fq_table_name.split('.', 1)
    if schema.lower() not in ['dw_workarea'] and not schema.lower().endswith('_stage'):
        raise ValueError('Schema must be \'dw_workarea\' or must end in \'_stage\'')

    if table_exists(schema, table_name, conn=conn):
        sql = 'DROP TABLE {}'.format(fq_table_name)
        logging.info(sql)
        with conn.cursor() as curs:
            curs.execute(sql)

    logging.info(ddl)
    with conn.cursor() as curs:
        curs.execute(ddl)

    grant_statements = list()
    if '_pud_' in schema.lower():
        grant_statements.append('GRANT ALL ON {} TO GROUP grp_etl_secured'.format(fq_table_name))
        grant_statements.append('GRANT SELECT ON {} TO GROUP grp_data_users_secured'.format(fq_table_name))
    else:
        grant_statements.append('GRANT ALL ON {} TO GROUP grp_etl'.format(fq_table_name))
        grant_statements.append('GRANT SELECT ON {} TO GROUP grp_data_users'.format(fq_table_name))

    with conn.cursor() as curs:
        for grant_statement in grant_statements:
            logging.info(grant_statement)
            curs.execute(grant_statement)
