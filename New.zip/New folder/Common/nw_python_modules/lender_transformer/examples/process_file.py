"""
This example shows how to use the lender_transformer code to process a single input file by using the
process_tran_file() function. This function requires that the map file be stored on S3.
"""
from lender_transformer.lender_transformation_new import process_tran_file

# define inputs
source_data_file = '/Users/jportwood/Downloads/SalesJan2009.csv'
map_file_s3_path = 'jeff_test/HappyTransactions_MAP.xlsx'

# define outputs -- valid file extensions include (json, csv, xlsx, xls)
output_clean_file = '/Users/jportwood/Downloads/SalesJan2009_cleaned.csv'

# Clean file
# This will output up to 3 new files:
#   "_cleaned.json" containing valid rows
#   "_warning.csv" containing warning rows
#   "_error.csv" containing error rows
# process_tran_file(source_data_file, output_clean_file, map_file_s3_path)
process_tran_file('/Users/jportwood/Downloads/Pave_2017_04_25.xlsx', '/Users/jportwood/Downloads/Pave_2017_04_25_cleaned.csv', 'jeff_test/Pave_map.xlsx', vertical='pl', lender='pave')