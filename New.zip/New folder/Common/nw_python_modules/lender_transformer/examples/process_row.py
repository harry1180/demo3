import json
import logging
import requests

from lender_transformer.mapper import parse_mapper
from lender_transformer.row_transformation import process_row


def get_api_data(api_url):
    """
    Parse JSON response from API
    :param api_url: str, api url
    :return: object, response
    """
    # make api call
    response = requests.get(api_url, timeout=60)

    # check for bad responses -- will raise HTTPError if so
    response.raise_for_status()

    return json.loads(response.json())['data']


if __name__ == '__main__':

    api_token = '12345abcde'
    api_url = 'http://api.happytransactions.com?token={}'.format(api_token)

    map_file = '/Users/jportwood/Desktop/HappyTransactions_MAP.xlsx'

    # must create map object from map file
    map_object = parse_mapper(map_file)

    # loop through api response to get each row
    clean_data = []
    for source_row in get_api_data(api_url):
        clean_row = process_row(source_row, map_object)

        # here you have the option to do whatever you want with the error/warning data
        # for now we'll just skip
        if clean_row.get('error_list') or clean_row.get('warn_list'):
            logging.warning('Skipping row')

        # here you have the option to do whatever you want with the clean data
        # for now we'll just append to a list and deal with it later
        else:
            clean_data.append(clean_row)

    logging.info('Cleaned {} rows'.format(str(len(clean_data))))
