import re

from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException

def execute_custom_cc(src_df_row, old_col_nm, new_col_nm, transform, lender):
	try:
		lender = lender.strip().lower()
        	new_col = 0
		if lender == 'commission_junction':
			if new_col_nm == 'txn_cnt':
				comm = src_df_row[old_col_nm]
		        	if comm > 0: new_col = 1
				return new_col
			if new_col_nm in ('commission_am', 'merchant_am'):
				if src_df_row[old_col_nm] is None or src_df_row[old_col_nm] == '': return None
				return src_df_row[old_col_nm] 
			else:
                		raise CustomColumnException(
                    			"Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))

		if lender in ('impact_radius', 'amex_ir'):
			if new_col_nm in ('dw_eff_dt', 'tran_click_dt','tran_click_ts'):
				cmpgn_nm,ref_dt,event_dt = old_col_nm.split(',')
				if src_df_row[cmpgn_nm].lower() == 'capital one credit cards': return src_df_row[ref_dt]
				return src_df_row[event_dt]
			if new_col_nm in ('src_prod_nm','prog_nm','aflt_catg_nm'):
				if src_df_row[old_col_nm].lower() == 'wealthfront investment service': return 'Wealthfront'
				return src_df_row[old_col_nm]
			if new_col_nm == 'src_unique_click_id':
				subid1,subid2 = old_col_nm.split(',')
				if src_df_row[subid1] is None or len(src_df_row[subid1]) == 0: return src_df_row[subid2]
				return src_df_row[subid1]
			if new_col_nm == 'txn_cnt':
				pay,cmpgn_nm,status,dt = old_col_nm.split(',')
				if src_df_row[pay] == 0: return 0
				if src_df_row[cmpgn_nm].lower() in ('wealthfront investment service','allstate','capital one credit cards', 'wealthsimple', 'blooom cpl', 'ellevest affiliate program') and src_df_row[status].lower() == 'pending': return 1
                                if src_df_row[cmpgn_nm].lower() == 'stash invest' and src_df_row[status].lower() == 'pending' and src_df_row[dt] >= '2017-08-01': return 1
                                if src_df_row[cmpgn_nm].lower() == 'stash invest' and src_df_row[status].lower() == 'approved' and src_df_row[dt] < '2017-08-01': return 1
                                if src_df_row[cmpgn_nm].lower() in ('american express consumer cards','american express open','hsbc credit cards') and src_df_row[status].lower() in ('approved','pending'): return 1
                                if src_df_row[cmpgn_nm].lower() not in ('wealthfront investment service','allstate','capital one credit cards', 'wealthsimple', 'blooom cpl', 'ellevest affiliate program') and src_df_row[status].lower() == 'approved': return 1
                                return 0
			if new_col_nm == 'commission_am':
				pay,cmpgn_nm,status,dt = old_col_nm.split(',')
				if src_df_row[cmpgn_nm].lower() == 'betterment': return src_df_row[pay]
				if src_df_row[cmpgn_nm].lower() in ('wealthfront investment service','allstate','capital one credit cards', 'wealthsimple', 'blooom cpl', 'ellevest affiliate program') and src_df_row[status].lower() == 'pending': return src_df_row[pay]
				if src_df_row[cmpgn_nm].lower() == 'stash invest' and src_df_row[status].lower() == 'pending' and src_df_row[dt] >= '2017-08-01': return src_df_row[pay]
				if src_df_row[cmpgn_nm].lower() == 'stash invest' and src_df_row[status].lower() == 'approved' and src_df_row[dt] < '2017-08-01': return src_df_row[pay]
				if src_df_row[cmpgn_nm].lower() in ('american express consumer cards','american express open','hsbc credit cards') and src_df_row[status].lower() in ('approved','pending'): return src_df_row[pay]
				if src_df_row[cmpgn_nm].lower() not in ('wealthfront investment service','allstate','capital one credit cards', 'wealthsimple', 'blooom cpl', 'ellevest affiliate program') and src_df_row[status].lower() == 'approved': return src_df_row[pay]
				return 0 
						
			if new_col_nm in ('src_status_tx','aflt_fin_tran_type_cd'):
				status,state,cmpgn = old_col_nm.split(',')
				if src_df_row[cmpgn].lower() == 'betterment': return '_'.join([src_df_row[status],'approved'])
				else: return '_'.join([src_df_row[status],src_df_row[state]])				
			else:
                                raise CustomColumnException(
                                        "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
		
		if lender in ('linkshare_coupons','linkshare_prequal'):
			if new_col_nm == 'aflt_network_id':
				if lender == 'linkshare_prequal': return 28
				return -15
			if new_col_nm == 'aflt_catg_nm':
				if lender == 'linkshare_prequal': return 'Coupons-prequal'
				return 'Coupons'
			if new_col_nm == 'src_data':
				return lender
			else:
                                raise CustomColumnException(
                                        "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))

	except CustomColumnException as cce:
        	print cce
        	raise CustomExecuteError(cce.value)
    	except Exception as e:
        	print e
        	raise CustomExecuteError("Error: execute_custom for this lender: {0}".format(lender))
