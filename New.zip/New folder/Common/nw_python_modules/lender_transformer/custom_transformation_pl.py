import re
import datetime
from re import sub
from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException


LIGHTSTREAM_LOAN_PURPOSE = ['AutoRefinancing','AutoRefinancingSecured','BoatRVPurchase','LeaseBuyOut','LeaseBuyOutSecured','MotorcyclePurchase','NewAutoPurchase','NewAutoPurchaseSecured','PrivatePartyPurchase','PrivatePartyPurchaseSecured','UsedAutoPurchase','UsedAutoPurchaseSecured','Boat/RV/Aircraft Purchase or Refinance']

SOFI_FILTER=['SoFi Refi 0','NerdWallet Student']

def execute_custom_pl(src_df_row, old_col_nm, new_col_nm, transform, lender):
    try:
        lender = lender.strip().lower()
        new_col = ''

        if lender.lower() == 'freedomfinancial':

            if new_col_nm == 'commission_am':
                status,amt = old_col_nm.split(',')
                if src_df_row[status] == 'Funding':
		    new_col = float(src_df_row[amt])*0.02
		else: new_col = 0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                if src_df_row[old_col_nm] == 'Funding':
                    new_col='funded'
                elif src_df_row[old_col_nm] == 'UW Approved' or src_df_row[old_col_nm] == 'Ready to Fund' or src_df_row[old_col_nm] == 'Ready to Approve':
                    new_col='approved'
                elif src_df_row[old_col_nm] == 'Full App Submitted':
                    new_col='applied'
                else:
                    new_col = 'started'

            elif new_col_nm == 'pl_cookie_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col


        if lender.lower() == 'upstart':

            if new_col_nm == 'commission_am':
                new_col=src_df_row[old_col_nm]
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                funded,approved,applied=old_col_nm.split(',')
                if src_df_row[funded]==1:
                    new_col='funded'
                elif src_df_row[approved]==1 and src_df_row[applied]==1:
                    new_col='approved'
                elif src_df_row[applied]==1:
                    new_col='applied'
            elif new_col_nm == 'pl_cookie_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        if lender.lower() == 'prosper':
            if new_col_nm == 'commission_am':
                if src_df_row[old_col_nm]:
                    new_col=float(src_df_row[old_col_nm])*0.02
		else:
		    new_col=0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                funded,listed,applied=old_col_nm.split(',')
                if src_df_row[funded]==1:
                    new_col='funded'
                elif src_df_row[funded]==0 and src_df_row[listed]==1:
                    new_col='approved'
                elif src_df_row[funded]==0 and src_df_row[listed]==0 and src_df_row[applied]==1:
                    new_col='applied'
            elif new_col_nm == 'pl_cookie_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        if lender.lower() == 'lendingclub':
            if new_col_nm == 'commission_am':
		amt,ref_nm = old_col_nm.split(',')
                if 'auto' not in src_df_row[ref_nm].lower() and src_df_row[amt]:
                    new_col = float(src_df_row[amt])*0.015
		else: new_col = 0
	    elif new_col_nm in ('aflt_fin_tran_type_cd','src_status_tx'):
		app_dt,offer_dt,list_dt,issue_dt = old_col_nm.split(',')
		if src_df_row[issue_dt]: new_col = 'Issued'
		elif src_df_row[list_dt]: new_col = 'Listed'
		elif src_df_row[offer_dt]: new_col = 'Offered'
		elif src_df_row[app_dt]: new_col = 'Applied'
		else: new_col = 'Lead'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col

        if lender.lower() == 'sofi':
            if new_col_nm == 'commission_am':
                comm,campaign_name=old_col_nm.split(',')
                if src_df_row[comm].lower() == 'funded':
                    if src_df_row[campaign_name] not in SOFI_FILTER and src_df_row[comm]:
                        new_col = 200
                    else:
                        new_col = 0
                else:
                    new_col = 0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                if src_df_row[old_col_nm].lower() == 'funded':
                    new_col='funded'
                elif src_df_row[old_col_nm].lower() in ('app_submitted','docs_uploaded','sign_documents'):
                    new_col = 'approved'
                elif src_df_row[old_col_nm].lower() in ('register','app_created','app_started'):
                    new_col = 'started'
                elif src_df_row[old_col_nm].lower() in ('login','expired','plan_complete','plan_created','email_paid_welcome'):
                    for key,value in src_df_row.iteritems():
                        src_df_row[key]= ''
                    new_col = ''
            elif new_col_nm == 'tran_app_st_dt':
		status,dt = old_col_nm.split(',')
                if src_df_row[status].lower() in ('register','app_created','app_started'):
		    new_col = src_df_row[dt]#datetime.datetime.strptime(src_df_row[dt] , '%d%b%Y').strftime('%Y-%m-%d')
            elif new_col_nm == 'pl_tran_approved_dt':
                status,dt = old_col_nm.split(',')
                if src_df_row[status].lower() in ('app_submitted','docs_uploaded','sign_documents'):
                    new_col = src_df_row[dt]#datetime.datetime.strptime(src_df_row[dt] , '%d%b%Y').strftime('%Y-%m-%d') 
            elif new_col_nm == 'tran_post_dt':
                status,dt = old_col_nm.split(',')
                if src_df_row[status].lower() in ('funded'):
                    new_col = src_df_row[dt]#datetime.datetime.strptime(src_df_row[dt] , '%d%b%Y').strftime('%Y-%m-%d')
            elif new_col_nm == 'pl_cookie_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1},{2}".format(new_col, lender,new_col_nm))
            return new_col


        if lender.lower() == 'lightstream':
            if new_col_nm == 'commission_am':
		comm,purpose,status=old_col_nm.split(',')
                if src_df_row[status] == 'Funded':
                    if src_df_row[purpose] not in LIGHTSTREAM_LOAN_PURPOSE and src_df_row[old_col_nm]:
                        new_col = 0.01*float(src_df_row[old_col_nm])
                    else:
                        new_col = 0
                else:
                    new_col = 0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                if src_df_row[old_col_nm] == 'Funded':
                    new_col='funded'
                elif src_df_row[old_col_nm] in ('Approved','CounterV','Counter','PreFunding','Expired'):
                    new_col = 'approved'
                else:
                    new_col = 'applied'
            elif new_col_nm == 'pl_src_loan_purpose':
		if src_df_row[old_col_nm] in LIGHTSTREAM_LOAN_PURPOSE:
		    for key,value in src_df_row.iteritems():
		        src_df_row[key]= ''
                    new_col = ''
                else:
                    new_col= src_df_row[old_col_nm] 
            elif new_col_nm.lower() == 'prequal_ind':
                if src_df_row[old_col_nm]:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
	    elif new_col_nm.lower() in ('pl_tran_application_dt','tran_post_dt','merchant_am'):
		val,purpose=old_col_nm.split(',')
		if src_df_row[purpose] not in LIGHTSTREAM_LOAN_PURPOSE and src_df_row[val]:
			new_col = src_df_row[val]
		else:
			if new_col_nm.lower() == 'merchant_am': new_col = 0 
			else: new_col = None
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col


        if lender.lower() == 'bestegg':
            if new_col_nm == 'pl_cookie_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col



        if lender.lower() == 'lendingpoint':

            if new_col_nm == 'commission_am':
                if src_df_row[old_col_nm] == 1:
                    new_col = 375
		else:
		    new_col = 0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                funded,applied = old_col_nm.split(',')
                if src_df_row[funded] == 1:
                    new_col='funded'
                elif src_df_row[funded]==0 and src_df_row[applied]==1:
                    new_col='applied'
            elif new_col_nm == 'pl_cookie_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        if lender.lower() == 'onemain':
            if new_col_nm == 'commission_am':
                status = old_col_nm
                if src_df_row[status]=='0':
                    new_col = 0
                else:
                    new_col = 150
            elif new_col_nm == 'pl_tran_application_dt':
                new_col = datetime.datetime.strptime(src_df_row[old_col_nm] , '%d%b%Y').strftime('%Y-%m-%d')
            elif new_col_nm == 'tran_post_dt':
                new_col = datetime.datetime.strptime(src_df_row[old_col_nm] , '%d%b%Y').strftime('%Y-%m-%d')
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                if src_df_row[old_col_nm] == 1:
                    new_col='funded'
                else:
                    new_col = 'applied'

            elif new_col_nm == 'pl_cookie_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col


        if lender.lower() == 'payoff':

            if new_col_nm == 'commission_am':
                dt,amt,funded_flag = old_col_nm.split(',')
                if src_df_row[dt] != '' and src_df_row[funded_flag] == 1:
                    new_col = 0.0225*float(src_df_row[amt])
		else: new_col = 0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                funded,approved,applied = old_col_nm.split(',')
                if src_df_row[funded] == 1:
                    new_col='funded'
                elif src_df_row[funded]==0 and src_df_row[approved]==1:
                    new_col='approved'
                elif src_df_row[funded]==0 and src_df_row[approved] == 0 and src_df_row[applied]==1:
                    new_col='applied'
                else:
                    new_col = 'started'

            elif new_col_nm == 'pl_cookie_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
	    elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        if lender.lower() == 'iloan':
            if new_col_nm == 'commission_am':
                new_col = 150 if src_df_row[old_col_nm] is not None and src_df_row[old_col_nm] != '' and src_df_row[old_col_nm] > 0 else 0
            elif new_col_nm in ('aflt_fin_tran_type_cd','src_status_tx'):
                booked,transfered=old_col_nm.split(',')
                if src_df_row[booked]==1:
                    new_col='funded'
                elif src_df_row[booked]==0 and src_df_row[transfered]==1:
                    new_col='approved'
                else:
                    new_col='applied'
            elif new_col_nm == 'pl_cookie_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col



        if lender.lower() == 'goldmansachs':

            if new_col_nm == 'commission_am':
                status,flag='request_status','is_funded'
                if src_df_row[old_col_nm] and src_df_row[status].lower()=='approved' and src_df_row[flag]==1:
                    new_col= float(src_df_row[old_col_nm])*0.02
                else:
                    new_col=0.0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                status,flag=old_col_nm.split(',')
                if src_df_row[status].lower() in ['rejected','declined']:
                    new_col='applied'
                elif src_df_row[status].lower()=='approved' and src_df_row[flag]==1:
                    new_col='funded'
                elif src_df_row[status].lower()=='approved' and src_df_row[flag]==0:
                    new_col='approved'
            elif new_col_nm.lower() == 'prequal_ind':
                if src_df_row[old_col_nm]:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        elif lender.lower() == 'upgrade':

            if new_col_nm == 'commission_am':
                if src_df_row[old_col_nm]!='(null)' or src_df_row[old_col_nm]!='':
                    new_col= float(src_df_row[old_col_nm])*0.0225
                else:
                    new_col= 0.0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                issued_dt,submitted_dt,application_dt,offer_dt=old_col_nm.split(',')
                if src_df_row[issued_dt]!="(null)":
                    new_col='funded'
                elif src_df_row[submitted_dt]!="(null)":
                    new_col='applied'
                elif src_df_row[application_dt]!="(null)":
                    new_col='started'
		elif src_df_row[offer_dt]!="(null)":
		    new_col='offered'
            elif new_col_nm == 'pl_cookie_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col
        
        elif lender.lower() == 'avant':

            if new_col_nm == 'commission_am':
                if src_df_row[old_col_nm]:
                    new_col= float(src_df_row[old_col_nm])*0.0225
                else:
                    new_col=0.0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                funded,decision=old_col_nm.split(',')
                if src_df_row[funded].lower()=='yes':
                    new_col='funded'
                elif src_df_row[decision].lower()=='reject' or src_df_row[decision].lower()=='import':
                    new_col='applied'
                else:
                    new_col='started'
            elif new_col_nm == 'pl_cookie_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col
	
        elif lender.lower() == 'marinerfinance':
	    if new_col_nm == 'commission_am':
	        if src_df_row[old_col_nm]:
		    new_col = 0.035*float(sub(r'[^\d.]','',src_df_row[old_col_nm]))
		else:
		    new_col = 0
	    else:
		raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        elif lender.lower() == 'earnest':

            if new_col_nm == 'commission_am':
                if src_df_row[old_col_nm].lower()=='yes':
                    new_col= 100
                else:
                    new_col=0.0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                agreed,approved=old_col_nm.split(',')
                if src_df_row[agreed].lower()=='yes':
                    new_col='funded'
                elif src_df_row[approved].lower()=='yes':
                    new_col='approved'
                else:
                    new_col='applied'
            elif new_col_nm == 'pl_cookie_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm == 'src_unique_click_id':
                if (len(src_df_row[old_col_nm].lower()) >=4 and len(src_df_row[old_col_nm].lower())<=8) or len(src_df_row[old_col_nm].lower())==36:
                    pass
                else:
                    new_col= src_df_row[old_col_nm]
            elif new_col_nm.lower() == 'prequal_ind':
                if (len(str(src_df_row[old_col_nm])) >=4 and len(str(src_df_row[old_col_nm]))<=8) or len(str(src_df_row[old_col_nm]))==36:
                    new_col = 'Yes'
                else:
                    new_col = 'No'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col
    except CustomColumnException as cce:
        print cce
        raise CustomExecuteError(cce.value)
    except Exception as e:
	print e
        raise CustomExecuteError("Error: execute_custom for this lender: {0}".format(lender))


