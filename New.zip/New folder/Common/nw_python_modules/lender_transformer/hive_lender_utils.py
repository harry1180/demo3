import os
import json
import yaml
import nw_hive
import logging
import subprocess
from datetime import datetime
from s3_modules import list_s3_keys_enhanced
from target_columns_hive import TARGET_COL_LOOKUP, DEDUP_COL_LOOKUP, STAGE_PARTITIONS, FACT_PARTITIONS, FACT_ENRICHED_COLS
from custom_exceptions import CustomFileFormatError, CustomColumnException, CustomTableSchemaException

SERDE = {
'json' : 'org.openx.data.jsonserde.JsonSerDe'
}

# Set up the logger for PyHive for the WARNING level
logger = logging.getLogger("pyhive")
logger.setLevel(logging.WARNING)
ch = logging.StreamHandler()
ch.setLevel(logging.WARNING)
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
ch.setFormatter(formatter)
logger.addHandler(ch)

conn = nw_hive.connect(logger)


def load_hive_tbl(table_nm, file_format, s3_bucket, s3_folder, presto_script, tbl_type, parm_file=None, ins_sqls=[]):
	"""
	Loads data into staging table. If the table doesn't exists, 
	then it will create it first in hive before refreshing it.
	:param table_nm: str, stage table name with schema.
	:param file_format: str, data type of the underlying files.
	:param s3_bucket: str, S3 bucket containing the partition files.
	:param s3_folder: str, S3 folder containing the partition files.
	:param presto_script: str, location of the Presto executable script.
	:param ins_sqls: list, list containing paths to all the Fact/Post stage Insert SQLs (defaults to []).
	:param tbl_type: str, type of table ('stage'/'fact').
	:param parm_file: json with sql parameters
	"""
	all_cols = TARGET_COL_LOOKUP + STAGE_PARTITIONS + FACT_PARTITIONS + FACT_ENRICHED_COLS
	print 'Total columns in TARGET_COL_LOOKUP: {}, STAGE_PARTITIONS: {}, FACT_PARTITIONS: {}, FACT_ENRICHED_COLS: {}'.format(
		len(TARGET_COL_LOOKUP), len(STAGE_PARTITIONS), len(FACT_PARTITIONS), len(FACT_ENRICHED_COLS))

	if not nw_hive.hive_table_exists(conn, table_nm):
	    print 'Table does not exist! Creating with file format {}'.format(file_format)
	    create_tbl(file_format, s3_bucket, s3_folder, table_nm, tbl_type) 
	else:
	    tbl_cols, tbl_partition_cols = nw_hive.get_hive_table_column_metadata(conn, table_nm)
	    tot_tbl_cols = len(tbl_cols)
	    print 'TOTAL COLUMNS IN TABLE {}: {}'.format(table_nm,tot_tbl_cols)

	    if tot_tbl_cols < len(all_cols):
		add_new_cols(table_nm, tbl_cols, tbl_partition_cols, tbl_type)
	    elif tot_tbl_cols > len(all_cols):
		err_msg = 'More columns found in table {} than expected. Please add the new cols to TARGET_COL_LOOKUP'.format(table_nm)
                print err_msg
                raise CustomColumnException(err_msg)
	
	refresh_tbl(table_nm, presto_script, ins_sqls, tbl_type, parm_file)
	

def ins_tbl(table_nm, presto_script, ins_sqls, parm_file):
	"""
	Updates the Poststage/Fact Table.
	:param table_nm: str, table name
	:param presto_script: str, Location of the Presto executable script
	:param fct_ins_sqls: list, list containing paths to all the Poststage/Fact Insert SQLs
	"""
	if len(ins_sqls) == 0:
		print 'No INSERT SQLs to exceute on the table {}'.format(table_nm)
		return
	
	for sql in ins_sqls:
		try:
		    print 'Executing : {}'.format(sql)
		    subprocess.call([presto_script, sql, parm_file])
		except Exception as e:
		    print e
		    break


def add_new_cols(table_nm, tbl_cols, tbl_partition_cols, tbl_type):
	"""
	Adds additional columns in the table based on the columns defined in target_columns_hive.py.
	:param table_nm: str, Hive table name
	:param tbl_cols: list, all columns in the table
	:param tbl_partition_cols: list, all partition columns in the table
	:param tbl_type: str, table type ('stage'/'fact'/'poststage')
	"""
	if tbl_type == 'stage':
		all_cols = TARGET_COL_LOOKUP + STAGE_PARTITIONS + FACT_PARTITIONS
	elif tbl_type in ('poststage','fact'):
		all_cols = TARGET_COL_LOOKUP + STAGE_PARTITIONS + FACT_PARTITIONS + FACT_ENRICHED_COLS
	else:
                err_msg = 'Un-recognized schema name!'
                print err_msg
                raise CustomTableSchemaException(err_msg)

	cols_to_add = []

	for col_nm,col_type in all_cols:
		if col_nm in tbl_partition_cols: continue
		if col_nm not in [col["name"] for col in tbl_cols]: 	
			cols_to_add.append("`{}` {}".format(col_nm, col_type))

	if len(cols_to_add) > 0:
		print "Adding columns: {}".format(", ".join(cols_to_add))
		add_col_sql = "ALTER TABLE `{}` ADD COLUMNS ({})".format(
				table_nm, ", ".join(cols_to_add))

		nw_hive.exec_hive_sql_ddl(conn, add_col_sql)


def refresh_tbl(table_nm, presto_script, ins_sqls, tbl_type, parm_file):
	"""
	Updates data in the table. Derives the table type/schema from the table name.
	For Stage - refreshes the table metastore
	For Fact - generates a newly versioned Fact table
	:param table_nm: str, Hive table name
	:param presto_script: str, location of the Presto executable script
	:param ins_sqls: list, list containing paths to all the Poststage/Fact Insert SQLs (defaults to [])
	:param tbl_type: str, table type ('stage'/'poststage'/'fact')
	"""
	if tbl_type == 'stage':
		print 'Refreshing Stage Table..'
		nw_hive.exec_hive_sql_ddl(conn,'MSCK REPAIR TABLE {}'.format(table_nm))
	elif tbl_type in ('poststage','fact'):
        	print 'Updating {} table..',format(tbl_type)
                ins_tbl(table_nm, presto_script, ins_sqls, parm_file)
	else:
		err_msg = 'Un-recognized schema name!'
                print err_msg
                raise CustomTableSchemaException(err_msg)


def generate_create_tbl_sql(table_nm, file_format, partition_by, tbl_type, cols, s3_bucket, s3_folder):
	"""
	Generates and returns SQL for creating Hive table.
	:param table_nm: str, Hive table name
	:param file_format: str, data type of the table data
	:param partition_by: str, partitioned columns and corresponding types
	:param tbl_type: str, external/managed table
	:param cols: list, list of tuples with <column_name, column_type>
	:param s3_bucket: str, S3 bucket holding the table
	:param s3_folder: str, S3 folder holding the table
	"""
	if file_format.lower() == 'json':
		# working with non-partitioned json tables.
		partition_lst = []
		for field in partition_by.split(','):
			field_nm, field_type = field.split()
			partition_lst.append((field_nm,field_type))

		cols = cols + partition_lst	        	
		quotes = '"'	

        	sql = "CREATE {}TABLE {} (\n{}\n)\nROW FORMAT SERDE '{}'\nWITH SERDEPROPERTIES(\n{}\n)\nLOCATION '{}'\nTBLPROPERTIES('serialization.null.format' = '')".format(tbl_type, table_nm, ',\n'.join(tup[0]+' '+tup[1] for tup in cols), SERDE[file_format.lower()], ',\n'.join(quotes+"mapping."+tup[0]+quotes+" = "+quotes+tup[0]+quotes for tup in cols), "s3://{0}/{1}".format(s3_bucket,s3_folder))

        else:
        	sql = "CREATE {}TABLE {} (\n{}\n)\nPARTITIONED BY ({}) STORED AS {} LOCATION '{}'\nTBLPROPERTIES('serialization.null.format' = '')".format(
                	tbl_type, table_nm, ',\n'.join(tup[0]+' '+tup[1] for tup in cols), partition_by, file_format.upper(), "s3://{0}/{1}".format(s3_bucket,s3_folder))

	return sql


def create_tbl(file_format, s3_bucket, s3_folder, table_nm, tbl_type):
	"""
	Creates Hive external staging table after evaluating that all files are in the specified 'file_format'.
	:param file_format: str, data type of the underlying files.
        :param s3_bucket: str, S3 bucket containing the partition files.
        :param s3_folder: str, S3 folder containing the partition files.
	:param table_nm: str, Hive table name.
	:param tbl_type: str, table type ('stage'/'fact')
	"""
	if tbl_type == 'stage':
		file_lst = list_s3_keys_enhanced(s3_folder, s3_bucket=s3_bucket)
		print "Files in bucket: ",file_lst
		format_check = check_file_format(file_lst, file_format)

		if format_check:
			partition_by = '{} STRING, {} STRING'.format(DEDUP_COL_LOOKUP['FILE_DT'], DEDUP_COL_LOOKUP['SOURCE'])
			# Extra space after EXTERNAL is intentional.
			tbl_type = 'EXTERNAL '
			cols = TARGET_COL_LOOKUP + FACT_PARTITIONS
			# All Date/Timestamp columns are converted to "string" due to Presto discrepancy with date fields.
			cols = [(tup[0], tup[1].replace("date","string")) for tup in cols]
			cols = [(tup[0], tup[1].replace("timestamp","string")) for tup in cols]
		else:
			err_msg = 'No file in directory with file format {}'.format(file_format)
	     		print err_msg
	     		raise CustomFileFormatError(err_msg)
	elif tbl_type in ('poststage','fact'):
		partition_by = '{} DATE'.format(DEDUP_COL_LOOKUP['DW_EFF_DT'])
		tbl_type = ''
		cols = TARGET_COL_LOOKUP + STAGE_PARTITIONS + FACT_ENRICHED_COLS
	else:
		err_msg = 'Un-recognized schema name!'
                print err_msg
                raise CustomTableSchemaException(err_msg)	
			
	sql = generate_create_tbl_sql(table_nm, file_format, partition_by, tbl_type, cols, s3_bucket, s3_folder)
	print 'Creating table : {}'.format(table_nm)
	nw_hive.exec_hive_sql_ddl(conn, sql)
		

def check_file_format(file_lst, file_format):
	"""
	Checks whether all files in file_lst are of the specified file_format.
	:param file_lst: str, list of all files in the directory.
	:param file_format: str, data type of the underlying files.
	"""
	for f in file_lst:
		 if 'SUCCESS' not in f and file_format not in f: return 0
	return 1


def print_hive_tbl(table_nm):
	"""
	Prints content of a specified Hive table.
	:param table_nm: specified Hive table.
	"""
	cur = conn.cursor()
	cur.execute('SELECT * FROM {}'.format(table_nm))
	print cur.fetchall()
	cur.close()
	
