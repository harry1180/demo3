import json
import os
import sys
import traceback
import time
from dateutil.parser import parse
from urlparse import urljoin

from email_module import send_email
from excelutils import excel2json
from s3_modules import s3_file_upload
from tran_log_modules import insert_log, update_log_cnt
import lender_transformation
import lender_transformation_new
from lender_utils import get_lenders, get_lender_details


# Valid file extension for
VALID_INPUT_EXTS = ['.csv', '.xlsx', '.xls', '.zip', '.gzip']

# S3 URL Parts
S3_URL_BASE = 'https://console.aws.amazon.com/s3/object/'
S3_URL_END = 'region=us-east-1&tab=overview'

REDSHIFT_FLAGS = {'redshift': True, 'all': True}
NERDLAKE_FLAGS = {'nerdlake': True, 'all': True}


def getskiprows(lender, map_file=None):
    if lender.lower() in ('citizensbank'):
        if os.path.splitext(os.path.basename(map_file))[0] == 'citizensbank_inschool_map':
            return 2
        elif os.path.splitext(os.path.basename(map_file))[0] == 'citizensbank_refi_map':
            return 3
    elif lender.lower() in ('lightstream'):
        return 3
    elif lender in ('quicken_purchase', 'quicken_refi', 'quicken_calls'):
        return 4
    elif lender in ('lendingtree_web', 'lendingtree_phone'):
        return 6
    elif lender in ('synchrony', 'ally', 'citizens_access'):
        return 9
    elif lender in ('cit'):
        return 10
    elif lender in ('us_bank'):
        return 11
    elif lender in ('marcus'):
        return 12
    elif lender in ('capitalone'):
        if os.path.splitext(os.path.basename(map_file))[0] == 'capitalone_cd_map':
            return 11
        elif os.path.splitext(os.path.basename(map_file))[0] == 'capitalone_mma_map':
            return 13
    return 0


def getskipfooter(lender):
    if lender in ('quicken_purchase', 'quicken_refi', 'quicken_calls', 'smartbiz', 'synchrony', 'capitalone',
                  'cit', 'marcus', 'ally', 'citizens_access'):
        return 1
    elif lender == 'ablelending':
        return 2
    return 0


def getsheetname(lender):
    if lender == 'commonbond':
        return ['Loans - Booked', 'Loans - Applications']
    elif lender == 'sofi':
        return 'SL'
    elif lender == 'laurelroad':
        return 'Tape'
    elif lender.lower() == 'freedomfinancial':
        return 'FreedomPlus'
    elif lender.lower() == 'lightstream':
        return 'Partner Posting Application Det'
    return 0


def multi_sheet_join(lender):
    if lender == 'commonbond':
        return 'merge'
    return None


def check_blocked_file(input_file, vertical):
    if vertical == 'pl':
        if 'lendingclub_nw_sb' in input_file.lower(): return True
    return False


def trigger_email(email_template_file, message=None, attachment=None):
    # parse template
    with open(email_template_file) as email_file:
        email_info = json.loads(email_file.read().replace('\n', ' ').replace('\r', ' '), strict=False)

    # build email message and add file attachment
    if attachment:
        email_info['attachment'] = attachment
        email_info['subject'] = '{subject}'.format(subject=email_info['subject'])
    if message:
        email_info['body'] = '{body} {message}'.format(body=email_info['body'], message=message)

    send_email(email_info)


def main(input_src, s3_bucket, s3_folder, email_template, vertical, aflt_tran_id, new_transform_in, hivefile_ext,
         hive_write_mode, redshift_override, redshift_in, nerdlake_in, map_dwnl_dir):
    """
    Main python script to convert Personal Loan raw Excel files to JSON files. Given a raw file path or
    path to directory containing raw files, each file will be logged to the transaction log table,
    converted from xlsx to json, and moved to S3.
    :param input_src: str, Input file path or directory path. All files will be processed if directory.
    :param s3_bucket: str, S3 bucket to store files
    :param s3_folder: str, S3 folder to store files
    :param email_template: str, file path to JSON email template
    :param vertical: str, name of vertical that lender belongs to
    :param aflt_tran_id: int, lender id
    :param new_transform_in: bool, Flag for using new transformation framework or not (this is temporary until we
        transition all lenders to new framework)
    :param hivefile_ext:str, extension of the output partition files for hive (defaults to 'orc')
    :param hive_write_mode: str, whether to write/append to existing partition (defaults to 'append')
    :param redshift_override: boolean, whether to generate redshift file or not (even when 1 file per day is generated). Defaults to False
    :param redshift_in: boolean, whether to generate Redshift file or not. Defaults to True
    :param nerdlake_in: boolean, whether to generate Nerdlake file or not. Defaults to True
    :param map_dwnl_dir: str, local path to download map files to
    """

    registered_lenders = get_lenders(vertical)
    file_list = []
    # Generate list of files to process from input source
    if os.path.isfile(input_src):
        file_list = [input_src]
    elif os.path.isdir(input_src):
        file_list = [os.path.join(input_src, f) for f in os.listdir(input_src) if
                     os.path.isfile(os.path.join(input_src, f)) and os.path.splitext(f)[1] in VALID_INPUT_EXTS]
    else:
        print("No input files to process!")

    # S3 folder to store partition files for hive (common for all verticals)
    s3_hive_folder = 's3n://east1-prod-nerdlake-0/dwnl_rcd_aflt_tran_stage/aflt_tran_process_files'

    for input_file in file_list:

        try:
            print('-----------------Generating output and input file names: Started-----------------')
            print('Input File: {}'.format(input_file))
            # To check whether the file is a valid file to process. This check is for cases where we get report for multiple verticals in one pull.
            # e.g. LendingClub SFTP for PL produces both SMB and PL reports.
            if check_blocked_file(input_file, vertical):
                continue
            input_filename = os.path.basename(input_file)
            fn, input_file_ext = os.path.splitext(input_file)
            fn = fn.split('/')
            print "fn: %s, input_file_ext: %s" % (fn, input_file_ext)
            outfile_dir = os.path.dirname(input_file)
            outfile_nm = '{}_cleaned'.format(os.path.splitext(os.path.basename(input_file))[0])
            output_redshift_file = os.path.join(outfile_dir, '{name}.{ext}'.format(name=outfile_nm, ext='json'))
            output_transformed_file = os.path.join(outfile_dir, '{name}.{ext}'.format(name=outfile_nm, ext='xlsx'))
            print('Output Redshift File: {}'.format(output_redshift_file))
            print('Output Transformed File {}'.format(output_transformed_file))
            print('-----------------Generating output and input file names: Completed-----------------')

            print('-----------------Getting lender name and corresponding mapping file: Started-------')
            lender, lender_map_path = get_lender_details(fn, registered_lenders, vertical)
            if lender == 'unknown':
                raise Exception("Lender is not part of the control table")
            if not lender_map_path:
                raise Exception("Unable to find mapping file")
            try:
                file_rcvd_dt = (input_filename.rpartition('_')[-1]).split('.')[0]
                parse(file_rcvd_dt)
            except:
                print "Error getting date from filename, going ahead with system time."
                file_rcvd_dt = time.strftime("%d-%m-%y")
            print 'lender mapping file : ', lender_map_path
            print('-----------------Getting lender name and corresponding mapping file: Ended---------')

            # new_transform_in is a flag for using the "new" row-based transformation code. Before using the new
            # you must convert any existing custom functions to use row-based logic (a row is a dict) and you also
            # need to convert mapping files to the new standard.
            if new_transform_in:

                print('-----------------Transforming Source to Target: Started-----------------')
                lender_transformation_new.process_tran_file(input_file, output_redshift_file, hivefile_ext,
                                                            lender_map_path, s3_hive_folder, s3_bucket, lender,
                                                            file_rcvd_dt, vertical, sheetname=getsheetname(lender),
                                                            multisheetjoin=multi_sheet_join(lender),
                                                            skiprows=getskiprows(lender, lender_map_path),
                                                            skip_footer=getskipfooter(lender),
                                                            hive_write_mode=hive_write_mode,
                                                            redshift_override=redshift_override,
                                                            redshift_in=redshift_in,
                                                            nerdlake_in=nerdlake_in,
                                                            map_dwnl_dir=map_dwnl_dir)
                print('-----------------Transforming Source to Target: Completed---------------')

                if os.path.isfile(output_redshift_file):
                    print('-----------------Insert file in Redshift log table: Started-----------------')
                    valid_log = insert_log(aflt_tran_id, output_redshift_file, lender)
                    print('-----------------Insert file in Redshift log table: Completed-----------------')

                error_file_nm = outfile_nm.replace('_cleaned', '_error')
                error_file = '{}.csv'.format(os.path.join(outfile_dir, error_file_nm))
                if os.path.isfile(error_file):
                    print('-----------------Handle Error Files: Started------------------------')
                    print('Sending to S3 {}'.format(error_file_nm))
                    error_s3_folder = os.path.join(s3_folder, 'error')
                    s3_file_upload(error_file, s3_bucket, error_s3_folder)

                    print('Sending Error Email {}'.format(error_file_nm))
                    url_contents = '{}?{}'.format(os.path.join(s3_bucket, error_s3_folder, error_file_nm), S3_URL_END)
                    error_file_url = urljoin(S3_URL_BASE, url_contents)
                    error_message = '{} error file: {}'.format(vertical, error_file_url)
                    trigger_email(email_template, error_message)

                    if valid_log:
                        print('Logging Error Count for {}'.format(lender))
                        update_log_cnt(aflt_tran_id, error_file, lender, cnt_type='error')
                    print('-----------------Handle Error Files: Completed------------------------')
                warning_file_nm = outfile_nm.replace('_cleaned', '_warning')
                warning_file = '{}.csv'.format(os.path.join(outfile_dir, warning_file_nm))
                if os.path.isfile(warning_file):
                    print('-----------------Handle Warning Files: Started------------------------')
                    print('Sending to S3 {}'.format(warning_file))
                    warning_s3_folder = os.path.join(s3_folder, 'warning')
                    s3_file_upload(warning_file, s3_bucket, warning_s3_folder)

                    print('Emailing {}'.format(warning_file))
                    url_contents = '{}?{}'.format(os.path.join(s3_bucket, warning_s3_folder, warning_file_nm),
                                                  S3_URL_END)
                    warning_file_url = urljoin(S3_URL_BASE, url_contents)
                    warning_message = '{} warning file: {}'.format(vertical, warning_file_url)
                    trigger_email(email_template, warning_message, warning_file)

                    if valid_log:
                        print('Logging Warning Count for {}'.format(lender))
                        update_log_cnt(aflt_tran_id, warning_file, lender, cnt_type='warning')
                    print('-----------------Handle Warning Files: Completed------------------------')

            else:

                print('-----------------Running python script to transform excel: Started-----------------')
                lender_transformation.transform_to_excel(input_file, output_transformed_file, lender_map_path,
                                                         s3_bucket, lender, file_rcvd_dt, vertical,
                                                         skiprows=getskiprows(lender),
                                                         skip_footer=getskipfooter(lender))
                print('-----------------Running python script to transform excel: Completed---------------')

                print('-----------------Running python script to convert csv to json: Started-------------')
                excel2json(output_transformed_file, output_redshift_file, ignoreheadercase=True, new_map=True)
                print('-----------------Running python script to convert csv to json: Completed-----------')

                print('-----------------Moving the Transformed file(.csv/.xlsx) to S3: Started------------------------')
                transformed_s3_folder = os.path.join(s3_folder, 'archive', 'transformed')
                s3_file_upload(output_transformed_file, s3_bucket, transformed_s3_folder)
                print('-----------------Moving the Transformed file(.csv/.xlsx) to S3: Completed----------------------')

                print('-----------------Insert file in log table: Started-----------------')
                insert_log(aflt_tran_id, output_transformed_file, lender)
                print('-----------------Insert file in log table: Completed---------------')

            if os.path.isfile(output_redshift_file):
                print(
                    '-----------------Moving the Transformed File to S3 - Redshift: Started--------------------------')
                dest_s3_folder = os.path.join(s3_folder, 'output', lender)
                s3_file_upload(output_redshift_file, s3_bucket, dest_s3_folder)
                print(
                    '-----------------Moving the Transformed File to S3 - Redshift: Completed-------------------------')

                if nerdlake_in:
                    print '******** FOLLOWING IS TEMPORARY UNTIL WE GET SPARK SUPPORT *****'
                    print(
                        '-----------------Moving the Transformed File to S3 - Nerdlake: Started-------------------------------')
                    outfile_nm = lender + time.strftime("_%Y-%m-%d_%H")
                    output_nl_file = os.path.join(outfile_dir, '{name}.{ext}'.format(name=outfile_nm, ext='json'))
                    os.rename(output_redshift_file, output_nl_file)
                    s3_hive_folder = 'dwnl_rcd_aflt_tran_stage/aflt_tran_process_files_non_spark'
                    nerdlake_bucket = 'east1-prod-nerdlake-0'
                    s3_file_upload(output_nl_file, nerdlake_bucket, s3_hive_folder)
                    print(
                        '-----------------Moving the Transformed File to S3 - Nerdlake: Completed-----------------------------')

            print(
                '-----------------Moving the Raw Input file(.csv/.xlsx) to S3: Started--------------------------------')
            raw_s3_folder = os.path.join(s3_folder, 'archive', 'raw')
            s3_file_upload(input_file, s3_bucket, raw_s3_folder)
            print(
                '-----------------Moving the Raw Input file(.csv/.xlsx) to S3: Completed------------------------------')

        except Exception, e:
            print('Exception: {}'.format(e))
            print('Failure processing file {}! An email will be sent out to the concerned party.'.format(input_file))
            email_message = str(e) + ' ' + str(traceback.format_exc())
            trigger_email(email_template, email_message, input_file)
            continue


if __name__ == '__main__':
    # Get the command line variables
    input_src = sys.argv[1]
    s3_bucket_name = sys.argv[2]
    s3_folder_name = sys.argv[3]
    email_json_template = sys.argv[4]
    vertical = sys.argv[5]
    aflt_tran_id = sys.argv[6]
    try:
        new_transform_in = sys.argv[7]
        new_transform_in = True
    except:
        new_transform_in = False
    try:
        hivefile_ext = sys.argv[8]
    except:
        hivefile_ext = 'orc'
    try:
        hive_write_mode = sys.argv[9]
    except:
        hive_write_mode = 'append'
    try:
        redshift_override = sys.argv[10]
    except:
        redshift_override = 'yes'
    try:
        sql_engine = sys.argv[11]
    except:
        sql_engine = 'redshift'

    try:
        map_dwnl_dir = sys.argv[12]
    except:
        map_dwnl_dir = '/tmp'

    if redshift_override.lower() == 'no':
        redshift_override = False
    else:
        redshift_override = True

    redshift_in = REDSHIFT_FLAGS.get(sql_engine, False)
    nerdlake_in = NERDLAKE_FLAGS.get(sql_engine, False)

    # Execute main function
    main(input_src, s3_bucket_name, s3_folder_name, email_json_template, vertical, aflt_tran_id, new_transform_in,
         hivefile_ext, hive_write_mode, redshift_override, redshift_in, nerdlake_in, map_dwnl_dir)
