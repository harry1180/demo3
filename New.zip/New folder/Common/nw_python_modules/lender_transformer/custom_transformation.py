import pandas as pd
import numpy as np
import os
import sys
import re
import xlsxwriter
from s3_modules import s3_file_download
from redshift_modules import exec_query
from custom_exceptions import MappingFileError
from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException
from custom_transformation_smb import execute_custom_smb
from custom_transformation_mrtg import execute_custom_mortgages
from custom_transformation_investing import execute_custom_investing


def execute_custom(newDf, dataDf, x_list, lender, vertical):
    '''
        Performs vertical specific custom transformations on the corresponding columns.
        newDf : output data frame which holds the transformed data
        dataDf : input data frame which holds the raw input data
        x_list : list specifying the mapping to be done from dataDf to newDf
        lender : lender's name for which transformation is being performed
        vertical : lender's vertical
    '''
    if vertical == 'smb':
        execute_custom_smb(newDf, dataDf, x_list, lender)
    elif vertical == 'mortgages':
        execute_custom_mortgages(newDf, dataDf, x_list, lender)
    elif vertical == 'investing':
        execute_custom_investing(newDf, dataDf, x_list, lender)
    else:
        print 'Custom transformation for this vertical not supported yet'
    return
