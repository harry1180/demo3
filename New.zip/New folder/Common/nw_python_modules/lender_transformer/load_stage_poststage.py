import os
import sys
import json
import traceback

from email_module import send_email
from tran_log_modules import update_log_stage_cnt
from redshift_modules import exec_query, generate_manifest_file


def init_email(email_template):
    with open(email_template) as email_file:
        email_info = json.loads(email_file.read().replace('\n', ' ').replace('\r', ' '), strict=False)
    return email_info


def get_lender_lst(aflt_tran_id):
    query = "Select distinct prog_nm from dw_report.dw_aflt_tran_log where to_date(dw_load_ts,'yyyy-mm-dd') = to_date(sysdate,'yyyy-mm-dd') and aflt_id = {0}".format(
        aflt_tran_id)
    lenders = exec_query(query)
    return [lender['prog_nm'] for lender in lenders]


def main(s3_bucket, s3_folder, email_template, stage_table, poststg_table, poststg_script, s3_access_key, s3_secret_key,
         json_path, aflt_tran_id, from_dt, to_dt, post_col='src_prod_nm', s3_prod_load_creds=None):
    """
    Main python script to load the transformed partners' JSON files into stage and poststage tables.
    :param s3_bucket: str, S3 bucket holding the transformed files and where the generated manifest files will be stored.
		      e.g. 'east1-prod-dwh-s3-0'
    :param s3_folder: str, S3 folder holding the transformed files.
		      e.g. 'dw_aflt_tran_mortgages_f_files/output/'
    :param stage_table: str, stage table to store data from the confirmed JSON files.
		      e.g. 'dw_stage.aflt_tran_mrtg_cnfrmd_s'
    :param poststg_table: str, post-stage table to store data from the staging table.
    		      e.g. 'dw_stage.aflt_tran_poststage_mortgages'
    :param email_template: str, absolute file path to JSON email template.
		      e.g. '/data/etl/Scripts/dw_aflt_tran_mortgages_f/pythonscripts/email_info.json'
    :param poststg_script: str, absolute file path to post stage insert .sql script.
                      e.g. '/data/etl/Scripts/dw_aflt_tran_mortgages_f/sqlscripts/aflt_tran_poststage_mortgages_confirmed.sql'
    :param s3_access_key: str, S3 Access key.
    :param s3_secret_key: str, S3 Secret key.
    :param json_path: str, absolute S3 path to JSONPATHS used for loading to stage table.
		      e.g. 'east1-prod-dwh-s3-0/json/aflt_transactions/aflt_tran_mortgages_confirmed.jsonpaths'
    :pram aflt_tran_id: int, aflt_tran_id of vertical.
		      e.g. 37
    :param from_dt: date, date to begin file-processing.
    :param to_dt: date, date to end file-processing.
    :param post_col: str, name of the column use to delete entries from poststage table.

    """

    lender_lst = get_lender_lst(aflt_tran_id)
    print lender_lst
    for lender in lender_lst:

        try:

            print '*****************Processing for lender: %s**************************' % lender

            print('-----------------Generating manifest files: Started-----------------')
            # Since s3_folder is of the format <s3_foldername>/output/ (as generated from the process_raw_to_confirmed_files.py script),
            # manifest folder will be created as <s3_foldername>/manifest.
            # e.g. dw_aflt_tran_mortgages_f_files/manifest (when s3_folder = dw_aflt_tran_mortgages_f_files/output/)
            s3_parent_folder = s3_folder.split('/')[0]
            s3_manifest_folder = os.path.join(s3_parent_folder, 'manifest')
            generate_manifest_file('Prod', s3_bucket, s3_folder, lender, s3_manifest_folder, from_dt, to_dt, 'modified')
            print('-----------------Generating manifest files: Completed---------------')

            print('-----------------Deleting from stage table: Started-----------------')
            query_stage_delete = "delete from {0};".format(stage_table)
            exec_query(query_stage_delete)
            print('-----------------Deleting from stage table: Completed----------------')

            print('-----------------Loading data in stage table: Started-----------------')
            manifest_file = lender + '_manifest.json'
            if s3_prod_load_creds:
                query_stage_load = "copy {0} from 's3://{1}/{2}/manifest/{3}' credentials '{4}' JSON as 's3://{5}' DATEFORMAT AS 'auto' TRUNCATECOLUMNS ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF EMPTYASNULL manifest;".format(
                    stage_table, s3_bucket, s3_parent_folder, manifest_file, s3_prod_load_creds, json_path)
            else:
                query_stage_load = "copy {0} from 's3://{1}/{2}/manifest/{3}' credentials 'aws_access_key_id={4};aws_secret_access_key={5}' JSON as 's3://{6}' DATEFORMAT AS 'auto' TRUNCATECOLUMNS ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF EMPTYASNULL manifest;".format(
                    stage_table, s3_bucket, s3_parent_folder, manifest_file, s3_access_key, s3_secret_key, json_path)
            exec_query(query_stage_load)
            print('-----------------Loading data in stage table: Completed----------------')

            print('-----------------Deleting from post stage table: Started-----------------')
            query_ps_delete = "delete from {0} where lower({1}) = lower('{2}');".format(poststg_table, post_col, lender)
            exec_query(query_ps_delete)
            print('-----------------Deleting from post stage table: Completed---------------')

            print('-----------------Insert/Update the data to post stage table: Started---------------')
            with open(poststg_script) as fl:
                content = fl.readlines()
            content = ''.join(content).replace('\n', ' ').split(';')
            if not content[-1].strip():
                content = content[:-1]
            for query in content:
                exec_query(query)
            print('-----------------Insert/Update the data to post stage table: Completed--------------')

            print('-----------------Update stage count in the log table: Started-----------------')
            update_log_stage_cnt(aflt_tran_id)
            print('-----------------Update stage count in the log table: Completed---------------')

        except Exception, e:
            email_info = init_email(email_template)
            print('Exception: {}'.format(e))
            print('Failure processing lender {}! An email will be sent out to the concerned party.'.format(lender))
            email_info['subject'] = email_info['subject'] + ' for lender ' + lender
            email_info['body'] = email_info['body'] + str(e) + ' ' + str(traceback.format_exc())
            send_email(email_info)
            continue


if __name__ == '__main__':

    if len(sys.argv) < 14:
        print(
        'Incorrect number of arguments passed. Please provide the following:\n 1. S3 bucket name\n 2. S3 folder containing the transformed files\n 3. email_json path\n 4. Stage table name\n 5. Post-stage table name\n 6. Post-stage table .sql file path\n 7. S3 Access key\n 8. S3 Secret key\n 9. JSON file path\n 10. aflt_tran_id of the Vertical\n 11. from_date\n 12. to_date\n 13. post_col\n')
    else:
        s3_bucket = sys.argv[1]
        s3_folder = sys.argv[2]
        email_json_template = sys.argv[3]
        stage_table = sys.argv[4]
        poststg_table = sys.argv[5]
        poststg_script = sys.argv[6]
        s3_access_key = sys.argv[7]
        s3_secret_key = sys.argv[8]
        json_path = sys.argv[9]
        aflt_tran_id = sys.argv[10]
        from_dt = sys.argv[11]
        to_dt = sys.argv[12]
        post_col = sys.argv[13]
        try:
            s3_prod_load_creds = sys.argv[14]
        except:
            s3_prod_load_creds = None

    # Execute main function
    main(s3_bucket, s3_folder, email_json_template, stage_table, poststg_table, poststg_script, s3_access_key,
         s3_secret_key, json_path, aflt_tran_id, from_dt, to_dt, post_col, s3_prod_load_creds)
