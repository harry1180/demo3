import re

from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException


RE_NON_NUMERIC = re.compile(r'[^\d.]+')


def kabbage_helper(kabbage_id):
    uid = ''
    try:
        extract_uid = re.match(r"^.*%(?P<discardChars>.*)corpID%(?P<unique_id>.*)", kabbage_id)
        if extract_uid:
            uid = extract_uid.group('unique_id')[len(extract_uid.group('discardChars')):]
    except:
        raise CustomColumnException("Error encountered while processing kabbage helper")
    return uid


def execute_custom_smb(src_df_row, old_col_nm, new_col_nm, transform, lender):
    try:
        lender = lender.strip().lower()
        new_col = ''

        if lender == 'bluevine':
            if new_col_nm == 'loan_amt_issued':
                client_flex_col_nm, client_factor_col_nm = old_col_nm.split(',')
                client_flex = int(src_df_row[client_flex_col_nm])
                client_factor = int(src_df_row[client_factor_col_nm])

                if client_flex == 0 and client_factor == 0:
                    new_col = ''
                elif client_flex >= client_factor:
                    new_col = client_flex
                else:
                    new_col = client_factor
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        #TODO: update this custom function
        # elif lender == 'streetshares':
        #     if new_col == 'click_id':
        #         col = x_list[1]
        #         newDf[new_col] = dataDf[col].str.split('=', 1).str[1]
        #     else:
        #         raise CustomColumnException(
        #             "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

        elif lender == 'ondeck':
            if new_col_nm == 'funnel_status':
                appl_status_lookup = {'nnn': "Not Applied",
                                      'nny': "Declined",
                                      'nyn': "Approved",
                                      'nyy': "Approved",
                                      'ynn': "Applied",
                                      'yny': "Declined",
                                      'yyn': "Approved",
                                      'yyy': "Approved"
                                      }
                appl_status = ''
                for field in old_col_nm.split(','):
                    status = src_df_row[field.strip()].lower()
                    if status == 'y':
                        appl_status += status
                    else:
                        appl_status += 'n'
                new_col = appl_status_lookup[appl_status]
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        elif lender == 'smartbiz':
            if new_col_nm == 'click_id':
                campagn_id, partnr_campagn_id = old_col_nm.split(',')
                if src_df_row[campagn_id.strip()] >= src_df_row[partnr_campagn_id.strip()]:
                    new_col = src_df_row[campagn_id.strip()]
                else:
                    new_col = src_df_row[partnr_campagn_id.strip()]
            elif new_col_nm == 'loan_amt_issued':
                new_col = src_df_row['src_col_12']
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        elif lender == 'lendingclub':
            if new_col_nm == 'funded_interest_rt':
                frnt_end_rt, loan_intrst_rt = old_col_nm.split(',')
                if src_df_row[frnt_end_rt.strip()] >= src_df_row[loan_intrst_rt.strip()]:
                    new_col = src_df_row[frnt_end_rt.strip()]
                else:
                    new_col = src_df_row[loan_intrst_rt.strip()]
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        elif lender == 'kabbage':
            if new_col_nm == 'click_id':
                final_ref_id, final_corr_data = [c.strip() for c in old_col_nm.split(',')]
                if len(src_df_row[final_corr_data]) == 32:
                    new_col = src_df_row[final_corr_data]
                elif src_df_row[final_ref_id].startswith('partner_nerdwallet'):
                    new_col = kabbage_helper(src_df_row[final_ref_id])
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        elif lender == 'fundbox':
            if new_col_nm == 'application_complete_dt':
                registration, conn_status = [c.strip() for c in old_col_nm.split(',')]
                if src_df_row[conn_status].lower() == 'connected':
                    new_col = src_df_row[registration]
            elif new_col_nm == 'approval_dt':
                registration, approved_status = [c.strip() for c in old_col_nm.split(',')]
                if src_df_row[approved_status].lower() == 'approved':
                    new_col = src_df_row[registration]
            elif new_col_nm == 'funded_dt':
                registration, clear_status = old_col_nm.split(',')
                if src_df_row[clear_status].lower() == 'clearing':
                    new_col = src_df_row[registration]
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        elif lender == 'credibilitycapital':
            if new_col_nm == 'funded_loan_term':
                old_col_str = str(src_df_row['Funded Loan Term'])
                if old_col_str:
                    new_col = int(RE_NON_NUMERIC.sub('', old_col_str))
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
            return new_col

        print "Completed Executing custom execute function"
    except CustomColumnException as cce:
        print cce
        raise CustomExecuteError(cce.value)
    except Exception as e:
        print e
        raise CustomExecuteError("Error: execute_custom for this lender: {0}".format(lender))
