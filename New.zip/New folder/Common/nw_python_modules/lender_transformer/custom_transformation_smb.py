import pandas as pd
import numpy as np
import os
import sys
import re
import xlsxwriter
from s3_modules import s3_file_download
from redshift_modules import exec_query
from custom_exceptions import MappingFileError
from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException


def kabbage_helper(x=''):
    try:
	uid = x
	extract_uid = re.match(r"^.*%(?P<discardChars>.*)corpID%(?P<unique_id>.*)", x)
	if extract_uid:
	    uid = extract_uid.group('unique_id')[len(extract_uid.group('discardChars')):]
    except:
	print "Error encountered while processing kabbage helper"
    return uid

def execute_custom_smb(newDf, dataDf, x_list, lender):
    try:
        new_col = x_list[0].strip().lower()
        old_col = x_list[1]
        lender = lender.strip().lower()
	if lender == 'bluevine':
	    if new_col == 'loan_amt_issued':
		client_flex, client_factor = old_col.split(',')
	        dataDf["temp_lai"] = np.where(dataDf[client_flex.strip()] >= dataDf[client_factor.strip()], dataDf[client_flex.strip()], dataDf[client_factor.strip()])
		newDf[new_col] = np.where(dataDf["temp_lai"] == 0, np.nan, dataDf["temp_lai"])
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
        if lender == 'streetshares':
            if new_col == 'click_id':
                col = x_list[1]
                newDf[new_col] = dataDf[col].str.split('=', 1).str[1]
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
        if lender == 'ondeck':
            if new_col == 'funnel_status':
                applctn, apprved, declned = old_col.split(',')
                appl_status = {'nnn': "Not Applied",
                               'nny': "Declined",
                               'nyn': "Approved",
                               'nyy': "Approved",
                               'ynn': "Applied",
                               'yny': "Declined",
                               'yyn': "Approved",
                               'yyy': "Approved"
                               }
                dataDf["temp_status"] = dataDf[applctn].map(lambda x: 'y' if x.lower() == 'y' else 'n')
                dataDf["temp_status"] += dataDf[apprved.strip()].map(lambda x: 'y' if str(x).lower() == 'y' else 'n')
		dataDf["temp_status"] += dataDf[declned.strip()].map(lambda x: 'y' if str(x).lower() == 'y' else 'n')
                newDf[new_col] = dataDf["temp_status"].map(appl_status)
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))
        if lender == 'smartbiz':
            if new_col == 'click_id':
                campagn_id, partnr_campagn_id = old_col.split(',')
                newDf[new_col] = np.where(dataDf[campagn_id.strip()] >= dataDf[partnr_campagn_id.strip()], dataDf[campagn_id.strip()], dataDf[partnr_campagn_id.strip()])
            elif new_col == 'funded_dt':
                funded_date, status  = old_col.split(',')
                newDf[new_col] = np.where(dataDf[status.strip()] == 'funded', dataDf[funded_date.strip()], np.nan)
            elif new_col == 'loan_amt_issued':
                newDf[new_col] = dataDf.filter(regex='^Unnamed', axis=1)
            else:
                raise CustomColumnException("Please handle the column: {0} for this lender: {1}".format(new_col, lender))

        if lender == 'lendingclub':
            if new_col == 'funded_interest_rt':
                frnt_end_rt, loan_intrst_rt =  old_col.split(',')
                frnt_end_rt = frnt_end_rt.strip()
                loan_intrst_rt = loan_intrst_rt.strip()
                newDf[new_col] = np.where(dataDf[frnt_end_rt] >= dataDf[loan_intrst_rt], dataDf[frnt_end_rt],
                                          dataDf[loan_intrst_rt])
            else:
                raise CustomColumnException("Please handle the column: {0} for this lender: {1}".format(new_col, lender))

	if lender == 'kabbage':
	    if new_col == 'click_id':
		FinalRefId, CreateCorrData, QualifyCorrData, FinalCorrData = old_col.split(',')
		FinalRefId = FinalRefId.strip()
		dataDf["temp_status"] = dataDf[FinalCorrData.strip()]
		dataDf["temp_status"].fillna('', inplace=True)
		dataDf[FinalRefId].fillna('', inplace=True)
		dataDf["temp_status"] = dataDf["temp_status"].map(lambda x: x[-32:] if ((x != '') and len(x) > 32) else x)
	 	dataDf["temp_status"] = np.where(dataDf[FinalRefId].map(lambda x: True if (x == 'partner_nerdwallet' or x == 'partner_nerdwallet1' or x =='') else False), dataDf["temp_status"],  dataDf[FinalRefId])
	        newDf[new_col] = dataDf["temp_status"].map(lambda x: kabbage_helper(x))
	    elif new_col == 'application_complete_dt':
		born_on_date, has_submitted_appl = old_col.split(',')
                newDf[new_col] = np.where(dataDf[has_submitted_appl.strip()] == True, dataDf[born_on_date.strip()].dt.date, np.nan)
	    else:
		raise CustomColumnException("Please handle the column: {0} for this lender: {1}".format(new_col, lender))

        if lender == 'fundbox':
            if new_col == 'application_complete_dt':
		registration, conn_status = old_col.split(',')
                newDf[new_col] = np.where(dataDf[conn_status.strip()] == 'Connected', dataDf[registration.strip()].dt.date, np.nan)
	    elif new_col == 'approval_dt':
		registration, approved_status = old_col.split(',')
                newDf[new_col] = np.where(dataDf[approved_status.strip()] == 'Approved', dataDf[registration.strip()].dt.date, np.nan)
	    elif new_col == 'funded_dt':
		registration, clear_status = old_col.split(',')
                newDf[new_col] = np.where(dataDf[clear_status.strip()] == 'Clearing', dataDf[registration.strip()].dt.date,  np.nan)
            else:
                raise CustomColumnException("Please handle the column: {0} for this lender: {1}".format(new_col, lender))
        print "Completed Executing custom execute function"
    except CustomColumnException as cce:
	print cce
        raise CustomExecuteError(cce.value)
    except Exception as e:
	print e
        raise CustomExecuteError("Error: execute_custom for column: {0} for this lender: {1}".format(new_col, lender))
