from __future__ import division

import datetime
import re

import pandas as pd

from custom_transformation_new import execute_custom
from custom_exceptions import CustomColumnException


# Regex Strings
RE_CURRENCY_STR = r'^\$?\-?([1-9]{1}[0-9]{0,2}(\,\d{3})*(\.\d{0,})?|[1-9]{1}\d{0,}(\.\d{0,})?|0(\.\d{0,})?|' \
                  r'(\.\d{1,2}))$|^\-?\$?([1-9]{1}\d{0,2}(\,\d{3})*(\.\d{0,})?|[1-9]{1}\d{0,}(\.\d{0,})?|0(\.\d{0,})?|' \
                  r'(\.\d{1,2}))$| ^\(\$?([1-9]{1}\d{0,2}(\,\d{3})*(\.\d{0,})?|[1-9]{1}\d{0,}(\.\d{0,})?|0(\.\d{0,})?|' \
                  r'(\.\d{1,2}))\)$'
RE_CURRENCY_MATCH = re.compile(RE_CURRENCY_STR)
RE_CURRENCY_SUB = re.compile(r'\$|,')
RE_ONLY_NUMBERS = re.compile(r'^[0-9]*$')
RE_PERCENT_SUB = re.compile(r'([0-9])+%')


def domain_transform(value, domain):
    """
    Wrapper function to call various domain functions
    :param value: raw value
    :param domain: str, domain from mapping file
    :return: cleansed value
    """
    if not value:
        return value
    new_col = value
    try:
        if domain == 'currency':
            new_col = currency_transform(value)
        elif domain in ('timestamp', 'datetime'):
            new_col = date_transform(value, '%Y-%m-%d %H:%M:%S')
        elif domain in ('date'):
            new_col = date_transform(value, '%Y-%m-%d')
        elif domain == 'percent':
            new_col = percent_transform(value)
        elif domain == 'numeric':
            new_col = numeric_transform(value)
        elif domain in ('int', 'integer'):
            new_col = int(numeric_transform(value))
        elif domain == 'string':
            new_col = string_transform(value)
        elif domain == 'click':
            new_col = string_transform(value)
    except Exception as e:
        raise CustomColumnException(e.message)
    if not new_col:
        new_col = None
    return new_col


def hardcode_transform(old_col_nm):
    """
    This will return back the value if transform is "hardcoded"
    """
    return old_col_nm.strip()


def date_transform(value, dt_format):
    """
    This will convert a datetime string, datetime object, or unix timestamp into a date string using the
    pandas to_datetime() function. Output format is as specified in the dt_format variable.
    """
    value_str = str(value).strip()
    # don't process if empty
    if not value_str:
        return value_str

    else:
        try:
            # try and convert str timestamps
            return pd.to_datetime(value_str).strftime(dt_format)
        except OverflowError as e:
            # try and convert unix timestamps which we occasionally see in excel files
            if len(value_str) >= 10:
                value_str = float(value_str[0:10])
            return datetime.datetime.fromtimestamp(value_str).strftime(dt_format)


def currency_transform(value):
    """
    This will convert a USD string to a float
        "$5,000" --> 5000.0
    """
    value_str = str(value).strip()
    # check to remove any in between spaces in the value.
    value_str = value_str.replace(' ', '')
    # don't process if empty
    if not value_str:
        return value_str

    else:
        # if all digits, convert to float
        if RE_ONLY_NUMBERS.match(value_str):
            return float(value_str)

        # if str matches currency regex, keep only digits
        elif RE_CURRENCY_MATCH.match(value_str):
            return float(RE_CURRENCY_SUB.sub('', value_str))

        # does not conform to valid currency
        else:
            raise CustomColumnException('Currency Transform Error: {}'.format(value_str))


def percent_transform(value):
    """
    This will transform a percent string to a float
        "5%" --> 0.05
    """
    value_str = str(value).strip()

    # don't process if empty
    if not value_str:
        return value_str

    # strip away extra characters and convert to percentage
    else:
        new_col = float(RE_PERCENT_SUB.sub(r'\1', value_str))
        if new_col > 1:
            new_col /= 100
        return new_col


def numeric_transform(value):
    """
       Convert value to float
           "1ae34" --> error
           "134.5" --> 134.5
           "" --> ""
       """
    value_str = str(value).strip()

    # don't process if empty
    if not value_str:
        return value_str

    return float(value_str)


def string_transform(value):
    """
    Convert value to string. Check to see if value is already a string so we don't affect
    encoding, otherwise to convert to string.
        " Hello World " --> "Hello World"
        123 --> "123"
    """
    if isinstance(value, str):
        return value.strip()
    else:
        return str(value).strip()


def click_transform(value):
    """
    Special handling of click ids. As of now, just converts to string.
    :param value:
    :return:
    """
    return string_transform(value)


def to_null_transform(value, transform):
    """
    Set a specific src value to empty string as target value.
    The transform field should take the format to_null="[VALUE]" where [VALUE] is the src value you want to set to null

    Ex:
        to_null="-"
        This will set "-" to empty string if this value is found in the src column
    """
    new_col = value
    strip_char = transform.split('=')[1].strip('\"')
    if str(value) == strip_char:
        new_col = value.replace(strip_char, '')
    return new_col


def map_values_transform(value, transform):
    """
    Map existing values to new values as defined in mapping file transform column.

    Ex:
    If transform value is "Booked=Funded, Underwriting=Approved" then any src value of "Booked"/"Underwriting" will
    be converted to a target value of "Funded"/"Approved" respectively
    """
    a = transform.strip().split(',')
    lookup = {}
    for pair in a:
        k, v = pair.split('=')
        if not lookup.get(k.lower().strip()):
            lookup[k.lower().strip()] = v.strip()
    new_col = lookup.get(value.lower().strip(), value)
    return new_col


def custom_transform(src_df_row, old_col_nm, new_col_nm, transform, lender, vertical):
    """
    Execute custom transformation
    """
    new_col = execute_custom(src_df_row, old_col_nm, new_col_nm, transform, lender, vertical)

    # we need to make sure that datetime objects are converted to valid strings
    if isinstance(new_col, datetime.date):
        new_col = date_transform(new_col)
    return new_col
