import sys
import json
import traceback
from email_module import send_email
from hive_lender_utils import load_hive_tbl

def init_email(email_template):
    with open(email_template) as email_file:
        email_info = json.loads(email_file.read().replace('\n', ' ').replace('\r', ' '), strict=False)
    return email_info


def main(s3_bucket, s3_stg, s3_fct, email_template, hive_stage_table, hive_fact_table, file_format, presto_script, fct_ins_sqls):
    """
    Main python script to load the transformed partners' JSON files into stage and poststage tables.
    :param s3_bucket: str, S3 Nerdlake bucket holding the partition files.
		      e.g. 'east1-prod-nerdlake-0'
    :param s3_stg: str, S3 folder holding the transformed partition files.
		      e.g. 'dwnl_rcd_aflt_tran_stage/aflt_tran_process_file/'
    :param s3_fct: str, S3 location of the fact table.
		      e.g. 'dwnl_rcd_aflt_tran_data/dw_aflt_tran_consolidated_f/'
    :param hive_stage_table: str, Hive stage table to store data from the confirmed partition files.
		      e.g. 'dwnl_rcd_aflt_tran_stage.aflt_tran_s'
    :param hive_fact_table: str, Hive fact table to store data from the Hive stage table.
		      e.g. 'dwnl_rcd_aflt_tran_data.dw_aflt_tran_consolidated_f'
    :param file_format: str, Format in which the partitions files are stored in S3
		      e.g. orc, json, etc.
    :param email_template: str, absolute file path to JSON email template.
		      e.g. '/data/etl/Scripts/aflt_tran_nerdlake/pythonscripts/email_info.json'
    :param presto_script: str, location of the presto executable script.
    :param fct_ins_sql: list, list of paths to all the Fact Insert SQLs

    """
    try:
 
	print('-----------------Loading data in stage Table - Nerdlake: Started-------------------')
	load_hive_tbl(hive_stage_table, file_format, s3_bucket, s3_stg, presto_script, "stage")
	print('-----------------Loading data in stage Table - Nerdlake: Completed-----------------')
	   
	print('-----------------Loading data in fact Table - Nerdlake: Started--------------------')
	load_hive_tbl(hive_fact_table, file_format, s3_bucket, s3_fct, presto_script, "fact", fct_ins_sqls)
	print('-----------------Loading data in fact Table - Nerdlake: Completed------------------')

    except Exception, e:
	email_info = init_email(email_template)
	print('Exception: {}'.format(e))
	print('Failure processing! An email will be sent out to the concerned party.')
	email_info['subject'] = email_info['subject']
	email_info['body'] = email_info['body'] + str(e) + ' ' + str(traceback.format_exc())
	send_email(email_info)


if __name__ == '__main__':
    	
    s3_bucket = sys.argv[1]
    s3_stg = sys.argv[2]
    s3_fct = sys.argv[3]
    email_json_template = sys.argv[4]
    hive_stage_table = sys.argv[5]
    hive_fact_table = sys.argv[6]
    file_format = sys.argv[7]
    presto_script = sys.argv[8]
    fct_ins_sqls = sys.argv[9:]

    # Execute main function
    main(s3_bucket, s3_stg, s3_fct, email_json_template, hive_stage_table, hive_fact_table, file_format, presto_script, fct_ins_sqls)
