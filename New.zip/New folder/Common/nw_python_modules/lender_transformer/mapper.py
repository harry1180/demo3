import numpy as np
import pandas as pd
from custom_exceptions import MappingFileError
from target_columns_hive import TARGET_COL_LOOKUP, STAGE_PARTITIONS, FACT_PARTITIONS


def parse_mapper(map_file, nerdlake_in):
    """
    Convert mapping XLSX file into list of dictionaries
    :param map_file: str, absolute path to mapping file
    :param nerdlake_in: boolean, whether to generate Nerdlake file or not. Defaults to True
    :return: list of dicts, contents of mapping file
    """
    map_converters = {'final_column': str,
                      'source_column': str,
                      'transformation': str,
                      'domain': str,
                      'critical': str}
   
    map_df = pd.read_excel(map_file, converters=map_converters)
    map_df = map_df.replace(np.nan, '', regex=True)
    map_list = map_df.to_dict(orient='records')
    
    if nerdlake_in:
    	# validate map header
    	if [f for f in list(map_df) if f not in map_converters.keys()]:
        	err_msg = 'Mapping File Header Incorrect! Valid column headers are {}'.format(','.join(map_converters.keys()))
		print err_msg
        	raise MappingFileError(err_msg)

    	# validation for mapping file target columns
    	target_columns = [key['final_column'].strip() for key in map_list]
    	verified_col_set = [key[0].strip() for key in TARGET_COL_LOOKUP] + [key[0].strip() for key in STAGE_PARTITIONS] + [key[0].strip() for key in FACT_PARTITIONS]
    	if set(target_columns).difference(set(verified_col_set)):
		err_msg = 'New columns found in mapping file, add them to TARGET_COL_LOOKUP: {}'.format(
				set(target_columns).difference(set(verified_col_set)))
		print err_msg
		raise MappingFileError(err_msg)

    return map_list

