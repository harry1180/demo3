import unittest

from lender_transformer import column_transformation


class TestDomainTransform(unittest.TestCase):

    def _test_column_transform(self, mock_data, transform_function):
        for case in mock_data:
            self.assertEqual(transform_function(case[0]), case[1], 'Failed convert "{}" to "{}"'.format(str(case[0]),
                                                                                                        str(case[1])))

    def test_hardcoded(self):
        mock_data = [
            ('test', 'test'),
            ('', ''),
        ]
        self._test_column_transform(mock_data, column_transformation.hardcode_transform)


    def test_currency(self):
        mock_data = [
            ('', ''),
            ('$5,000', float(5000)),
            ('5000', float(5000)),
            ('5,000', float(5000)),
            ('$5,000.00', float(5000)),
            ('$5000', float(5000)),
            (5000, float(5000)),
            (5000.0, float(5000)),
	    ('$ 5000.0', float(5000))
        ]
        self._test_column_transform(mock_data, column_transformation.currency_transform)


    def test_percent(self):
        mock_data = [
            ('', ''),
            ('5%', float(0.05)),
            ('5', float(0.05)),
            (0.05, float(0.05)),
            (5, float(0.05)),
        ]
        self._test_column_transform(mock_data, column_transformation.percent_transform)


    def test_date(self):
        mock_data = [
            ('', ''),
            ('2017-11-13', '2017-11-13 00:00:00'),
            ('2017-11-13 07:30:25', '2017-11-13 07:30:25'),
            ('11/13/2017', '2017-11-13 00:00:00'),
            ('11/13/2017 07:30:25', '2017-11-13 07:30:25'),
            ('2017/11/13', '2017-11-13 00:00:00'),
            ('11/13/17', '2017-11-13 00:00:00'),
            ('Nov 13, 2017', '2017-11-13 00:00:00'),
            ('November 13, 2017', '2017-11-13 00:00:00'),
            ('nov-13-17', '2017-11-13 00:00:00'),
            ('nov-13-17 07:30:25', '2017-11-13 07:30:25'),
        ]
        self._test_column_transform(mock_data, column_transformation.date_transform)


class TestColumnTransformToNull(unittest.TestCase):

    def test_to_null(self):
        mock_data = [
            ('test case', 'test', 'test case'),
            (100, '-', 100),
            ('-', '-', ''),
            ('7', '7', '')
        ]
        for case in mock_data:
            self.assertEqual(column_transformation.to_null_transform(case[0], 'to_null="{}"'.format(case[1])), case[2])


class TestColumnTransformMapValues(unittest.TestCase):

    def test_to_null(self):
        mock_transformation = 'booked=Funded,sold=Sold'
        mock_data = [
            ('test case', 'test case'),
            ('booked', 'Funded'),
            ('Booked', 'Funded'),
            ('SOLD', 'Sold')
        ]
        for case in mock_data:
            self.assertEqual(column_transformation.map_values_transform(case[0], mock_transformation), case[1])
