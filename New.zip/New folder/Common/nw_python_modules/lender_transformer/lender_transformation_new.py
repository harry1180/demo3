import datetime
import json

import pandas as pd
import numpy as np

from custom_exceptions import CustomExecuteError
from custom_exceptions import MappingFileError
from mapper import parse_mapper
from redshift_modules import exec_query
from row_transformation import process_row
from s3_modules import s3_file_download
from target_columns_hive import DEDUP_COL_LOOKUP


try:
    import pyspark
    import commands
except ImportError:
    import sys, os, re


    sys.path.append('/usr/lib/spark/python')
    import pyspark
from pyspark.sql import SQLContext
from pyspark.sql.window import Window
from pyspark.sql.functions import min, col, when


def get_redshift_load_status(lender):
    """
    Returns True only when no new file for the current day has been processed. This makes sure (mostly for API calls), that
    only 1 file is processed per day per lender for Redshift (instead of generating new files at every hour)
    :param lender: lender name 
    """
    query = "Select trunc(max(dw_load_ts)) as dt from dw_report.dw_aflt_tran_log where lower(prog_nm) like '{0}'".format(
        lender.lower())
    try:
        max_dt = exec_query(query)
        max_dt = [dt['dt'] for dt in max_dt][0].strftime('%Y-%m-%d')
        now = datetime.datetime.now().strftime('%Y-%m-%d')
        if max_dt == now: return False
        return True
    except:
        return True


def write_redshift_output(list_of_rows, output_file, **kwargs):
    """
    Determine which file format to write output file to
    :param list_of_rows: list, contents of data to write to file
    :param output_file: str, path to output file
    """
    _, input_file_ext = os.path.splitext(output_file)
    if input_file_ext == '.csv':
        write_csv_output(list_of_rows, output_file)
    elif input_file_ext == '.json':
        write_json_output(list_of_rows, output_file, kwargs.get('redshift'))
    elif input_file_ext in ['.xlsx', '.xls']:
        write_excel_output(list_of_rows, output_file)
    else:
        raise Exception('Invalid file extension for output file: {}'.format(output_file))


def write_hive_output(list_of_rows, hivefile_ext, s3_hive_folder, write_mode='append'):
    """
    Converts 'list_of_rows' to PySpark DataFrame, cleans and dedups it and writes it into S3 as partitions based on file received date and data source.
    :param list_of_rows: list, contents of data to write to file
    :param hivefile_ext: str, file partitions format
    :param s3_hive_folder: str, s3 location to store the partition files at.
    :param write_mode: str, whether to append/overwrite to existing partition. Defaults to 'append'.
    """
    conf = pyspark.SparkConf()
    sc = pyspark.SparkContext(conf=conf)
    sqlcontext = SQLContext(sc)
    spark_df = sqlcontext.createDataFrame(list_of_rows)
    spark_df = dedupe_keys(spark_df)
    spark_df = dedupe_commission(spark_df)

    try:
        if hivefile_ext == 'json':
            spark_df.repartition(DEDUP_COL_LOOKUP['FILE_DT'], DEDUP_COL_LOOKUP['SOURCE']).write.partitionBy(
                DEDUP_COL_LOOKUP['FILE_DT'], DEDUP_COL_LOOKUP['SOURCE']).mode(write_mode).json(s3_hive_folder)
        elif hivefile_ext in ['pq', 'parq']:
            spark_df.repartition(DEDUP_COL_LOOKUP['FILE_DT'], DEDUP_COL_LOOKUP['SOURCE']).write.partitionBy(
                DEDUP_COL_LOOKUP['FILE_DT'], DEDUP_COL_LOOKUP['SOURCE']).mode(write_mode).parquet(s3_hive_folder)
        elif hivefile_ext in ['orc']:
            spark_df.repartition(DEDUP_COL_LOOKUP['FILE_DT'], DEDUP_COL_LOOKUP['SOURCE']).write.partitionBy(
                DEDUP_COL_LOOKUP['FILE_DT'], DEDUP_COL_LOOKUP['SOURCE']).mode(write_mode).orc(s3_hive_folder)
        else:
            raise Exception('Invalid hive file extension : {}'.format(hivefile_ext))
    except Exception as e:
        print e
    return


def dedupe_keys(df):
    """
    Uses Pyspark to delete duplicate records with the same Primary Key.
    :param df: Pyspark DataFrame containing all the records.
    """
    # splitting the dataframe to segregate error records (with null subid and txnid) with non-error records
    null_df = df.where((col(DEDUP_COL_LOOKUP['SUB_ID']).isNull()) & (col(DEDUP_COL_LOOKUP['TXN_ID']).isNull()))
    not_null_df = df.where(
        (col(DEDUP_COL_LOOKUP['SUB_ID']).isNotNull()) & (col(DEDUP_COL_LOOKUP['TXN_ID']).isNotNull()))
    not_null_df = not_null_df.dropDuplicates(['aflt_network_tran_id'])
    return not_null_df.unionAll(null_df)


def dedupe_commission(df):
    """
    Uses Pyspark to make sure that commission is applied only once to records which have the same Subid, Txnid, Prod name but different statuses.
    :param df: Pyspark DataFrame containing all the records.
    """
    w = Window.partitionBy(DEDUP_COL_LOOKUP['SUB_ID'], DEDUP_COL_LOOKUP['TXN_ID'], DEDUP_COL_LOOKUP['PROD_NM'])

    # splitting the dataframe to segregate error records (with null subid and txnid) with non-error records
    null_df = df.where((col(DEDUP_COL_LOOKUP['SUB_ID']).isNull()) & (col(DEDUP_COL_LOOKUP['TXN_ID']).isNull()))
    not_null_df = df.where(
        (col(DEDUP_COL_LOOKUP['SUB_ID']).isNotNull()) & (col(DEDUP_COL_LOOKUP['TXN_ID']).isNotNull()))

    # 'df1' is used as a handler which is joined with the 'not_null_df', subsequently making sure that commission 
    # for records with same transaction id, subid and product name is applied only once. 
    # Transaction count is also adjusted accordingly.
    df1 = not_null_df.select(min('aflt_network_tran_id').over(w).alias('min_key'))
    a = not_null_df.alias('a')
    b = df1.alias('b')
    c = a.join(b, col('b.min_key') == col('a.aflt_network_tran_id'), how='left_outer')
    c = c.withColumn(DEDUP_COL_LOOKUP['COMMISSION_AM'], when(col('min_key').isNotNull(),
                                                             c[DEDUP_COL_LOOKUP['COMMISSION_AM']]).otherwise(0))
    c = c.withColumn(DEDUP_COL_LOOKUP['TXN_CNT'], when(col('min_key').isNotNull(),
                                                       c[DEDUP_COL_LOOKUP['TXN_CNT']]).otherwise(0))
    c = c.drop('min_key')
    final_df = c.unionAll(null_df)
    return final_df


def write_excel_output(list_of_rows, output_file):
    """
    Given a list of dictionaries, where each dictionary represents a row with K/V pairs, output file in XLSX format.
    Header will be extracted from keys of dictionary.
    :param list_of_rows: list, contents of data to write to file
    :param output_file: str, path to output file
    """
    writer = pd.ExcelWriter(output_file, engine='xlsxwriter')
    data_frame = pd.DataFrame(list_of_rows).applymap(lambda x: x.decode('utf-8', 'ignore') if type(x) == str else x)
    data_frame.to_excel(writer, sheet_name='Sheet1', index=0)
    writer.save()
    return


def write_csv_output(list_of_rows, output_file):
    """
    Given a list of dictionaries, where each dictionary represents a row with K/V pairs, output file in CSV format.
    Header will be extracted from keys of dictionary.
    :param list_of_rows: list, contents of data to write to file
    :param output_file: str, path to output file
    """
    with open(output_file, 'w') as writer:
        data_frame = pd.DataFrame(list_of_rows).applymap(lambda x: x.decode('utf-8', 'ignore') if type(x) == str else x)
        data_frame.to_csv(writer, index=False)
        return


def write_json_output(list_of_rows, output_file, redshift=False):
    """
    Given a list of dictionaries, where each dictionary represents a row with K/V pairs, output file in json format.
    Option for "redshift" style JSON file.
    redshift = False --> natural nested JSON object (list of dicts)
    redshift = True --> outputs a "dictionary" for each row (newline separated)
    :param list_of_rows: list, contents of data to write to file
    :param output_file: str, path to output file
    :param redshift: formatting option
    """
    with open(output_file, 'w') as json_out:
        if redshift:
            for row in list_of_rows:
                json.dump(row, json_out)
                json_out.write('\n')
        else:
            json.dump(list_of_rows, json_out)


def get_rows_from_df(data_frame):
    for index, df_row in data_frame.iterrows():
        yield index, df_row.to_dict()


def combine_df(df_lst, multisheetjoin):
    """
    Combines all the dataframes in the dictionary using the method defined in the 'multisheetjoin'.
    :param df_lst: list, list of dataframes
    :param multisheetjoin: str, how you want to join in the dataframes.
    """

    if multisheetjoin == 'merge':
        df = df_lst[0]
        for i in range(1, len(df_lst)):
            df = pd.DataFrame.merge(df, df_lst[i], how="outer")
        return df
    elif multisheetjoin == 'concat':
        return pd.concat(df_lst)
    else:
        raise Exception('Operation {} not currenty supported'.format(multisheetjoin))


def clean_df(df):
    """
    Clean the dataframe as follows:
        1. replace all newline characters(if any) in column names with spaces
        2. if any columns do not have a corresponding header value, assign them to src_col_# to avoid pandas issues
    :param df: dataframe to clean-up
    :return: cleaned pandas dataframe
    """
    clean_column_list = []
    for i, src_col_nm in enumerate(df.columns):
        src_col_nm = re.sub(r'\n', ' ', src_col_nm)
        src_col_nm = re.sub(r'^Unnamed.+', 'src_col_{}'.format(str(i)), src_col_nm)
        clean_column_list.append(src_col_nm.strip())
    df.columns = clean_column_list
    return df


def file_to_df(input_file, sheetname=0, skiprows=0, skip_footer=0):
    """
    Convert input file to pandas data frame. Pandas is an easy way to parse a variety of input file types.
    :param input_file: str, path to file
    :param skiprows: int, number of header rows to skip
    :param skip_footer: int, number of footer rows to skip
    :return: pandas data frame
    """

    # data frame for the lender data
    fn, input_file_ext = os.path.splitext(input_file)
    if input_file_ext == '.xlsx' or input_file_ext == '.xls':
        source_data_frame = pd.read_excel(input_file, sheetname=sheetname, skiprows=skiprows, skip_footer=skip_footer)
    elif input_file_ext == '.csv':
        source_data_frame = pd.read_csv(input_file, skiprows=skiprows, skipfooter=skip_footer)
    elif input_file_ext == '.zip':
        source_data_frame = pd.read_csv(input_file, skiprows=skiprows, skipfooter=skip_footer, compression='zip')
    elif input_file_ext in ('.gzip', '.gz'):
        source_data_frame = pd.read_csv(input_file, skiprows=skiprows, skipfooter=skip_footer, compression='gzip')
    else:
        raise Exception('Invalid extension "{}" for input file: {}'.format(input_file_ext, input_file))

    # replace all newline characters(if any) in column names with spaces
    # if any columns do not have a corresponding header value, assign them to src_col_# to avoid pandas issues
    if type(sheetname) is list:
        source_data_frame_lst = []
        for _, df in source_data_frame.iteritems():
            source_data_frame_lst.append(clean_df(df))
        return source_data_frame_lst
    else:
        source_data_frame = clean_df(source_data_frame)
        return source_data_frame


def process_tran_file(input_file, output_redshift_file, hivefile_ext, lender_map_path, s3_hive_folder,
                      s3_bucket='east1-prod-dwh-s3-0',
                      lender='unknown', file_received_dt=None, vertical=None, sheetname=0, multisheetjoin=None,
                      skiprows=0, skip_footer=0, hive_write_mode='append',
                      redshift_override=False, redshift_in=True, nerdlake_in=True, map_dwnl_dir='/tmp'):
    """
    Main function which transforms the 'input_file' into a conformed 'output_transformed_file' by applying specific
    transformations defined in the 'lender_map_path' mapping file.
    This function will output up to 3 files:
        1) conformed "_cleaned" JSON file with valid rows. Valid rows are rows in which no critical fields failed
            to transform
        2) conformed "_warning" JSON file with warning rows. Warning rows are rows in which non-critical fields failed
            to transform. These rows also exist in the "_cleaned" file as well.
        3) conformed "_error" JSON file with error rows. Error rows are rows in which critical fields failed to
            transform. These rows DO NOT exist in "_cleaned" file
    :param input_file: str, path to raw file that is to be transformed
    :param output_redshift_file: str, path to final conformed output file
    :param hivefile_ext:str, extension of the output partition files for hive (defaults to 'orc')
    :param lender_map_path: str, s3 path to mapping file
    :param s3_bucket: str, s3 bucket where mapping file is stored
    :param s3_hive_folder: str, S3 folder to store partition files for hive
    :param lender: str, lender name
    :param file_received_dt: str, date str for received date
    :param vertical: str, vertical name
    :param sheetname: str, name of the sheet to get the data from, defaults to 0
    :param multisheetjoin: str, how you wish to combine data from multiple sheets if applicable, defaults to None
    :param skiprows: int, number of header rows to skip
    :param skip_footer: int, number of footer rows to skip
    :param hive_write_mode: str, whether to append/overwrite existing partitions. Defaults to 'append'
    :param redshift_override: boolean, whether to generate redshift file or not (even when 1 file per day is generated). Defaults to False
    :param redshift_in: boolean, whether to generate Redshift file or not. Defaults to True
    :param nerdlake_in: boolean, whether to generate Nerdlake file or not. Defaults to True
    """
    try:
        file_received_dt = datetime.datetime.now().strftime('%Y-%m-%d')
        input_filename = os.path.basename(input_file)
        s3_path = lender_map_path
        print "s3_path", s3_path

        # parse mapping file contents
        try:
            map_file = s3_file_download(s3_bucket, '', s3_path, map_dwnl_dir, to_file=True)
            map_list = parse_mapper(map_file, nerdlake_in)
        except:
            raise MappingFileError('Could not parse map file')

        # For multiple sheets
        if type(sheetname) is list:
            src_df_lst = file_to_df(input_file, sheetname=sheetname, skiprows=skiprows, skip_footer=skip_footer)
            source_data_frame = combine_df(src_df_lst, multisheetjoin)
        else:
            source_data_frame = file_to_df(input_file, sheetname=sheetname, skiprows=skiprows, skip_footer=skip_footer)

        # convert nan to empty string
        source_data_frame = source_data_frame.replace(np.nan, '', regex=True)

        # different buckets to store processed data, logic is defined based on warn_in and error_in below
        valid_content = []
        warning_content = []
        error_content = []

        for index, src_row in get_rows_from_df(source_data_frame):

            # Process source row contents as defined by mapping files
            target_row = process_row(src_row, map_list, lender, vertical)

            # tag provenance
            target_row['src_filename'] = input_filename
            target_row['src_file_received_dt'] = file_received_dt

            # Other PL lenders have file_received_date adn filename
            try:
                if vertical.lower() == 'pl':
                    target_row['file_received_date'] = str(
                        datetime.datetime.strptime(target_row['src_file_received_dt'], '%Y%m%d'))
                    target_row['filename'] = input_filename
            except:
                pass

            # determine error rows -- these are "invalid" and will not be included in "_cleaned" file
            if target_row.get('error_list'):
                target_row['row_num'] = index + 1
                error_content.append(target_row)
            else:
                valid_content.append(target_row)

            # determine warning rows -- these are considered "valid" and will be included in "_cleaned" file
            if target_row.get('warning_list') and not target_row.get('error_list'):
                target_row['row_num'] = index + 1
                warning_content.append(target_row)

        # write output file - Redshift
        print '******* OVERRIDING redshift_override TO BE ALWAYS EQUAL TO "True" TO ALWAYS GENERATE .json FILE UNTIL WE GET SPARK SUPPORT ******'
        redshift_override = True

        if redshift_in and not redshift_override:
            load_redshift = get_redshift_load_status(lender)
            if load_redshift:
                print 'Redshift - writing to the file : {}'.format(output_redshift_file)
                write_redshift_output(valid_content, output_redshift_file, redshift=True)
            else:
                print 'Already downloaded 1 Redshift file for today'

        if redshift_in and redshift_override:
            print 'Redshift - writing to the file : {}'.format(output_redshift_file)
            write_redshift_output(valid_content, output_redshift_file, redshift=True)

        # write output file partitions - Hive
        if nerdlake_in:
            # print 'Nerdlake - creating file partitions in folder : {}'.format(s3_hive_folder)
            print '********** COMMENTING write_hive_output() TEMPORARILY UNTIL SPARK IS ENABLED!!*************'
            print '********** USING REDSHIFT JSON FILE IN NERDLAKE UNTIL THEN ****************'
            # write_hive_output(valid_content, hivefile_ext, s3_hive_folder, hive_write_mode)

        # write error file
        if error_content:
            error_file_nm = '{}.csv'.format(os.path.splitext(output_redshift_file)[0].replace('_cleaned', '_error'))
            write_csv_output(error_content, error_file_nm)

        # write warning file
        if warning_content:
            warn_file_nm = '{}.csv'.format(os.path.splitext(output_redshift_file)[0].replace('_cleaned', '_warning'))
            write_csv_output(warning_content, warn_file_nm)

    except MappingFileError as mpe:
        print "{0}".format(mpe.value)
        raise mpe
    except KeyError as ke:
        print "Key Error: {0}".format(ke)
        raise ke
    except CustomExecuteError as cpe:
        print "{0}".format(cpe.value)
        raise cpe
    except Exception, e:
        print('Exception: {}'.format(e))
        raise e
