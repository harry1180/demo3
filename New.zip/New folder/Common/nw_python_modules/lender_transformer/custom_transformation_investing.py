from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException


def execute_custom_investing(newDf, dataDf, x_list, lender):

    new_col = x_list[0].strip().lower()
    lender = lender.strip().lower()

    try:
        if lender == 'optionshouse':
            if new_col == 'aflt_fin_tran_type_cd':
                newDf['aflt_fin_tran_type_cd'] = dataDf['approval_date'].map(lambda x: 'funded' if str(x) != 'nan' else 'started')
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

        print "Completed Executing custom execute function"

    except CustomColumnException as cce:
        raise CustomExecuteError(cce.value)
    except:
        raise CustomExecuteError("Error: execute_custom for column: {0} for this lender: {1}".format(new_col, lender))
