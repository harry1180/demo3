import re

from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException


RE_ASPIRATION_CLICK_ID = re.compile("click_id=(\w{16})")


def execute_custom_banking(src_df_row, old_col_nm, new_col_nm, transform, lender):

    try:
        lender = lender.strip().lower()
        new_col = None

        if lender == 'aspiration':
            if new_col_nm == 'src_unique_click_id':
                try:
                    click_id_val = RE_ASPIRATION_CLICK_ID.search(src_df_row['Wait List UTM Campaign']).group(1)
                except AttributeError:
                    click_id_val = None
                new_col = click_id_val

        if lender == 'synchrony':
            if new_col_nm == 'banking_product_type':
                if 'cd rate' in src_df_row['Placement'].lower():
                    new_col = 'cd'
                elif 'savings rate' in src_df_row['Placement'].lower():
                    new_col = 'savings'

        if lender in ('marcus', 'ally'):
            if new_col_nm == 'banking_product_type':
                if 'cd' in src_df_row['Placement'].lower():
                    new_col = 'cd'
                elif 'osa' in src_df_row['Placement'].lower():
                    new_col = 'savings'

        if lender == 'citizens_access':
            if new_col_nm == 'banking_product_type':
                if 'cd' in src_df_row['Ad'].lower():
                    new_col = 'cd'
                elif 'savings/checking' in src_df_row['Ad'].lower():
                    new_col = 'savings'

        return new_col

    except CustomColumnException as cce:
        print cce
        raise CustomExecuteError(cce.value)

    except Exception as e:
        print e
        raise CustomExecuteError("Error: execute_custom for this lender: {0}".format(lender))