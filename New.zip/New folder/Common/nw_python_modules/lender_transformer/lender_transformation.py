# _*_ coding: utf-8
'''
pending work
-Add exception for rows that are total(aggregate) rows 
-still using xlsxwriter for pandas to write the transformed excel file.
-negative testing
'''

import pandas as pd
import numpy as np
import os
import sys
import re
import xlsxwriter
from s3_modules import s3_file_download
from redshift_modules import exec_query
from custom_transformation import execute_custom
from custom_exceptions import MappingFileError
from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException
from dateutil import parser
import datetime


# from data_validators import validate_date
# from data_validators import validate_numeric
# from data_validators import validate_text


def column_transform(newDf, dataDf, x_list, lender, vertical):
    """
    Performs transformations on the specific columns as defined in the respective mapping file.
        newDf : output data frame
        dataDf : input data frame
        x_list : list specifying the mapping defined in the mapping file
        lender : lender's name
        vertical : lender's vertical
    """
    new_col = x_list[0].strip()
    old_col = x_list[1]

    # set hardcoded values
    if x_list[2] == 'hardcoded':
        newDf[new_col] = old_col

    # convert to datetime object
    elif x_list[2] in ('date', 'datetime'):
        newDf[new_col] = pd.to_datetime(dataDf[old_col])
    else:
        if x_list[2] == 'custom':
            execute_custom(newDf, dataDf, x_list, lender, vertical)
        else:
            old_col = x_list[1]
            a = x_list[2].strip().split(',')
            dic = {k: v for k, v in (x.split('=') for x in a)}
            newDf[new_col] = dataDf[old_col].map(dic)
    print "The {0} col for {1} is transformed as {2}".format(new_col, lender, old_col)
    return


def validate_date(new_pd_series, new_col, err_list=[]):
    len_series = len(new_pd_series)
    null_check = new_pd_series.isnull()
    for i in xrange(0, len_series):
        type_elem = str(type(new_pd_series[i]))
        try:
            if (not null_check[i]) and (new_pd_series[i] != '') and (
                type_elem not in ["<class 'pandas.tslib.Timestamp'>", "<type 'datetime.datetime'>",
                                  "<type 'datetime.date'>"]):
                parser.parse(new_pd_series[i])
        except:
            err_list.append(
                "Error while validating Date {0} from column {1}, col type: {2}".format(new_pd_series[i], new_col,
                                                                                        type(new_pd_series[i])))
            new_pd_series[i] = None
    return new_pd_series, err_list


def validate_numeric(new_pd_series, new_col, err_list=[]):
    len_series = len(new_pd_series)
    null_check = new_pd_series.isnull()
    for i in xrange(0, len_series - 1):
        try:
            if not null_check[i]:
                temp = float(new_pd_series[i]) + 1
        except:
            err_list.append("Error while validating numeric {0} from column {1}".format(new_pd_series[i], new_col))
            new_pd_series[i] = None
    return new_pd_series, err_list


def validate_text(new_pd_series, new_col, err_list=[]):
    return new_pd_series, err_list


def no_validate(new_pd_series, new_col, err_list=[]):
    return new_pd_series, err_list


def get_domain_validator(dk):
    return {'date': validate_date,
            'numeric': validate_numeric,
            'text': validate_text
            }.get(dk, no_validate)


def domain_validation(new_pd_series, domain, new_col):
    new_pd_series, err_list = get_domain_validator(domain)(new_pd_series, new_col)
    return new_pd_series, err_list


def col_map_validation():
    return


def final_checksum():
    return


# Writes the output data frame to an excel file.
def write_output(newDf, output_file):
    writer = pd.ExcelWriter(output_file, engine='xlsxwriter')
    newDf = newDf.applymap(lambda x: x.decode('utf-8', 'ignore') if type(x) == str else x)
    newDf.to_excel(writer, sheet_name='Sheet1', index=0)
    writer.save()
    return


# Performs any Vertical level validation check on the column values.
def vertical_specific_validation(vertical, newDf):
    if vertical == 'smb':
        newDf = newDf.loc[newDf['click_id'].map(lambda x: False if x == "Total" else True)]
    return newDf


# the following function is incomplete and just a place holder of what I tried to achieve for a col_existence
def does_col_exist(old_col, set_data_cols, input_file):
    g = old_col.split(',')
    if not set(map(lambda x: x.strip(), g)).issubset(set_data_cols):
        raise MappingFileError(
            "All the required column(s) %s is/are not present in the Input Data File: %s" % (g, input_file))

        # if len(g) > 1:
        #    if not set(g).issubset(set_data_cols):
        #	raise MappingFileError("All the required column(s) %s is/are not present in the Input Data File: %s" % (g, input_file))
        # else:
        #    if not set([g]).issubset(set_data_cols):
        #	raise MappingFileError("All the required column(s) %s is/are not present in the Input Data File: %s" % (g, input_file))
        # print "Required columns exist"


def transform_to_excel(input_file, output_transformed_file, lender_map_path, s3_bucket='east1-prod-dwh-s3-0',
                       lender="unknown", file_received_dt=None, vertical="growth", skiprows=0, skip_footer=0):
    '''
	Main function which transforms the 'input_file' into a confirmed 'output_transformed_file' by applying specific transformations defined \
	in the 'lender_map_path' mapping file.
       input_file : actual file (e.g.  '/tmp/StreetShares_smb_12-13-2017.xlsx')
       output_transformed_file : final confirmed file (e.g.'/tmp/StreetShares_smb_12-13-2017_Transformed.xlsx')
       lender_map_path : specific mapping file (e.g. 's3://east1-prod-dwh-s3-0/aflt_tran_process_smb_loans/transformation/streetshares_map.xlsx')
       s3_bucket : s3 bucket holding the mapping file (e.g. 'east1-prod-dwh-s3-0')
       lender : lender's name for which transformation is being done (e.g. 'StreetShares')
       file_received_dt : date when the input_file was received (e.g. '12-13-2017')
       vertical : vertical which the lender belongs to (e.g. 'smb')
       skiprows : integer value denoting number of lines to skip before the header in the 'input_file'
       skip_footer : integer value denoting number of lines to skip from the footer in the 'input_file'
    '''
    error_msg = []
    try:
        if not file_received_dt:
            raise Exception("The filename needs a date and should be in the following format lender_vertical_date.ext")
        input_filename = os.path.basename(input_file)
        fn, input_file_ext = os.path.splitext(input_file)
        s3_path = lender_map_path
        print "s3_path", s3_path

        # data frame for the mapping sheet
        map_file = s3_file_download(s3_bucket, '', s3_path, '/tmp', to_file=True)
        mapDf = pd.read_excel(map_file)

        # data frame for the lender data
        if input_file_ext == '.xlsx' or input_file_ext == '.xls':
            dataDf = pd.read_excel(input_file, skiprows=skiprows, skip_footer=skip_footer)
        elif input_file_ext == '.csv':
            dataDf = pd.read_csv(input_file, skiprows=skiprows, skipfooter=skip_footer)
        else:
            raise Exception('Invalid extension "{}" for input file: {}'.format(input_file_ext, input_file))

        # create a new data frame to write the output
        newDf = pd.DataFrame()

        # replace all newline characters(if any) in column names with spaces (E.g. lendingtree)
       	dataDf.columns = [re.sub(r'\n', ' ', c) if isinstance(c,str) or isinstance(c,unicode) else c for c in dataDf.columns]

        # main loop over the confirmed columns
        mapNum = mapDf.as_matrix(columns=None)

        for x in mapNum:
            old_col = x[1].strip() if type(x[1]) == str else x[1]
            new_col = x[0].strip()
            transform = x[2]
            domain = str(x[3])

            print "Now processing the column : %s and applying : %s " % (new_col, transform)
            # appending new columns
            if str(transform) != 'nan':
                column_transform(newDf, dataDf, x, lender, vertical)
            else:
                if old_col in dataDf.columns:
                    newDf[new_col] = dataDf[old_col]
                else:
                    newDf[new_col] = ''
            newDf[new_col], v_err_list = domain_validation(newDf[new_col], domain, new_col)

            if v_err_list:
                v_err_str = "\n".join(v_err_list)
                error_msg.append(v_err_str)
                v_err_list = []

        newDf['src_filename'] = input_filename
        newDf['src_file_received_dt'] = file_received_dt
        newDf = vertical_specific_validation(vertical, newDf)

        # col_map_validation
        # final_checksum

        # wrting output to new xls file.
        print "Writing to the file: %s" % (output_transformed_file)
        write_output(newDf, output_transformed_file)

    except MappingFileError as mpe:
        print "{0}".format(mpe.value)
        error_msg.append(mpe.value)
    except KeyError as ke:
        print "Key Error: {0}".format(ke)
        error_msg.append(ke)
    except CustomExecuteError as cpe:
        print "{0}".format(cpe.value)
        error_msg.append(cpe.value)
    except Exception, e:
        print('Exception: {}'.format(e))
        error_msg.append(e)
    finally:
        return error_msg
