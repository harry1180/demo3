import os

from custom_exceptions import MappingFileError
from redshift_modules import exec_query
from s3_modules import s3_file_download_wildcard_search


def get_lenders(vertical):
    query = "Select lender from dw_report.ctl_dw_aflt_tran_growth_f where lower(vertical) = lower('{0}') and validated_in = 'yes' group by 1".format(
        vertical)
    lenders = exec_query(query)
    return [lender['lender'].lower() for lender in lenders]


def get_lender_details(fn, registered_lenders, vertical):
    query = "select distinct lender, lender_dwnld_wildcard, mapping_file from dw_report.ctl_dw_aflt_tran_growth_f where lower(vertical) like '{0}' and lower(data_source) like 'email_reports';"
    lenders = exec_query(query.format(vertical))

    lendername = 'unknown'
    mapping_file = ''
    for lender in lenders:
        if lender['lender_dwnld_wildcard'].lower() in fn[-1].lower() and lender['lender'].lower() in registered_lenders:
            lendername = lender['lender'].lower()
            mapping_file = lender['mapping_file']
            print "lender : %s, matched to file: %s" % (lendername, fn[-1])
            break
    return lendername, mapping_file


def get_mapping_file(lendername, vertical):
    try:
        print "*************", lendername, vertical
        query = "Select mapping_file from dw_report.ctl_dw_aflt_tran_growth_f where lower(lender) = '{0}' and lower(vertical) = '{1}' and validated_in = 'yes' group by 1".format(
            lendername.lower(), vertical.lower())
        mapping_file = exec_query(query)
        for map_file in mapping_file: return map_file['mapping_file']
    except:
        raise MappingFileError("Error while executing query to get  mapping file for lender: " + lendername)


def fetch_input_files(vertical, s3_bucket, s3_folder, local_output):
    s3_download_from = os.path.join(s3_folder, 'output')
    s3_archive_to = os.path.join(s3_folder, 'archive')
    for lender in get_lenders(vertical):
        s3_file_download_wildcard_search(s3_bucket, s3_download_from, lender, local_output, s3_archive_to)
