import pandas as pd
import numpy as np
import os
import sys
import re
import string
import xlsxwriter
from datetime import datetime,date
from s3_modules import s3_file_download
from redshift_modules import exec_query
from custom_exceptions import MappingFileError
from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException

QUICKEN_COMMISION = {
	'content': {
        	'quicken_purchase': 55,
                'quicken_refi': 110
	},
        'review': {
        	'quicken_purchase': 65,
                'quicken_refi': 130
	},
        'preapproval': {
         	'quicken_purchase': 75,
                'quicken_refi': 150
	},
	'rate': {
		'quicken_purchase': 75,
		'quicken_refi': 150
	},
        'other': {
        	'quicken_purchase': 30,
                'quicken_refi': 60
	}
}

def isNaN(val):
	return val!=val

def execute_custom_mortgages(newDf, dataDf, x_list, lender):
    try:
        new_col = x_list[0].strip().lower()
        old_col = x_list[1]
        lender = lender.strip().lower()

        if lender in ('lendingtree_phone','lendingtree_web'):
	    # 'tran_post_dt', 'tran_post_ts' are populated as 'fund_dt' only when the commission amount > 0.
            if new_col in ('tran_post_dt','tran_post_ts'):
                price,fund_dt  = old_col.split(',')
		dataDf[price] = dataDf[price.strip()].replace('-',0)
                newDf[new_col] = np.where(dataDf[price] > 0,dataDf[fund_dt],pd.to_datetime(None))
		for i in range(0,len(newDf[new_col])):
			newDf[new_col][i] = pd.to_datetime(newDf[new_col][i], format='%Y-%m-%d')
	    # 'txn_cnt' is populated as 1 only when the row was actually a transaction (i.e. when commission amount > 0)
	    elif new_col == 'txn_cnt':
		price = old_col
		newDf[new_col] = np.where(dataDf[price.strip()] > 0, 1, 0)
	    else:
                raise CustomColumnException (
                    "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

        elif lender in ('quicken_purchase','quicken_refi'):
	      newDf[new_col] = np.nan
	      # 'tran_post_dt', 'tran_post_ts' are populated as 'dt' only when the 'leads' > 0 and credit rating ('credit') is not 'Poor'.
	      if new_col in ('tran_post_dt','tran_post_ts'):
		  leads,credit,dt = old_col.split(',')
		  newDf[new_col] = np.where(np.logical_or(dataDf[leads.strip()] == 0, dataDf[credit.strip()] == 'Poor'),pd.to_datetime(None),dataDf[dt])
		  newDf[new_col] = pd.to_datetime(newDf[new_col], format ="%d-%b-%y")
	      # 'tran_click_dt', 'tran_click_ts', 'dw_eff_dt' are populated as 'dt' in the 'yyyy-mm-dd' format.
	      elif new_col in ('tran_click_dt','tran_click_ts','dw_eff_dt'):
		  newDf[new_col] = pd.to_datetime(dataDf[old_col], format ="%d-%b-%y")
	      # 'txn_cnt' is populated as 0 when credit rating('credit') is 'Poor' else as number of 'leads'.
	      elif new_col == 'txn_cnt':
		  leads,credit,qls_str = old_col.split(',')
                  for index,row in dataDf.iterrows():
			if pd.isnull(row[leads] and row[qls_str] and row[credit]): continue
                        if row[leads.strip()] == 0 or row[credit.strip()] == 'Poor' : newDf.set_value(index,new_col,0) 
			elif ('ndw' not in row[qls_str].lower()) and ('nwr' not in row[qls_str].lower()) : newDf.set_value(index,new_col,0)
                        else : newDf.set_value(index,new_col,row[leads.strip()])
		  newDf[new_col] = newDf[new_col].replace(np.nan,0)
	      # 'commission_am' is populated based on the rules defined in 'QUICKEN_COMMISSION" dict and the date parameter.
              elif new_col == 'commission_am':
		  leads,qls_str,credit,dt = old_col.split(',')
		  for index, row in dataDf.iterrows():
			if pd.isnull(row[leads] and row[qls_str] and row[credit]): continue
			if row[leads] == 0 or row[credit] == 'Poor' : newDf.set_value(index,new_col,0)
			elif 'content' in row[qls_str].lower() or 'unknown' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['content'][lender])
			elif 'review' in row[qls_str].lower() or 'roundup' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['review'][lender])
			elif 'preapproval' in row[qls_str].lower() or 'preapprov' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['preapproval'][lender])
			elif 'rate' in row[qls_str].lower() or 'qlrt' in row[qls_str].lower() or 'rktrt' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['rate'][lender])
			elif 'ndw' in row[qls_str].lower() or 'nwr' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['other'][lender])
			if row[leads] > 1: newDf.set_value(index,new_col,newDf.at[index,new_col]*row[leads])
	      elif new_col == 'src_status_tx':
		  # Order of statuses from initiated to finished: 
		  # 'Lead','Allocated', 'Credit Pulled', 'Setup Completed', 'Pre-Approval Letter'.
		  newDf.src_status_tx = newDf.src_status_tx.astype(str)
		  qls_str,allocate_cnt,setup_prcnt,credit_prcnt,pal_cnt = old_col.split(',')
		  for index,row in dataDf.iterrows():
			if pd.isnull(row[qls_str] and row[allocate_cnt] and row[setup_prcnt] and row[credit_prcnt] and row[pal_cnt]): continue
			# In quicken, last row has the totals so need to skip that.
			if row[pal_cnt] > 0 : newDf.set_value(index,new_col,'Pre-Approval Letter')
			elif row[setup_prcnt] > 0 : newDf.set_value(index,new_col, 'Setup Completed')
			elif row[credit_prcnt] > 0 : newDf.set_value(index,new_col,'Credit Pulled')
			elif row[allocate_cnt] > 0 : newDf.set_value(index,new_col, 'Allocated')
			else : newDf.set_value(index,new_col, 'Lead')
	      # Since, 'Partner Code' is '1' at many places so replacing it with NULL
	      elif new_col == 'src_unique_click_id':
		  newDf.src_unique_click_id = newDf.src_unique_click_id.astype(str)
		  partner_cd = old_col
		  newDf[new_col] = np.where(dataDf[partner_cd.strip()] == '1', np.nan, dataDf[partner_cd.strip()])				
	      # Since, 'Partner Code' is '1' at many places so replacing it with NULL
	      elif new_col == 'src_application_id':
                  newDf.src_application_id = newDf.src_application_id.astype(str)
                  partner_cd = old_col
                  newDf[new_col] = np.where(dataDf[partner_cd.strip()] == '1', np.nan, dataDf[partner_cd.strip()])
	      # Since, 'Partner Code' is '1' at many places so replacing it with NULL
              elif new_col == 'src_transaction_id':
                  newDf.src_transaction_id = newDf.src_transaction_id.astype(str)
                  partner_cd = old_col
                  newDf[new_col] = np.where(dataDf[partner_cd.strip()] == '1', np.nan, dataDf[partner_cd.strip()])
	      else:
                  raise CustomColumnException (
                      "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

	elif lender == 'rocket':
		newDf[new_col] = np.nan
		# 'commission_am' is populated based on the rules defined in 'QUICKEN_COMMISSION" dict.
		if new_col == 'commission_am':
			dt,channel,purpose,qls_str = old_col.split(',')
			for index, row in dataDf.iterrows():
				comm_type = 'quicken_'+row[purpose].lower()
				if row[purpose].lower() == 'refinance': comm_type = 'quicken_refi'
                        	if pd.isnull(row[channel] and row[qls_str] and row[purpose]): continue
				elif 'rate' in row[channel].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['rate'][comm_type])
				else:
                        		if 'content' in row[qls_str].lower() or 'unknown' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['content'][comm_type])
                        		elif 'review' in row[qls_str].lower() or 'roundup' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['review'][comm_type])
                        		elif 'preapproval' in row[qls_str].lower() or 'preapprov' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['preapproval'][comm_type])
                        		elif 'rate' in row[qls_str].lower() or 'qlrt' in row[qls_str].lower() or 'rktrt' in row[qls_str].lower(): newDf.set_value(index,new_col,QUICKEN_COMMISION['rate'][comm_type])
                        		elif 'ndw' in row[qls_str].lower() or 'nwr' in row[qls_str].lower(): 
						if row[dt].date() < datetime.strptime('2017-03-13','%Y-%m-%d').date(): newDf.set_value(index,new_col,QUICKEN_COMMISION['other'][comm_type])
						else : newDf.set_value(index,new_col,QUICKEN_COMMISION['content'][comm_type])
		# Order of statuses from initiated to finished:
                # 'Lead', 'Account Created', 'Setup Completed', 'Pre-Approval Letter', 'Closed'.
		elif new_col == 'src_status_tx':
			newDf.src_status_tx = newDf.src_status_tx.astype(str)
			create_cnt,setup_cnt,pal_cnt,close_cnt = old_col.split(',')
			for index,row in dataDf.iterrows():
                        	if pd.isnull(row[create_cnt] and row[setup_cnt] and row[pal_cnt] and row[close_cnt]): continue
                        	if row[close_cnt] > 0 : newDf.set_value(index,new_col,'Closed')
                        	elif row[pal_cnt] > 0 : newDf.set_value(index,new_col, 'Pre-Approval Letter')
                        	elif row[setup_cnt] > 0 : newDf.set_value(index,new_col,'Setup Completed')
                        	elif row[create_cnt] > 0 : newDf.set_value(index,new_col, 'Account Created')
                        	else : newDf.set_value(index,new_col, 'Lead')
		# In Hasoffers 'src_solumn_18' specifies the page type so using the same for the file data source.
		# This column will further help in the rocket updates being done in the end to reconcile between HasOffers and the File numbers.
		elif new_col == 'src_column_18':
			newDf.src_column_18 = newDf.src_column_18.astype(str)
			channel,qls_str = old_col.split(',')
			for index,row in dataDf.iterrows():
				if pd.isnull(row[channel] and row[qls_str]): continue
				if 'rate' in row[channel].lower(): newDf.set_value(index,new_col, 'Rocket Rate')
				else:
					if 'content' in row[qls_str].lower() or 'unknown' in row[qls_str].lower(): newDf.set_value(index,new_col,'Rocket Content')
                                        elif 'review' in row[qls_str].lower() or 'roundup' in row[qls_str].lower(): newDf.set_value(index,new_col,'Rocket Review')
                                        elif 'preapproval' in row[qls_str].lower() or 'preapprov' in row[qls_str].lower(): newDf.set_value(index,new_col,'Rocket Preapproval')
                                        elif 'rate' in row[qls_str].lower() or 'qlrt' in row[qls_str].lower() or 'rktrt' in row[qls_str].lower(): newDf.set_value(index,new_col,'Rocket Rate')
                                        elif 'ndw' in row[qls_str].lower() or 'nwr' in row[qls_str].lower(): newDf.set_value(index,new_col,'Rocket Content')

	elif lender == 'quicken_calls':
		newDf[new_col] = np.nan
		# 'tran_post_dt', 'tran_post_ts' are populated as 'dt' only when the 'leads' > 0.
		if new_col in ('tran_post_dt','tran_post_ts'):
			dt,leads = old_col.split(',')
			newDf[new_col] = np.where(dataDf[leads] == 0, pd.to_datetime(None), dataDf[dt])
			newDf[new_col] = pd.to_datetime(newDf[new_col], format ="%d-%b-%y")
		# 'tran_click_dt', 'tran_click_ts', 'dw_eff_dt' are populated as 'dt' in the 'yyyy-mm-dd' format.
		elif new_col in ('tran_click_dt','tran_click_ts','dw_eff_dt'):
			newDf[new_col] = pd.to_datetime(dataDf[old_col], format ="%d-%b-%y")
		# 'commission_am' is $80 for all Purchase/Refi/Mortgage First call leads.
		elif new_col == 'commission_am':
			newDf[new_col] = np.where(dataDf[old_col] == 0, 0, 80*dataDf[old_col])
		# 'txn_cnt' is populated only when the net leads > 0.
		elif new_col == 'txn_cnt':
			newDf[new_col] = np.where(dataDf[old_col] == 0, 0, dataDf[old_col])
		else:
                  raise CustomColumnException (
                      "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

	elif lender == 'clicks_net':
		newDf[new_col] = np.nan
		# 'tran_post_dt','tran_click_dt' are populated as 'dt' only when commission is not 0
		if new_col in ('tran_post_dt','tran_post_ts'):
		    commission,dt = old_col.split(',')
		    dataDf[commission] = dataDf[commission.strip()].replace(to_replace='[^0-9.]+',value='',regex=True)
		    newDf[new_col] = np.where(dataDf[commission.strip()] == 0, pd.to_datetime(None), dataDf[dt.strip()])
		    newDf[new_col] = pd.to_datetime(newDf[new_col], format ="%Y-%m-%d")
		# 'src_status_tx' is populated as 'click' if number if no. of clicks is not 0, 'impression' if no. of impressions is not 0 and 'not defined' otherwise.
		elif new_col == 'src_status_tx':
		    click,impression = old_col.split(',')
		    newDf[new_col] = np.where(dataDf[click.strip()] == 0,np.where(dataDf[impression] == 0, 'not defined', 'impression'), 'click')
		elif new_col in ('aflt_network_tran_id','src_unique_click_id','src_application_id','src_transaction_id'):
		    newDf[new_col] = np.where(dataDf[old_col.strip()] == ':', np.nan, dataDf[old_col.strip()])
		    newDf[new_col] = newDf[new_col].str.replace(':','')
		# 'commission' comes with a '$' in the input files so need to filter that out.
		elif new_col in ('commission_am'):
		    epc,clicks = old_col.split(',')
		    newDf[new_col] = dataDf[clicks.strip()]*dataDf[epc.strip()].replace(to_replace='[^0-9.]+',value='',regex=True).astype(float)
		else:
                  raise CustomColumnException (
                      "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

	elif lender == 'homelight':
		newDf[new_col] = np.nan
		# 'commission_am' is $30 for a 'buyer' and $60 for a 'seller'.
		if new_col in ('commission_am'):
			newDf[new_col] = np.where(dataDf[old_col.strip()] == 'seller', 60, 30)
		else:
                  raise CustomColumnException (
                      "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

	elif lender == 'jg wentworth':
		newDf[new_col] = np.nan
		# 'commission_am' is $65 for 'purchase' and $100 for 'refi'.
		# At many place there are call leads (without any explicit Purchase/Refi tags) which shoule be marked as 0.
		if new_col == 'commission_am': 
			ltype,bad_lead = old_col.split(',')
			newDf[new_col] = np.where(isNaN(dataDf[bad_lead.strip()]), np.where(dataDf[ltype.strip()] == 'Purchase', 65, np.where(dataDf[ltype.strip()] == 'Refinance', 100, 0)), 0)
 		elif new_col in ('tran_post_dt','tran_post_ts'):
			dt,bad_lead,ltype = old_col.split(',')	
			newDf[new_col] = np.where(isNaN(dataDf[bad_lead.strip()]), np.where(isNaN(dataDf[ltype.strip()]), pd.to_datetime(None), dataDf[dt.strip()]), pd.to_datetime(None))
			newDf[new_col] = pd.to_datetime(newDf[new_col], format ="%Y-%m-%d")
		elif new_col == 'txn_cnt':
			bad_lead,ltype = old_col.split(',')
			newDf[new_col] = np.where(isNaN(dataDf[bad_lead.strip()]), np.where(isNaN(dataDf[ltype.strip()]), 0, 1), 0)
		else:
                  raise CustomColumnException (
                      "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

	elif lender == 'network capital':
		newDf[new_col] = np.nan
		# 'commission_am' is $25 for 'Purchase' and $50 for 'Refinance'
		if new_col == 'commission_am':
			newDf[new_col] = np.where(dataDf[old_col.strip()].str.contains('Purchase'), 25, 50)
		else:
		  raise CustomColumnException (
	              "Please handle the column: {0} for this lender: {1}".format(new_col, lender))

        print "Completed Executing Custom Execute Function"
    except CustomColumnException as cce:
	print cce
        raise CustomExecuteError(cce.value)
    except Exception as e:
	print e
        raise CustomExecuteError(
		"Error: execute_custom for column: {0} for this lender: {1}".format(new_col, lender))
