import re

from custom_exceptions import CustomExecuteError
from custom_exceptions import CustomColumnException

SOFI_COMMISSION_TIERS = {
	'tier1' : 9999999,
	'tier2' : 19999999,
	'tier3' : 29999999
}

SOFI_COMMISSION_RATES = {
	'tier1' : 0.0065,
	'tier2' : 0.0070,
	'tier3' : 0.0075,
	'tier4' : 0.0080
}

def execute_custom_edu(src_df_row, old_col_nm, new_col_nm, transform, lender):
    try:
        lender = lender.strip().lower()
        new_col = ''
	
        if lender == 'purefy':
            if new_col_nm == 'txn_cnt':
		new_col = 1 if (src_df_row[old_col_nm] is not None and src_df_row[old_col_nm] <> '') and src_df_row[old_col_nm] > 0 else 0
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col

        if lender == 'sofi':
            if new_col_nm == 'src_unique_click_id':
		new_col = '' if src_df_row[old_col_nm] is None or src_df_row[old_col_nm] == '' else src_df_row[old_col_nm].split('>')[1].split(',')[0].replace('"','')
	    elif new_col_nm == 'txn_cnt':
		new_col = 0 if src_df_row[old_col_nm] == 0 else 1
	    elif new_col_nm == 'src_status_tx':
		dt_st,dt_submit,dt_fund = old_col_nm.split(',')
		if src_df_row[dt_fund] <> None and src_df_row[dt_fund.strip()] <> '': new_col = 'funded'
		elif src_df_row[dt_submit] <> None and src_df_row[dt_submit.strip()] <> '': new_col = 'submit'
		elif src_df_row[dt_st] <> None and src_df_row[dt_st.strip()] <> '': new_col = 'start'
		else: new_col = 'lead'
	    elif new_col_nm == 'commission_am':
		fund_am = src_df_row[old_col_nm]
		if fund_am == 0: new_col = 0
		elif fund_am <= SOFI_COMMISSION_TIERS['tier1']: new_col = round(fund_am*SOFI_COMMISSION_RATES['tier1'],2)
		elif fund_am <= SOFI_COMMISSION_TIERS['tier2']: new_col = round(fund_am*SOFI_COMMISSION_RATES['tier2'],2)
		elif fund_am <= SOFI_COMMISSION_TIERS['tier3']: new_col = round(fund_am*SOFI_COMMISSION_RATES['tier3'],2)
		else: new_col = round(fund_am*SOFI_COMMISSION_RATES['tier4'],2)
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col

	if lender == 'elfi':
	    if new_col_nm == 'commission_am':
		status,dt = old_col_nm.split(',')
		new_col = 550 if src_df_row[status].lower() == 'disbursement' and src_df_row[dt] is not None and src_df_row[dt] <> '' else 0
	    elif new_col_nm == 'txn_cnt':
		status,dt = old_col_nm.split(',')
		new_col = 1 if src_df_row[status].lower() == 'disbursement' and src_df_row[dt] is not None and src_df_row[dt] <> '' else 0
	    else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col

	if lender == 'earnest':
	    if new_col_nm == 'commission_am':
		dt,status = old_col_nm.split(',')
		new_col = 0 if src_df_row[dt] is None or src_df_row[dt] == '' or src_df_row[status].lower() == 'void' else 450
	    elif new_col_nm == 'txn_cnt':
		dt,status = old_col_nm.split(',')
                new_col = 0 if src_df_row[dt] is None or src_df_row[dt] == '' or src_df_row[status].lower() == 'void' else 1
	    else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col	
	
        if lender == 'laurelroad':
            if new_col_nm == 'commission_am':
                comm,status = old_col_nm.split(',')
                new_col = src_df_row[comm] if src_df_row[status] == 'Partner Paid' or src_df_row[status] == 'closed_funded' else 0
            elif new_col_nm == 'src_unique_click_id':
                new_col = '' if src_df_row[old_col_nm] is None or src_df_row[old_col_nm] == '' or 'subid' not in src_df_row[old_col_nm].lower() else src_df_row[old_col_nm].lower().split('subid=')[1].split('&')[0]
            elif new_col_nm == 'txn_cnt':
                new_col = 1 if src_df_row[old_col_nm] == 'Partner Paid' or src_df_row[old_col_nm] == 'closed_funded' else 0
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                new_col = 'funded' if src_df_row[old_col_nm] == 'Partner Paid' or src_df_row[old_col_nm] == 'closed_funded' else 'applied'
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col

        if lender == 'lendkey':
            if new_col_nm == 'commission_am':
                dt,amt = old_col_nm.split(',')
                new_col = float(src_df_row[amt])*0.009 if src_df_row[dt] <> '' else 0
            elif new_col_nm == 'txn_cnt':
                new_col = 1 if src_df_row[old_col_nm] <> '' else 0
            elif new_col_nm == 'src_unique_click_id':
                new_col = '' if src_df_row[old_col_nm] is None or src_df_row[old_col_nm] == '' or 'aff-nerdwallet=' not in src_df_row[old_col_nm].lower() else src_df_row[old_col_nm].lower().split('aff-nerdwallet=')[1]
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col

	
	if lender == 'commonbond':
	    if new_col_nm in ('commission_am','merchant_am','src_term_tx','src_apr_tx','src_int_rt'):	
		new_col = '' if src_df_row[old_col_nm] is None else src_df_row[old_col_nm]
	    elif new_col_nm == 'txn_cnt':
		new_col = 0 if src_df_row[old_col_nm] is None or src_df_row[old_col_nm] == '' or src_df_row[old_col_nm] == 0 else 1
	    else:
		raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col

        if lender == 'citizensbank':
            if new_col_nm == 'commission_am':
                status,amt = old_col_nm.split(',')
                new_col = 0 if src_df_row[status].lower() == 'no' else float(src_df_row[amt])*0.01
            elif new_col_nm == 'txn_cnt':
                new_col = 0 if src_df_row[old_col_nm].lower() == 'no' else 1
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                new_col = 'applied' if src_df_row[old_col_nm].lower() == 'no' else 'funded'
            elif new_col_nm == 'src_unique_click_id':
                new_col = '' if src_df_row[old_col_nm] is None or src_df_row[old_col_nm] == '' or 'subid' not in src_df_row[old_col_nm].lower() else src_df_row[old_col_nm].lower().split('subid=')[1].split('&')[0]
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col


        if lender == 'collegeave':
            if new_col_nm == 'commission_am':
                ind,amt = old_col_nm.split(',')
                new_col = 0 if src_df_row[ind] == 0 else float(src_df_row[amt])*0.009
            elif new_col_nm == 'txn_cnt':
                new_col = 0 if src_df_row[old_col_nm] == 0 else 1
            elif new_col_nm == 'aflt_fin_tran_type_cd':
                new_col = 'funded' if src_df_row[old_col_nm] == 1 else 'applied'
            elif new_col_nm == 'src_unique_click_id':
                new_col = '' if src_df_row[old_col_nm] == '#N/A' else src_df_row[old_col_nm]
            else:
                raise CustomColumnException(
                    "Please handle the column: {0} for this lender: {1}".format(new_col_nm, lender))
            return new_col


    except CustomColumnException as cce:
        print cce
        raise CustomExecuteError(cce.value)
    except Exception as e:
        print e
        raise CustomExecuteError("Error: execute_custom for this lender: {1}".format(lender))
