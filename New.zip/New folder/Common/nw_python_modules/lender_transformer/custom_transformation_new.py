from custom_exceptions import CustomColumnException
from custom_transformation_smb_new import execute_custom_smb
from custom_transformation_mrtg import execute_custom_mortgages
from custom_transformation_investing import execute_custom_investing
from custom_transformation_cc import execute_custom_cc
from custom_transformation_pl import execute_custom_pl
from custom_transformation_edu import execute_custom_edu
from custom_transformation_banking import execute_custom_banking


def execute_custom(src_df_row, old_col, new_col_nm, transform, lender, vertical):
    '''
        Performs vertical specific custom transformations on the corresponding columns.
        src_df_row : incoming source row
        mapping : column mapping object
        lender : lender's name for which transformation is being performed
        vertical : lender's vertical
    '''
    if vertical == 'smb':
        new_col = execute_custom_smb(src_df_row, old_col, new_col_nm, transform, lender)
    elif vertical == 'cc':
        new_col = execute_custom_cc(src_df_row, old_col, new_col_nm, transform, lender)
    elif vertical == 'edu':
        new_col = execute_custom_edu(src_df_row, old_col, new_col_nm, transform, lender)
    elif vertical == 'pl':
        new_col = execute_custom_pl(src_df_row, old_col, new_col_nm, transform, lender)
    elif vertical == 'banking':
        new_col = execute_custom_banking(src_df_row, old_col, new_col_nm, transform, lender)
    # elif vertical == 'mortgages':
    #    execute_custom_mortgages(src_df_row, old_col, transform, lender)
    # elif vertical == 'investing':
    #    execute_custom_investing(src_df_row,old_col, transform, lender)
    else:
        raise CustomColumnException('Custom transformation for this vertical not supported yet')
    return new_col
