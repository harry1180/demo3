import copy
import imp
import os
import os.path
import platform
import re
import shutil
import six
import ssl
import struct
import string
import subprocess
import sys
import time

if platform.system() == 'Java':
    import json
else:
    import ujson as json

# Third party modules
from google.protobuf.descriptor import FieldDescriptor
from prettytable import PrettyTable
from email.MIMEText import MIMEText

# NerdWallet modules
import event_enrichment
from file_and_path_utils import FileUtils
import nw_hive
import nwpyschemas.util as pb_utils
from s3_modules import get_s3_files_in_range, check_if_key_exist, s3_file_download, mv_to_s3, s3_file_upload


def deserialize_pb(pb_class, serialized_pb):
    """
    Deserializes the given ProtoBuf encoded string and returns the corresponding ProtoBuf
    object.

    Example:
        pb_class = load_class('PageViewEvent')
        deserialize_pb(pb_class, serialized_pb)

    :param pb_class: should be a protobuf class object (NOT instance)
    :param serialized_pb: the protobuf encoded string corresponding to the given schema
    :return: protobuf object
    """
    pb = pb_class()
    pb.ParseFromString(serialized_pb)
    return pb


def get_event_overrides(custom_overrides):
    # Get global overrides
    overrides_json_file = open(os.environ.get('dwh_common_base_dir', '/data/etl/Common') + '/event_overrides.json')
    overrides = json.loads(overrides_json_file.read())

    # Merge custom and global overrides. Custom overrides take precedence if there is conflict
    if custom_overrides:
        for full_name, ovrds in custom_overrides.iteritems():
            if full_name in overrides:
                overrides[full_name].update(ovrds)
            else:
                overrides[full_name] = ovrds
    return overrides


def apply_name_overrides(json_dict, overrides):
    for full_name in json_dict.keys():
        # Extract the short name from the fully qualified name
        new_name = full_name.rpartition('.')[2]

        if full_name in overrides:
            name_override = overrides.get(full_name).get('name')
            if name_override is not None:
                new_name = name_override

        json_dict[new_name] = json_dict[full_name]
        del json_dict[full_name]


def redshift_scrub_dict(in_dict):
    """
    Examines values in a dictionary and changes any values that will cause load
    errors with the Redshift COPY command. The list of changes is:

    1. If a value is a string and the first character of that string is a null
       character, the Redshift COPY command fails with the error "Invalid null
       byte - field longer than 1 byte". If the string is a unicode string, the
       first character is changed to U+2400. If it's a non-unicode string, it's
       changed to '0'.

    @param in_dict: dictionary of elements
    """
    for key, val in in_dict.iteritems():
        if not isinstance(val, six.string_types):
            continue
        if len(val) < 1 or ord(val[0]) != 0:
            continue
        # Note: This probably isn't Python 3 compatible
        if isinstance(val, unicode):
            in_dict[key] = unichr(9216) + val[1:]
            continue
        in_dict[key] = "0" + val[1:]


def FileParser_pb_to_json(schema_class, pb_fname, json_fname, json_function, overrides, extra_process = None):
    """
    This method reads the protobuf binary data off disk, through schema_class to decode protobuf,
            and writes into output files - json and parquet - line by line
    Example: FileParser_pb_to_json_n_parquet('FormInputChangedEvent', '/data/FormInputChangedEvent/2016/09/16/10.protobuf', '/json/FormInputChangedEvent/dw_eff_dt=2016-09-16/10.json', customize_json_dict)
    """
    skip_json = False
    if json_fname is None:
        skip_json = True

    fi  = open(pb_fname, 'r')
    if not skip_json:
        foj = open(json_fname, 'a')

    done = False
    pb_class = pb_utils.load_class(schema_class)
    read_cnt  = 0
    jwrite_cnt = 0
    jerror_cnt = 0

    while done == False:
        length_str = fi.read(8)
        if length_str == '':
            fi.close()
            if not skip_json:
                foj.close()

            done = True
            continue

        length = struct.unpack(">Q", length_str)[0]
        record = fi.read(length)
        read_cnt += 1
        if len(record) != length:
            fi.close()
            if not skip_json:
                foj.close()
                jerror_cnt += 1
            done = True
        else:
            parsed_protobuf = deserialize_pb(pb_class, record)
            json_dict = pb_utils.protobuf_to_dict(parsed_protobuf, flatten=True, use_full_names=True)

            if not skip_json:
                # Events that we want to do full enrichment on. This set is used to control when events have full
                # enrichment. After all events are converted, refactor this code so that full enrichment happens all
                # the time.
                full_enrich_events = {
                    "BackendNWUserDataExportEvent",
                    "BankingRateImpressionEvent",
                    "EmbedViewEvent",
                    "FormInputChangedEvent",
                    "ForumActivityEvent",
                    "JoinEvent",
                    "PageViewEvent",
                    "RoleChangeEvent",
                    "SessionStartEvent",
                }
                #### Output json dict
                ## Begin: customize fields
                try:
                    apply_name_overrides(json_dict, overrides)
                    custom_dict = event_enrichment.enrich(
                        in_dict=json_dict,
                        event_specific_enrichment=json_function,
                        generic_enrichment=schema_class in full_enrich_events
                    )

                    if not skip_record(custom_dict):
                        json_dict.update(custom_dict)
                        ## End: customize fields
                        redshift_scrub_dict(json_dict)
                        json.dump(json_dict, foj, sort_keys=True)
                        foj.write("\n")
                        jwrite_cnt += 1
                except ValueError as e:
                    print('Error processing json_dict: {}: {}'.format(e, json_dict))
                    jerror_cnt += 1
                    done = True
                    continue
                    # TODO: don't mark done immediately???

                if extra_process != None:
                    extra_process.process_row(json_dict)

    return (read_cnt, jwrite_cnt, jerror_cnt)


# Filter out records marked with the _skipthisrecord key
def skip_record(custom_dict):
    if '_skipthisrecord' in custom_dict:
        if isinstance(custom_dict['_skipthisrecord'], bool):
            return custom_dict['_skipthisrecord']
        else:
            print('Error: _skipthisrecord key does not map to boolean value')
            raise ValueError
    return False


def print_load_stats(src_bucket, dst_bucket, output_filetype, load_stats):
    pt = PrettyTable(['input_s3 %s' % src_bucket, 'lost_recs', 'error_recs', 'partitions', 'input_recs',
                      'output_%s_recs' % output_filetype, 'output_s3 %s FILESET' % dst_bucket])
    pt.align = 'r'  # Right align by default
    pt.align['input_s3 %s' % src_bucket] = 'l'
    pt.align['output_s3 %s FILESET' % dst_bucket] = 'l'
    pt.padding_width = 1  # One space between column edges and contents (default)
    si = so = se = sp = sl = mikl = mokl = 0  # set sums and max_key_lengths to zero

    for c in load_stats:
        if 'bypassed' in c and c['bypassed']:
            lost_recs = None
        else:
            lost_recs = c.get('read_count', 0) - c.get('write_count', 0) - c.get('error_count', 0)

        if 'input' in c:
            mikl = max(mikl, len(c['input']) - len(src_bucket) - 6)
            mokl = max(mokl, (len(c['output']) - len(dst_bucket) - 6) if 'output' in c else 0)

            pt.add_row([
                c['input'][len(src_bucket) + 6:]
                , lost_recs if lost_recs is not None else ''
                , c.get('error_count', '')
                , c.get('partition_count', '')
                , c.get('read_count', '')
                , c.get('write_count', '')
                , c['output'][len(dst_bucket) + 6:] if 'output' in c else ''
            ])

        si += c.get('read_count', 0)
        so += c.get('write_count', 0)
        se += c.get('error_count', 0)
        sp += c.get('partition_count', 0)
        if lost_recs:
            sl += lost_recs

    # maybe a better library? :)
    pt.add_row(['-' * max(mikl, 9 + len(src_bucket)), '-' * max(9, len(str(sl))), '-' * max(10, len(str(se))),
                '-' * max(10, len(str(sp))),
                '-' * max(10, len(str(si))), '-' * max(12 + len(output_filetype), len(str(so))),
                '-' * max(mokl, 18 + len(dst_bucket))])
    pt.add_row(['Total', sl, se, sp, si, so, ''])
    print pt


def Emit_protobuf_enhanced(pb_class_nm, src_bucket, src_path, start_date, end_date,
    local_input_path, local_output_path, dst_bucket, dst_path, dst_system, ovrd_flag,
    enhancement_function, schema_list, custom_overrides, pymodulename, compression, tablename, extra_process = None,
    src_aws_profile=None, dst_aws_profile=None):
    """
    Downloads protobuf or pb files from S3 to local ETL server, converts to json-dict format and parquet-format files, and uploads backs to S3.
    @param pb_class_nm is the protocol buf class.  If dest_system='redshift', it's a python module name, if java, it's a java class name
    @param src_bucket is the source s3 bucket
    @param src_path is the source path to get to the individual file
    @param start_date is the processing start date in YYYY-MM-DD format
    @param end_date is the processing end date in YYYY-MM-DD format
    @param local_input_path   is the EC2 working directory for inputs (common)
    @param local_output_path  is the EC2 working directory for outputs (common)
    @param dst_bucket is the destination s3 bucket
    @param dst_path is the destination path to get to the individual file
    @param dst_system is either 'redshift' (emits json) or 'nerdlake' (emits parquet)
    @param ovrd_flag is a string ('True' or 'False') indicating whether we should attempt to rewrite s3 outputs even if we sense they are present
    @param enhancement_function should be a function type
    @param schema_list is the parquet extra field descriptor list
    @param custom_overrides is an object that contains properties which modifies the default deserialization process
    @param pymodulename is typically passed as os.path.realpath(__file__) in an convert_protobuf_to_dwh.py function
    @param compression is the compression type, or 'None'
    @param tablename is the name of the hive table to be autocreated / autoupdated (nerdlake only)
    @param extra_process is used to have another process 'ride along' with the deserialization / ++ process.  In PageViewEvent, for example, we use it to write out some additional files
    """

    print 'Reading protobuf from s3://%s/%s' % (src_bucket, src_path)
    print 'Running for date range of [%s =< data date < %s)' % (start_date, end_date)

    if dst_system != 'redshift' and dst_system != 'nerdlake':
        raise RuntimeError("dest_system must be either 'redshift' or 'nerdlake'")
    if dst_system == 'redshift' and compression != 'None':
        raise RuntimeError("redshift processing supports only compression='None'")

    # Build event overrides object for this job
    overrides = get_event_overrides(custom_overrides)

    # Counters for files processed, working directory marked for deletion, columns from the last PqWriter invocation
    record_counter = []
    choproot = None

    ## Main action
    # Download the protobuf and convert to json or parquet, adding in the extra ++ fields
    # For each s3 object that has changed, then convert and write to output files
    print('')
    for key in sorted(get_s3_files_in_range('Prod', src_bucket, start_date, end_date, src_path, 'protobuf', ignore_empty=True, aws_profile=src_aws_profile)):
        key_metrics = {}
        key_metrics['input'] = 's3://%s/%s' % (src_bucket, key)
        read_count = write_count = error_count = 0

        print('Found s3://%s/%s' % (src_bucket, key))
        if not key.endswith('.protobuf'):
            print('    Skipping (not a .protobuf file)')
            continue

        ## identify parts of and full path/filenames:
        #
        #                   key = 'CCImpressionEvent/2015/09/17/10.protobuf'
        #             s3_subdir = '2015/09/17'
        #   s3_subdir_partition = 'dw_eff_dt=2015-09-17'
        #       file_input_path = '/data/etl/Data/CCImpressionEvent/input/2015/09/17'
        #                         (follows s3 protobuf folder structure)
        #      file_output_path = '/data/etl/Data/CCImpressionEvent/output/dw_eff_dt=2015-09-17'
        #                         (follows the partition folder name scheme)
        #     file_archive_path = '/data/etl/Data/CCImpressionEvent/archive/dw_eff_dt=2015-09-17'
        #                         (not used)
        #    protobuf_file_name = '10.protobuf'
        #              choproot = '/data/etl/Data/CCImpressionEvent/'
        #       output_filetype = 'json' or 'pq'
        #       output_filename = '10.json' or '2015.09.17.10.pq'
        # local_output_filename = '/data/etl/Data/CCImpressionEvent/output/dw_eff_dt=2015-09-17/10.json' or .pq
        #    s3_output_pathname = 'CCImpressionEvent_nerdlake/dw_eff_dt=2015-09-17'
        #    s3_output_filename = Redshift: 'CCImpressionEvent/dw_eff_dt=2015-09-17/10.json'
        #                         NerdLake: 'dwnl_stage/CCImpressionEvent_s/dw_eff_dt=2015-09-17/2015.09.17.10.pq'
        # legacy_s3_output_filename = Redshift: None
        #                         NerdLake: 'dwnl_stage/CCImpressionEvent_s/dw_eff_dt=2015-09-17/10_2015.09.17.10.pq'
        #  local_input_filename = '/data/etl/Data/CCImpressionEvent/input/2015/09/17/10.protobuf'

        s3_subdir             = os.path.dirname(key)[len(src_path):].strip('/')
        s3_subdir_partition   = 'dw_eff_dt=' + s3_subdir.replace("/", "-")
        file_input_path       = os.path.join(local_input_path,   s3_subdir)
        file_output_path      = os.path.join(local_output_path,  s3_subdir_partition)
        protobuf_file_name    = os.path.basename(key)
        choproot              = os.path.abspath('%s/../..' % file_output_path)

        if   dst_system == 'redshift':
            output_filetype   = 'json'
            output_filename   = os.path.splitext(protobuf_file_name)[0] + '.json'
            legacy_output_filename = None
        elif dst_system == 'nerdlake':
            output_filetype   = 'pq'
            src_file          = os.path.splitext(protobuf_file_name)[0]
            output_filename   = s3_subdir.replace("/", ".") + '.' + src_file.replace(':', '.') + '.pq'
            legacy_output_filename = src_file.replace(':', '.') + '_' + s3_subdir.replace("/", ".") + '.' + src_file.replace(':', '.') + '.pq'
        else:
            raise ValueError('dst_system was \'{}\', must be \'redshift\' or \'nerdlake\''.format(dst_system))

        local_output_filename = os.path.join(file_output_path, output_filename)
        s3_output_pathname    = os.path.join(dst_path, s3_subdir_partition)
        s3_output_filename    = os.path.join(s3_output_pathname, output_filename)
        legacy_s3_output_filename = None if legacy_output_filename is None else os.path.join(s3_output_pathname, legacy_output_filename)

        key_metrics['output'] = 's3://' + os.path.join(dst_bucket, s3_output_filename)
        key_metrics['local_output_filename'] = local_output_filename
        key_metrics['file_output_path'] = file_output_path
        key_metrics['s3_output_pathname'] = s3_output_pathname
        key_metrics['s3_output_filename'] = s3_output_filename

        FileUtils.create_path(file_input_path)
        FileUtils.create_path(file_output_path)

        ## if processing is already complete because the destination file exists on s3, then skip it,
        # unless the override flag is set
        # the try/except is there to avoid "404 not found's" when there's not a destination area yet,
        # so just act like there's work to do!
        print('    Looking for s3://{}/{}'.format(dst_bucket, s3_output_filename))
        if legacy_s3_output_filename is not None:
            print('             or s3://{}/{}'.format(dst_bucket, legacy_s3_output_filename))
        try:
            if check_if_key_exist(dst_bucket, s3_output_filename) or check_if_key_exist(dst_bucket, legacy_s3_output_filename):
                if ovrd_flag == 'False':  # note that sys.argv[] are still strings, hasn't converted to a boolean
                    print('    Skipping (dest. key already exists)')
                    s3_output_filename = None    # continue executing, but skip a lot of steps to still get final-output table data
                    del key_metrics['output']
                    key_metrics['bypassed'] = True
                else:
                    print('    Re-emitting (overwriting)')
        except:
            pass

        ## retrieve input

        local_input_filename = None
        if s3_output_filename is not None:
            tries = 1
            while tries < 10:
                print('    Downloading')
                try:
                    key_metrics['input_download_start_time'] = long(time.time() * 1000.0)
                    local_input_filename = s3_file_download(src_bucket, src_path, key, local_input_path, to_file=True, aws_profile=src_aws_profile)
                    if dst_system == 'nerdlake' and ':' in local_input_filename:
                        new_local_input_filename = local_input_filename.replace(':', '.')
                        os.rename(local_input_filename, new_local_input_filename)
                        local_input_filename = new_local_input_filename
                    key_metrics['input_download_end_time'] = long(time.time() * 1000.0)
                    key_metrics['local_input_filename'] = local_input_filename
                    print('    Downloaded to %s' % local_input_filename)
                    break
                except ssl.SSLError:
                    print '    SSL Error. Sleeping for a minute.'
                    time.sleep(60)
                    tries +=1
            else:
                raise TimeoutError

        record_counter.append(key_metrics)

    ## now do the conversion / enrichment
    print('')
    print('Converting ProtoBuf files')
    if dst_system == 'redshift':
        redshift_deserialization(record_counter, dst_bucket, extra_process, pb_class_nm, enhancement_function, choproot, overrides)

    elif dst_system == 'nerdlake':
        record_counter = nerdlake_deserialization(record_counter, dst_bucket, dst_path, tablename, local_output_path, compression,
                                                    ovrd_flag, pb_class_nm, enhancement_function, pymodulename, schema_list, overrides,
                                                  dst_aws_profile=dst_aws_profile)
    print('Conversion complete')

    # finally, print some stats and send email alerts if applicable

    if len(record_counter) > 0:
        print ' '
        print 'Batch Completed. Printing key file stats ...'
        print_load_stats(src_bucket, dst_bucket, output_filetype, record_counter)
        error_alert(record_counter, src_path, dst_system)
    else:
        print "No work was done.  If you want to process one day's data, make sure the end date is in the future."

    ## Clean up
    print ''
    if choproot is not None:
        shutil.rmtree(choproot)
        print 'Deleted directory %s' % choproot
    if extra_process != None:
        extra_process.cleanup()

    print 'Complete.'
    return record_counter


def send_email(body, sender, recipients, subject):
    msg = MIMEText(body)
    msg['From'] = sender
    msg['To'] = ', '.join(recipients)
    msg['Subject'] = subject
    p = subprocess.Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=subprocess.PIPE)
    p.communicate(msg.as_string())


# Send email notification if any error occurred during deserialization
def error_alert(record_counter, src_path, dst_system):
    error_logs = []
    for key_metrics in record_counter:
        if key_metrics.get('error_count') > 0:
            error_logs.append(str(key_metrics['error_count']) + ' errors deserializing ' + src_path)

    if len(error_logs) > 0:
        sender = 'event_modules.Emit_protobuf_enhanced@nerdwallet.com'
        # TODO: update list of recipients
        recipients = ['abayrami@nerdwallet.com', 'dmiddleton@nerdwallet.com']
        subject = src_path + ' deserialization to ' + dst_system + ' caused errors'
        send_email('\n'.join(error_logs), sender, recipients, subject)


def redshift_deserialization(record_counter, dst_bucket, extra_process, pb_class_nm, enhancement_function, choproot, overrides, dst_aws_profile=None):
    """
    Convert all input protobuf files listed in record_counter to json for copying to redshift
    """

    for key_metrics in record_counter:
        if 'local_input_filename' not in key_metrics or 'local_output_filename' not in key_metrics:
            continue

        local_input_filename = key_metrics['local_input_filename']
        local_output_filename = key_metrics['local_output_filename']
        file_output_path = key_metrics['file_output_path']
        s3_output_pathname = key_metrics['s3_output_pathname']
        s3_output_filename = key_metrics['s3_output_filename']

        print('Converting to JSON: {}'.format(local_input_filename))
        print('    Writing to: {}'.format(local_output_filename))

        if extra_process != None:
            extra_process.fileinit(local_output_filename, file_output_path, s3_output_pathname, choproot)

        key_metrics['convert_start_time'] = long(time.time() * 1000.0)
        (read_count, write_count, error_count) = FileParser_pb_to_json(pb_class_nm, local_input_filename, local_output_filename,
                                                                       enhancement_function, overrides, extra_process)
        key_metrics['convert_end_time'] = long(time.time() * 1000.0)
        key_metrics['read_count'] = read_count
        key_metrics['write_count'] = write_count
        key_metrics['error_count'] = error_count

        elapsed_ms = key_metrics['convert_end_time'] - key_metrics['convert_start_time']
        print('    Wrote %d of %d records with %d errors' % (write_count, read_count, error_count))
        if (float(elapsed_ms) / 1000.0) > 0.0:
            print '    Conversion complete: {0:,.1f} recs/sec'.format(float(read_count) / (float(elapsed_ms) / 1000.0))

        if os.path.exists(local_input_filename):
            print('    Deleting ' + local_input_filename)
            os.remove(local_input_filename)

        print('    Uploading to s3://{}/{}'.format(dst_bucket, s3_output_filename))
        key_metrics['upload_start_time'] = long(time.time() * 1000.0)
        mv_to_s3(local_output_filename, s3_output_pathname, dst_bucket, aws_profile=dst_aws_profile)
        key_metrics['upload_end_time'] = long(time.time() * 1000.0)

        if extra_process:
            extra_process.filefinishupload()

        if os.path.exists(local_output_filename):
            print('    Deleting ' + local_output_filename)
            os.remove(local_output_filename)


def get_field_message_type(pb_class_name, field_name):
    """
    Given a ProtoBuf class name and a field name, returns back the name of the message type for that field.
    :param pb_class_name: Name of the ProtoBuf class.
    :param field_name: Field name of the message
    :return: Name of the type of the message. Returns None if the field doesn't exist or if the field isn't a message.
    """
    pb_class = pb_utils.load_class(pb_class_name)
    pb_fields = pb_class.DESCRIPTOR.fields_by_name
    if field_name not in pb_fields:
        return None
    field = pb_fields[field_name]
    if field.type != FieldDescriptor.TYPE_MESSAGE:
        return None
    return field.message_type.name


def global_enrich(pb_class_name):
    """
    Determine if we should apply global enrichment ++ fields to this ProtoBuf class when deserializing it.
    :param pb_class_name: Name of the ProtoBuf class
    :return: True or False, indicating if global ++ fields should be added to this ProtoBuf class when deserializing it.
    """

    # See: https://github.com/NerdWallet/logger.nerdwallet/blob/develop/src/flask_app/controllers/events.py, variable
    # name NONBEHAVIOR_EVENTS.
    blacklist = {
        'BrowserTimingEvent',
        'ExperimentExposureEvent',
        'HeartbeatEvent',
    }
    if pb_class_name in blacklist:
        return False

    header_message_type = get_field_message_type(pb_class_name, 'header')

    if header_message_type is None:
        return False

    if header_message_type == 'EventHeader':
        return True

    return False


def nerdlake_deserialization(record_counter, dst_bucket, dst_path, tablename, local_output_path, compression,
    ovrd_flag, pb_class_nm, enhancement_function, pymodulename, schema_list, overrides, dst_aws_profile=None):
    """
    Convert all input protobuf files listed in record_counter to parquet on nerdlake
    """

    local_input_filenames = [key_metrics['local_input_filename'] for key_metrics in record_counter if 'local_input_filename' in key_metrics]

    if len(local_input_filenames) > 0:
        # Convert to a space delimited string to pass as an argument to PqWriter
        local_input_filenames = ' '.join(local_input_filenames)
    else:
        # No files to deserialize
        return record_counter

    total_metrics = {}
    total_metrics['convert_start_time'] = long(time.time() * 1000.0)

    # Build the Java class name
    java_class_namespace = "event"
    if pb_class_nm == "ABLog":
        java_class_namespace = "ab_server"
    java_class_name = "{0}Proto${0}".format(pb_class_nm)
    java_class_fullname = "{}.{}".format(java_class_namespace, java_class_name)

    (read_count, write_count, error_count, partitions, cols) = run_pqwriter(
        inp_file=local_input_filenames,
        pbuf_javaclass=java_class_fullname,
        pyscript=pymodulename,
        pyenrichfunc=enhancement_function,
        pypqschema=schema_list,
        pyoverrides=overrides,
        compression=compression,
        global_enrich=global_enrich(pb_class_nm)
    )
    total_metrics['convert_end_time'] = long(time.time() * 1000.0)
    total_metrics['read_count'] = read_count
    total_metrics['write_count'] = write_count
    total_metrics['error_count'] = error_count
    total_metrics['partition_count'] = len(partitions)

    for part in sorted(partitions):
        print 'Deserialzed  to: %s' % part

    # upload the partitions to s3.

    total_metrics['upload_start_time'] = long(time.time() * 1000.0)

    for part in sorted(partitions):
        adj_s3_path = dst_path.strip('/') + '/' + part[len(local_output_path):].strip('/')

        if not check_if_key_exist(dst_bucket, adj_s3_path) or ovrd_flag == 'True':
            s3_file_upload(part, dst_bucket, os.path.dirname(adj_s3_path),
                           s3_file_nm=os.path.basename(adj_s3_path), aws_profile=dst_aws_profile)
        print 'Uploaded to: s3://%s/%s' % (dst_bucket, adj_s3_path)

    total_metrics['upload_end_time'] = long(time.time() * 1000.0)

    if len(cols) > 0:
        # eg: s3_output_base = 's3://east1-prod-nerdlake-0/dwnl_stage/PageViewEvent_s
        s3_output_base = 's3://' + os.path.join(dst_bucket, dst_path)
        update_hive_metastore(tablename, s3_output_base, cols, record_counter)

    return [total_metrics]


# Nerdlake's architecture is that we create or update the schema with any new columns.  We also need to tell the hive metastore about any
# new partitions.  We do this only when we've moved data in.
def update_hive_metastore(table_name, s3_output_base, targetcols, record_counter):
    conn = nw_hive.connect()
    hive_table_exists = nw_hive.hive_table_exists(conn, table_name)

    if not hive_table_exists:
        sqlln = ['`{}` {}'.format(col['pqName'], col['hvType']) for col in targetcols if col['pqName'] != 'dw_eff_dt']
        create_sql = "CREATE EXTERNAL TABLE {} (\n{}\n)\nPARTITIONED BY (dw_eff_dt DATE)\nSTORED AS PARQUET\nLOCATION '{}'".format(
            table_name, ',\n'.join(sqlln), s3_output_base)
        print('\n' + create_sql)
        nw_hive.exec_hive_sql_ddl(conn, create_sql)

    hive_columns, hive_partitioned_columns = nw_hive.get_hive_table_column_metadata(conn, table_name)

    # If we have a data type change, Hive won't be able to read both the new and old files. We must restate all history
    # for this event.
    if hive_table_exists:
        hive_col_types = dict()
        for hive_column in hive_columns:
            col_name = hive_column['name']
            col_type = hive_column['type']
            hive_col_types[col_name] = col_type
        type_errors = []
        for pb_col in targetcols:
            if pb_col['pqName'].lower() not in hive_col_types.keys():
                continue
            if pb_col['hvType'].lower() != hive_col_types[pb_col['pqName'].lower()]:
                type_errors.append("Field `{}` data type does not match: Hive={}, Parquet={}".format(
                    pb_col['pqName'].lower(),
                    hive_col_types[pb_col['pqName'].lower()],
                    pb_col['hvType'].lower()))
        if len(type_errors) > 0:
            print("ERROR: Data type change: {}".format(", ".join(type_errors)))
            raise TypeError("Inconsistent data types between Hive and Parquet")

    # Look for new columns and add them to the Hive table
    if hive_table_exists:
        hive_col_names = set()
        for hive_column in hive_columns:
            hive_col_names.add(hive_column['name'])
        cols_to_add = set()
        for pb_col in targetcols:
            if pb_col['pqName'].lower() in hive_col_names:
                continue
            #if pb_col['pqName'] in hive_partitioned_columns:
            #    continue
            alter_sql = 'ALTER TABLE `{}` ADD COLUMNS (`{}` {})'.format(
                table_name, pb_col['pqName'].lower(), pb_col['hvType'])
            print('\n' + alter_sql)
            nw_hive.exec_hive_sql_ddl(conn, alter_sql)

    # Look for new partitions to be added
    output_partitions = dict()
    pb_regex = re.compile(r'^.*/(dw_eff_dt=\d+-\d+-\d+)/[^/]+\.pq$')
    for rec in record_counter:
        output_key = rec['s3_output_filename'].rstrip("/")
        if output_key[-3:].lower() != ".pq":
            continue
        match = pb_regex.match(output_key)
        if not match:
            print("WARNING: {} doesn't look like a Parquet file, ignoring it for partition-creation purposes".format(
                output_key))
            continue

        partition_name = match.group(1)
        pb_directory = s3_output_base.rstrip("/") + "/" + partition_name
        output_partitions[str(partition_name)] = pb_directory

    hive_partitions = nw_hive.get_hive_table_partitions(conn, table_name)
    for partition_name in set(output_partitions.keys()).difference(hive_partitions):
        alter_sql = "ALTER TABLE `{}` ADD PARTITION ( dw_eff_dt='{}' ) LOCATION '{}'".format(
            table_name, partition_name[10:], output_partitions[partition_name])
        print('\n' + alter_sql)
        nw_hive.exec_hive_sql_ddl(conn, alter_sql)

    conn.close()


def run_pqwriter(inp_file, pbuf_javaclass, pyscript=None, pyenrichfunc=None, pypqschema=None, pyoverrides=None, compression='None', maxrecs=None, debuglevel=None, global_enrich=None):
    args = ['nerdwallet.dwh.Pb2PqWriter',
            '--inputfile',     inp_file,
            '--protobufclass', pbuf_javaclass,
            '-compression',    compression]
    if pyscript:
        args.extend(['-pyscript', pyscript])
        if pyenrichfunc:
            args.extend(['-enrichfunc', pyenrichfunc.__name__])
        if pypqschema:
            args.extend(['-pqschema',       json.dumps(pypqschema)])
    if pyoverrides:
        args.extend(['-overrides', json.dumps(pyoverrides)])
    if maxrecs is not None:
        args.extend(['-maxrecs', str(maxrecs)])
    if debuglevel is not None:
        args.extend(['-v', debuglevel])
    if global_enrich is not None:
        args.extend(['-enrichglobal', str(global_enrich)])

    jl_nw   = '/opt/dwh-jarlib/nw'
    jl_inet = '/opt/dwh-jarlib/inet-sourced'
    dependent_jars = [ 'commons-cli-1.3.1.jar',
                       'commons-pool-1.5.4.jar',
                       'elephant-bird-core-4.14.jar',
                       'elephant-bird-hadoop-compat-4.14.jar',
                       'hadoop-lzo-0.4.19.jar',
                       'json-simple-1.1.jar',
                       'libthrift-0.7.0.jar',
                       'parquet-column-1.9.0.jar',
                       'parquet-common-1.9.0.jar',
                       'parquet-encoding-1.9.0.jar',
                       'parquet-format-2.3.1.jar',
                       'parquet-hadoop-1.9.0.jar',
                       'parquet-jackson-1.9.0.jar' ]

    classpath = []
    classpath.append(os.path.join(os.environ['dwh_common_base_dir'], 'nw_java_classes', 'PqWriter.jar'))
    classpath.append(os.path.join(jl_nw, '*'))  # not best practice but avoids naming pbuf 'packages' explicitly
    for p in dependent_jars:
        classpath.append(os.path.join(jl_inet, p))

    output = call_java_hadoopey_jython(args, classpath)

    try:
        stats = json.loads(output)  # if this excepts, it could mean the java program wrote debugging to stdout
    except ValueError:
        print 'Could not decode the json response payload from PqWriter:\n{}'.format(output)
        print 'Did something non-json-ey get emitted?'
        raise RuntimeError("PqWriter wrote non-json in stdout response")

    read_count  = stats['records_in_counted']
    write_count = stats['records_out_counted']
    error_count = stats['records_with_errors']
    partitions  = stats['partitions']
    cols        = stats['columns']

    print "Memory Use (MB): Rss %d RssPeak %d VmSize %d VmSizePeak %d JvmTotal %d JvmMax %d JvmFree %d LastMemstore %d" % (
      stats['JvmLinuxRssMB'], stats['JvmLinuxRssPeakMB'], stats['JvmLinuxVmMB'], stats['JvmLinuxVmPeakMB'],
      stats['JvmReportedTotalMemoryMB'], stats['JvmReportedMaxMemoryMB'], stats['JvmReportedFreeMemoryMB'],
      stats['columns'][0]['memstoreBytes'] / 1024 / 1024 )
    print ""

    pt = PrettyTable([ 'idx', 'pqName', 'pqType', 'hiveType',
                       'pbName', 'pbType',
                       'colPages', 'colRawBytes', 'colCompBytes', 'dictEntries', 'dictRawBytes', 'dictCompBytes', 'rowgroups',
                    ])
    pt.align = 'l'
    pt.padding_width = 0
    for c in stats['columns']:
      pt.add_row([ c['colIdx'] + 1, c['pqName'], c['pqType'], c['hvType'],
                   c['pbName'], c['pbType'],
                   c['colPages'], c['colRawBytes'], c['colCompressedBytes'], c['dictEntries'], c['dictRawBytes'], c['dictCompressedBytes'], c['rowgroups'],
                 ])
      # ddl += c['pqName'] + ' ' + c['hvType'] + ','
    print pt

    #  o.put("maxFieldLength",      ci.maxFieldLength);
    #  o.put("sumFieldLength",      ci.sumFieldLength);
    #  o.put("recordCount",         ci.recordCount); // probably not useful
    #  // badchars
    # memstorebytes from the first column, pull it up the right place.


    # the parquet writer, because it uses hadoop libraries underneath, emits the parquet file using its
    # LocalFileSystem / ChecksumFileSystem classes.  These generate .filename.crc files where we're
    # writing parquet.  (On Hadoop, HDFS handles these checksums under the covers.).  Anyway, we don't
    # upload these to s3 (they're not relevant and won't be checked, even when bringing into EMR), and
    # are removed when the job finishes.

    return (read_count, write_count, error_count, partitions, cols)


def call_java_hadoopey_jython(args, classpath=None):
    """
    Invoke the JVM, in a jython-ish, hadoop-ey environment.
    @param args is a list of the args to the jvm
    @param classpath a list of items to put into the classpath.  Usually you don't want this empty.
    Return:
        One big string of the JVM's stdout
    """
    if args is None or len(args) < 1:
        raise ValueError("you've gotta pass args to call_java_hadoopey_jython(), my friend")

    if classpath is None:
        classpath = {}

    newenviron = copy.deepcopy(os.environ)    # be extra careful I don't mess with anything else

    # set pythonpath include 'blackhole', which is a directory that looks like a dist-packages directory with zero-length package names
    # which cause jython indigestion, typically because they have C dependencies.  what would happen is that, when jython includes a
    # module on sys.path (perhaps something that doesn't even RUN, it just shows up due to an import or some condition we don't use),
    # you will see something like "ImportError: C extension: hashtable not built." exception, as is the case for pandas.  This
    # blackhole directory takes precedence in the jython context to blissfully ignore the module.
    blackhole = os.path.join(newenviron['dwh_common_base_dir'], 'nw_java_classes', 'jython_blackhole')
    newenviron['PYTHONPATH'] = blackhole + os.pathsep + newenviron['PYTHONPATH']

    newenviron['JYTHONPATH'] = newenviron['PYTHONPATH']
    # I don't think I also need to set /data/etl/Common/nw_python_modules since it should already be present

    newenviron['PYTHONDONTWRITEBYTECODE'] = 'True'
    # jython is kind of poopy and likes to write $py.class files around (ex Common/nw_python_modules/event_modules$py.class), and
    # the above doesn't seem to work, fortunately directories in prod are locked down.  ditto with things like
    # /opt/jython2.7/cachedir/packages/zookeeper-3.4.6-tests.pkc, although that's fixed with python.cachedir.skip.  For more info, see:
    #     http://stackoverflow.com/questions/4655454/how-to-control-where-py-class-files-go
    #     http://www.jython.org/docs/library/sys.html sys.dont_write_bytecode
    #     https://mail.python.org/pipermail/jython-checkins/2011-May/000019.html
    #     https://github.com/jythontools/jython/blob/a8e007667205c61678dd7287282f711175ff4277/src/org/python/core/PySystemState.java

    newcp = []
    newcp.append('/opt/jython2.7/jython.jar')
    newcp.extend(classpath)
    newcp.extend(string.rstrip(subprocess.check_output(['hadoop', 'classpath'])).split(os.pathsep))
    newcp.append('/usr/lib/hive/lib/hive-exec.jar')
    newenviron['CLASSPATH'] = os.pathsep.join(newcp)

    runargs = ['/usr/bin/java', '-Djava.library.path=%s/lib/native' % newenviron['HADOOP_HOME'],
                                '-Dpython.cachedir.skip=True' ]
    runargs.extend(args)

    if 1==2:
        print runargs
        print newenviron

    # Run.  I'm using the complex mode so that stderr streams directly back (it's where log4j/slf4j log channels go),
    # but stdout I consume as a string, so that I can parse it and output it.
    try:
        output = subprocess.check_output(runargs, env=newenviron, bufsize = 1024 * 64)
    except subprocess.CalledProcessError as err:
        print 'JVM spawn returned %d :' % err.returncode
        print err.output
        raise RuntimeError('JVM returned %d' % err.returncode)

    return output


def _pb_field_to_redshift_type(pb_field):
    """
    Returns the equivalent Redshift data type for the specified ProtoBuf field.
    :param pb_field: ProtoBuf FieldDescriptor object
    :return: Redshift data type
    """

    # Repeated fields are stored as VARCHAR(MAX). Redshift's COPY command stores repeated objects as a JSON string.
    if pb_field.label == FieldDescriptor.LABEL_REPEATED:
        return 'VARCHAR(MAX)'

    redshift_type = {
        FieldDescriptor.TYPE_DOUBLE:   'FLOAT8',
        FieldDescriptor.TYPE_FLOAT:    'FLOAT4',
        FieldDescriptor.TYPE_INT64:    'BIGINT',
        FieldDescriptor.TYPE_UINT64:   'DECIMAL(20,0)',
        FieldDescriptor.TYPE_INT32:    'INT',
        FieldDescriptor.TYPE_FIXED64:  'BIGINT',
        FieldDescriptor.TYPE_FIXED32:  'INT',
        FieldDescriptor.TYPE_BOOL:     'BOOLEAN',
        FieldDescriptor.TYPE_STRING:   'VARCHAR(MAX)',
        # FieldDescriptor.TYPE_BYTES: Not Supported
        FieldDescriptor.TYPE_UINT32:   'BIGINT',  # Could also be DECIMAL(10,0), but BIGINT should be more efficient
        FieldDescriptor.TYPE_ENUM:     'VARCHAR(255)',
        FieldDescriptor.TYPE_SFIXED32: 'INT',
        FieldDescriptor.TYPE_SFIXED64: 'BIGINT',
        FieldDescriptor.TYPE_SINT32:   'INT',
        FieldDescriptor.TYPE_SINT64:   'BIGINT',
    }
    return redshift_type.get(pb_field.type)


def _parquet_type_to_redshift_type(parquet_type):
    """
    Translates a Parquet type to a Redshift column data type.
    :param pb_type:
    :return:
    """
    redshift_type = {
        'binary': 'VARCHAR(MAX)',
        'boolean': 'BOOLEAN',
        'byte_array': 'VARCHAR(MAX)',  # Not sure how this differs from BINARY; not currently being used
        'float': 'FLOAT4',
        'double': 'FLOAT8',
        'int32': 'INT',
        'int64': 'BIGINT',
        'int96': 'TIMESTAMP',
        # NerdWallet pseudo-types
        'msas': 'VARCHAR(MAX)',
    }
    return redshift_type.get(parquet_type.lower())


def _parquet_field_specs_to_redshift_fields(parquet_field_specs):
    """
    Given a collection of Parquet field definitions, returns a dictionary containing Redshift column names as the keys
    and the Redshift data type as the values.
    :param parquet_field_specs:
    :return:
    """
    table_columns = dict()
    for parquet_field_spec in parquet_field_specs:
        pq_required_flag, pq_data_type, pq_col_name = parquet_field_spec.split(' ', 2)
        not_null = ' NOT NULL' if pq_required_flag.lower() == 'required' else ''
        redshift_type = _parquet_type_to_redshift_type(pq_data_type)
        if not redshift_type:
            sys.stderr.write('WARNING: Enriched field {}: type not supported in Redshift\n'.format(pq_col_name))
            continue
        redshift_col_name = pq_col_name.split(' ')[0]
        table_columns[redshift_col_name] = redshift_type + not_null
    return table_columns


def _get_protobuf_redshift_fields(pb_fields, overrides=None):
    """
    Given a ProtoBuf fields descriptor, returns a dictionary of the Redshift field names as the keys and the Redshift
    data types as the values.
    :param pb_fields:
    :return:
    """
    fieldnames = dict()
    for pb_field in pb_fields:
        if pb_field.message_type:
            fieldnames.update(_get_protobuf_redshift_fields(pb_field.message_type.fields, overrides))
            continue

        redshift_col_name = pb_field.name
        redshift_col_type = _pb_field_to_redshift_type(pb_field)
        if not redshift_col_type:
            sys.stderr.write('WARNING: {}: type not supported in Redshift\n'.format(pb_field.full_name))
            continue

        if pb_field.type in (FieldDescriptor.TYPE_STRING, FieldDescriptor.TYPE_ENUM):
            # We can't use the LABEL_REQUIRED label on ProtoBuf string fields. It's possible to give an empty string
            # as a value and we translate these to NULL in Redshift. We do want to make some string fields NOT NULL so
            # we do this using a hard-coded list. These fields are set by Logger and will never be blank.
            if redshift_col_name.lower() in ('event_ts', 'eventname', 'guid'):
                redshift_col_required = True
            else:
                redshift_col_required = False
        else:
            redshift_col_required = pb_field.label == FieldDescriptor.LABEL_REQUIRED
        if overrides and pb_field.full_name in overrides:
            redshift_col_name = overrides[pb_field.full_name].get('name', redshift_col_name)
            redshift_col_type = overrides[pb_field.full_name].get('redshift_type', redshift_col_type).upper()
            redshift_col_required = overrides[pb_field.full_name].get('required', redshift_col_required)

        col_spec = redshift_col_type
        if redshift_col_required:
            col_spec += ' ' * (12 - len(col_spec))
            col_spec += ' NOT NULL'
        fieldnames[redshift_col_name] = col_spec

    return fieldnames


def protobuf_class_to_redshift_table(pb_class_name, fq_table_name, overrides=None, dist_key=None):
    """
    Given a ProtBuf class name, this function returns the DDL to create a table in Redshift that the data can be loaded
    into.

    :param pb_class_name: Name of the ProtBuf class
    :param fq_table_name: Fully qualified name of the Redshift table i.e., schema.table_name
    :param overrides: Field overrides (e.g., name and type)
    :param dist_key: Distribution key of the Redshift table (optional)
    :return:
    """
    pb_class = pb_utils.load_class(pb_class_name)

    # First retrieve the ProtoBuf fields
    table_columns = _get_protobuf_redshift_fields(pb_class.DESCRIPTOR.fields, overrides=overrides)

    # Next grab the generic enrichment fields
    parquet_field_specs = event_enrichment.get_enriched_parquet_types(pb_class_name)
    table_columns.update(_parquet_field_specs_to_redshift_fields(parquet_field_specs))

    # And finally, grab the event-specific enriched fields
    event_enrich_script = '{scripts_dir}/deserialize_event/{event_name}/pythonscripts/{event_name}.py'.format(
        scripts_dir=os.environ.get('dwh_scripts_base_dir', '/data/etl/Scripts'),
        event_name=pb_class_name
    )
    if os.path.exists(event_enrich_script):
        event_mod = imp.load_source(pb_class_name, event_enrich_script)
        if 'custom_fields' in dir(event_mod):
            table_columns.update(_parquet_field_specs_to_redshift_fields(event_mod.custom_fields))

    # Build a CREATE TABLE statement
    sql_lines = list()
    sql_lines.append('CREATE TABLE {} ('.format(fq_table_name))

    max_col_name_length = max([len(col_name) for col_name in table_columns.keys()])
    for col_name in sorted(table_columns.keys(), key=lambda s: s.lower()):
        sql_lines.append('    "{col_name}"{padding}    {data_type},'.format(
            col_name=col_name,
            padding=' ' * (max_col_name_length - len(col_name)),
            data_type=table_columns[col_name]))

    sql_lines.append('    {col_name: <{max_col_length}}    VARCHAR(255) DEFAULT USER    NOT NULL,'.format(
        col_name='dw_load_user_tx',
        max_col_length=max_col_name_length + 2))
    sql_lines.append('    {col_name: <{max_col_length}}    TIMESTAMP    DEFAULT SYSDATE NOT NULL'.format(
        col_name='dw_load_ts',
        max_col_length=max_col_name_length + 2))
    sql_lines.append(')')
    if dist_key:
        sql_lines.append('DISTKEY ( "{}" )'.format(dist_key))
    elif 'guid' in table_columns:
        sql_lines.append('DISTKEY ( guid )')
    else:
        sql_lines.append('DISTSTYLE EVEN')

    return '\n'.join(sql_lines), sorted(table_columns.keys(), key=lambda s: s.lower())
