import sys
import time
import json
import os.path
import shutil

from s3_modules import get_s3_files_in_range, s3_file_download, mv_to_s3, check_if_key_exist
from file_and_path_utils import FileUtils

sys.path.append('/data/etl/Common/nw_python_modules/json_modules')
import json_utils as json_util


def main():
    """
    Pulls python files from S3 using details specified in a .ctrl file. It then converts all python/json files (format: [{},\n{},...,\n{}]\n) to json (format: {}\n...\n{}\n) that is loadable by Redshift
    and re-uploads to S3.
    Usage: python ccimpression_event.py <source_bucket> <source_path> <task_name> <local_input_path> <local_output_path> <local_archive_path> <destination_bucket> <destination_output_path> <destination_archive_path> <start_date_yyyy-mm-dd> <end_date_yyyy-mm-dd>
    """
    if len(sys.argv) != 13:
        print 'Input %d arguments:\n%s' % (len(sys.argv), str(sys.argv))
        print main.__doc__
        print "Exit."
        return
    print 'Start ...'
    #print 'Input %d arguments:\n%s' % (len(sys.argv), str(sys.argv))
    source_bucket              = sys.argv[1] 
    source_path                = sys.argv[2] 

    task_name                  = sys.argv[3] 

    local_input_path           = sys.argv[4] 
    local_output_path          = sys.argv[5] 
    local_archive_path         = sys.argv[6] 
    
    destination_bucket         = sys.argv[7] 
    destination_path           = sys.argv[8] 
    destination_output_path    = sys.argv[9] 
    destination_archive_path   = sys.argv[10] 

    start_date_time            = sys.argv[11]
    end_date_time              = sys.argv[12]
    print 'Processing json files from s3: %s / %s to s3: %s / %s' % (source_bucket, source_path, destination_bucket, destination_path)
    print 'Running for date range of [%s, %s]' % (start_date_time, end_date_time)

    # Local fs stuff
    FileUtils.create_path(local_input_path)
    FileUtils.create_path(local_output_path)
    FileUtils.create_path(local_archive_path)

    local_batch_filename = os.path.join(local_output_path, task_name) + "_" + time.strftime('%Y_%m_%d_%H_%M') + '.json'
    # local_batch_filename = /data/etl/Data/ccimpression_event/output/ccimpression_event_2015_09_17_09_11.json

    # Main action
    # Download the python files and merged into one json file for loading into Redshift 
    with open(local_batch_filename, 'w') as batch_outfile:
        for key in get_s3_files_in_range('Prod', source_bucket, start_date_time, end_date_time, source_path):
            # key = CCImpressionEvent/2015/09/17/10.json
            print 'Found key at s3: %s / %s' % (source_bucket, key)
            
            s3_dest_file = key.replace(source_path + '/', destination_archive_path)
            # s3_dest_file = ccimpression_event/archive/2015/09/17/10.json
            
            # If output_filename has been downloaded and deserialized, then skip it
            if check_if_key_exist(destination_bucket, s3_dest_file):
                print 'DWH Key already exist at s3: %s / %s' % (destination_bucket, s3_dest_file)
                continue
            #print 'DWH Key is: %s' % s3_dest_file

            s3_subdir = os.path.dirname(s3_dest_file).replace(destination_archive_path, '')
            # s3_subdir=2015/09/17
        
            file_input_path = os.path.join(local_input_path, s3_subdir)
            FileUtils.create_path(file_input_path)
            
            file_archive_path = os.path.join(local_archive_path, s3_subdir)
            FileUtils.create_path(file_archive_path)
            
            # only when key doesn't exist then download from s3 to local
            local_input_filename = s3_file_download(source_bucket, source_path, key, local_input_path, to_file=True)
            # local_input_filename=/data/etl/Data/ccimpression_event/input/2015/09/17/10.json
            print 'Downloaded   to %s' % local_input_filename
            
            # File and path manipulation
            local_archive_filename = local_input_filename.replace(local_input_path, local_archive_path)
            # local_archive_filename=/data/etl/Data/ccimpression_event/archive/2015/09/17/10.json
            
            json_util.json_convert_for_redshift(local_input_filename, local_archive_filename)
            print 'Converted    to %s' % local_archive_filename
            
            with open(local_input_filename, 'rb') as input_file:
                json_rows = json.load(input_file)
                for row in json_rows:
                    json.dump(row, batch_outfile, sort_keys=True, indent=4, ensure_ascii=True)
                    batch_outfile.write('\n')
            
            # Upload the json from local path to destination s3 bucket
            s3_archive_path = os.path.join(destination_archive_path,s3_subdir)
            mv_to_s3(local_archive_filename, s3_archive_path, destination_bucket)
            print 'Uploaded     to s3: %s / %s' % (destination_bucket, os.path.join(s3_archive_path,os.path.basename(local_archive_filename)))
    
    mv_to_s3(local_batch_filename, destination_output_path, destination_bucket)
    print 'Uploaded     from %s to s3: %s / %s' % ( local_batch_filename, destination_bucket, os.path.join(destination_output_path,os.path.basename(local_batch_filename)) )

    # Clean
    #shutil.rmtree(local_input_path)
    #print 'Deleted directory %s' % local_input_path
    #shutil.rmtree(local_output_path)
    #print 'Deleted directory %s' % local_output_path
    #shutil.rmtree(local_archive_path)
    #print 'Deleted directory %s' % local_archive_path
    print 'Complete.'

if __name__ == '__main__':
    main()
