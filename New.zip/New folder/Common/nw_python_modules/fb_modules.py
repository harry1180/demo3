from functools import wraps
import sys
import time

from facebook_business import FacebookSession
from facebook_business import FacebookAdsApi
from facebook_business.adobjects.adreportrun import AdReportRun


TRIES = 10  # Number of tries for FB API call
API_TIMEOUT = 10
MAX_EXEC_TIME = 30*60 # Max time to wait respond with 0%

def get_api(app_id, app_secret, access_token):
    """Return FB API object based on FB credential."""
    ### Setup session and api objects
    session = FacebookSession(
        app_id=app_id, app_secret=app_secret, access_token=access_token)
    api = FacebookAdsApi(session)
    return api


def async_job(func):
    """Decorator for async FB API call function."""
    @wraps(func)
    def func_inner(*args, **kwargs):
        tries_num = 1
        result = None
        while tries_num < TRIES:
            async_job = func(*args, **kwargs)
            try:
                start_tm_try = time.time()
                while True:
                    job = async_job.remote_read()
                    pcnt_exec = job[AdReportRun.Field.async_percent_completion]
                    print("Percent done: " + str(pcnt_exec))
                    if job: # if job success then get out of loop
                        break
                    # if job not success yet, check the time of exec.
                    curr_tm_exec = time.time()
                    if curr_tm_exec - start_tm_try > MAX_EXEC_TIME:
                        raise ValueError("Time of execution exceeded {} sec.".format(str(MAX_EXEC_TIME)))
                    time.sleep(API_TIMEOUT)
                time.sleep(2)
                result = async_job.get_result()
                break  # if job done
            except Exception as e:
                print str(e)
                print 'FB API call failed. Trying again {} times'.format(
                    str(tries_num))
                tries_num += 1
        return result

    return func_inner


def get_accounts(fb_user, fields=None):
    """Retrieve and display a list of the user ad accounts for AdUser object."""
    return fb_user.get_ad_accounts(fields=fields)


@async_job
def get_insights(account, params=None):
    """Return iterable of campaign insights for AdAccount object based on params"""
    if not params:
        print "Error, please pass 'params' to get_insights function"
        sys.exit(1)
    result = account.get_insights(params=params, is_async=True)
    return result


def to_dict(fb_api_data, fields):
    """Retrieve data for fileds from FB API results and return as list of dicts"""
    dict_list = []
    for d in fb_api_data:
        obj = dict()
        for field in fields:
            if field in d.__dict__['_json']:
                obj[field] = d.__dict__['_json'][field]
        dict_list.append(obj)
    return dict_list
