#/usr/bin/python
"""Create steps sql and DQ files based on config json file.

use "python create_scd_steps.py --help" for more information
"""
import argparse
import json
import os
import sys


def mk_step1(schema_work, schema_tgt, tbl_work, tbl_tgt, tgt_col_list,
             logical_key_col_list, output_file_path, fn):
    """Create sql file for step 1 and save it in output_file_path dir."""
    # Template
    sql = """
          INSERT INTO {schema_tgt}.{tbl_tgt}
          (
           {tgt_col_list}
          )
          SELECT
           {src_col_list}
          FROM {schema_work}.{tbl_work} w
          WHERE NOT EXISTS
          (SELECT 1 FROM {schema_tgt}.{tbl_tgt} d WHERE {where_sql} );
         """

    # Get params
    tgt_cols_sql = '\n           ,'.join(tgt_col_list)
    src_cols_sql = '\n           ,'.join(['w.' + col for col in tgt_col_list])
    where_sql = '\nAND '.join(
        ['w.{key} = d.{key}'.format(key=key) for key in logical_key_col_list])

    # Generate SQL
    sql_step = sql.format(
        schema_tgt=schema_tgt,
        schema_work=schema_work,
        tbl_tgt=tbl_tgt,
        tbl_work=tbl_work,
        tgt_col_list=tgt_cols_sql,
        src_col_list=src_cols_sql,
        where_sql=where_sql)

    # Save sql file
    with open(os.path.join(output_file_path, fn), 'wb') as sql_file:
        sql_file.write(sql_step)
    print 'File {} saved in to the {}.'.format(fn, output_file_path)


def mk_step2(schema_work, schema_tgt, tbl_work, tbl_tgt, scd_col_compare_list,
             logical_key_col_list, output_file_path, fn):
    """Create sql file for step 2 and save it in output_file_path dir."""
    # Template
    sql = """
          UPDATE {schema_tgt}.{tbl_tgt}
          SET dw_expr_dt      = trunc(SYSDATE) - 1,
              curr_in         = 0,
              dw_last_updt_ts = SYSDATE,
              dw_last_updt_tx = 'Update expire existing'
          FROM {schema_work}.{tbl_work} w
          WHERE {where_sql}
          AND {schema_tgt}.{tbl_tgt}.curr_in = 1
          AND (
               {scd_col_compare_sql}
               OR COALESCE({schema_tgt}.{tbl_tgt}.del_in, 0) = 1);
         """

    # Get params
    where_sql = '\nAND '.join(['w.{key} = {schema_tgt}.{tbl_tgt}.{key}'.format(
        schema_tgt=schema_tgt, tbl_tgt=tbl_tgt, key=key)
                               for key in logical_key_col_list])

    key_list = []
    for key in scd_col_compare_list:
        key_list.append(
            "COALESCE({schema_tgt}.{tbl_tgt}.{compare_key},'{default_val}') <> \
                         COALESCE(w.{compare_key},'{default_val}')".format(
                schema_tgt=schema_tgt,
                tbl_tgt=tbl_tgt,
                compare_key=key,
                default_val='0' if not key.endswith('_dt') else '9999-12-31'))
    scd_col_compare_sql = '\n               OR '.join(key_list)

    # Generate SQL
    sql_step2 = sql.format(
        schema_tgt=schema_tgt,
        schema_work=schema_work,
        tbl_tgt=tbl_tgt,
        tbl_work=tbl_work,
        scd_col_compare_sql=scd_col_compare_sql,
        where_sql=where_sql)

    # Save sql file
    with open(os.path.join(output_file_path, fn), 'wb') as sql_file:
        sql_file.write(sql_step2)
    print 'File {} saved in to the {}.'.format(fn, output_file_path)


def mk_step3(schema_work, schema_tgt, tbl_work, tbl_tgt, tgt_col_list,
             scd_col_compare_list, logical_key_col_list, dw_sys_col_list,
             output_file_path, fn):
    """Create sql file for step 3 and save it in output_file_path dir."""

    # Template
    sql = """
         INSERT INTO {schema_tgt}.{tbl_tgt}
          (
           {tgt_cols_sql}
          )
          SELECT
           {src_cols_sql}
          FROM {schema_work}.{tbl_work} w
          INNER JOIN
          (
            SELECT *
            FROM
            (
              SELECT *
              , row_number() over(partition BY {logical_key_col_sql} ORDER BY dw_load_ts DESC) AS dedup_flag
              FROM {schema_tgt}.{tbl_tgt} d
            ) sub
            WHERE dedup_flag = 1
          ) tgt
          ON
             {on_sql}
          WHERE (
                --inserting changed record
            (
                    {scd_col_compare_sql}
            )
                -- inserting deleted record
                OR COALESCE(tgt.del_in,0) = 1
            );
         """

    # Get params
    col_list = []
    for col in tgt_col_list:
        col_list.append('{}'.format(col))
    tgt_cols_sql = '\n           ,'.join(col_list)

    src_col_list = []
    for col in tgt_col_list:
        if col in dw_sys_col_list:
            src_col_list.append(dw_sys_col_list[col] + ' AS ' + col)
        else:
            src_col_list.append('w.' + col)
    src_cols_sql = '\n           ,'.join(src_col_list)

    on_sql = '\nAND '.join(['w.{key} = tgt.{key}'.format(key=key)
                            for key in logical_key_col_list])

    key_list = []
    for key in scd_col_compare_list:
        key_list.append("COALESCE(tgt.{compare_key},'{default_val}') <> \
                         COALESCE(w.{compare_key},'{default_val}')".format(
            schema_tgt=schema_tgt,
            tbl_tgt=tbl_tgt,
            compare_key=key,
            default_val='0' if not key.endswith('_dt') else '9999-12-31'))
    scd_col_compare_sql = '\n               OR '.join(key_list)

    # Generate SQL
    sql_step2 = sql.format(
        schema_tgt=schema_tgt,
        schema_work=schema_work,
        tbl_tgt=tbl_tgt,
        tbl_work=tbl_work,
        tgt_cols_sql=tgt_cols_sql,
        src_cols_sql=src_cols_sql,
        logical_key_col_sql=', '.join(logical_key_col_list),
        scd_col_compare_sql=scd_col_compare_sql,
        on_sql=on_sql)

    # Save sql file
    with open(os.path.join(output_file_path, fn), 'wb') as sql_file:
        sql_file.write(sql_step2)
    print 'File {} saved in to the {}.'.format(fn, output_file_path)


def mk_step4(schema_work, schema_tgt, tbl_work, tbl_tgt, logical_key_col_list,
             output_file_path, fn):
    """Create sql file for step 4 and save it in output_file_path dir."""

    # Template
    sql = """
          UPDATE {schema_tgt}.{tbl_tgt}
          SET dw_expr_dt      = trunc(SYSDATE) - 1,
              curr_in         = 0,
              dw_last_updt_ts = SYSDATE,
              dw_last_updt_tx = 'Update expire deleted'
          FROM
          (
          SELECT temp_prod.*,
            s.{logical_key} AS record_exists
          FROM
          (
            SELECT MAX(dw_load_ts) AS dw_load_ts,
                {logical_key}
            FROM {schema_tgt}.{tbl_tgt}
            GROUP BY 2
          ) temp_prod
          LEFT OUTER JOIN {schema_work}.{tbl_work} s ON s.{logical_key} = temp_prod.{logical_key}
          ) filtered_records
          WHERE filtered_records.record_exists IS NULL
          AND   {schema_tgt}.{tbl_tgt}.{logical_key} = filtered_records.{logical_key}
          AND   {schema_tgt}.{tbl_tgt}.dw_load_ts =  filtered_records.dw_load_ts
          AND   {schema_tgt}.{tbl_tgt}.curr_in    =  1
          AND   {schema_tgt}.{tbl_tgt}.del_in     <> 1
        ;
         """

    sql_step4 = sql.format(
        schema_tgt=schema_tgt,
        schema_work=schema_work,
        tbl_tgt=tbl_tgt,
        tbl_work=tbl_work,
        logical_key=logical_key_col_list[0])

    # Save sql file
    with open(os.path.join(output_file_path, fn), 'wb') as sql_file:
        sql_file.write(sql_step4)
    print 'File {} saved in to the {}.'.format(fn, output_file_path)


def mk_step5(schema_work, schema_tgt, tbl_work, tbl_tgt, tgt_col_list,
             logical_key_col_list, output_file_path, fn):
    """Create sql file for step 5 and save it in output_file_path dir."""

    # Template
    sql = """
         INSERT INTO {schema_tgt}.{tbl_tgt}
          (
           {tgt_cols_sql}
          )
          SELECT
           {src_cols_sql}
        FROM
        (
        SELECT t.*
        FROM {schema_tgt}.{tbl_tgt} t,
        (
            SELECT temp_prod.*,
                s.{logical_key} AS record_exists
            FROM
            (
            SELECT MAX(dw_load_ts) AS dw_load_ts,
                    {logical_key}
            FROM {schema_tgt}.{tbl_tgt}
            GROUP BY 2
        ) temp_prod
        LEFT OUTER JOIN {schema_work}.{tbl_work} s ON s.{logical_key}= temp_prod.{logical_key}
        ) filtered_records
        WHERE filtered_records.record_exists IS NULL
        AND   t.{logical_key}  = filtered_records.{logical_key}
        AND   t.dw_load_ts = filtered_records.dw_load_ts
        AND   t.curr_in    = 0
        AND   t.del_in     = 0
        );
         """

    # Get params
    col_list = []
    for col in tgt_col_list:
        col_list.append('{}'.format(col))
    tgt_cols_sql = '\n           ,'.join(col_list)

    src_col_list = []
    for col in tgt_col_list:
        if col in dw_sys_col_list:
            if col == 'del_in':
                col_val = '1'
            else:
                col_val = dw_sys_col_list[col]
            src_col_list.append(col_val + ' AS ' + col)
        else:
            src_col_list.append(col)
    src_cols_sql = '\n           ,'.join(src_col_list)

    # Generate SQL
    sql_step5 = sql.format(
        schema_tgt=schema_tgt,
        schema_work=schema_work,
        tbl_tgt=tbl_tgt,
        tbl_work=tbl_work,
        tgt_cols_sql=tgt_cols_sql,
        src_cols_sql=src_cols_sql,
        logical_key=logical_key_col_list[0])

    # Save sql file
    with open(os.path.join(output_file_path, fn), 'wb') as sql_file:
        sql_file.write(sql_step5)
    print 'File {} saved in to the {}.'.format(fn, output_file_path)


def mk_dq_camp(tbl_tgt, logical_key_col_list, output_file_path, fn):
    """Create json file for DQ SCD and save it in output_file_path dir."""

    # Template
    jtext = """
    "DQ_Job_Name": "{tbl_tgt} Load",
    "DQ_Job_Group_Level1": "Marketing {tbl_tgt}",
    "DQ_Job_Group_Level2": "Horizontal",
    "DQ_Job_Group_Level3": "Marketing",
    "DQ_Job_Desc": "Verify Dimension data - SCD",
    "Email_TO": "marketing-analytics@nerdwallet.com,analytics@nerdwallet.com,jyoo@nerdwallet.com,ssundara@nerdwallet.com,cwhittle@nerdwallet.com",
    "Email_CC": "",
    "Email_FROM": "dwh-dq@nerdwallet.com",
    "Fail_On_Error": "Yes",
    "DQ_Query": "SELECT
                    {logical_keys_sql}, count(*), 'FAILURE' dq_status
                    FROM
                    {tbl_tgt}
                    WHERE
                    curr_in = 1
                    GROUP BY
                    {logical_keys_sql}
                    HAVING
                    count(*) >1;"
    """

    # Generate SQL
    jtext_dq_camp = jtext.format(
        tbl_tgt=tbl_tgt, logical_keys_sql=', '.join(logical_key_col_list))
    jtext_dq_camp = '{\n' + jtext_dq_camp + '\n}'

    # Save json file
    with open(os.path.join(output_file_path, fn), 'wb') as jfile:
        jfile.write(jtext_dq_camp)
    print 'File {} saved in to the {}.'.format(fn, output_file_path)


def mk_data_availability(schema_tgt, tbl_tgt, output_file_path, fn):
    """Create json file for DQ of data availability and save it in output_file_path dir."""

    # Template
    jtext = """
    "DQ_Job_Name": "{schema_tgt}.{tbl_tgt}",
    "DQ_Job_Group_Level1": "{tbl_tgt}",
    "DQ_Job_Group_Level2": "Vertical",
    "DQ_Job_Group_Level3": "Marketing - Campaign spent data $$ ",
            "DQ_Job_Desc": "Data Availability in {schema_tgt}.{tbl_tgt}",
    "Email_TO": "marketing-analytics@nerdwallet.com,analytics@nerdwallet.com,ssundara@nerdwallet.com,jyoo@nerdwallet.com",
    "Email_CC": "",
    "Email_FROM": "dwh-dq@nerdwallet.com",
    "Fail_On_Error": "Yes",
    "DQ_Query": "
        SELECT
            '{tbl_tgt}' Data_Source,
            cal.cal_dt,
            fact.cnt,
            CASE
                WHEN
                    COALESCE(fact.cnt,0) > 0
                THEN
                    'SUCCESS'
                ELSE
                    'WARNING'
                END
                    dq_status
        FROM
            (SELECT
                *
            FROM
                dw_report.dw_date_d
            WHERE
                cal_dt between
                  (SELECT
                     MIN(dw_eff_dt)
                   FROM
                     {tbl_tgt})
                   AND
                   (SELECT
                      MAX(dw_eff_dt)
                    FROM
                      {tbl_tgt})
            ) cal
            LEFT JOIN
                (SELECT
                    dw_eff_dt, COUNT(1) cnt
                FROM
                    {schema_tgt}.{tbl_tgt}
                GROUP BY 1
                ) fact
            ON
                cal.cal_dt = fact.dw_eff_dt
        ORDER BY
            cal.cal_dt DESC ;
        "
    """

    # Generate SQL
    jtext_dq = jtext.format(schema_tgt=schema_tgt, tbl_tgt=tbl_tgt)
    jtext_dq = '{\n' + jtext_dq + '\n}'

    # save json file
    with open(os.path.join(output_file_path, fn), 'wb') as jfile:
        jfile.write(jtext_dq)
    print 'File {} saved in to the {}.'.format(fn, output_file_path)


if __name__ == '__main__':

    desc = """
            Example of config json file:
            {
                "dim": {
                    "work_schema": "dw_stage",
                    "tgt_schema": "dw_report",
                    "work_tbl": "mktg_taboola_campaign_w",
                    "tgt_tbl": "mktg_taboola_campaign_d",
                    "tgt_col_list": [
                        "ext_customer_id",
                        "advertiser_id",
                        "is_active_in",
                        "status_cd",
                        "curr_in",
                        "del_in",
                        "dw_expr_dt",
                        "dw_load_ts"
                    ],
                    "logical_key_col_list": ["campaign_id"],
                    "scd_col_compare_list": [
                        "campaign_nm",
                        "ext_customer_id",
                        "is_active_in",
                        "status_cd"
                    ],
                    "dw_sys_col_list": {
                        "curr_in": "1",
                        "del_in": "0",
                        "dw_expr_dt": "TO_DATE('9999-12-31','YYYY-MM-DD')",
                        "dw_load_ts": "SYSDATE"
                    },
                    "output_file_path": "~/codegen/",
                    "step1_fn": "_insert_new.sql",
                    "step2_fn": "_update_expr.sql",
                    "step3_fn": "_insert_existing.sql",
                    "step4_fn": "_update_deleted.sql",
                    "step5_fn": "_insert_deleted.sql",
                    "dq_camp_fn": "_dq.json"
                },
                "events":{
                    "tgt_tbl": "mktg_taboola_campaign_perf_f",
                    "dq_data_availability_fn": "_data_availability.json"
                }
            }
            """
    parser = argparse.ArgumentParser(
        description=desc,
        usage='python %(prog)s --config=config.json',
        formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument(
        '-c',
        '--config_file',
        required=True,
        action='store',
        dest='config_file',
        help='Config json file')
    args = parser.parse_args()

    # Read config file
    try:
        with open(args.config_file) as config_file:
            CONFIG = json.load(config_file)
    except Exception, e:
        print "Error: can not open config file {}".format(args.config_file)
        print str(e)
        sys.exit(1)

    # Setup vars
    schema_work = CONFIG['dim']['work_schema']
    schema_tgt = CONFIG['dim']['tgt_schema']
    tbl_work = CONFIG['dim']['work_tbl']
    tbl_tgt = CONFIG['dim']['tgt_tbl']

    tgt_col_list = CONFIG['dim']['tgt_col_list']
    logical_key_col_list = CONFIG['dim']['logical_key_col_list']
    scd_col_compare_list = CONFIG['dim']['scd_col_compare_list']
    dw_sys_col_list = CONFIG['dim']['dw_sys_col_list']
    output_file_path = os.path.expanduser(CONFIG['dim']['output_file_path'])

    # Create sqlfile
    mk_step1(
        schema_work=schema_work,
        schema_tgt=schema_tgt,
        tbl_work=tbl_work,
        tbl_tgt=tbl_tgt,
        tgt_col_list=tgt_col_list,
        logical_key_col_list=logical_key_col_list,
        output_file_path=output_file_path,
        fn='step1_' + tbl_tgt + CONFIG['dim']['step1_fn'])

    mk_step2(
        schema_work=schema_work,
        schema_tgt=schema_tgt,
        tbl_work=tbl_work,
        tbl_tgt=tbl_tgt,
        scd_col_compare_list=scd_col_compare_list,
        logical_key_col_list=logical_key_col_list,
        output_file_path=output_file_path,
        fn='step2_' + tbl_tgt + CONFIG['dim']['step2_fn'])

    mk_step3(
        schema_work=schema_work,
        schema_tgt=schema_tgt,
        tbl_work=tbl_work,
        tbl_tgt=tbl_tgt,
        tgt_col_list=tgt_col_list,
        scd_col_compare_list=scd_col_compare_list,
        logical_key_col_list=logical_key_col_list,
        dw_sys_col_list=dw_sys_col_list,
        output_file_path=output_file_path,
        fn='step3_' + tbl_tgt + CONFIG['dim']['step3_fn'])

    mk_step4(
        schema_work=schema_work,
        schema_tgt=schema_tgt,
        tbl_work=tbl_work,
        tbl_tgt=tbl_tgt,
        logical_key_col_list=logical_key_col_list,
        output_file_path=output_file_path,
        fn='step4_' + tbl_tgt + CONFIG['dim']['step4_fn'])

    mk_step5(
        schema_work=schema_work,
        schema_tgt=schema_tgt,
        tbl_work=tbl_work,
        tbl_tgt=tbl_tgt,
        tgt_col_list=tgt_col_list,
        logical_key_col_list=logical_key_col_list,
        output_file_path=output_file_path,
        fn='step5_' + tbl_tgt + CONFIG['dim']['step5_fn'])

    mk_dq_camp(
        tbl_tgt=tbl_tgt,
        logical_key_col_list=logical_key_col_list,
        output_file_path=output_file_path,
        fn=tbl_tgt + CONFIG['dim']['dq_camp_fn'])

    mk_data_availability(
        schema_tgt=schema_tgt,
        tbl_tgt=CONFIG['events']['tgt_tbl'],
        output_file_path=output_file_path, fn=CONFIG['events']['tgt_tbl'] +
        CONFIG['events']['dq_data_availability_fn'])
