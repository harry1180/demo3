import requests
from time import strftime, gmtime
import time
import json


user = 'mozscape-b509f513cb'

def verify_semrush_key(sr_key, expected_use = 100):
    """ This function returns a semrush key that has balance > expected use.
    If the number of expected API units is not specified, it tries for 100 API units
    call method: get_semrush_key(expected_use) """

    # url to check API unit balance
    url = 'http://www.semrush.com/users/countapiunits.html?key={}'.format(str(sr_key))
    response = requests.get(url, allow_redirects=True, timeout=1000, stream=True)
    try:
        api_units_balance = int(response.text)
        if api_units_balance > expected_use:
            return True
        else:
            return False
    except:
        return False


def moz_url_metrics_fetch(link_tx,password):
    """ Use this fucntion to call get Moz URL metrices
    This fucntion returns the json response from Moz.
    call method: moz_url_metrics(url)"""

    url_base ='http://lsapi.seomoz.com/linkscape/url-metrics/'+ str(link_tx) \
    + '?Cols=182537206068412413&AccessID=mozscape-b509f513cb&Signature=d9745f9dbacb42b991a5de0350f641c&Expires='
    # Cols=182537206068412413, equates to 56 columns listed below:
    #keys = ['fed','feid','fejp','fejr','fem','ffb','fg+','fid','fipl','fjp','fjr',
    #        'flan','fmrp','fmrr','fspf','fsplc','fspp','fsps','fspsc','ftrp','ftrr',
    #        'ftw','fuid','pda','ped','peid','pejp','pejr','pib','pid','pjp','pjr',
    #        'pmrp','pmrr','ptrp','ptrr','puid','ued','ueid','uemrp','uemrr',
    #        'ufq','uid','uifq','uipl','ujid','ulc','umrp','umrr','upa','upl',
    #        'us','ut','utrp','utrr','uu']
 
    sesstime= str(int(time.time())+300)
    url = url_base + sesstime
    print url

    attempts = 0
    while attempts < 3:
        try:
            r = requests.get(url, auth=(user, password))
            a = json.loads(r.text)
            break
        except Exception as e:
            attempts += 1
            print("Error: {}".format(e))
            print("Sleeping for 60 seconds")
            time.sleep(60)
            print("Retrying attempt {} of 3".format(str(attempts)))
    try:
        da = str(a["pda"])
    except:
        da = ''
    return a #[link_tx,da , r.text]

def generate_organic_results_url(kw,key_input,display_limit=0,display_offset=0):
     """Call the generate_organic_result_url by passing keyword,semrush key, display limit, display offset.
     This data is assumed to be sorted on seo result position desc
     call method: generate_organic_results_url(kw,key_input,display_limit=0,display_offset=0) """

     url_base = 'http://api.semrush.com/'
     display_date = strftime("%Y%m%d", gmtime())  # current date to set as data as of date
     key=key_input
     #display_filter= '%2B%7CCp%7CGt%7C0'
     # selecting 2 columns, url and url domain
     export_columns='Ur,Dn'
     #display_sort='tr_desc' # traffic decc
     database='us' # 
     report_type='phrase_organic'
     url=url_base+'?type='+report_type
     url+= '&key='+key
     url+='&display_limit='+str(display_limit)
     url+='&export_columns='+export_columns
     url+='&phrase='+kw   
     #url+='&display_sort='+display_sort
     url+='&database='+database
     #url+='&display_offset='+str(display_offset)
     return url


def generate_semrush_url(report_type, kw, key_input, export_columns, database='us', display_limit=0):
    """
    This function generates a semrush api URL by passing:
    :param report_type: name of endpoint
    :param kw: specific keyword
    :param key_input: API key
    :param export_columns: comma separated string of columns
    :param database: semrush database to return results from
    :param display_limit: max number of rows to return, default all rows
    :return: str, url to call semrush API with
    """

    url_base = 'http://api.semrush.com/'
    url = '{0}?type={1}&key={2}&display_limit={3}&export_columns={4}&phrase={5}&database={6}'.format(url_base,
                                                                                                     report_type,
                                                                                                     key_input,
                                                                                                     str(display_limit),
                                                                                                     export_columns,
                                                                                                     kw,
                                                                                                     database)
    return url

def moz_url_metrics_parser(json_in):
    """Use this method to convert json output from Moz Url Metrics call: moz_url_metrics(link_tx). 
    This function returns directotry with columns listed in the keys dictionary 
    in that order. Call method: moz_url_metrics_parser(json_in)"""

    keys = ['fed','feid','fejp','fejr','fem','ffb','fg+','fid','fipl','fjp','fjr',
            'flan','fmrp','fmrr','fspf','fsplc','fspp','fsps','fspsc','ftrp','ftrr',
            'ftw','fuid','pda','ped','peid','pejp','pejr','pib','pid','pjp','pjr',
            'pmrp','pmrr','ptrp','ptrr','puid','ued','ueid','uemrp','uemrr',
            'ufq','uid','uifq','uipl','ujid','ulc','umrp','umrr','upa','upl',
            'us','ut','utrp','utrr','uu']
    row=[]
    for key in keys:
        try:
            #row.append(str(json_in[key]).replace(u'\u2019', u'\'').encode('ascii', 'ignore'))
            row.append(str(json_in[key]).replace(u'\u2019', u'\'').replace('\n','').replace('\t','').replace('\r','').encode('ascii', 'ignore'))
        except:
            row.append('')
    return row

