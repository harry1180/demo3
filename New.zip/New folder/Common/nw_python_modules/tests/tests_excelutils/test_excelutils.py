import json
import os
import unittest

from excelutils import excel2json


INPUT_EXCEL = 'test_excel.xlsx'
OUTPUT_JSON = 'test_json.json'
TRUTH_JSON = 'test_json_truth.json'


class Excel2json(unittest.TestCase):

    def test_excel2json(self):
        """
        Test excel2json method
        """

        input_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), INPUT_EXCEL)
        output_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), OUTPUT_JSON)
        truth_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), TRUTH_JSON)

        # clean up output file if exists
        if os.path.isfile(output_file):
            os.remove(output_file)

        # convert to json
        excel2json(input_file, output_file)

        # compare with truth
        f_truth_list = []
        with open(truth_file) as f_truth:
            for t_row in f_truth:
                f_truth_list.append(json.loads(t_row.strip()))

        f_output_list = []
        with open(output_file) as f_output:
            for o_row in f_output:
                f_output_list.append(json.loads(o_row.strip()))

        self.assertEqual(f_truth_list, f_output_list)

        # clean up output file if exists
        if os.path.isfile(output_file):
            os.remove(output_file)



if __name__ == '__main__':
    unittest.main()
