import requests
import unittest

from nw_retry import nw_retry, REQUEST_EXCEPTIONS


@nw_retry(Exception, tries=3, delay=1, backoff=1)
def retry_fail():
    raise Exception


@nw_retry(Exception, tries=3, delay=1, backoff=1)
def retry_success():
    return True


@nw_retry(REQUEST_EXCEPTIONS, tries=3, delay=1, backoff=1)
def retry_api(api_url):
    r = requests.get(api_url)
    r.raise_for_status()
    return True


class RetryTest(unittest.TestCase):
    """
    Test Cases for nw_retry decorator
    """


    def test_exception_retry_fail(self):
        """
        Test retry with generic Exception
        """
        self.assertRaises(Exception, lambda: retry_fail())


    def test_exception_retry_success(self):
        """
        Test retry with generic Exception
        """
        self.assertTrue(retry_success())


class RetryApiTest(unittest.TestCase):
    """
    Test Cases for nw_retry decorator using request exceptions
    """
    def test_api_retry_connection_error(self):
        """
        Malformed URL to simulate HTTP Connection Error.
        Decorator will retry and ultimately raise Exception.
            Correct URL: "http://httpstat.us/200"
            Malformed URL: "http://httpstat/200"
        """
        self.assertRaises(REQUEST_EXCEPTIONS, lambda: retry_api('http://httpstat/200'))


    def test_api_retry_200_success(self):
        """
        Test api retry with 200 response code: OK
        """
        self.assertTrue(retry_api('http://httpstat.us/200'))


    def test_api_retry_400_fail(self):
        """
        Test api retry with 400 response code: Bad Request
        """
        self.assertRaises(REQUEST_EXCEPTIONS, lambda: retry_api('http://httpstat.us/400'))


    def test_api_retry_500_fail(self):
        """
        Test api retry with 500 response code: Internal Server Error
        """
        self.assertRaises(REQUEST_EXCEPTIONS, lambda: retry_api('http://httpstat.us/500'))


if __name__ == '__main__':
    unittest.main()
