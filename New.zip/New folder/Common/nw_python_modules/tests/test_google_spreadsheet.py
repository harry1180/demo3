import unittest

import google_spreadsheet as gs
from redshift_modules import exec_query


URL = 'https://docs.google.com/spreadsheets/d/1Z8tnsqZOOFRUmdd-PoGNc1edPkHzA-GuYtyt-TLGMJ4/edit#gid=0'
SCHEMA = 'dw_bkup'
TABLE = 'google_unicode_test'

S3_BUCKET = 'east1-prod-dwh-s3-0'
S3_PATH = 'google_spreadsheet_upload'

class GoogleSpreadsheetTest(unittest.TestCase):

    def test_read(self):
        """
        Test read method
        """
        expected_results = [[u'column_1', u'column_2', u'column_3', u'column_4', u'column_5'],
                            [u'test', u't\xeast', u'', u'123', u'abc'],
                            [u'test', u't\u0119st', u'xxx', u'456']]

        spreadsheet = gs.GoogleSpreadsheet(URL)
        self.assertEqual(spreadsheet.read('Sheet1'), expected_results, 'Read results do not equal expected results')


    def test_worksheet_exists(self):
        """
        Test sheet_exists method
        """
        worksheet = 'Sheet1'
        spreadsheet = gs.GoogleSpreadsheet(URL)
        self.assertTrue(spreadsheet.sheet_exists(worksheet))


class GsToTableTest(unittest.TestCase):

    def test_gs_to_table(self):
        """
        Test gs_to_table function
        """

        # delete contents from table to ensure a clean load each time
        delete_query = 'delete from {schema}.{table}'.format(schema=SCHEMA, table=TABLE)
        exec_query(delete_query)

        # load contents to table
        gs.gs_to_table(URL, schema=SCHEMA, table=TABLE, worksheet='Sheet1', file_out_dir='/Users/jportwood/dwh/Data',
                       remove_fields=['column_3'], s3_bucket=S3_BUCKET, s3_path=S3_PATH)


        expected_results = [{'column_5': 'abc', 'column_4': '123', 'column_2': 't\xc3\xaast', 'column_1': 'test'},
                            {'column_5': None, 'column_4': '456', 'column_2': 't\xc4\x99st', 'column_1': 'test'}]
        table_contents = exec_query('SELECT * FROM {}.{}'.format(SCHEMA, TABLE))

        self.assertEqual(sorted(table_contents, key=lambda k: k['column_4']),
                         sorted(expected_results, key=lambda k: k['column_4']))


if __name__ == '__main__':
    unittest.main()
