import gspread
import json

from oauth2client.client import SignedJwtAssertionCredentials

def login():
    ######return(gspread.login("analytics-google-docs-apiid@nerdwallet.com","33U5EPt2"))
    json_key = json.load(open('/data/etl/Common/nw_python_modules/google_login.json'))
    scope = ['https://spreadsheets.google.com/feeds']
    credentials = SignedJwtAssertionCredentials(json_key['client_email'], json_key['private_key'], scope)
    return(gspread.authorize(credentials))
