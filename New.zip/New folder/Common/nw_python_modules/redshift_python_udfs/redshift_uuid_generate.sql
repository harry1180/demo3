CREATE or replace FUNCTION f_str_uuid()
/* returns a unique id based on clock time and the server we are calling from */
RETURNS varchar
VOLATILE AS $$
import uuid
return str(uuid.uuid1())
$$ LANGUAGE plpythonu;