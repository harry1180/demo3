-- Drop the udf 
DROP FUNCTION f_parseurl(url varchar(max));
-- Create udf 
-- Returns a delimited '$' string (urlPath$Scheme$Type$Domain)
CREATE FUNCTION f_parseurl(url varchar(max))
RETURNS varchar(max)
IMMUTABLE AS $$
import urlparse
import re

url = url.strip()
reg = re.compile('cdn.ampproject.org(/.){1,3}/')
isAmpURL = False
if 'ampproject' in url:
    url = reg.sub("",url)
    isAmpURL = True
    
# Parse out the url
parsed_url = urlparse.urlparse(url)
# Dict to hold required values
req_attr = {}
    
# Check if any of the attributes of the url
# are None.... Replace with N/A
req_attr["scheme"] = "N/A" if parsed_url.scheme is None else parsed_url.scheme
req_attr["hostname"] = "N/A" if parsed_url.hostname is None else (parsed_url.hostname).replace('www.','')
req_attr["path"] = "N/A" if parsed_url.path is None or parsed_url.path == '/' or parsed_url.path.strip() == '' else (parsed_url.path).lower()
req_attr["type"] = "Desktop"
    
if isAmpURL:
    req_attr["path"] = (req_attr["path"]).replace('.amp','')
    if (req_attr["path"])[-4:] == '/amp':
        req_attr["path"] = (req_attr["path"])[:-4]
    if '/amp/' in req_attr["path"]:
        req_attr["path"] = (req_attr["path"]).replace('/amp','')
    req_attr["hostname"] = (req_attr["hostname"]).replace('amp.','')        
    
if req_attr["hostname"][:2] == 'm.':
    req_attr["type"] = "Mobile"
    req_attr["hostname"] = req_attr["hostname"].replace('m.','')
            
# return a delimited string consisting of parsed url attributes
return "$".join(req_attr.values())
$$ LANGUAGE plpythonu;
