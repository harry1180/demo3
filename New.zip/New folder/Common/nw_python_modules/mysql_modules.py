import pymysql
import json
import logging
logr = logging.getLogger(__name__)

def mysql_connect(creds):
    """
    connect to mysql using this dictionary of credentials
    you can load credentials from redshift_modules.load_creds()
    """
    logr.info("Connecting to Mysql")
    # creds=load_creds()  ## assume
    rds_dbhost=creds['rds_prod_dbHost']
    rds_database=creds['rds_prod_database']
    rds_user=creds['rds_prod_username']
    rds_password=creds['rds_prod_password']
    rds_port=creds['rds_prod_port']
    config = {
      'user': rds_user,
      'password': rds_password,
      'host': rds_dbhost,
      'database': rds_database,
      'port':rds_port,
      'raise_on_warnings': True,
    }
    conn = pymysql.connect(host=config['host'],
                           port=int(config['port']), user=config['user'],
                           passwd=config['password'],
                           db=config['database'],
                           local_infile=True)
    conn.autocommit=True
    return(conn)

def mysql_exec(qry,conn=None,creds=None):
    """
    execute a mysql query
    if no conn, create one
    if no creds, load it
    if creds and creds is a string, treat it as a filename and load it
    """
    if conn is None:  # create connection if not given
        if creds is None:  # also load creds if not given
            from redshift_module import load_creds
            creds = load_creds()
        elif isinstance(creds, (str,unicode)):
            creds = load_creds(creds)
        conn=mysql_connect(creds)
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute(qry)
    res = [x for x in cur]
    conn.commit()
    cur.close()
    conn.close()
    return(res)

