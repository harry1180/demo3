import json
from httplib2 import Http
from oauth2client.client import SignedJwtAssertionCredentials
from apiclient.discovery import build
from apiclient.http import MediaIoBaseDownload
from apiclient.errors import HttpError


def google_cloud_storage_file_download(json_file,google_playstore_client_email,CLOUD_STORAGE_ACCESS_MODE,google_playstore_cloud_storage_bucket,report_to_download,output_filename,CHUNKSIZE):
   """
   Function to download files from google cloud storage. Api call will authenticate the user based on the client_sceret file and then download the file in chunks based on the defined chunk size.
   Example Call
   google_cloud_storage_file_download('google_playstore_client_sceret.json','abc@developer.gserviceaccount.com','https://www.googleapis.com/auth/devstorage.read_only','pubsite_prod_rev','stats/installs/installs_com.mobilecreditcards_app_version_201612.csv','google_app_version.csv',1024):
   
   """

   private_key = json.loads(open(json_file).read())['private_key']
   credentials = SignedJwtAssertionCredentials(google_playstore_client_email, private_key,CLOUD_STORAGE_ACCESS_MODE)
   storage = build('storage', 'v1', http=credentials.authorize(Http()))
   f = file(output_filename, 'w')
   
   request = storage.objects().get_media( bucket=google_playstore_cloud_storage_bucket,object=report_to_download)
   media = MediaIoBaseDownload(f, request, chunksize=CHUNKSIZE)
   
   while True:
       try:
         download_progress, done = media.next_chunk()
       except  HttpError, error:
         if int(error.resp['status']) == 404  :
             print 'File not found: %s' % error
             return 404
         else :    
             print 'An error occurred: %s ' % error
             return -1
       if download_progress:
         print 'Download Progress: %d%%' % int(download_progress.progress() * 100)
       if done:
         print 'Download Completed for ' 
         return 
       if media._total_size == None :
         print 'Total Size not set. Exiting'
         return  
         
   return 

