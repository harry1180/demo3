from datetime import datetime, timedelta
import decimal
import gzip
import logging
import os
import re

from botocore.exceptions import ClientError
import boto3
from boto3.dynamodb.types import TypeDeserializer
import pytz
import ujson as json

import nw_hive


DYNAMO_TO_HIVE_DATA_TYPES = {
    'B': 'string',  # Binary
    'BOOL': 'boolean',  # Boolean
    'BS': 'array<string>',  # Binary Set
    'L': 'string',  # List
    'M': 'string',  # Map
    'N': 'string',  # Number
    'NS': 'array<string>',  # Number Set
    'S': 'string',  # String
    'SS': 'array<string>',  # String Set
}


def get_nerdlake_bucket_name():
    return 'east1-prod-nerdlake-0'


def get_nerdlake_stage_database():
    return 'dwnl_pud_stage'


def get_nerdlake_data_database():
    return 'dwnl_pud_data'


def parse_cdc_key_name(key_name):
    """
    Parses the filename of a DynamoDB CDC file
    :param key_name: S3 key name, full path is optional
    :return: A two-element tuple containing the DynamoDB table name and a datetime object of the timestamp in the
     key name
    """
    regex = re.compile(
        r'^[a-z0-9]+-[a-z0-9]+-([a-z0-9]+-[a-z0-9_]+)-firehose-to-s3-\d+-(\d\d\d\d-\d\d-\d\d-\d\d-\d\d-\d\d)-.*$',
        re.IGNORECASE)
    regex_match = regex.match(os.path.basename(key_name))
    if not regex_match:
        return None
    table_name = regex_match.group(1)
    file_timestamp = datetime.strptime(regex_match.group(2), '%Y-%m-%d-%H-%M-%S')
    return table_name, file_timestamp


def get_s3_keys(bucket_name, prefix, start_datetime=None, end_datetime=None):
    """
    Retrieves S3 keys
    :param bucket_name:
    :param prefix:
    :param start_datetime:
    :param end_datetime:
    :return:
    """

    # Get the list of keys on or after the earliest timestamp
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)
    matching_s3_keys = list()
    for obj in bucket.objects.filter(Prefix=prefix):
        if start_datetime is not None and obj.last_modified < start_datetime:
            continue
        if end_datetime is not None and obj.last_modified >= end_datetime:
            continue
        matching_s3_keys.append(obj.key)

    return matching_s3_keys


def get_transformed_key_name(cdc_key_name):
    table_name, filename_timestamp = parse_cdc_key_name(cdc_key_name)
    transformed_s3_key_name = '{dbname}/dynamodb_{tablename}/file_dt={filedate}/{cdc_key_name}.json.gz'.format(
        dbname=get_nerdlake_stage_database(),
        tablename=table_name.replace('-', '_'),
        filedate=filename_timestamp.strftime('%Y-%m-%d'),
        cdc_key_name=os.path.basename(cdc_key_name)
    )
    return transformed_s3_key_name


def daterange(start_date, end_date):
    for n in range(int ((end_date - start_date).days)):
        yield start_date + timedelta(n)


def get_cdc_keys_to_process(s3_bucket_name, s3_folder_name, start_datetime=None, end_datetime=None, overwrite=False):
    """
    Finds all  DynamoDB CDC S3 keys that don't have a corresponding S3 file on NerdLake.
    :param s3_bucket_name: S3 bucket name to look for keys on
    :param s3_folder_name: S3 "folder" name to look for keys under (i.e., the S3 key prefix)
    :param start_datetime: The earliest S3 modification timestamp to return
    :param end_datetime: Non-inclusive datetime for the last S3 modification timestamp
    :param overwrite: Ignore pre-existing target keys
    :return: A set containing the S3 key names that need to be processed
    """

    # Adjust our start_date if needed
    earliest_valid_cdc_datetime = datetime(2018, 3, 1, 0, 0, 0, 0, pytz.utc)
    if start_datetime is None:
        start_datetime = datetime.now() - timedelta(days=7)
    if start_datetime.tzinfo is None:
        start_datetime = pytz.utc.localize(start_datetime)
    if start_datetime < earliest_valid_cdc_datetime:
        logging.warn('dynamodb_cdc.get_s3_keys(): adjusting start_date to earliest CDC file timestamp: {}'.format(
            earliest_valid_cdc_datetime))
        start_datetime = earliest_valid_cdc_datetime

    # If end datetime is offset-naive, set it to UTC
    if end_datetime is not None and end_datetime.tzinfo is None:
        end_datetime = pytz.utc.localize(end_datetime)

    transformed_bucket_name = get_nerdlake_bucket_name()

    logging.info('Looking for unprocessed keys in s3://{}/{}/'.format(
        s3_bucket_name, s3_bucket_name.rstrip('/')
    ))
    start_date = start_datetime.date()
    end_date = end_datetime.date if end_datetime is not None else datetime.now().date()
    cdc_keys = list()
    for proc_date in daterange(start_date, end_date + timedelta(days=1)):
        date_prefix = '{prefix}/{date_with_slashes}/'.format(
            prefix=s3_folder_name.strip('/'),
            date_with_slashes=proc_date.strftime('%Y/%m/%d')
        )
        logging.info('    ' + date_prefix)
        cdc_keys.extend(get_s3_keys(s3_bucket_name, date_prefix, start_datetime, end_datetime))
    logging.info('    Found {} keys'.format(len(cdc_keys)))

    if overwrite:
        return set(cdc_keys)

    # Convert the CDC file key names into the target key names
    logging.info('    Converting source key names into target key names')
    transformed_s3_key_names = dict()
    for cdc_key in cdc_keys:
        transformed_s3_key_name = get_transformed_key_name(cdc_key)
        transformed_s3_key_names[transformed_s3_key_name] = cdc_key

    # Figure out common prefixes of all the target key names. This will be used to make the S3 query faster. We can't
    # use os.path.commonprefix() here due to an edge case on the first couple days of the year. In this edge case, the
    # common prefix would end up pulling back all files which will be fairly slow. Instead, we pick up all of the
    # bottom-level folders.
    logging.info('    Determining folders on S3 that would hold the target keys')
    common_transformed_key_prefixes = set()
    for transformed_s3_key_name in transformed_s3_key_names:
        common_transformed_key_prefixes.add(os.path.dirname(transformed_s3_key_name))
    logging.info('    Found {} folders'.format(len(common_transformed_key_prefixes)))

    # Pull all S3 keys from the target system
    existing_transformed_keys = list()
    for common_transformed_key_prefix in sorted(common_transformed_key_prefixes):
        logging.info('    Getting all keys that start with s3://{}/{}'.format(
            transformed_bucket_name, common_transformed_key_prefix))
        folder_transformed_keys = get_s3_keys(transformed_bucket_name, common_transformed_key_prefix, None, None)
        existing_transformed_keys.extend(folder_transformed_keys)
    logging.info('    Found {} existing keys on target'.format(len(existing_transformed_keys)))
    existing_transformed_key_names = set(existing_transformed_keys)

    # Find target keys that don't exist
    logging.info('    Finding target keys that don\'t exist')
    unprocessed_transformed_key_names = set(transformed_s3_key_names.keys()).difference(existing_transformed_key_names)
    logging.info('    Found {} target keys that don\'t exist'.format(len(unprocessed_transformed_key_names)))

    # Translate the unprocessed transformed key names back into the original source names
    unprocessed_key_names = set()
    for unprocessed_transformed_key_name in unprocessed_transformed_key_names:
        unprocessed_key_names.add(transformed_s3_key_names[unprocessed_transformed_key_name])

    return unprocessed_key_names


def _deserialize_dynamodb_record(rec):
    """
    Given a dictionary containing a DynamoDB record, deserialize it into a standard Python dictionary. This translates
    the serialized DynamoDB values and data types into native Python data types. We also preserve the original DynamoDB
    data types to prevent data type loss.
    :param rec: A DynamoDB record
    :return: A two-element tuple of a native Python dictionary containing the DynamoDB record and a dictionary
    containing the DynamoDB data type for each field.
    """
    deser = TypeDeserializer()
    data = dict()
    types = dict()
    for rec_key, rec_val_serialized in rec.iteritems():
        try:
            data[rec_key.strip()] = deser.deserialize(rec_val_serialized)
        except decimal.Rounded as ex:
            if rec_key == 'app_state':
                logging.warn('Failed to deserialize key \'app_state\' due to decimal rounding error')
            else:
                raise ex
        for dynamodb_data_type_code in rec_val_serialized:
            types[rec_key.strip()] = DYNAMO_TO_HIVE_DATA_TYPES.get(dynamodb_data_type_code, 'unknown')
            break
    return data, types


def transform_cdc_file(input_filename, output_filename):
    """
    Reads a DynamoDB CDC JSON file and transforms it into a JSON file that can be more easily parsed by Hive.
    - For CDC records that are inserts or updates, new field data is stored in JSON attribute $.dynamodb.NewImage
    - For CDC records that are updates or deletes, old field data is stored in JSON attribute $.dynamodb.OldImage
    - We "flip" the JSON file by moving all top-level fields into a dictionary $.cdc_metadata and move everything in
      $.dynamodb.NewImage to top-level fields.
    - Selected metadata fields (e.g., SequenceNumber) are also stored at the top-level.
    :param input_filename:
    :param output_filename:
    :return: List of dictionaries that describe the field names and types in the transformed JSON file.
    """
    fhin = open(input_filename, 'r')
    hive_key_field_types = dict()
    hive_regular_field_types = dict()
    hive_metadata_field_types = dict()
    # fhout = open(output_filename, 'w')
    fhout = gzip.open(output_filename, 'wb')
    record_count = 0
    convert_start = datetime.now()
    for line in fhin:
        record_count = record_count + 1
        cdc = json.loads(line)
        formatted_rec = dict()

        # Important metadata fields that should become first-level fields. Prepend the fieldnames with 'cdc_metadata_'
        # to prevent name collision.
        formatted_rec['cdc_metadata_SequenceNumber'] = cdc['dynamodb']['SequenceNumber']
        formatted_rec['cdc_metadata_eventName'] = cdc['eventName']
        hive_metadata_field_types['cdc_metadata_SequenceNumber'] = 'string'
        hive_metadata_field_types['cdc_metadata_eventName'] = 'string'

        # Pick out the keys for this record and store them in a first-level field
        cdc_keys = set()
        for cdc_key_name, cdc_key_value_serialized in cdc['dynamodb']['Keys'].iteritems():
            for field_type in cdc_key_value_serialized:
                hive_key_field_types[cdc_key_name] = DYNAMO_TO_HIVE_DATA_TYPES.get(field_type, 'unknown')
                break
            cdc_keys.add(cdc_key_name)
        formatted_rec['cdc_metadata_Keys'] = sorted(cdc_keys, key=lambda s: s.lower())
        hive_metadata_field_types['cdc_metadata_Keys'] = 'array<string>'

        # The $.dynamodb.NewImage dictionary is the value of all fields for the new/modified record. These will be
        # first-level fields. This only exists on INSERT and MODIFY records.
        if 'NewImage' in cdc['dynamodb']:
            newimage_dict, newimage_types = _deserialize_dynamodb_record(cdc['dynamodb']['NewImage'])
            formatted_rec.update(newimage_dict)
            hive_regular_field_types.update(newimage_types)

        for hive_key_field_name in hive_key_field_types:
            del hive_regular_field_types[hive_key_field_name]

        ###########################################################################
        # Pick out all of the metadata and store it in $.cdc_metadata
        ###########################################################################
        cdc_metadata = dict()

        # All top-level fields in the CDC message are metadata, except 'dynamodb'
        for cdc_key in cdc:
            if cdc_key in ['dynamodb']:
                continue
            cdc_metadata[cdc_key] = cdc[cdc_key]

        # Everything in the 'dynamodb' object, except for NewImage and Keys should
        # be stored as metadata. This includes OldImage.
        for cdc_key in cdc['dynamodb']:
            if cdc_key in ['NewImage', 'Keys']:
                continue
            if cdc_key == 'OldImage':
                oldimage_data, oldimage_types = _deserialize_dynamodb_record(cdc['dynamodb']['OldImage'])
                cdc_metadata[cdc_key] = oldimage_data
            else:
                cdc_metadata[cdc_key] = cdc['dynamodb'][cdc_key]
        formatted_rec['cdc_metadata'] = cdc_metadata
        hive_metadata_field_types['cdc_metadata'] = 'string'

        fhout.write(json.dumps(formatted_rec))
        fhout.write('\n')
    fhout.close()
    fhin.close()
    convert_duration = datetime.now() - convert_start
    recs_per_second = float(record_count) / convert_duration.total_seconds()
    logging.info('    Transformed {} records, {:0,.1f} recs/sec'.format(record_count, recs_per_second))

    return hive_key_field_types, hive_regular_field_types, hive_metadata_field_types


def get_table_struct_metadata(key_fields, regular_fields, metadata_fields):
    """
    Combines three sets of fields into a single list of fields, ordered by key fields, regular fields, and metadata
    fields.
    :param key_fields:
    :param regular_fields:
    :param metadata_fields:
    :return:
    """
    metadata = list()
    for key_set in [key_fields, regular_fields, metadata_fields]:
        for field_name in sorted(key_set.keys()):
            field = dict()
            field['name'] = field_name.lower()
            field['type'] = key_set[field_name]
            metadata.append(field)
    return metadata


def create_hive_json_structure(conn, table_name, key_fields, regular_fields, metadata_fields):
    """
    Creates an external Hive table that references transformed JSON files.
    :param conn: Hive connection
    :param table_name: Fully qualified Hive table name
    :param key_fields: Dictionary containing the key fields in the table
    :param regular_fields: Dictionary containing the non-key fields in the table
    :param metadata_fields: Dictionary containing the metadata fields in the table
    :return:
    """
    key_field_names = sorted(key_fields.keys(), key=lambda s: s.lower())
    regular_field_names = sorted(regular_fields.keys(), key=lambda s: s.lower())
    metadata_field_names = sorted(metadata_fields.keys(), key=lambda s: s.lower())
    hive_database, hive_table_name = table_name.split('.')
    create_ddl = list()
    create_ddl.append('CREATE EXTERNAL TABLE `{}` ('.format(table_name.lower()))
    for ctr, field_name in enumerate(key_field_names):
        create_ddl.append('    {}`{}`    {}'.format(
            '' if ctr == 0 else ',',
            field_name.lower(),
            key_fields[field_name]
        ))
    for field_name in regular_field_names:
        create_ddl.append('    ,`{}`    {}'.format(field_name.lower(), regular_fields[field_name]))
    for field_name in metadata_field_names:
        create_ddl.append('    ,`{}`    {}'.format(field_name.lower(), metadata_fields[field_name]))
    create_ddl.append(')')
    create_ddl.append('PARTITIONED BY ( file_dt date )')
    create_ddl.append('ROW FORMAT SERDE \'org.openx.data.jsonserde.JsonSerDe\'')
    create_ddl.append('WITH SERDEPROPERTIES (')
    for ctr, field_name in enumerate(key_field_names):
        create_ddl.append('    {}"mapping.{}" = "{}"'.format(
            '' if ctr == 0 else ',',
            field_name.lower(),
            field_name
        ))
    for field_name in regular_field_names:
        create_ddl.append('    ,"mapping.{}" = "{}"'.format(field_name.lower(), field_name))
    for field_name in metadata_field_names:
        create_ddl.append('    ,"mapping.{}" = "{}"'.format(field_name.lower(), field_name))
    create_ddl.append(')')
    create_ddl.append('LOCATION \'s3://{}/{}/{}/\''.format(
        get_nerdlake_bucket_name(),
        hive_database.lower(),
        hive_table_name.lower()
    ))
    logging.info('\n'.join(create_ddl))
    nw_hive.exec_hive_sql_ddl(conn, '\n'.join(create_ddl))


def update_hive_json_structure(table_name, key_fields, regular_fields, metadata_fields):
    """
    Updates a Hive table structure to match the sets of columns provided.
    :param table_name: Fully qualified Hive table name
    :param key_fields: dictionary containing the key fields for the table, these will be the first set of columns in
    the table.
    :param regular_fields: dictionary containing non-key fields for the table, these will be the second set of columns
    in the table.
    :param metadata_fields: dictionary containing metadata fields for the table, these will be teh last set of columns
    in the table.
    :return:
    """
    conn = nw_hive.connect()

    if not nw_hive.hive_table_exists(conn, table_name):
        create_hive_json_structure(conn, table_name, key_fields, regular_fields, metadata_fields)
    else:
        existing_cols, existing_partitions = nw_hive.get_hive_table_column_metadata(conn, table_name)
        existing_col_names = set([a['name'] for a in existing_cols])
        missing_col_names = set()
        for key_set in [key_fields, regular_fields, metadata_fields]:
            missing_col_names.update(set([a.lower() for a in key_set.keys()]).difference(existing_col_names))
        if len(missing_col_names) > 0:
            # TODO: Figure out how to get ALTER TABLE ADD COLUMNS working, if that's even possible
            logging.info('New columns found: {}'.format(', '.join(sorted(missing_col_names))))
            logging.info('Dropping and re-creating {}'.format(table_name))
            sql = 'DROP TABLE `{}`'.format(table_name)
            logging.info(sql)
            nw_hive.exec_hive_sql_ddl(conn, sql)
            create_hive_json_structure(conn, table_name, key_fields, regular_fields, metadata_fields)

    sql = 'MSCK REPAIR TABLE `{}`'.format(table_name)
    logging.info(sql)
    nw_hive.exec_hive_sql_ddl(conn, sql)

    conn.close()
    return


def get_table(table_name, aws_profile=None, aws_region=None):
    """
    :param table_name: DynamoDB table name
    :param aws_profile: aws profile
    :param aws_region: aws region
    :return: dynamodb.Table
    """
    session = boto3.session.Session(profile_name=aws_profile, region_name=aws_region)
    dynamodb = session.resource('dynamodb')
    table = dynamodb.Table(table_name)
    try:
        trash = table.creation_date_time
    except ClientError as ex:
        logging.error('Unable to connect to Dynamo table {}:'.format(table_name))
        logging.error(ex)
        raise ex
    logging.info('Connected to table: {}'.format(table_name))
    return table


def put_item_in_table(table_name, item, aws_profile=None, aws_region=None):
    """
    :param table_name: DynamoDB table name
    :param item: Dictionary to be upserted into table
    :param aws_profile: aws profile
    :param aws_region: aws region
    :return: DynamoDB response dictionary
    """
    table = get_table(table_name, aws_profile, aws_region)
    res = table.put_item(Item=item)
    return res

