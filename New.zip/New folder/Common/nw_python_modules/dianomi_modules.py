import cgi
import csv
import os
import shutil


def download_url(session, url, directory, vert_id):
    """Download file from url to directory

    URL is expected to have a Content-Disposition header telling us what
    filename to use.
    Returns filename of downloaded file.
    """
    response = session.get(url, stream=True)
    if not response.ok:
        raise ValueError('Failed to download')

    params = cgi.parse_header(
        response.headers.get('content-disposition', ''))[-1]

    if 'filename' not in params:
        raise ValueError('Could not find a filename')

    filename = os.path.basename(vert_id + '_' + params['filename'])
    abs_path = os.path.join(directory, filename)
    with open(abs_path, 'wb') as target:
        response.raw.decode_content = True
        shutil.copyfileobj(response.raw, target)

    return filename


def combine_files(header, fns, path_to):
    """Combine files into generator

    Updated: added ability to hadle a csv files
    which have ',', '\r\n' within its fileds
    """
    for fn in fns:
        with open(os.path.join(path_to, fn), 'rb') as f:
            rows = csv.reader(
                f, quotechar='"', delimiter=',', skipinitialspace=True)
            f.next()
            for row in rows:
                row_fine = [r.replace('\n', '').replace('\r', '') for r in row]
                yield dict(zip(header, row_fine))
