'''Collection of some common utility methods generally used for ETL purposes which are not specific to redshift or S3'''

import platform
from datetime import datetime, timedelta
import os.path
import glob
from file_and_path_utils import FileUtils
import ssl
import time
import math
from suds.sudsobject import asdict
import json
import csv
import json
import StringIO
import pprint
import re
from subprocess import call,check_call,Popen
import os
import inspect
import struct
from google.protobuf.descriptor import FieldDescriptor
from nwutils.dict_utils import flatten_dict
from nwutils.modules import find_module_in_package
from nwpyschemas.util import load_class
import argparse
from datetime import datetime

if platform.system() != 'Java':
    from pandas.io.json import json_normalize
    import numpy as np

def fetch_creds(input_var_name):
    """function to fetch credentials from credentials-control file in Common"""
    creds = open('/data/etl/Common/credentials.ctrl')

    for line in creds:
        if input_var_name in line:
            #print line
            psql_prod_username=line.split('=')[1].replace('"',"")
            return str(psql_prod_username)

def table_print(data, title_row):
    """
    Method to print a JSON object in tabular format.
    data: list of dicts,
    title_row: e.g. key names from json object associated with header name [('name', 'Programming Language'), ('type', 'Language Type')]
    call example : table_print(exception_records_list,[('conversion_name', 'conversion_name'), ('google_click_id', 'google_click_id'), ('conversion_timestamp', 'conversion_timestamp'), ('conversion_value', 'conversion_value'),('exception_reason', 'exception_reason')])
    """
    max_widths = {}
    data_copy = [dict(title_row)] + list(data)
    for col in data_copy[0].keys():
      max_widths[col] = max([len(str(row[col])) for row in data_copy])
    cols_order = [tup[0] for tup in title_row]
  
    def custom_just(col, value):
      if type(value) == int:
        return str(value).rjust(max_widths[col])
      else:
        return value.ljust(max_widths[col])
  
    for row in data_copy:
      row_str = " | ".join([custom_just(col, row[col]) for col in cols_order])
      print "| %s |" % row_str
      if data_copy.index(row) == 0:
        underline = "-+-".join(['-' * max_widths[col] for col in cols_order])
        print '+-%s-+' % underline

def recursive_asdict(d):
    """Convert Suds object into serializable format."""
    out = {}
    for k, v in asdict(d).iteritems():
        if hasattr(v, '__keylist__'):
            out[k] = recursive_asdict(v)
        elif isinstance(v, list):
            out[k] = []
            for item in v:
                if hasattr(item, '__keylist__'):
                    out[k].append(recursive_asdict(item))
                else:
                    out[k].append(item)
        else:
            out[k] = v
    return out

def suds_to_json(data):
    """ Convert suds object to JSON format"""
    return json.dumps(recursive_asdict(data))

def convert_csv_to_python_json(field_names, file_delimiter, input_f_name, output_f_name,max_rejections=10):
    
    """
    Call example:

    #field_names = 'Partner_UUID,Obfuscated_BlueKai_UUID,Tag_URI,Pixel_URL,Referrer,Campaign_ID,Win_Time,IP_address,Categories_with_Timestamp'
    #input_f_name='/Users/srikanthsundara/DWH/mktg/bluekai/nerdwallet_batch_2016040112.log.part.bv'
    #output_f_name='/Users/srikanthsundara/DWH/mktg/nerdwallet_batch_2016033119.json'
    #file_delimiter='\t'
    #max_rejections=10
    convert_csv_to_python_json(field_names, file_delimiter, input_f_name, output_f_name,max_rejections=10)
    """

    #set counters
    total_counter=0
    success_counter=0
    exception_counter=0
    dq_status="NOTIFY"
    is_first_row=0
    #exception handling
    exception_records_list=[]

    with open(input_f_name, 'r') as infile:

        with open(output_f_name, 'w') as outfile:
            outfile.write('[')

            if total_counter > 1:
                outfile.write(',')

            for line in infile:
                #print line
                total_counter=total_counter+1

                try:
                    #print line
                    #strip non ascii chars
                    parsed_line=line.decode('utf8').encode('ascii','ignore')
                    #parsed_line = ''.join([x for x in line if ord(x) < 128])
                    #print parsed_line.decode('unicode-escape').encode('latin1').decode('utf8')
                    #print parsed_line
                    s_buffer = StringIO.StringIO(parsed_line)
                    #print s_buffer.getvalue()
                    reader = csv.DictReader(s_buffer, field_names.split(','),delimiter = file_delimiter)

                    #print type(reader)
                    #print reader._fieldnames
                    num_of_parsed_fields=len(parsed_line.split(file_delimiter))
                    num_of_header_fields=len(field_names.split(','))

                    if num_of_header_fields > num_of_parsed_fields:
                        print "num_of_header_fields is not equal to num_of_parsed_fields"
                        exception_counter=exception_counter+1
                        exception_records_list.append(line)
                        continue

                    for obj in list(reader):
                        #print obj
                        if total_counter > 1:
                            outfile.write(',\n')
                        #pretty print
                        #json.dump(obj, outfile, indent=4, sort_keys=True,ensure_ascii=True)
                        #regular print
                        json.dump(obj, outfile, ensure_ascii=True)

                    success_counter=success_counter+1

                except Exception,e:
                    print "Exception while converting to convert_csv_to_python_json : "+str(e)
                    exception_counter=exception_counter+1
                    exception_records_list.append(line)
            outfile.write(']\n')

    if exception_counter > max_rejections:
            dq_status="FAILURE"

    if exception_counter <= max_rejections:
            dq_status="SUCCESS"

    #writing conversions to log file
    print "Counters:"
    print "+-----------------+----------------------------+----------------------+------------------+"
    print "total_counter:",total_counter
    print "success_counter:",success_counter
    print "exception_counter:",exception_counter
    print "DQ_STATUS:",dq_status
    print "Exceptions:"
    print "+-----------------+----------------------------+----------------------+------------------+"
    print  pprint.pprint(exception_records_list)
    print output_f_name
    return dq_status


def export_to_json_redshift(list_of_dicts,local_filename,mode='w'):
    
    """Call Example : 
    export_to_json_redshift(fb_campaign_details,'/Users/srikanthsundara/DWH/mktg/campaign_fb/input/'+'fb_campaign_details.json') """
    
    with open(local_filename, mode) as outfile:
        for item in list_of_dicts:
            json.dump(item, outfile, indent=4, sort_keys=True)
            outfile.write('\n')
    print "File exported @ "+local_filename

def export_nested_json_to_json_redshift(nested_json,local_filename,add_dict=False):
    '''
    Call Example:
    export_nested_json_to_json_redshift(historical_credit_card,'historical_credit_card.json')
    '''
    flat_df=json_normalize(nested_json).replace(np.nan,'', regex=True)
    if add_dict:
	for key,value in add_dict.iteritems():
		flat_df[key]=flat_df.apply(lambda _: value, axis=1)
    flat_json=flat_df.to_dict(orient='records')
    export_to_json_redshift(flat_json,local_filename,mode='a')

def compress_file(compression_method,local_filename):
    from subprocess import call,check_call,Popen
    import os
    tries = 1
    print compression_method+' ing '+local_filename

    while tries < 5:
        try:
            Popen([compression_method,local_filename]).wait()
            if compression_method=='gunzip':
                processed_file_list=glob.glob(local_filename.replace('.gz',''))
                print processed_file_list
                if len(processed_file_list)==0:
                    tries +=1
                    print "Unable to wait for compression to finish. Attempting again"
                    continue
            break
        except Exception as e :
            print str(e)+" Sleeping for a minute."
            time.sleep(30)
            tries +=1
    else:
        raise TimeoutError


def print_file_stats_as_table(JSON_record_counter):
    from prettytable import PrettyTable
    import json
    import pandas as pd

    """
    Call Example : JSON_record_counter is a list of dicts with file stats like pre and post processing record counts.
                   log_file_stats(JSON_record_counter)
    """

    if len(JSON_record_counter)>0:
        print 'Printing key file stats ...'
        #x = PrettyTable(counter[0].viewkeys())
        x = PrettyTable(["key_file_name", "raw_json_record_count","parsed_json_redshift_record_count","diff"])
        x.align = "l" # Left align
        x.padding_width = 1 # One space between column edges and contents (default)
        for c in JSON_record_counter:
            x.add_row([c['key_file_name'],c['raw_json_record_count'],c['parsed_json_redshift_record_count'],(c['raw_json_record_count']-c['parsed_json_redshift_record_count'])])

        # calculate totals
        df=pd.DataFrame.from_records(JSON_record_counter)
        sum_raw_json_record_count=int(str(df[["raw_json_record_count"]].sum()).replace('dtype: int64','').replace('raw_json_record_count',''))
        sum_parsed_json_redshift_record_count=int(str(df[["parsed_json_redshift_record_count"]].sum()).replace('dtype: int64','').replace('parsed_json_redshift_record_count',''))

        x.add_row(["---------------------------------------------------------------------","-------------------------------","-------------------------------------------","-----------------------------------------"])
        x.add_row(["Total",sum_raw_json_record_count,sum_parsed_json_redshift_record_count,(sum_raw_json_record_count-sum_parsed_json_redshift_record_count)])
        print x

def convert_csv_to_redshift_json(field_names, file_delimiter, input_f_name, output_f_name,max_rejections=10):

    """
    Call example:

    #field_names = 'Partner_UUID,Obfuscated_BlueKai_UUID,Tag_URI,Pixel_URL,Referrer,Campaign_ID,Win_Time,IP_address,Categories_with_Timestamp'
    #input_f_name='/Users/srikanthsundara/DWH/mktg/bluekai/nerdwallet_batch_2016040112.log.part.bv'
    #output_f_name='/Users/srikanthsundara/DWH/mktg/nerdwallet_batch_2016033119.json'
    #file_delimiter='\t'
    #max_rejections=10
    convert_csv_to_redshift_json(field_names, file_delimiter, input_f_name, output_f_name,max_rejections=10)
    """

    #set counters
    total_counter=0
    success_counter=0
    exception_counter=0
    dq_status="NOTIFY"
    is_first_row=0
    #exception handling
    exception_records_list=[]

    with open(input_f_name, 'r') as infile:

        with open(output_f_name, 'w') as outfile:

            for line in infile:
                #print line
                total_counter=total_counter+1

                try:
                    #print line
                    #strip non ascii chars
                    parsed_line=line.decode('utf8').encode('ascii','ignore')
                    #parsed_line = ''.join([x for x in line if ord(x) < 128])
                    #print parsed_line.decode('unicode-escape').encode('latin1').decode('utf8')
                    #print parsed_line
                    s_buffer = StringIO.StringIO(parsed_line)
                    #print s_buffer.getvalue()
                    reader = csv.DictReader(s_buffer, field_names.split(','),delimiter = file_delimiter)

                    #print type(reader)
                    #print reader._fieldnames
                    num_of_parsed_fields=len(parsed_line.split(file_delimiter))
                    num_of_header_fields=len(field_names.split(','))

                    if num_of_header_fields > num_of_parsed_fields:
                        print "num_of_header_fields is not equal to num_of_parsed_fields"
                        exception_counter=exception_counter+1
                        exception_records_list.append(line)
                        continue

                    for obj in list(reader):
                        json.dump(obj, outfile, ensure_ascii=True)

                    success_counter=success_counter+1

                except Exception,e:
                    print "Exception while converting to convert_csv_to_python_json : "+str(e)
                    exception_counter=exception_counter+1
                    exception_records_list.append(line)

    if exception_counter > max_rejections:
            dq_status="FAILURE"

    if exception_counter <= max_rejections:
            dq_status="SUCCESS"

    #writing conversions to log file
    print "Counters:"
    print "+-----------------+----------------------------+----------------------+------------------+"
    print "total_counter:",total_counter
    print "success_counter:",success_counter
    print "exception_counter:",exception_counter
    print "DQ_STATUS:",dq_status
    print "Exceptions:"
    print "+-----------------+----------------------------+----------------------+------------------+"
    print  pprint.pprint(exception_records_list)
    print output_f_name
    return dq_status

def get_schema(descriptor):
    # Helper function of get_schema_list()
    result = []
    for f in descriptor.fields:
        if f.type != 11:
            result.append(f.name)
        # Type = 11 means it is an embedded message
        else:
            temp = get_schema(f.message_type)
            result.extend(temp)
    result.sort()
    return result

def get_schema_list(event_name):
    # Generate protobuf schema list
    # e.g. result = get_schema_list("PageViewEvent")
    # result will be a list of columns from PageViewEvent schema from Kafka
    # Reference: https://developers.google.com/protocol-buffers/docs/reference/python/
    schemaclass = load_class(event_name)
    result = get_schema(schemaclass.DESCRIPTOR)
    return result

#check the format of date input and raise exception if it's not in "%Y-%m-%d"
def valid_date(s):
    try:
        dt = datetime.strptime(s, "%Y-%m-%d")
        return s
    except ValueError:
        msg = "Not a valid date format('yyyy-mm-dd): '{0}'.".format(s)
        raise argparse.ArgumentTypeError(msg)


def parse_nw_dns(inc_filepath):
    """
    Parse ".inc" file to extract DNS
    :param inc_filepath: str, full path to ".inc" file
    :return: str, dns string
    """
    if not os.path.isfile(inc_filepath):
        raise OSError
    with open(inc_filepath, 'rb') as file_in:
        for row in file_in:
            if not row.strip():
                continue
            key, value = row.split('=', 1)
            if key == 'NERDLAKE_DNS':
                return value.strip().strip('\"').strip('\'')
    raise Exception('NERDLAKE_DNS not present in {}'.format(inc_filepath))
