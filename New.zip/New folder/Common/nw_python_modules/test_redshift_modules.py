#!/bin/env python
"""
Nose tests for the redshift_modules
Usage:
> nosetests test_redshift_modules.py -v
"""
from nose.tools import with_setup, assert_raises


from redshift_modules import *

## ---------------------------------------
fakecreds = '/tmp/fakecreds.ctrl'
def load_creds_setup():
    with open(fakecreds,'w') as ofp:
        ofp.write("""
#var1=commented
var1=willbeoverwritten
var1=finalvalue
var2=othervalue
"""
)
def load_creds_teardown():
    import os
    os.unlink(fakecreds)

@with_setup(load_creds_setup,load_creds_teardown)
def test_load_creds():
    creds = load_creds(fakecreds)
    assert creds['var1']=='finalvalue'

@with_setup(load_creds_setup,load_creds_teardown)
def test_fetch_creds():
    var2 = fetch_creds('var2',fakecreds)
    assert var2=='othervalue'
    var1,var2 = fetch_creds(['var1','var2'],fakecreds)
    assert var1=='finalvalue' and var2=='othervalue'
    
## ---------------------------------------
def test_redshift_connect():
    conn = redshift_connect()
    conn.close()

    
## ---------------------------------------
def test_query_decomment():
    qry = """
/* this is a 
multi-line header comment
*/
some code -- comments after the code
more code
"""
    res = query_decomment(qry)
    assert res.strip().split() == 'some code more code'.split()

## ---------------------------------------
def test_query_types():
    qry = """
/* some comment */
select count(*) from foo ;
/* another comment */
drop table if exists bar ;
/* yet another comment */
create table bar ;
"""
    qt = query_types(qry)
    assert qt == 'select drop create'.split()

## ---------------------------------------
def test_exec_query():
    logr.debug("testing that simple exec_query works")
    qry = "explain select * from dw_ba_report.ba_metric_dim;"
    exec_query(qry)
    logr.debug("testing that drop statements not allowed")
    qry = "drop dw_workarea.dropme;"
    assert_raises(RuntimeError, exec_query, qry)
    logr.debug("testing compatability with select")
    qry = "select 2+2 as four;"
    out = exec_query(qry)
    assert len(out)==1
    assert out[0]['four'] == 4
