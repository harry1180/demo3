import json
import pandas as pd

def excel_json(xls,dest_file,sheetname=0,header=0):
    """ Function to convert excel to Redshift Copy readable Json
    sheetname= can be either the sheet number or can be the name of the sheet
    header = 0, if the first row is header. Else put None for no header
    Sample call
    excel_json('/Users/vaibhavjajoo/investing_lost_keywords.xlsx',\
        '/Users/vaibhavjajoo/investing_lost_keywords.json', \
           sheetname=0,header=0)
    """
    with open(xls, 'rb') as f
        df = pd.read_excel(f, sheetname=sheetname, header=0, parse_cols='A:G'  )
        dict1 =  df.to_dict(orient='index')
        with open(dest_file,'w') as w:
            for row in range(len(dict1)):
                json.dump(dict1[row], w, indent=4)                
                #w.newlines
                
def list_sheets(xls):
    """List sheet names for a given excel
    call: list_sheets('/Users/vaibhavjajoo/excels/investing_lost_keywords.xlsx')
    Returns List with sheet names"""
    x = pd.ExcelFile(xls)
    return x.sheet_names          
