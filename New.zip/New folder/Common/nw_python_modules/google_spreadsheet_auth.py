"""
Steps to generate new credentials for Google Spreadsheet API

- IMPORTANT: you need to be logged in as dwh_service@nerdwallet.com user:
    - Log out of Okta
    - Log back in to Okta using dwh_service user (creds are stored in DWH 1Password Vault)

- Log in to Google Sheets API Portal (console.developers.google.com/apis/)
- Click on "Credentials" on the left-hand side
- Click "Create credentials" --> "OAuth client ID" --> "Other" --> "Create" (Name can be whatever)
- Download the JSON file for the new credentials that were just created
    [ looks like client_secret_205273667620-l7b38smnrelur3cgfv8jf8rgoroahsf9.apps.googleusercontent.com.json ]

- Run this script below using the above file for INPUT_SECRETS_FILE and choose path for OUTPUT_CREDENTIALS_FILE.
Note: this script will prompt a web browser window to open where you will see an option to choose the dwh_service
user and then you must click to verify. If successful, you should see "Authentication successful." printed to
the terminal. [I'm not sure how this would work on dwhadmin machines since a browser is required].

- You can then use the output file and encrypt these values:
    https://github.com/NerdWallet/nw-chef/blob/master/data_bags/dwh/gs_credentials.json

"""
import argparse
from oauth2client import file, client, tools


# If modifying these scopes, delete the file token.json.
SCOPES = 'https://www.googleapis.com/auth/spreadsheets'

# Downloaded from the Google Sheets API portal
# Looks something like: client_secret_205273667620-l7b38smnrelur3cgfv8jf8rgoroahsf9.apps.googleusercontent.com.json
INPUT_SECRETS_FILE = ''

# Credentials file to be outputted by the oauth script below
OUTPUT_CREDENTIALS_FILE = '/Users/<username>/Desktop/gs_credentials.json'


def main():
    """Shows basic usage of the Sheets API.
    Prints values from a sample spreadsheet.
    """
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[tools.argparser])
    flags = parser.parse_args()

    store = file.Storage(OUTPUT_CREDENTIALS_FILE)
    creds = store.get()
    if not creds or creds.invalid:
        flow = client.flow_from_clientsecrets(INPUT_SECRETS_FILE, SCOPES)
        tools.run_flow(flow, store, flags)


if __name__ == '__main__':
    main()
