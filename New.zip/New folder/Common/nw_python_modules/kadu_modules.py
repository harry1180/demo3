import json
import os
import logging
import pwd
import socket

from datetime import datetime
from decimal import Decimal
from urlparse import urlparse


class KaduParams:
    def __init__(self, kadu_args):
        self.args = kadu_args
        self.now = datetime.utcnow()
        self.topic = kadu_args.topic
        self.protocol = kadu_args.protocol
        self.kafka_servers = kadu_args.kafka_servers.split(',')
        self.s3_bucket = self.get_s3_bucket()
        self.s3_key_format = kadu_args.s3_key_format
        self.save = kadu_args.save
        self.no_s3 = kadu_args.no_s3
        self.read_only = kadu_args.read_only
        self.kafka_client_id = self.get_kafka_client_id()
        self.s3_key = self.get_s3_key()
        self.poll_timeout_ms = self.get_poll_timeout_ms()
        self.no_recovery = kadu_args.no_recovery
        self.offset_table = self.get_offset_table()
        self.offset_hist_table = self.get_offset_hist_table()
        self.local_out = self.get_local_out()
        self.aws_profile = kadu_args.aws_profile
        self.aws_region= kadu_args.aws_region
        self.manual_start_offsets = json.loads(kadu_args.start_offsets.replace("'", "\"")) if kadu_args.start_offsets else None
        self.manual_end_offsets = json.loads(kadu_args.end_offsets.replace("'", "\"")) if kadu_args.end_offsets else None

    def get_kafka_client_id(self):
        username = self.get_username()
        host_name = self.get_host_name()
        return 'dwh_kadu_{}@{}'.format(username, host_name)

    def get_s3_bucket(self):
        if self.args.s3:
            s3_bucket = urlparse(self.args.s3).path
        elif self.args.s3_bucket:
            s3_bucket = self.args.s3_bucket
        else:
            raise KaduError('No s3 bucket set')
        return s3_bucket

    def get_s3_key(self):
        if self.args.s3:
            s3_key = urlparse(self.args.s3).scheme
        elif self.args.s3_key_format == 'prod_s3_key':
            if self.args.protocol == 'json':
                s3_key = self.now.strftime('{}/%Y/%m/%d/%H:%M:%S.json'.format(self.args.topic))
            else:
                s3_key = self.now.strftime('{}/%Y/%m/%d/%H:%M:%S.protobuf'.format(self.args.topic))
        else:
            if self.args.protocol == 'json':
                s3_key = self.now.strftime('kadu/{}/%Y/%m/%d/%H:%M:%S.json'.format(self.args.topic))
            else:
                s3_key = self.now.strftime('kadu/{}/%Y/%m/%d/%H:%M:%S.protobuf'.format(self.args.topic))
        return s3_key

    def get_poll_timeout_ms(self):
        return int(self.args.poll_timeout_ms) if self.args.poll_timeout_ms else 5000

    def get_local_out(self):
        if self.args.out:
            local_out = self.args.out
        elif self.args.protocol == 'json':
            local_out = os.path.join(os.getenv('Linux_Output'), 'kadu-{}-{}.json'.format(os.getpid(), self.args.topic))
        else:
            local_out = os.path.join(os.getenv('Linux_Output'), 'kadu-{}-{}.protobuf'.format(os.getpid(), self.args.topic))
        return local_out

    def get_offset_table(self):
        if self.args.dynamo_environment == 'prodenv':
            return 'dwh-kadu-offsets'
        elif self.args.dynamo_environment == 'stageenv':
            return 'dwh-kadu-offsets'
        elif self.args.dynamo_environment == 'kafka10test':
            return 'dwh-kadu-offsets-kafka10test'
        else:
            raise KaduError('No dynamo environment set')

    def get_offset_hist_table(self):
        if self.args.dynamo_environment == 'prodenv':
            return 'dwh-kadu-offsets-hist'
        elif self.args.dynamo_environment == 'stageenv':
            return 'dwh-kadu-offsets-hist'
        elif self.args.dynamo_environment == 'kafka10test':
            return 'dwh-kadu-offsets-hist-kafka10test'
        else:
            raise KaduError('No dynamo environment set')

    @staticmethod
    def get_username():
        return pwd.getpwuid(os.geteuid())[0]

    @staticmethod
    def get_host_name():
        return socket.gethostname()


class KaduRunLog:
    def __init__(self, name, offset_dict=dict(), topic=None):
        self.name = name
        self.offset_dict = offset_dict
        self.topic = offset_dict.pop('kafka_topic_nm') if offset_dict.get('kafka_topic_nm') is not None else topic
        self.file_size = offset_dict.pop('upload_file_size') if offset_dict.get('upload_file_size') is not None else None
        self.s3_key = offset_dict.pop('upload_file_s3_key') if offset_dict.get('upload_file_s3_key') is not None else None
        self.upload_ts = offset_dict.pop('extract_start_ts') if offset_dict.get('extract_start_ts') is not None else None
        self._replace()

    def get_offset(self, partition):
        k = 'partition_' + str(partition)
        try:
            offset = self.offset_dict[k]
            return int(offset)
        except KeyError:
            logging.debug('{} does not exist for topic: {} in {}'.format(k, self.topic, self.name))
            return None

    def set_offset(self, partition, offset):
        k = 'partition_' + str(partition)
        try:
            self.offset_dict[k] = int(offset)
        except Exception as e:
            logging.error(e)
            raise KaduError('Partition does not exist for topic: {} in {}, cannot set offset'.format(self.topic, self.name))
        return

    def get_file_size(self):
        if self.file_size is not None:
            return self.file_size
        logging.info('No file associated with these offsets')
        return

    def set_file_size(self, file_size):
        self.file_size = file_size
        logging.debug('File size for offset {} set to:{}'.format(self.name, file_size))
        return

    def get_file_s3_key(self):
        if self.s3_key is not None:
            return self.s3_key
        logging.info('No s3 key associated with these offsets')
        return

    def set_file_s3_key(self, s3_key):
        self.s3_key = s3_key
        logging.debug('s3_key for offset {} set to:{}'.format(self.name, s3_key))
        return

    def get_upload_ts(self):
        if self.upload_ts is not None:
            return self.upload_ts
        logging.info('No upload_ts associated with these offset')

    def set_upload_ts(self, ts):
        self.upload_ts = ts
        logging.debug('upload_ts for offset {} set to:{}'.format(self.name, ts))
        return

    def add_partition(self, partition, offset=None):
        k = 'partition_' + str(partition)
        if k in self.offset_dict:
            logging.info('Partition already exist')
            return
        if offset and not isinstance(offset, int):
            raise KaduError('Offset must be of type<int> input {} type {}'.format(offset, type(offset)))
        self.offset_dict[k] = offset
        logging.debug('{} added with offset: {} in {}'.format(k, offset, self.name))

    def del_partition(self, partition):
        k = 'partition_' + str(partition)
        if k not in self.offset_dict:
            logging.info("Partition does not exists")
            return
        del self.offset_dict[k]
        logging.debug('{} deleted'.format(k))

    def get_payload(self):
        payload = dict()
        payload['kafka_topic_nm'] = self.topic
        payload['extract_start_ts'] = self.upload_ts
        payload['upload_file_s3_key'] = self.s3_key
        payload['upload_file_size'] = self.file_size
        payload.update(self.offset_dict)
        logging.debug('{} : {}'.format(self.name, payload))
        return payload

    def get_partition_count(self):
        n = 0
        for i in self.offset_dict.keys():
            if 'partition' in i:
                n += 1
        return n

    def _replace(self):
        for key, value in self.offset_dict.iteritems():
            if isinstance(value, Decimal):
                self.offset_dict[key] = int(value)

    def __str__(self):
        return "\n" + self.name + ":" + json.dumps(self.offset_dict, sort_keys=True, indent=2, separators=(',', ': '))


class KaduError(Exception):

    def __init__(self, message):
        self.message = message
