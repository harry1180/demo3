#!/usr/bin/env python

import argparse
from datetime import datetime, timedelta
import logging

import redshift_scd


logging.basicConfig(format="[%(asctime)s] [%(levelname)-8s] %(name)s - %(message)s", level=logging.DEBUG)


parser = argparse.ArgumentParser(description='Perform an SCD merge on Redshift')
parser.add_argument(
    '--source-table',
    metavar='<schema.table_name>',
    help='Table that contains data for the current state of the source table.',
    required=True)
parser.add_argument(
    '--target-table',
    metavar='<schema.table_name>',
    help='Table that contains the SCD data.',
    required=True)
parser.add_argument(
    '--key-fields',
    metavar='<field1[,field2[,...]]>',
    help='Field(s) that are the natural primary key for the tables.',
    required=True)
parser.add_argument(
    '--ignore-fields',
    metavar='<field1[,field2[,...]]>',
    help='Field(s) that should be ignored when comparing data to detect changes.',
    required=False)
parser.add_argument(
    '--skip-deletes',
    action='store_true',
    help='Don\'t expire records if they aren\'t in the source table. Useful for data sources that provide recently changed records instead of a full extract.',
    required=False)
parser.add_argument(
    '--simulate',
    action='store_true',
    help='Don\'t execute any SQL that modifies data.',
    required=False)
parser.add_argument(
    '--date',
    metavar='<YYYY-MM-DD>',
    help='Date that is used to assign the DW_EFF_DT and DW_EXPR_DT fields; defaults to the previous day.',
    required=False)
args = parser.parse_args()

logging.info('Execution begins')
if args.source_table:
    logging.info('Source table:  ' + args.source_table)
if args.target_table:
    logging.info('Target table:  ' + args.target_table)
if args.key_fields:
    logging.info('Key Fields:    ' + args.key_fields)
if args.ignore_fields:
    logging.info('Ignore Fields: ' + args.ignore_fields)
if args.skip_deletes:
    logging.info('Skip Deletes:  Yes')
if args.date:
    logging.info('SCD Date:      ' + args.date)


# Remove any leading and trailing whitespace from the field name lists
npk_fields = args.key_fields.split(',')
for i, key_field in enumerate(npk_fields):
    npk_fields[i] = key_field.strip()
ignore_fields = None
if args.ignore_fields:
    ignore_fields = set()
    for ignore_field in args.ignore_fields.split(','):
        ignore_fields.add(ignore_field.strip())

# Default the SCD date to today
if args.date:
    scd_date = datetime.strptime(args.date, '%Y-%m-%d')
else:
    scd_date = datetime.today()

redshift_scd.merge(
    fq_source_table_name=args.source_table,
    fq_target_table_name=args.target_table,
    key_fields=npk_fields,
    ignore_fields=ignore_fields,
    scd_date=scd_date,
    skip_deletes=args.skip_deletes,
    simulate=args.simulate)

logging.info('Execution ends')
