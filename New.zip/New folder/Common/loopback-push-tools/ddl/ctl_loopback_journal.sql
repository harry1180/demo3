DROP TABLE IF EXISTS dw_stage.ctl_loopback_journal;

CREATE TABLE dw_stage.ctl_loopback_journal (
  transmission_nm      VARCHAR(64),
  transmission_seq_nr  INTEGER,
  transmission_guid    VARCHAR(36),
  transmission_stat_cd CHAR(1),  -- R=running S=success E=error P=purged
  environment_cd       CHAR(1),  -- P=prod S=stage
  delta_full_cd        CHAR(1),  -- F=full D=delta
  execute_ts           TIMESTAMP,
  purge_snap_at_ts     TIMESTAMP,
  extract_user_nm      VARCHAR(64),
  creator_job_nm       VARCHAR(128),
  processing_dt        DATE,
  dest_bucket_nm       VARCHAR(64),
  manifest_json        VARCHAR(MAX)
)
DISTSTYLE KEY DISTKEY(transmission_nm)
SORTKEY(transmission_nm, transmission_seq_nr);

GRANT ALL ON dw_stage.ctl_loopback_journal TO GROUP grp_etl_secured;

