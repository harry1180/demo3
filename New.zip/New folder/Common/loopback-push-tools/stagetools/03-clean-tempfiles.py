#!/usr/bin/env python

from   boto.s3.connection import S3Connection
from   boto.s3.key import Key

s3conn = S3Connection()
s3bucket = s3conn.get_bucket('east1-prod-dwh-s3-0')
s3bucket.delete_key('_memberid_prod_stage_mapping/memberid_prod_stage_mapping.json')
s3bucket.delete_key('_memberid_prod_stage_mapping/memberid_prod_stage_mapping.jsonpaths')

