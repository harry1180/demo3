DROP TABLE IF EXISTS dw_stage.dw_memberid_prod_stage_mapping;

CREATE TABLE dw_stage.dw_memberid_prod_stage_mapping (
  prod_user_id    VARCHAR(36)   ENCODE LZO DISTKEY,
  stage_user_id   VARCHAR(36)   ENCODE LZO,
  dw_load_ts      TIMESTAMP     ENCODE LZO,
  dw_last_updt_ts TIMESTAMP     ENCODE LZO,
  dw_last_updt_tx VARCHAR(3000) ENCODE LZO
)
SORTKEY(prod_user_id);

GRANT ALL ON dw_stage.dw_memberid_prod_stage_mapping TO GROUP grp_etl_secured;

COPY dw_stage.dw_memberid_prod_stage_mapping
FROM 's3://east1-prod-dwh-s3-0/_memberid_prod_stage_mapping/memberid_prod_stage_mapping.json'
ACCESS_KEY_ID '' SECRET_ACCESS_KEY ''
FORMAT AS JSON 's3://east1-prod-dwh-s3-0/_memberid_prod_stage_mapping/memberid_prod_stage_mapping.jsonpaths'
MAXERROR AS 1
COMPUPDATE ON STATUPDATE ON;

DELETE FROM dw_stage.dw_memberid_prod_stage_mapping WHERE prod_user_id IS NULL;

