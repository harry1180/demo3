#!/usr/bin/env python

from   boto.s3.connection import S3Connection
from   boto.s3.key import Key
import psycopg2

from   datetime import datetime
import json
from   subprocess import Popen, PIPE, STDOUT
import sys


# This is a bzip2'd file which is the full list of member_id's from stage.  Someone from the
# UDP team must extract this.  Note this parameter is assumed trusted, not to contain JSON or
# shell special characters.
srcfile = '2017.07.19-ahollenbach-stage-memberids.csv.bz2'


def main():
    now = loadTs()

    inputrecs = getBz2RecordCount(srcfile)

    out_flo = open('memberid_prod_stage_mapping.json', 'w')

    stage_recs_flo = Popen(['/bin/bzcat', srcfile], stdout=PIPE)
    # oops: use bz2 module  if we decide to clone / reuse this module again

    sql = 'SELECT user_id FROM (SELECT user_id FROM dw_user_d WHERE curr_in=1 ORDER BY RANDOM()) LIMIT {};'
    pdbconn = psycopg2.connect('host=redshift.east1.prod.nerdwallet.com port=5439 dbname=dev user=awelchCrazypants password=foo')
    prod_recs_cur = pdbconn.cursor()
    prod_recs_cur.execute('SET SEED TO {}'.format(randomSeed()))
    prod_recs_cur.execute(sql.format(inputrecs))

    for stage_user_id in stage_recs_flo.stdout:
        json.dump( {'prod_user_id'   : prod_recs_cur.fetchone()[0],
                    'stage_user_id'  : stage_user_id.strip(),
                    'dw_load_ts'     : now,
                    'dw_last_updt_ts': now,
                    'dw_last_updt_tx': srcfile}, out_flo)
        out_flo.write("\n")

    stage_recs_flo.wait()
    prod_recs_cur.close()
    pdbconn.close()
    out_flo.close()

    s3conn = S3Connection()
    s3bucket = s3conn.get_bucket('east1-prod-dwh-s3-0')
    s3k = Key(s3bucket)

    s3k.key = '_memberid_prod_stage_mapping/memberid_prod_stage_mapping.json'
    s3k.set_contents_from_filename('memberid_prod_stage_mapping.json')

    s3k.key = '_memberid_prod_stage_mapping/memberid_prod_stage_mapping.jsonpaths'
    jp = '{ "jsonpaths": [ "$.prod_user_id", "$.stage_user_id", "$.dw_load_ts", "$.dw_last_updt_ts", "$.dw_last_updt_tx" ] }'
    s3k.set_contents_from_string(jp)




def getBz2RecordCount(filename):
    cmdline = '/bin/bzcat {} | /usr/bin/wc -l'.format(filename)
    bzwc    = Popen(cmdline, shell=True, stdout=PIPE, stderr=STDOUT)
    bzwc.wait()

    ret  = bzwc.stdout.read()
    if ret.strip().isdigit():
        return int(ret.strip())

    print 'Failure when running: {}'.format(cmdline)
    print ret
    raise ValueError()


def randomSeed():
    d = float((datetime.utcnow() - datetime(1970, 1, 1)).total_seconds()) * 100000000 / sys.maxint
    return d


def loadTs():
    d = datetime.utcnow()
    return d.strftime('%Y-%m-%d %H:%M:%S')


if __name__ == '__main__':
    main()


