dwh/Scripts/loopback_udp/stagetools 
================================================

With the data loopback from DWH to the User Data Platform, there is a need to get data loaded
into stage.  Without reasonable data in stage, many folks will not be able to test.  (Ditto
QA environments, eventually.)  

However, DWH data only exists in production.  Yes, a stage DWH could consume data from stage's
event stream and databases, but there's unquestionably other data in DWH which doesn't
originate from there:  3rd party feeds, analytic models, etc..  Maybe one day, we'll run
stage daily processing on a stage DWH, but that's a long way off for currently marginal value.  

Making the assumption that it's okay for data in stage to be self-inconsistent, i.e. it's
okay that UDP data contains data derived from activities which occurred in stage, as well as
data that comes from PRODUCTION DWH (anonymized and masked), we adopt this technique:

    - Some identities (user_id's, member_id's, etc) in prod DWH map to stage identities.  
    - This mapping should remain static until there's a decision to 'reset the baseline'.  
    - Right now, the algorithm is "random" as based on a timestamp-seeded RANDOM() ordering on Redshift.  
    - In the future, there will likely need to be other mapping approaches, so we left the algorithm in python :)

The resulting mapping is in dw_stage.memberid_prod_stage_mapping.  It is sensitive data.  It is
used in ETL processes when run in the 'stage mode'.   

The implementation herein does a full refresh.  We'd probably need to do something more exotic in the future.



