echo "
###########################################################################################
##                  ******   UNLOAD FUNCTION   ******                                    ##
## This function deletes and unloads new files that were generated using sql Command     ##
## It takes 3 Mandatory Arguments and 1 optional Aruments. Arguments need to follow as   ##
## Mandatory Args : 1) SQL file 2) Path to s3 folder 3) wild_card for file prefix        ##
## Optional Args :  4) S3 Bucket by default it unloads to DWH buckets, it can be changed ##
##                                                                                       ##
###########################################################################################
"
source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

if [ -z $4 ]; then
        unload_bucket=$Events_dwh_bucket
    else
        unload_bucket=$4
fi

if [ "$#" -lt 3 ]; then
    echo "Please pass three parameters to unload commands"
    exit 1
else
    Deletepath="$(echo -e "${2}" | sed -e 's/^[[/]]*//')"
    echo "Deleting the files from the path : "$2
    echo "Deleting the files with the wildcardsearch : "$3
    python -c "from s3_modules import delete_key; delete_key('$Deletepath','$unload_bucket','${3}')" || true
    #sudo rm -f /s3mnt-dwh-staging$2$3* || true
    input=`cat $1`
    query="unload "$input" to '"$s3_bucket_name$2$3"' credentials '$s3_prod_load_creds' delimiter '\t' parallel off;"
    psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
    #sudo chmod 777 /s3mnt-dwh-staging$2$3*
    #sudo chgrp etl /s3mnt-dwh-staging$2$3*
fi
