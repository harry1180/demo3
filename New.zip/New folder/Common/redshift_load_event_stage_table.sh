#!/bin/bash
set -e

if [ $# -lt 1 ] || [ $# -gt 3 ]
then
    echo "Usage: $0 <NameOfEvent> [start_date] [end_date]"
    exit 1
fi
event_name="$1"

job_name="pbclass_${1,,}_s"
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************$Processing_Step" >&2
    exit 1
}
trap 'abort' 0

Processing_Step="Setting Variables, Running Preprocess scripts and Creating DIR Structures"
echo_processing_step ${job_name} "$Processing_Step" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
source_bucket=$Events_dwh_bucket
source_path=$event_name
destination_bucket=$Events_dwh_bucket
destination_path=$job_name
stagedb=dw_qa_stage
if [ $(id -un) == "airflow" ]
then
    stagedb=dw_stage
fi

if [ -z $2 ] ; then
  from_date="$(date -d '-3 days' '+%Y-%m-%d')"
else
  from_date="$2"
fi 

if [ -z $3 ] ; then
  to_date="$(date -d '1 days' +'%Y-%m-%d')"
else
  to_date="$3"
fi

echo 'source_bucket              :-   '${source_bucket}
echo 'source_path                :-   '${source_path}
echo 'destination_bucket         :-   '${destination_bucket}
echo 'destination_path           :-   '${destination_path}
echo 'from_date                  :-   '${from_date}
echo 'to_date                    :-   '${to_date}
echo 'stagedb                    :-   '${stagedb}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "$Processing_Step" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

# Cleanup S3 and local files
s3_top_level_folder_name=redshift_copy
if [ $(id -un) != "airflow" ]
then
    s3_top_level_folder_name=redshift_copy_dev
fi
manifest_s3_url="s3://$destination_bucket/$s3_top_level_folder_name/$stagedb.$job_name.manifest.json"
Processing_Step="Deleting $manifest_s3_url"
echo_processing_step ${job_name} "$Processing_Step" "Started"
python -c "
from s3_modules import delete_key
delete_key('$s3_top_level_folder_name','$destination_bucket','$stagedb.$job_name.manifest.json')" || true
echo_processing_step ${job_name} "$Processing_Step" "Completed"

Processing_Step="Cleaning local files"
echo_processing_step ${job_name} "$Processing_Step" "Started"
find $Linux_Input   -name \*.json -exec rm {} \; || true
find $Linux_Output  -name \*.json -exec rm {} \; || true
find $Linux_Archive -name \*.json -exec rm {} \; || true
echo_processing_step ${job_name} "$Processing_Step" "Completed"

# Convert json-format to Redshift-format and create one manifest/index file for loading data into Redshift
Processing_Step="Generating manifest file to $manifest_s3_url"
echo_processing_step ${job_name} "$Processing_Step" "Started"
manifest_command="
from datetime import datetime
import redshift_modules
redshift_modules.generate_manifest_file2(
    event_s3_url_prefix='s3://$source_bucket/$source_path',
    manifest_s3_url='$manifest_s3_url',
    scan_type='hive',
    start_date_time=datetime.strptime('$from_date', '%Y-%m-%d'),
    end_date_time=datetime.strptime('$to_date', '%Y-%m-%d'))
"
echo "$manifest_command"
python -c "$manifest_command"
echo_processing_step ${job_name} "$Processing_Step" "Completed"

# Load the Redshift table
Processing_Step="Loading $stagedb.$job_name"
echo_processing_step ${job_name} "$Processing_Step" "Started"
export s3_prod_load_creds
python $dwh_common_base_dir/redshift_load_event_stage_table.py \
    --pb-class-name "$event_name" \
    --table-name "$stagedb.$job_name" \
    --manifest-s3-url "$manifest_s3_url" \
    --overrides-filename "$dwh_common_base_dir/event_overrides.json" \
    --redshift-s3-creds-envar s3_prod_load_creds
echo_processing_step ${job_name} "$Processing_Step" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
