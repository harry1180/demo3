import sys
import time
import json

def main():
    hql_script              = sys.argv[1]
    param_file              = sys.argv[2]

    with open(param_file) as json_file:
        param_json = json.load(json_file)

    with open(hql_script, 'r') as content_file:
        for line in content_file:
            for k in param_json.keys():
                line_params=line.replace(k,param_json[k])
                line=line_params
            sys.stdout.write(line_params)

if __name__ == '__main__':
    main()
