
trap : 0

abort()
{
    echo >&2 '
**********************************************************
*** ERROR CODE BEACON PAGE VIEW  COMPLETE LOAD ABORTED ***
**********************************************************
'
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}

trap 'abort' 0

set -e


#######################################
#Main Script
#######################################

Processing_Step="Loading beacon page view"
bash /data/etl/Scripts/dw_beacon_page_view_f/shellscripts/dw_beacon_page_view_f.sh 1

Processing_Step="Loading beacon page activity"
bash /data/etl/Scripts/dw_beacon_page_activity_f/shellscripts/dw_beacon_page_activity_f.sh 1


trap : 0
echo >&2 '
************************************************
*** BEACON PAGE VIEW COMPLETE LOAD COMPLETED *** 
************************************************
'

