job_name='Tableau_Extract_Refresh'


job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source /etc/profile.d/tabcmd.sh
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source /etc/passwords.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
#  bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e



echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+---- Starting to Refresh Tableau Extract---+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

input_date="$(date +'%Y%m%d%H%M%S')"
if [ "$#" -eq 2 ]; then
    Workbookname=$1
    extract_name=$2
else
    Workbookname=$1
    extract_name="--url"
fi
export tabcmd_session=${Workbookname}
echo 'Workbookname     :-'$Workbookname


#DIRECTORY=/var/log/.tabcmd/${Workbookname}
#echo "Job run Directory is "$DIRECTORY

#if [ ! -d "$DIRECTORY" ]; then
#  echo "Directory does't exist so creating and granting full permissions"

#  mkdir $DIRECTORY
#  chmod 777 $DIRECTORY
#fi

#pushd $DIRECTORY


#bash tabcmd login -s 172.20.101.238 -u $tableau_username -p $tableau_password

#bash tabcmd refreshextracts --synchronous ${extract_name} ${Workbookname}
bash tabcmd refreshextracts -s 172.20.101.238 -u $tableau_username -p $tableau_password --no-cookie --synchronous ${extract_name} ${Workbookname}
#bash tabcmd logout

#popd


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----Completed to Refresh Tableau Extract---+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

#echo_processing_step ${job_name} "Calling End Script" "Started"
#bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
#echo_processing_step ${job_name} "Calling End Script" "Completed"
job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
