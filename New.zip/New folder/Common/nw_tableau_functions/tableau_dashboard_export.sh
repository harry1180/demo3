job_name='Tableau_Dashboards'


job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source /etc/profile.d/tabcmd.sh
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source /etc/passwords.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
#  bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e



echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+---- Starting to Export Tableau report-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

#################################
#################################
##### Pre Processing Steps ######
#################################
#################################

check_create_directories () {
if [ ! -d "$1" ];
then
        echo "Directory doesnt exists creating "$1
        mkdir -p $1
        chmod -R 775 $1
#        chgrp -R etl $1
else
        echo "Structure already exists for "$1
fi

}

echo "Cheking if Tableau_Dashboards exists in Data Direcotry"
data_dir=${dwh_data_base_dir}"/Tableau_Dashboards"
check_create_directories $data_dir
input_date="$(date +'%Y%m%d%H%M%S')"
folder_name=$1
archive_folder=${folder_name}/archive
report_name=$2
PDF_Name_extract=`echo $report_name |cut -d'/' -f1`
PDF_Name=${PDF_Name_extract}.pdf
echo "folder_name   :-"$folder_name

echo "report_name   :-"$report_name
echo "PDF_Name      :-"$PDF_Name


Report_Folder=${data_dir}/${folder_name}
echo "Cheking if Report_Folder exists in Data Direcotry"
check_create_directories $Report_Folder
check_create_directories ${data_dir}/${archive_folder}
#################################
#################################
#session_id=${folder_name}-${PDF_Name_extract}
#export tabcmd_session=${session_id}

#DIRECTORY=/var/log/.tabcmd/${session_id}
#echo "Job run Directory is "$DIRECTORY

#if [ ! -d "$DIRECTORY" ]; then
#  echo "Directory does't exist so creating and granting full permissions"
#  mkdir $DIRECTORY
#  chmod 777 $DIRECTORY
#fi

#pushd $DIRECTORY

#bash tabcmd login --no-cookie -s 172.20.101.238 -u $tableau_username -p $tableau_password

#bash ${dwh_common_base_dir}/nw_tableau_functions/lib/tabcmd.sh export "${report_name}?:refresh=yes" --fullpdf --pagelayout landscape --width 1200 --height 1000 -f "${PDF_Name}"
#bash tabcmd export "${report_name}?:refresh=yes" --fullpdf -f "${PDF_Name}"
bash tabcmd export -s 172.20.101.238:80 -u $tableau_username -p $tableau_password --no-cookie "${report_name}?:refresh=yes" --fullpdf -f "${PDF_Name}"


echo "+----------+-----Tableau Report Exported Successfully-----+----------+"
mv ${PDF_Name} ${Report_Folder}/
cp ${data_dir}/${folder_name}/${PDF_Name} ${data_dir}/${archive_folder}/${PDF_Name_extract}_${input_date}.pdf || true
chmod 777 ${data_dir}/${folder_name}/${PDF_Name} || true
chmod 777 ${data_dir}/${archive_folder}/${PDF_Name_extract}_${input_date}.pdf || true
echo "+----------+-----Moving and Archiving Files Completed-----+----------+"

bash tabcmd logout


python -c "from s3_modules import s3_file_upload; s3_file_upload('${data_dir}/${folder_name}/${PDF_Name}', '$Events_dwh_bucket', '${job_name}/${folder_name}/', s3_file_nm='default')" || true

python -c "from s3_modules import s3_file_upload; s3_file_upload('${data_dir}/${archive_folder}/${PDF_Name_extract}_${input_date}.pdf', '$Events_dwh_bucket', '${job_name}/${archive_folder}/', s3_file_nm='default')" || true
echo "+----------+-----Moving and Archiving Files to S3 Completed-----+----------+"

#popd



echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----Completed to Export Tableau report-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

#echo_processing_step ${job_name} "Calling End Script" "Started"
#bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
#echo_processing_step ${job_name} "Calling End Script" "Completed"
job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

