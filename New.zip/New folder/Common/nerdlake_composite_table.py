#!/usr/bin/python

import argparse
import logging
import sys

import nw_hive

parser = argparse.ArgumentParser()
parser.add_argument(
    "--base-field",
    required=True,
    help="Field name that has a unique value for each base table. For event tables this is 'event_name'.")

parser.add_argument(
    "--base-table",
    required=True,
    action="append",
    help="Base table, specified 1..N times. Format is 'TableName,BaseFieldValue' e.g., "
         + "dwnl_stage.HeartBeatEvent_s,HEARTBEAT_EVENT'")

parser.add_argument(
    "--composite-table",
    required=True,
    help="Table that will combine all base tables")

parser.add_argument(
    "--file-format",
    help="Format that the underlying files are in e.g., PARQUET or ORC")

args = parser.parse_args(sys.argv[1:])

"""
~/dwh/Common/nerdlake_composite_table.py \
    --base-field event_name \
    --base-table dwnl_workarea.all_events_s \
    --composite-table dwnl_stage.HeartBeatEvent_s,HEARTBEAT_EVENT
"""

if "." not in args.composite_table:
    print("Specify SCHEMA.TABLE_NAME for --composite-table")
    sys.exit(1)
consolidated_table_name = args.composite_table

base_tables = dict()
for base_table in args.base_table:
    table_name, base_field_value = base_table.split(",", 1)
    base_tables[table_name] = base_field_value

file_format = "PARQUET"
if args.file_format:
    file_format = args.file_format

# Set up the logger for PyHive for the WARNING level
logger = logging.getLogger("pyhive")
logger.setLevel(logging.WARNING)
ch = logging.StreamHandler()
ch.setLevel(logging.WARNING)
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
ch.setFormatter(formatter)
logger.addHandler(ch)

# Set up the logger for this program
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
ch.setFormatter(formatter)
logger.addHandler(ch)

logger.info("Execution begins")

hive_conn = nw_hive.connect(logger)

# ######################################################################################################################
# Verify that all columns in the base tables are in the consolidated table
# ######################################################################################################################

all_column_type = dict()
all_column_source = dict()
inconsistent_types = set()

# Retrieve metadata for all base tables and store the types in all_column_type
logger.info("Getting column names and types for all base tables")
for base_table in sorted(base_tables.keys(), key=lambda s: s.lower()):
    logger.info("  " + base_table)
    columns, partitioned_cols = nw_hive.get_hive_table_column_metadata(hive_conn, base_table)
    if len(partitioned_cols) != 1 or partitioned_cols[0] != "dw_eff_dt":
        logger.critical("    Table is not a single-level partitioned table, partitioned by DW_EFF_DT")
        sys.exit(1)
    for column in columns:
        if column["name"] in all_column_type:
            if all_column_type[column["name"]] != column["type"]:
                inconsistent_types.add(column["name"])
                logger.warning("{} has type {}, but was previously {}"
                               .format(column["name"], column["type"], all_column_type[column["name"]]))
        else:
            all_column_type[column["name"]] = column["type"]
        if column["name"] not in all_column_source:
            all_column_source[column["name"]] = []
        all_column_source[column["name"]].append(base_table.lower())
    logger.debug("    Found {} distinct columns so far".format(len(all_column_type)))

if not nw_hive.hive_table_exists(hive_conn, consolidated_table_name):
    logger.info("Creating consolidated table {}".format(consolidated_table_name))
    create_sql = "CREATE EXTERNAL TABLE `{}` (\n".format(consolidated_table_name)
    cols_to_create = []
    for col_name in sorted(all_column_type.keys()):
        if col_name in ["dw_eff_dt", args.base_field.lower()]:
            continue
        cols_to_create.append("`{}` {} COMMENT 'Found in {}'".format(
            col_name,
            all_column_type[col_name],
            ", ".join(sorted(all_column_source[col_name], key=lambda s: s.lower())).replace("'", "''")))
    create_sql += "\n,".join(cols_to_create) + "\n"
    create_sql += ")\n"
    create_sql += "PARTITIONED BY ( `{}` {}, dw_eff_dt date )\n".format(
        args.base_field, all_column_type[args.base_field.lower()])
    create_sql += "STORED AS {}\n".format(file_format)
    consolidated_table_schema, consolidated_base_table_name = consolidated_table_name.split(".", 1)
    create_sql += "LOCATION 's3://east1-prod-nerdlake-0/{}/{}/'".format(
        consolidated_table_schema, consolidated_base_table_name)
    print("\n{}\n".format(create_sql))
    nw_hive.exec_hive_sql_ddl(hive_conn, create_sql)
else:
    logger.info("Looking for columns to add")
    consolidated_columns, consolidated_partitioned_cols = nw_hive.get_hive_table_column_metadata(
        hive_conn, consolidated_table_name)
    cols_to_add = []  # List of columns that need to be added to the consolidated table
    comments_to_update = []  # List of comments that need to be updated on the consolidated table
    for col_name in sorted(all_column_type.keys()):
        if col_name in consolidated_partitioned_cols:
            continue

        correct_comment = "Found in {}".format(
            ", ".join(sorted(all_column_source[col_name], key=lambda s: s.lower())))
        if col_name in inconsistent_types:
            correct_comment = "WARNING: This column has inconsistent data types in the underlying files. " \
                + "Querying it may result in SQL errors."

        # Hive has a limit of 256 characters on comments. Trim the correct
        # comment down so we don't keep trying to update all comments that
        # should be longer than this.
        correct_comment = correct_comment[0:256]

        # If the column doesn't exist in the consolidated table, add it to the
        # list of columns to be added. If it does exist, make sure the comment
        # on the column is correct.
        if col_name not in [cons_col["name"] for cons_col in consolidated_columns]:
            cols_to_add.append("`{}` {} COMMENT '{}'".format(
                col_name,
                all_column_type[col_name],
                correct_comment.replace("'", "''")))
        else:
            current_comment = None
            for cons_col in consolidated_columns:
                if cons_col["name"] == col_name:
                    current_comment = cons_col["comment"]
                    break
            if current_comment is None or correct_comment != current_comment:
                update_stmt = "`{0}` `{0}` {1} COMMENT '{2}'".format(
                    col_name,
                    all_column_type[col_name],
                    correct_comment.replace("'", "''"))
                comments_to_update.append(update_stmt)

    if len(cols_to_add) > 0:
        logger.info("Adding columns: ".format(", ".join(cols_to_add)))
        add_col_sql = "ALTER TABLE `{}` ADD COLUMNS ({})".format(
            consolidated_table_name, ", ".join(cols_to_add))
        print("\n" + add_col_sql)
        nw_hive.exec_hive_sql_ddl(hive_conn, add_col_sql)

    for comment_to_update in comments_to_update:
        sql = "ALTER TABLE `{}` CHANGE {}".format(consolidated_table_name, comment_to_update)
        print("\n" + sql)
        nw_hive.exec_hive_sql_ddl(hive_conn, sql)


# ######################################################################################################################
# Verify that all partitions in all base tables are in the consolidated table
# ######################################################################################################################

# Get the list of partitions in the consolidated table and convert it to a dictionary
# for easier scanning
logger.info("Getting list of partitions from consolidated table {}".format(consolidated_table_name))
consolidated_partition_list = nw_hive.get_hive_table_partitions(hive_conn, consolidated_table_name)
consolidated_partitions = dict()
for part in consolidated_partition_list:
    part_cols = part.split("/")
    if len(part_cols) != 2:
        raise ValueError("Consolidated table must be partitioned with two fields, found {} instead".format(
            len(part_cols)))
    first_part_val = part_cols[0].split("=", 1)[1]
    second_part_val = part_cols[1].split("=", 1)[1]
    if first_part_val not in consolidated_partitions:
        consolidated_partitions[first_part_val] = {second_part_val}
    else:
        consolidated_partitions[first_part_val].add(second_part_val)

# Add and remove partitions for each base table
for base_table in sorted(base_tables.keys(), key=lambda s: s.lower()):
    base_field_val = base_tables[base_table]
    s3_location = None
    logger.info("Updating partitions for {}".format(base_table))
    base_table_partitions = nw_hive.get_hive_table_partitions(hive_conn, base_table)

    # Add partitions to the consolidated table
    parts_to_add = []
    for base_table_partition in sorted(base_table_partitions, key=lambda s: s.lower()):
        cnsl_part_value = "{}={}/{}".format(
            args.base_field, base_field_val, base_table_partition.encode('ascii', 'replace'))
        if cnsl_part_value not in consolidated_partition_list:
            if not s3_location:
                s3_location = nw_hive.get_hive_table_location(hive_conn, base_table).rstrip("/")
            parts_to_add.append(
                "PARTITION ({}='{}', dw_eff_dt='{}') LOCATION '{}'".format(
                    args.base_field,
                    base_field_val,
                    base_table_partition.encode('ascii', 'replace')[10:],
                    s3_location + "/" + base_table_partition.encode('ascii', 'replace')
                ))

    if len(parts_to_add) > 0:
        logger.info("  Adding {} partition(s)".format(len(parts_to_add)))
        alter_stmt = "ALTER TABLE {} ADD\n{}".format(
            consolidated_table_name,
            " \n".join(parts_to_add)
        )
        print("\n{}\n".format(alter_stmt))
        nw_hive.exec_hive_sql_ddl(hive_conn, alter_stmt)

    # Remove partitions from the consolidated table
    if base_field_val in consolidated_partitions:
        parts_to_drop = []
        for date_val in consolidated_partitions[base_field_val]:
            if "dw_eff_dt={}".format(date_val) in base_table_partitions:
                continue
            parts_to_drop.append("PARTITION ({}='{}', dw_eff_dt='{}')".format(
                args.base_field,
                base_field_val,
                date_val
            ))
        if len(parts_to_drop) > 0:
            logger.info("  Dropping {} partition(s)".format(len(parts_to_drop)))
            drop_sql = "ALTER TABLE {} DROP {}".format(
                consolidated_table_name,
                ",\n".join(parts_to_drop)
            )
            print("\n{}\n".format(drop_sql))
            nw_hive.exec_hive_sql_ddl(hive_conn, drop_sql)

logger.info("Disconnecting from Hive")
hive_conn.close()

logger.info("Execution ends")
