import argparse
import logging
import sys

import nw_hive
import nw_presto
from postgres_export import export_table

from redshift_modules import redshift_connect, get_table_columns

logging.basicConfig(format='[%(levelname)-8s]:%(asctime)s %(message)s', level=logging.DEBUG, datefmt='%Y/%m/%d %H:%M:%S')


def step01_choose_extract_mode(presto_conn, stage_table):
    """
    Check to see if records exist in stage table for current_date. If no records then run in full mode
    :param presto_conn: nw_presto connection
    :param stage_table: full table name
    :return:
    """
    logging.info('step01: Choosing extract mode (full_mode or partial_mode)')
    sql = 'SELECT COUNT(*)\n'
    sql += 'FROM {}\n'.format(stage_table)
    sql += 'WHERE dw_eff_dt = DATE(LOCALTIMESTAMP)'
    logging.debug("Step01 SQL:\n{}".format(sql))

    day_count = nw_presto.get_scalar_value(presto_conn, sql)
    logging.info('{} records in {}'.format(day_count, stage_table))

    if day_count == 0:
        extract_mode = 'full_mode'
    elif day_count > 0:
        extract_mode = 'partial_mode'
    else:
        logging.error('step01: unexpected day_count response, {}'.format(day_count))
        sys.exit(1)

    logging.info('step01: Postgres export running in {}'.format(extract_mode))

    return extract_mode


def step02_create_hive_pre_stage_table(hive_conn, pre_stage_table, idb_columns_desc):
    schema, table_name = pre_stage_table.split('.')[1:]
    hive_fq_table_name = '.'.join([schema, table_name])

    logging.info("Step02: Dropping and recreating {}".format(hive_fq_table_name))

    nw_hive.drop_delete_table(hive_conn, hive_fq_table_name)

    hive_cols = [col_item['name'] + ' string' for col_item in idb_columns_desc]

    sql = 'CREATE TABLE {} (\n'.format(hive_fq_table_name)
    sql += '    ' + ',\n    '.join(hive_cols)
    sql += '\n)\n'
    sql += 'ROW FORMAT SERDE \'org.apache.hadoop.hive.serde2.OpenCSVSerde\'\n'
    sql += 'WITH SERDEPROPERTIES (\n'
    sql += '\'separatorChar\' = \',\',\n'
    sql += '\'quoteChar\' = \'"\'\n)\n'
    sql += 'LOCATION \'s3://east1-prod-nerdlake-0/{schema}/{table_name}\''.format(schema=schema, table_name=table_name)

    nw_hive.exec_hive_sql_ddl(hive_conn, sql)
    logging.info("Step02: {} dropped and recreated".format(hive_fq_table_name))


def step03_postgres_export(server, port, database, username, idb_profile, s3_output, extract_columns, where_clause,
                           extract_mode, force_full_extract):
    """
    Extract records from identity db and export them to s3 location of pre-stage table
    :param server: idb server
    :param port: idb port
    :param database: idb database name
    :param username: idb username
    :param idb_profile: idb profile name
    :param s3_output: s3 output path for postgres export
    :param extract_columns: list of columns to extract
    :param where_clause: Where clause to use in partial mode
    :param extract_mode: Full or partial mode
    :return: nada
    """
    logging.info('Step02: Running postgres export from Identity DB in {}'.format(extract_mode))

    if extract_mode == 'full_mode' or force_full_extract:
        where_clause = None
    else:
        where_clause = where_clause

    export_table(
        server=server,
        port=port,
        database=database,
        username=username,
        table_name=idb_profile,
        output=s3_output,
        columns=extract_columns,
        where_clause=where_clause,
        compress_output=True,
        skip_header=True)
    logging.info('Step02: Postgres export complete'.format(extract_mode))


def step04_stage_insert(presto_conn, stage_table_cols, stage_table, pre_stage_trans_cols, pre_stage_table):
    """
    Insert records from pre_stage table to stage table
    :param presto_conn: nw_preto connection
    :param stage_table_cols: stage table columns
    :param stage_table: stable table full name
    :param pre_stage_trans_cols: pre stage columns after being transformed
    :param pre_stage_table: full pre_stage table name
    :return:
    """
    logging.info('Step03: Insert records from {} to {}'.format(pre_stage_table, stage_table))
    sql = 'INSERT INTO {}(\n'.format(stage_table)
    sql += '{}\n)\n'.format(',\n'.join(col for col in stage_table_cols))
    sql += 'SELECT\n'
    sql += '  {}\n'.format(',\n  '.join(col for col in pre_stage_trans_cols))
    sql += 'FROM {} stg\n'.format(pre_stage_table)
    logging.debug(sql)

    res = nw_presto.insert_rows(presto_conn, sql)
    logging.info('Step03: {} records inserted into {}'.format(res, stage_table))


def pre_stage_column_transformation(stage_cols, extract_mode, idb_profile):
    """
    All pre stage columns stored as strings. must be transformed to handle casting to specific types
    :param stage_cols: raw stage column names.
    :param extract_mode: Full or partial mode (used for load timestamps)
    :return:
    """

    if idb_profile == 'yodlee_transactions':
        stage_cols = map(lambda y: (y[0].replace('calc_date', 'date'), y[1]), stage_cols)

    if idb_profile == 'yodlee_credit_accounts':
        stage_cols = map(lambda y: (y[0].replace('interest_rate', 'apr'), y[1]), stage_cols)

    output_columns = []
    for column, column_type in stage_cols:
        if column == 'dw_load_ts':
            if extract_mode == 'full_mode':
                dw_ts_column = 'DATE_TRUNC(\'DAY\', LOCALTIMESTAMP) AS dw_load_ts'
            else:
                dw_ts_column = 'LOCALTIMESTAMP AS dw_load_ts'
            output_columns.append(dw_ts_column)
        elif column == 'dw_eff_dt':
            dw_dt_column = 'DATE(LOCALTIMESTAMP) AS dw_eff_dt'
            output_columns.append(dw_dt_column)
        elif column_type == 'decimal(18,6)':
            decimal_column = 'CAST(nullif(nullif({}, \'NaN\'), \'\') AS DECIMAL(18,6))'.format(column)
            output_columns.append(decimal_column)
        elif column_type == 'timestamp':
            ts_column = string_to_timestamp(column)
            output_columns.append(ts_column)
        elif column_type == 'bigint':
            biging_column = 'CAST(nullif({}, \'\') AS BIGINT)'.format(column)
            output_columns.append(biging_column)
        elif column_type in ('int', 'integer'):
            int_column = 'CAST(nullif({}, \'\') AS INT)'.format(column)
            output_columns.append(int_column)
        elif column_type == 'date':
            dt_column = 'DATE(\n'
            dt_column += string_to_timestamp(column)
            dt_column += ')'
            output_columns.append(dt_column)
        elif column_type == 'boolean':
            boolean_column = 'CAST(nullif({}, \'\') AS BOOLEAN)'.format(column)
            output_columns.append(boolean_column)
        elif column == 'id':
            id_column = 'stg.id'
            output_columns.append(id_column)
        else:
            null_column = 'nullif({}, \'\')'.format(column)
            output_columns.append(null_column)

    return output_columns


def string_to_timestamp(column_nm):
    ts_column = 'CASE\n'
    ts_column += '    WHEN length({col}) > 19 THEN date_parse(nullif({col}, \'\'), \'%Y-%m-%d %H:%i:%s.%f\')\n'
    ts_column += '    WHEN length({col}) <= 19 AND length({col}) >10 THEN date_parse(nullif({col}, \'\'), \'%Y-%m-%d %H:%i:%s\')\n'
    ts_column += '    ELSE date_parse(nullif({col}, \'\'), \'%Y-%m-%d\')\n'
    ts_column += 'END'

    return ts_column.format(col=column_nm)


def export(server, port, database, username, idb_profile, s3_output, where_clause, stage_table, pre_stage_table,
           force_full_extract):
    logging.info('Beginning export from IDB to S3 for {}'.format(idb_profile))

    presto_conn = nw_presto.connect()
    hive_conn = nw_hive.connect()
    identity_conn = redshift_connect(input_db='identity')

    # stage table columns for postgres extract
    stage_columns_desc = nw_presto.get_column_names(presto_conn, stage_table, include_type=True)
    stage_columns = [col[0] for col in stage_columns_desc]

    idb_columns_desc = get_table_columns(identity_conn, 'public.' + idb_profile)
    idb_columns = [col_item['name'] for col_item in idb_columns_desc]

    # query control table to determine if in full or partial mode
    extract_mode = step01_choose_extract_mode(presto_conn, stage_table)

    # Drop and recreate pre-stage table
    step02_create_hive_pre_stage_table(hive_conn, pre_stage_table, idb_columns_desc)

    # Export data from identity postgres db to s3
    step03_postgres_export(server, port, database, username, idb_profile, s3_output, idb_columns, where_clause,
                           extract_mode, force_full_extract)

    # Insert pre_stage into stage
    pre_stage_trans_cols = pre_stage_column_transformation(stage_columns_desc, extract_mode, idb_profile)
    step04_stage_insert(presto_conn, stage_columns, stage_table, pre_stage_trans_cols, pre_stage_table)


if __name__ == '__main__':
    logging.getLogger('boto').setLevel(logging.WARNING)
    logging.getLogger('botocore').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    parser = argparse.ArgumentParser(description='Extract profiles from Identity Database into s3')
    parser.add_argument('--server', required=True)
    parser.add_argument('--port', required=True)
    parser.add_argument('--database', required=True)
    parser.add_argument('--username', required=True)
    parser.add_argument('--idb_profile', required=True)
    parser.add_argument('--s3_output', required=True)
    parser.add_argument('--where_clause', required=False)
    parser.add_argument('--stage_table', required=True)
    parser.add_argument('--pre_stage_table', required=True)
    parser.add_argument('--force_full_extract', action="store_true", required=False)

    args = parser.parse_args()
    logging.debug(args)
    logging.info('Begin IDB extract of {}'.format(args.idb_profile))
    export(
        server=args.server,
        port=args.port,
        database=args.database,
        username=args.username,
        idb_profile=args.idb_profile,
        s3_output=args.s3_output,
        where_clause=args.where_clause,
        stage_table=args.stage_table,
        pre_stage_table=args.pre_stage_table,
        force_full_extract=args.force_full_extract
    )
    logging.info('Extract complete.')
