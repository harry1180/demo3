#!/usr/bin/python

# Purpose: This script removes old subdirectories under a table's directory on
#          S3. Some tables are rebuilt hourly and we keep the contents in a
#          timestamped subdirectory so that we don't have to copy data from
#          dwnl_stage to dwnl_data. This script cleans up old subdirectories.

import logging
logging.basicConfig(format="[%(asctime)s] %(message)s", level=logging.INFO)

import re
import sys

import nw_hive
import s3_modules

if len(sys.argv) != 2:
    print("Usage: remove_nerdlake_table_subdirs.py <tablename>")
    sys.exit(1)

hive_table_name = sys.argv[1]

if "." not in hive_table_name:
    print("ERROR: Hive table name must contain a '.': {}".format(hive_table_name))
    sys.exit(1)

logging.info("Execution begins")

s3_bucket = "east1-prod-nerdlake-0"
s3_key_prefix = hive_table_name.replace(".", "/") + "/"

# Get the location of our DWNL_DATA table
hive_conn = nw_hive.connect();
hive_table_location = nw_hive.get_hive_table_location(hive_conn, hive_table_name);
hive_conn.close()
logging.info("Location of {}: {}".format(hive_table_name, hive_table_location))

location_regex_match = re.match(r"^s3://[^/]+/([^/]+)/([^/]+)/([^/]+)$", hive_table_location)
if location_regex_match is None:
    logging.critical("Unexpected location")
    sys.exit(1)

loc_schema = location_regex_match.group(1)
loc_table_name = location_regex_match.group(2)
loc_timestamp = location_regex_match.group(3)
loc_key = "{}/{}/{}".format(loc_schema, loc_table_name, loc_timestamp)

if hive_table_name != "{}.{}".format(loc_schema, loc_table_name):
    logging.critical("S3 location's path doesn't match table and schema")
    sys.exit(1)

if not re.match(r"^\d\d\d\d\.\d\d.\d\d.\d\d.\d\d.\d\d$", loc_timestamp):
    logging.critical("S3 location's lowest-level subdirectory [[{}]] doesn't look like a timestamp".format(loc_timestamp))
    sys.exit(1)

# Scan all keys under our main directory and look for folder keys and subdirectories
logging.info("Getting all keys under s3://{}/{}".format(s3_bucket, s3_key_prefix))
candidate_keys = s3_modules.list_s3_keys(s3_bucket=s3_bucket, from_s3_string=s3_key_prefix)
logging.info("Found {} S3 keys".format(len(candidate_keys)))
folder_keys = set()
sub_dirs = set()
for candidate_key in candidate_keys:
    logging.debug("    Key: {}".format(candidate_key))
    if candidate_key[-9:] == "_$folder$":
        folder_keys.add(candidate_key)
        continue
    if "/" in candidate_key[len(s3_key_prefix):]:
        slash_pos = candidate_key.index("/", len(s3_key_prefix))
        sub_dir = candidate_key[0:slash_pos]
        if re.match(r"^.*/\d\d\d\d.\d\d.\d\d.\d\d.\d\d.\d\d", sub_dir):
            sub_dirs.add(sub_dir)
        continue

if len(folder_keys) > 0:
    logging.info("Folder keys:")
    for folder_key in sorted(folder_keys):
        logging.info("    " + folder_key)

if len(sub_dirs) > 0:
    logging.info("Sub-directories:")
    for sub_dir in sorted(sub_dirs):
        msg = "    " + sub_dir
        if sub_dir == loc_key:
            msg += " ({} points here)".format(hive_table_name)
        logging.info(msg)

# TODO: Remove all of the folder keys.

# Remove the production table location from the list of keys to do cleanup on
if loc_key in sub_dirs:
    sub_dirs.remove(loc_key)
else:
    logging.warn("Subdirectory {} does not exist on S3".format(loc_key))

# Remove all but the 3 most recent subdirectories
logging.info("Removing all but the 3 most recent non-production subdirectories")
if len(sub_dirs) <= 3:
    logging.info("Nothing to do")
    logging.info("Execution ends")
    sys.exit(0)

dirs_to_delete = sorted(sub_dirs, reverse=True)[3:]
for dir_to_delete in dirs_to_delete:
    logging.info("Removing: {}/*".format(dir_to_delete))
    s3_modules.delete_key(s3_bucket=s3_bucket, from_s3_string=dir_to_delete)

logging.info("Execution ends")
