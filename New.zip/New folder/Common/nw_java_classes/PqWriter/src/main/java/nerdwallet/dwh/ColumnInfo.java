package nerdwallet.dwh;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicIntegerArray;

public class ColumnInfo {
  public String srcName;
  public String pqName;
  public String pqType;
  public String hvType;
  public long   colIdx;

  public String pbName;    // null when a ++ column or control column
  public String pbType;    // ditto

  public boolean            isEnrichedColumn;
  public long               maxFieldLength;
  public AtomicLong         sumFieldLength;
  public AtomicLong         recordCount;
  public long               memstoreBytes;
//  public HashMap<>          badchars;

  public long colPages;
  public long colRawBytes;
  public long colCompressedBytes;
  public long dictEntries;
  public long dictRawBytes;
  public long dictCompressedBytes;
  public long rowgroups;

  /*
   * From the Spark SQL docs:
   *     When reading from and writing to Hive metastore Parquet tables, Spark SQL will try
   *     to use its own Parquet support instead of Hive SerDe for better performance.
   *     This behavior is controlled by the spark.sql.hive.convertMetastoreParquet
   *     configuration, and is turned on by default.
   * https://spark.apache.org/docs/latest/sql-programming-guide.html#hive-metastore-parquet-table-conversion
   *
   * However, Hive is case insensitive, while Parquet is not. So using Spark SQL's Parquet support
   * with our Hive metastore can lead to field mismatch when names have mixed case. Yet we still want to
   * use that over Hive SerDe for the better performance. The solution then is to always write parquet
   * field names in lowercase since they will be lowercased in the metastore anyway. We will make the
   * reasonable assumption that protobuf messages never contain fields that have the same lower case name.
   */

  public ColumnInfo(String srcName, String pqName, String type) throws UnsupportedOperationException {

    if(_colsByPqName.containsKey(pqName)) {
      throw new UnsupportedOperationException("*** DUPLICATE FIELD NAME " + pqName + " DETECTED ***  " +
        "FYI, DWH has an agreement with PIE that we shall not reuse field names in the same message.  " +
        "For example, a toplevel message cannot contain a field named 'region' since it's already " +
        "used in EventHeader.GeoHeader.");
    }

    this.srcName        = srcName;
    this.pqName         = pqName;
    pqType              = type;
    hvType              = null;
    colIdx              = _colsByIndx.size();

    pbName              = null;
    pbType              = null;

    isEnrichedColumn    = false;
    maxFieldLength      = 0;
    sumFieldLength      = new AtomicLong(0);
    recordCount         = new AtomicLong(0);
    memstoreBytes       = 0;
//  badchars      = new HashMap<>();

    dictEntries         = 0;
    dictRawBytes        = 0;
    dictCompressedBytes = 0;
    colPages            = 0;
    colRawBytes         = 0;
    colCompressedBytes  = 0;
    rowgroups           = 0;

    _colsBySrcName.put(srcName, this);
    _colsByPqName.put(pqName, this);
    _colsByIndx.add(this);
  }

  public void recordProtobufInfo(String name, String type) {
    pbName = name;
    pbType = type;
  }

  public void recordHiveType(String type) {
    hvType = type;
  }

  public void recordIsEnrichedColumn() {
    isEnrichedColumn = true;
  }

  public void recordColInfo(long pages, long raw, long compressed, long lastColMemStore) {
    colPages            += pages;
    colRawBytes         += raw;
    colCompressedBytes  += compressed;
    memstoreBytes        = lastColMemStore;
    rowgroups++;
  }

  public void recordDictInfo(long entries, long raw, long compressed) {
    dictEntries         += entries;
    dictRawBytes        += raw;
    dictCompressedBytes += compressed;
  }

  public void observeField(String f) {
    if(f == null) { return; }

    int length = f.length();

    sumFieldLength.addAndGet(length);
    recordCount.incrementAndGet();

    synchronized(this) {
      if(length > maxFieldLength) { maxFieldLength = length; }
    }
  }


  static protected HashMap<String, ColumnInfo> _colsBySrcName = new HashMap<String, ColumnInfo>();
  static protected HashMap<String, ColumnInfo> _colsByPqName = new HashMap<String, ColumnInfo>();
  static protected ArrayList<ColumnInfo>       _colsByIndx = new ArrayList<ColumnInfo>();

  static ColumnInfo getInstanceBySrcName(String srcName) {
    return _colsBySrcName.get(srcName);
  }

  static ColumnInfo getInstanceByPqName(String pqName) {
    return _colsByPqName.get(pqName);
  }

  static ColumnInfo getInstance(int index) {
    return _colsByIndx.get(index);
  }

  static List<ColumnInfo> getOrderedList() {
    return _colsByIndx;
  }

  static int size() {
    return _colsByIndx.size();
  }

  static List<Map<String, Object>> serializeAllInstances() {
    // i couldn't make JSONStreamAware work
    List<Map<String, Object>> a = new ArrayList<Map<String, Object>>(_colsByIndx.size());

    for(int i=0; i < _colsByIndx.size(); i++) {
      ColumnInfo                   ci = _colsByIndx.get(i);
      Map<String, Object> o = new LinkedHashMap<String, Object>(17);

      o.put("pqName",              ci.pqName);
      o.put("pqType",              ci.pqType);
      o.put("hvType",              ci.hvType);
      o.put("colIdx",              ci.colIdx);
      o.put("pbName",              ci.pbName);
      o.put("pbType",              ci.pbType);
      o.put("isEnrichedColumn",    ci.isEnrichedColumn);
      o.put("maxFieldLength",      ci.maxFieldLength);
      o.put("sumFieldLength",      ci.sumFieldLength);
      o.put("recordCount",         ci.recordCount); // probably not useful
      o.put("memstoreBytes",       ci.memstoreBytes);
      // badchars
      o.put("colPages",            ci.colPages);
      o.put("colRawBytes",         ci.colRawBytes);
      o.put("colCompressedBytes",  ci.colCompressedBytes);
      o.put("dictEntries",         ci.dictEntries);
      o.put("dictRawBytes",        ci.dictRawBytes);
      o.put("dictCompressedBytes", ci.dictCompressedBytes);
      o.put("rowgroups",           ci.rowgroups);

      a.add(o);
    }
    return a;
  }

}
