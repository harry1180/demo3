package nerdwallet.dwh;

import com.google.protobuf.Descriptors.FieldDescriptor.JavaType;
import com.google.protobuf.Descriptors;
import com.google.protobuf.Message;
import com.twitter.elephantbird.util.Protobufs;
import java.util.StringTokenizer;
import nerdwallet.dwh.ColumnInfo;
import nerdwallet.dwh.PythonDictEnricher;
import org.apache.parquet.schema.MessageType;
import org.apache.parquet.schema.MessageTypeParser;
import org.apache.parquet.schema.OriginalType;
import org.apache.parquet.schema.PrimitiveType.PrimitiveTypeName;
import org.apache.parquet.schema.Type;
import org.apache.parquet.schema.Types.GroupBuilder;
import org.apache.parquet.schema.Types.Builder;
import org.apache.parquet.schema.Types;
import java.util.List;

/**
 * Converts a Protocol Buffer Descriptor into a Parquet schema.  
 *
 * It also collapses sub-messages into first-level column names ... This is okay because we don't have 'repeated message' structure in
 * our protobuf schemata, and we also don't appear to have reused names amongst objects, either.  
 *
 * Originally, I tried cloning and modifying org.apache.parquet.proto.ProtoSchemaConverter, but it wasn't really easy to add the 
 * 'collapse' logic so I just gave up and refactored it and got to a simpler, happier place.  
 */

public class Pb2PqSchema {
  static MessageType _cachedSchema;
  static String extraFieldsSchema;

  public static MessageType getDestPqSchema(Class<? extends Message> protobufClass, PythonDictEnricher enricher) {
    if(_cachedSchema != null) {
      return _cachedSchema;
    }

    Descriptors.Descriptor descriptor = Protobufs.getMessageDescriptor(protobufClass);

    GroupBuilder bld = Types.buildMessage();

    for(Descriptors.FieldDescriptor tlDesc : descriptor.getFields()) {
      convertProtobufField(bld, tlDesc, Type.Repetition.REQUIRED, enricher, null);
    }

    MessageType base    = (MessageType) bld.named(descriptor.getFullName());
    MessageType control = MessageTypeParser.parseMessageType(getControlFields(protobufClass));
    MessageType addins  = MessageTypeParser.parseMessageType(getNewFields(protobufClass, enricher));
    MessageType merged  = base.union(control).union(addins);

    _cachedSchema = merged;
    return merged;
  }


  protected static String getControlFields(Class<? extends Message> protobufClass) {
    Descriptors.Descriptor descriptor = Protobufs.getMessageDescriptor(protobufClass);

    ColumnInfo ci;
    ci = new ColumnInfo("dw_eff_dt",        "dw_eff_dt",        "INT32 (DATE)"); ci.recordHiveType("DATE");
    ci = new ColumnInfo("dw_load_ts",       "dw_load_ts",       "INT96"); ci.recordHiveType("TIMESTAMP");
    ci = new ColumnInfo("dw_last_updt_ts",  "dw_last_updt_ts",  "INT96"); ci.recordHiveType("TIMESTAMP");
    ci = new ColumnInfo("dw_last_updt_tx",  "dw_last_updt_tx",  "BINARY (UTF8)"); ci.recordHiveType("STRING");

    StringBuilder sb = new StringBuilder().append("message ").append(descriptor.getFullName()).append("{\n")
                       .append("  required int32  dw_eff_dt       (DATE);\n")
                       .append("  required int96  dw_load_ts;\n")
                       .append("  optional int96  dw_last_updt_ts;\n")
                       .append("  optional binary dw_last_updt_tx (UTF8);\n")
                       .append("}\n");
    return sb.toString();
  }


  protected static String getNewFields(Class<? extends Message> protobufClass, PythonDictEnricher enricher) {
    Descriptors.Descriptor descriptor = Protobufs.getMessageDescriptor(protobufClass);
    List<String> newcols = enricher.getSchemaAdditions();

    StringBuilder sb = new StringBuilder().append("message ").append(descriptor.getFullName()).append("{\n");
    for(int i=0; i < newcols.size(); i++) {
      StringTokenizer st = new StringTokenizer(newcols.get(i));
      int tokens = st.countTokens();
      if(tokens < 3 || tokens > 4) { throw new UnsupportedOperationException("protobuf string is not valid: " + newcols.get(i)); }

      String cardin = st.nextToken().toUpperCase();
      String type = st.nextToken().toUpperCase();
      String name = st.nextToken();
      String typeModifier = "";
      if(st.hasMoreTokens()) {
          typeModifier = " " + st.nextToken().toUpperCase();
      }
      String fulltype = cardin + " " + type + typeModifier;

      ColumnInfo ci = new ColumnInfo(name, snakeCase(name), fulltype);
      ci.recordHiveType( hiveTypeFromPqType(fulltype) );
      ci.recordIsEnrichedColumn();

      // "parquet types" "msas" is an abbreviation for the following
      if(type.equals("MSAS")) {
        sb.append(String.format("  %s GROUP %s (MAP) {\n" +
                                "    REPEATED GROUP key_value {\n" +
                                "      REQUIRED BINARY key (UTF8);\n" +
                                "      OPTIONAL GROUP value (LIST) {\n" +    // REPEATED BINARY value (UTF8) is not allowed, see LogicalTypes.md
                                "        REPEATED GROUP list {\n" +
                                "          OPTIONAL BINARY element (UTF8);\n" +
                                "        }\n" +
                                "      }\n" +
                                "    }\n" +
                                "  }\n", cardin, ci.pqName));
      }
      // "parquet types" "amss" is an abbreviation for the following
      else if(type.equals("AMSS")) {
        sb.append(String.format("  %s GROUP %s (LIST) {\n" +
                                "    REPEATED GROUP list {\n" +
                                "      REQUIRED GROUP map (MAP) {\n" +
                                "        REPEATED GROUP key_value {\n" +
                                "          REQUIRED BINARY key (UTF8);\n" +
                                "          OPTIONAL BINARY value (UTF8);\n" +
                                "        }\n" +
                                "      }\n" +
                                "    }\n" +
                                "  }\n", cardin, ci.pqName));
      } else {
        String fieldDescription = cardin + " " + type + " " + ci.pqName + typeModifier;
        sb.append("  ").append(fieldDescription).append(";\n");
      }

    }
    sb.append("}\n");

    extraFieldsSchema = sb.toString();
    return extraFieldsSchema;
  }


  protected static GroupBuilder convertProtobufField(GroupBuilder bld, Descriptors.FieldDescriptor descriptor, 
                                                     Type.Repetition parentRepetition, PythonDictEnricher enricher, String parents) {

      Type.Repetition card     = getProtobufRepetition(descriptor); // "cardinatity" of the field: required/optional/repeated
      JavaType        javaType = descriptor.getJavaType();
      ColumnInfo      ci       = null;
      String          srcName  = descriptor.getName();
      String          colName  = snakeCase(srcName);
      String          colPbName;

      if(parents == null) { colPbName = srcName; }
                     else { colPbName = parents + "." + srcName; }

      String nameOverride = enricher.getNameOverride(descriptor.getFullName());
      if (nameOverride != null) {
          srcName = nameOverride;
          colName = nameOverride;
      }

      String typeOverride = enricher.getTypeOverride(descriptor.getFullName());
      if (typeOverride != null && typeOverride.equals("timestamp")) {
          ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "INT96"));
          ci.recordProtobufInfo(colPbName, addPbPqCard(card, "LONG"));
          ci.recordHiveType("TIMESTAMP");
          bld.primitive(PrimitiveTypeName.INT96, card).named(ci.pqName);
          return bld;
      }

      Boolean requiredOverride = enricher.getRequiredOverride(descriptor.getFullName());
      if (requiredOverride != null) {
          if (requiredOverride) {
              card = Type.Repetition.REQUIRED;
          } else {
              card = Type.Repetition.OPTIONAL;
          }
      }

      if(parentRepetition == Type.Repetition.OPTIONAL && card == Type.Repetition.REQUIRED) {
        // if the parent record is optional, then as a child, all of my fields are optional.  That is unless the child field is repeated,
        // which supports zero-length repetitions / arrays
        card = Type.Repetition.OPTIONAL;
      }

      if(descriptor.isExtension()) {
        throw new UnsupportedOperationException("Cannot convert Protobuf message with extension field(s)");
      }

      // Originally, I used bld.primitive(...,card).id(VerySimpleCounter.pop()).named(descriptor.getName()); but the id didn't seem
      //                                            ----------------------------
      // to matter that much, and just to avoid cases with non-numbered fields in the PqWriteSupport, I removed here.  Also it removes 
      // the challenge of numbering new "++" fields.    

      switch (javaType) {
        case BOOLEAN:      ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "BOOLEAN"));
                           ci.recordProtobufInfo(colPbName, addPbPqCard(card, "BOOLEAN"));
                           ci.recordHiveType(hiveTypeFromPqType(ci.pqType));
                           primitiveOrList(bld, PrimitiveTypeName.BOOLEAN, card).named(ci.pqName);
                           break;

        case INT:          ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "INT32"));
                           ci.recordProtobufInfo(colPbName, addPbPqCard(card, "INT"));
                           ci.recordHiveType(hiveTypeFromPqType(ci.pqType));
                           primitiveOrList(bld, PrimitiveTypeName.INT32, card).named(ci.pqName);
                           break;

        case LONG:         ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "INT64"));
                           ci.recordProtobufInfo(colPbName, addPbPqCard(card, "LONG"));
                           ci.recordHiveType(hiveTypeFromPqType(ci.pqType));
                           primitiveOrList(bld, PrimitiveTypeName.INT64, card).named(ci.pqName);
                           break;

        case FLOAT:        ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "FLOAT"));
                           ci.recordProtobufInfo(colPbName, addPbPqCard(card, "FLOAT"));
                           ci.recordHiveType(hiveTypeFromPqType(ci.pqType));
                           primitiveOrList(bld, PrimitiveTypeName.FLOAT, card).named(ci.pqName);
                           break;

        case DOUBLE:       ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "DOUBLE"));
                           ci.recordProtobufInfo(colPbName, addPbPqCard(card, "DOUBLE"));
                           ci.recordHiveType(hiveTypeFromPqType(ci.pqType));
                           primitiveOrList(bld, PrimitiveTypeName.DOUBLE, card).named(ci.pqName);
                           break;

        case BYTE_STRING:  ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "BINARY"));
                           ci.recordProtobufInfo(colPbName, addPbPqCard(card, "BYTE_STRING"));
                           ci.recordHiveType(hiveTypeFromPqType(ci.pqType));
                           primitiveOrList(bld, PrimitiveTypeName.BINARY, card).named(ci.pqName);
                           break;

        case STRING:       ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "BINARY (UTF8)"));
                           ci.recordProtobufInfo(colPbName, addPbPqCard(card, "STRING"));
                           ci.recordHiveType(hiveTypeFromPqType(ci.pqType));
                           primitiveOrList(bld, PrimitiveTypeName.BINARY, card).as(OriginalType.UTF8).named(ci.pqName);
                           break;

        case ENUM:         ci = new ColumnInfo(srcName, colName, addPbPqCard(card, "BINARY (ENUM)"));
                           ci.recordProtobufInfo(colPbName, addPbPqCard(card, "ENUM"));
                           ci.recordHiveType(hiveTypeFromPqType(ci.pqType));
                           primitiveOrList(bld, PrimitiveTypeName.BINARY, card).as(OriginalType.ENUM).named(ci.pqName);
                           break;

        // instead of nesting objects as in ProtoSchemaConverter, this just descends the protobuf structure but doesn't create 'subobjects' in the parquet.  note that
        // this assumption is based on how submessages/subobjects in NW's protobuf ARE NEVER REPEATED, which they are not in 2016-12-06 and because we want to keep
        // table structure the same as we have today (collapsed).  
        case MESSAGE:  
                          if(card == Type.Repetition.REPEATED) {
                            throw new UnsupportedOperationException("Cannot convert repeating messages in this release of NwPb2Pq");
                          }
                          for(Descriptors.FieldDescriptor llDesc : descriptor.getMessageType().getFields()) {
                            convertProtobufField(bld, llDesc, card, enricher, colPbName);
                          }
                          break;

        default:          throw new UnsupportedOperationException("Cannot convert Protocol Buffer: unknown type " + javaType);
      }

    return bld;
  }

  // Turn camelCase field names to snake_case
  static String snakeCase(String s) {
      /*
       *  First pass: match uppercase char preceded by lowercase char
       *  Second pass: match lowercase char preceded by a group (len >= 2)
       *               of uppercase alphanumeric chars
       *
       *  NOTE: for special cases users can choose to apply a name override
       */
      s = s.replaceAll("([a-z])([A-Z])", "$1_$2");
      s = s.replaceAll("([0-9A-Z]+)([A-Z][a-z])", "$1_$2");
      return s.toLowerCase();
  }

  // Append a primitive type or a list type to the provided schema builder depending on the cardinality of the type
  protected static Builder primitiveOrList(GroupBuilder bld, PrimitiveTypeName type, Type.Repetition card) {
      if (card == Type.Repetition.REPEATED)
          return bld.optionalList().requiredElement(type);
      else
          return bld.primitive(type, card);
  }

  protected static Type.Repetition getProtobufRepetition(Descriptors.FieldDescriptor descriptor) {
    if (descriptor.isRequired()) {
      return Type.Repetition.REQUIRED;
    } else if (descriptor.isRepeated()) {
      return Type.Repetition.REPEATED;
    } else {
      return Type.Repetition.OPTIONAL;
    }
  }

  protected static String addPbPqCard(Type.Repetition card, String basetype) {
    if(card == Type.Repetition.REQUIRED) { return "REQUIRED " + basetype; }
    if(card == Type.Repetition.REPEATED) { return "REPEATED " + basetype; }
    return "OPTIONAL " + basetype;  // Type.Repetition.OPTIONAL
  }

  protected static String hiveTypeFromPqType(String pqType) {
    if(pqType.equals("OPTIONAL BOOLEAN"))       return "BOOLEAN";
    if(pqType.equals("OPTIONAL INT32"))         return "INT";
    if(pqType.equals("OPTIONAL INT64"))         return "BIGINT";
    if(pqType.equals("OPTIONAL INT96"))         return "TIMESTAMP";  // we're not using INT96 for anything else
    if(pqType.equals("OPTIONAL FLOAT"))         return "FLOAT";
    if(pqType.equals("OPTIONAL DOUBLE"))        return "DOUBLE";
    if(pqType.equals("OPTIONAL BINARY"))        return "BINARY";
    if(pqType.equals("OPTIONAL BINARY (UTF8)")) return "STRING";
    if(pqType.equals("OPTIONAL BINARY (ENUM)")) return "STRING";
    if(pqType.equals("OPTIONAL MSAS"))          return "MAP<STRING,ARRAY<STRING>>";
    if(pqType.equals("OPTIONAL AMSS"))          return "ARRAY<MAP<STRING,STRING>>";

    // Hive doesn't appear to have a "NOT NULL" DDL clause
    if(pqType.equals("REQUIRED BOOLEAN"))       return "BOOLEAN";
    if(pqType.equals("REQUIRED INT32"))         return "INT";
    if(pqType.equals("REQUIRED INT64"))         return "BIGINT";
    if(pqType.equals("REQUIRED INT96"))         return "TIMESTAMP";
    if(pqType.equals("REQUIRED FLOAT"))         return "FLOAT";
    if(pqType.equals("REQUIRED DOUBLE"))        return "DOUBLE";
    if(pqType.equals("REQUIRED BINARY"))        return "BINARY";
    if(pqType.equals("REQUIRED BINARY (UTF8)")) return "STRING";
    if(pqType.equals("REQUIRED BINARY (ENUM)")) return "STRING";
    if(pqType.equals("REQUIRED MSAS"))          return "MAP<STRING,ARRAY<STRING>>";
    if(pqType.equals("REQUIRED AMSS"))          return "ARRAY<MAP<STRING,STRING>>";

    if(pqType.equals("REPEATED BOOLEAN"))       return "ARRAY<BOOLEAN>";
    if(pqType.equals("REPEATED INT32"))         return "ARRAY<INT>";
    if(pqType.equals("REPEATED INT64"))         return "ARRAY<BIGINT>";
    if(pqType.equals("REPEATED INT96"))         return "ARRAY<TIMESTAMP>";
    if(pqType.equals("REPEATED FLOAT"))         return "ARRAY<FLOAT>";
    if(pqType.equals("REPEATED DOUBLE"))        return "ARRAY<DOUBLE>";
    if(pqType.equals("REPEATED BINARY"))        return "ARRAY<BINARY>";
    if(pqType.equals("REPEATED BINARY (UTF8)")) return "ARRAY<STRING>";
    if(pqType.equals("REPEATED BINARY (ENUM)")) return "ARRAY<STRING>";

    // There are parquet types which haven't been mapped to hive types, because I don't have good
    // test data :)   Feel free to extend.  Pb files will still be generated, but the hive update
    // will croak.
    return "-UNSUPPORTED-";
  }

}
