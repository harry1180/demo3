package nerdwallet.dwh;

import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Message;
import com.google.protobuf.MessageOrBuilder;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigInteger;
import java.nio.file.InvalidPathException;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.python.core.PyDictionary;
import nerdwallet.dwh.Pb2PqParquetWriter;
import nerdwallet.dwh.PythonDictEnricher;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;
import org.apache.parquet.hadoop.ParquetWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Pb2PqSprayer {

  // we implement a lazy-instantiated map of timebucket to ParquetWriter instances so as to implement physical file-based
  // partitioning.  a timebucket is the number of days since the unix epoch, calculated from the protobuf's timestamp
  // field (assumed to be always present), using integer (long) division which truncates the fractional portion of the
  // timestamp.  new instances of ParquetWriter are created lazily.

  protected HashMap<Long, Pb2PqParquetWriter<Message>> writers;
  protected ArrayList<String> local_outputs;
  protected static final long msecInDay = 24 * 60 * 60 * 1000;

  protected String               outputtemplate;        // a java formatstring with y/m/d removed
  protected Long                 specifiedTimebucket;   // the y/m/d timebucket derived from input file

  protected Class<Message>       pbufclass;
  protected CompressionCodecName compname;
  protected PythonDictEnricher   pde;

  protected FieldDescriptor      fdHeader;
  protected FieldDescriptor      fdTimestamp;

  private static final Logger LOG = LoggerFactory.getLogger(Pb2PqSprayer.class);

  public Pb2PqSprayer(String inputfile, Class<Message> pbufclass, CompressionCodecName compname, PythonDictEnricher pde)
                      throws IllegalAccessException, InvalidPathException, InvocationTargetException, IOException, NoSuchMethodException {

    this.pbufclass     = pbufclass;
    this.compname      = compname;
    this.pde           = pde;
    this.local_outputs = new ArrayList<String>(2);
    this.writers       = new HashMap<Long, Pb2PqParquetWriter<Message>>();

    // local filename templates

    Matcher match = Pattern.compile( "(.*)input/(\\d*)/(\\d*)/(\\d*)/(.*)\\.[^.]*" ).matcher(inputfile);
    if(!match.matches()) {
      throw new InvalidPathException(inputfile, "Could not parse so as to be able to generate separate partition files.");
    }

    specifiedTimebucket = new GregorianCalendar(Integer.valueOf(match.group(2)),     // year
                                                Integer.valueOf(match.group(3)) - 1, // month
                                                Integer.valueOf(match.group(4)))     // day
                                               .getTimeInMillis() / msecInDay;

    /*
     * In the output file name, y/m/d are derived from the timestamp of the data itself
     * .../output/dw_eff_dt=yyyy-mm-dd/<srcInfo>.pq
     *
     * srcInfo is the dot separated subpath of the input protobuf file, eg: 2015.09.17.source_filename
     * This way, looking at the target file name, we can trace the data back to its source file
     */
    String srcInfo = match.group(2) + "." + match.group(3) + "." + match.group(4) + "." + match.group(5);
    outputtemplate = match.group(1) + "output/dw_eff_dt=%1$tY-%1$tm-%1$td/"  + srcInfo + ".pq";

    // cached field descriptors for the protobuf to get at timestamp

    Message pbufdim  = (Message) pbufclass.getMethod("getDefaultInstance").invoke(null);
    this.fdHeader    = pbufdim.getDescriptorForType().findFieldByName("header");
    // The protobuf class might not have a 'header' field
    if (this.fdHeader != null) {
        Message pbufdih  = (Message) pbufdim.getField(this.fdHeader);
        this.fdTimestamp = pbufdih.getDescriptorForType().findFieldByName("timestamp");
    }

    // always write out the file passed from python Emit_protobuf_enhanced, since it's used for skip logic.  Normally, the output filename
    // sent in from the python layer would have records in the file, but not always, especially when (say) PIE does backloading of data
    // after a logger / kafka / gobblin problem and puts the data in an unusual filename like backload.protobuf.

    getNewWriter(specifiedTimebucket);
  }

  public void close() throws IOException {
    for(Pb2PqParquetWriter<Message> mywriter : writers.values()) {
      mywriter.close();
    }
  }

  // Ignore records with _skipthisrecord = true
  protected boolean skipRecord(Message record) {
      // Apply custom event ++ logic
      PyDictionary enrichedDict = pde.getEnrichedValues((MessageOrBuilder)record);

      Boolean skip = (Boolean) enrichedDict.get("_skipthisrecord");
      if (skip == null) return false;
      else return skip.booleanValue();
  }

  // Returns true if message was written out, false otherwise
  public boolean write(Message t) throws IOException {
    // The result cached from the previous record should not be reused
    pde.clearCache();

    if (skipRecord(t)) return false;

    Pb2PqParquetWriter<Message> mywriter = null;

    Long timebucket;
    if (fdHeader != null) {
        Message header    = (Message) t.getField(fdHeader);
        Long    tsUtcMsec = (Long) header.getField(fdTimestamp);
        timebucket = tsUtcMsec / msecInDay;
    } else {
        Long zzz_timestamp = null;
        PyDictionary enrichedDict = pde.getEnrichedValues((MessageOrBuilder) t);
        Object po_zzz_timestamp = enrichedDict.get("zzz_timestamp");
        if (po_zzz_timestamp != null) {
            if (po_zzz_timestamp instanceof Long) {
                zzz_timestamp = (Long) po_zzz_timestamp;
            } else if (po_zzz_timestamp instanceof BigInteger) {
                zzz_timestamp = new Long(((BigInteger) po_zzz_timestamp).longValue());
            }
        }
        if (zzz_timestamp != null) {
            timebucket = zzz_timestamp / msecInDay;
        } else {
            timebucket = specifiedTimebucket;
        }
    }

    mywriter = writers.get(timebucket);
    mywriter = (mywriter != null) ? mywriter : getNewWriter(timebucket);

    LOG.debug("buckets {} {}", timebucket, specifiedTimebucket);

    mywriter.write(t);
    return true;
  }

  protected Pb2PqParquetWriter<Message> getNewWriter(Long timebucket) throws IOException {
    Pb2PqParquetWriter<Message> mywriter;

    String outfile = String.format(outputtemplate, timebucket * msecInDay);
    local_outputs.add(outfile);
    String uri_path = outfile;

    if (! uri_path.matches("^[a-zA-Z]+://.*$")) {
        // Ensure we have an absolute path and specify the uri scheme
        uri_path = "file://" + new File(uri_path).getCanonicalPath();
    }
    LOG.info("creating " + uri_path);

    mywriter = new Pb2PqParquetWriter<Message>(new Path(uri_path),
                                               pbufclass,
                                               compname,
                                               ParquetWriter.DEFAULT_BLOCK_SIZE,
                                               true,  // validating = yes
                                               new Configuration(),
                                               ParquetWriter.MAX_PADDING_SIZE_DEFAULT,
                                               pde);
    writers.put(timebucket, mywriter);
    return mywriter;
  }

  public ArrayList<String> partitions() {
      return local_outputs;
  }

}

