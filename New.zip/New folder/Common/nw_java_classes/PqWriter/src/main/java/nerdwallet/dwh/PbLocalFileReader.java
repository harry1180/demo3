package nerdwallet.dwh;

import com.google.protobuf.Message;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import nerdwallet.dwh.PbReader;

public class PbLocalFileReader<T extends Message> extends PbReader<T> {

  protected FileInputStream fis;

  public PbLocalFileReader(Class <? extends Message> clazz, String fname) throws FileNotFoundException {
    super(clazz, new FileInputStream(fname));
  }

}
