package nerdwallet.dwh;

public class VerySimpleCounter {
  int c;

  public VerySimpleCounter(int initval) {
    c = initval;
  }

  public int pop() {
    return c++;
  }
}

