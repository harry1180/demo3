package nerdwallet.dwh;

import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.twitter.elephantbird.util.Protobufs;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import nerdwallet.dwh.CapturingLogFilter;
import nerdwallet.dwh.ColumnInfo;
import nerdwallet.dwh.Pb2PqSprayer;
import nerdwallet.dwh.PythonDictEnricher;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.PatternLayout;
import org.apache.parquet.column.ParquetProperties;
import org.apache.parquet.hadoop.ParquetFileWriter;
import org.apache.parquet.hadoop.ParquetWriter;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;
import org.apache.parquet.schema.MessageType;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is the driver for the NerdWallet ProtocolBuf to Parquet converter.  
 *
 *
 * Some helpful docs:
 * 
 * The source of truth:     https://github.com/apache/parquet-format
 * Datatypes:               https://github.com/apache/parquet-format/blob/master/LogicalTypes.md
 * Encodings:               https://github.com/apache/parquet-format/blob/master/Encodings.md
 *                          (there's no clear API that allows for per-column config of encoding)
 * Mailing list:            dev@parquet.apache.org
 * Mailing list archives:   http://mail-archives.apache.org/mod_mbox/parquet-dev/
 * Timestamps (hive agony): https://github.com/apache/parquet-format/pull/49
 *                          http://grokbase.com/t/hive/user/1523p4rw0v/parquet-support-for-timestamp-in-0-14
 *                          https://issues.apache.org/jira/browse/HIVE-10642
 *                          http://stackoverflow.com/questions/28292876/hives-timestamp-is-same-as-parquets-timestamp
 *                          https://github.com/Parquet/parquet-mr/issues/218
 *
 */

public class Pb2PqWriter {
  private static final Logger LOG = LoggerFactory.getLogger(Pb2PqWriter.class);

  public static void main(String[] args) {
    Options opts = new Options();
    opts.addOption(Option.builder("i").required(true).longOpt("inputfile").hasArgs().valueSeparator(' ')
                  .desc("input protobuf file, can be repeated").build());
    opts.addOption(Option.builder("c").required(true).longOpt("protobufclass").hasArg()
                  .desc("protobuf java class, ie event.PageViewEventProto.PageViewEvent").build());
    opts.addOption(Option.builder("pyscript").hasArg()
                  .desc("path to the python helper script").build());
    opts.addOption(Option.builder("enrichfunc").hasArg()
                  .desc("python function which supplies ++ dictionaries").build());
    opts.addOption(Option.builder("pqschema").hasArg()
                  .desc("python list describing ++ parquet columns").build());
    opts.addOption(Option.builder("overrides").hasArg()
                  .desc("python list describing overrides").build());
    opts.addOption(Option.builder("compression").hasArg()
                  .desc("set the pq's internal rowgroup compression").build());
    opts.addOption(Option.builder("enrichglobal").hasArg()
            .desc("True or False, indicating if global enrichment should be applied to the deserialization").build());
    opts.addOption(Option.builder("v").hasArg().desc("log level: OFF, FATAL, ERROR, WARN, INFO, DEBUG, TRACE, ALL").build());
    opts.addOption(Option.builder("maxrecs").hasArg()
                  .desc("emit this many records from each source file (handy for debugging)").build());
    opts.addOption(Option.builder("h").desc("prints this message").build());

    CommandLineParser parser = new DefaultParser();
    HelpFormatter formatter = new HelpFormatter();
    CommandLine cmd;

    try {
      cmd = parser.parse(opts, args);
    } catch(ParseException e) {
      System.err.println(e.getMessage());
      formatter.printHelp("Pb2PqWriter", opts);
      System.exit(1);
      return;
    }

    if(cmd.hasOption("h")) {
      formatter.printHelp("Pb2PqWriter", opts);
      return;
    }

    String                 logformat = "%d{ISO8601} %-5p %c - %m%n";  // not using %x NDC (nested diag ctx)
    if(amiSystemUser())  { logformat = "%-5p %c - %m%n"; } // emit timestamp if running in airflow

    ConsoleAppender ca = new ConsoleAppender(new PatternLayout(logformat), ConsoleAppender.SYSTEM_ERR);
    if(cmd.hasOption("v")) {
      ca.setThreshold(Level.toLevel(cmd.getOptionValue("v")));
    } else {
      ca.setThreshold(Level.INFO);
    }
    ca.addFilter(new CapturingLogFilter());
    LogManager.getRootLogger().getLoggerRepository().resetConfiguration();
    LogManager.getRootLogger().addAppender(ca);
    LOG.info("Execution begins");

    LOG.info("Protocol Buffer class name: " + cmd.getOptionValue("c"));
    Class<Message> pbufclass = getPBufClass(cmd.getOptionValue("c"));
    if(pbufclass == null) {
      // diagnostics are printed by getPBufClass()
      System.exit(1);
      return;
    }

    long maxRecs = -1;
    if(cmd.hasOption("maxrecs")) {
      try {
        maxRecs = Long.valueOf(cmd.getOptionValue("maxrecs")).longValue();
      } catch(NumberFormatException e) {
        LOG.error("-maxrecs {} is not a valid argument", cmd.getOptionValue("maxrecs"));
        System.exit(1);
        return;
      }
      LOG.info("Maximum records: " + maxRecs);
    }

    CompressionCodecName compname = ParquetWriter.DEFAULT_COMPRESSION_CODEC_NAME;
    if(cmd.hasOption("compression")) {
      String compnames = cmd.getOptionValue("compression");
      if(compnames.equalsIgnoreCase("none")) { compnames = "UNCOMPRESSED"; }
      compname = CompressionCodecName.fromConf(compnames);
      LOG.info("Compression: " + compname);
    }

    // Determine if we should apply global enrichment or not, defaulting to "yes".
    boolean genericEnrich = true;
    if (cmd.hasOption("enrichglobal")) {
      genericEnrich = Boolean.parseBoolean(cmd.getOptionValue("enrichglobal"));
    }
    LOG.info("Generic Enrichment: " + genericEnrich);

    try {
      PythonDictEnricher pde = new PythonDictEnricher(cmd.getOptionValue("pyscript"),
                                                      cmd.getOptionValue("enrichfunc"),
                                                      cmd.getOptionValue("pqschema"),
                                                      cmd.getOptionValue("overrides"),
                                                      pbufclass.getName(),
                                                      genericEnrich);

      long recs_in = 0, recs_out = 0, recs_err = 0;
      java.util.Date convertStart = new java.util.Date();
      String[] inputfiles = cmd.getOptionValues("i");
      ArrayList<String> totalPartitions = new ArrayList<String>();

      for(int i=0; i < inputfiles.length; i++) {
        java.util.Date fileStart = new java.util.Date();
        LOG.info("Converting {}", inputfiles[i]);
        PbLocalFileReader pbfr = new PbLocalFileReader<Message>(pbufclass, inputfiles[i]);
        Pb2PqSprayer writer = new Pb2PqSprayer(inputfiles[i], pbufclass, compname, pde);

        while(true) {
          Message j = null;
          if(maxRecs != -1 && pbfr.getRecno() >= maxRecs) { break; }

          try {
            j = pbfr.getNextObj();
            if(j == null) { break; } // EOF
            recs_in++;

            if (writer.write(j))
                recs_out++;
          } catch(Throwable t) {
            recs_err++;
            LOG.warn("Unexpected exception thrown", t);
          }
        } // end over all records
        totalPartitions.addAll(writer.partitions());
        writer.close();
        java.util.Date fileEnd = new java.util.Date();
        double fileDuration = ((double) (fileEnd.getTime() - fileStart.getTime())) / 1000.0;
        LOG.info("    File conversion time: " + String.format("%.1f", fileDuration));
        double overallDuration = ((double) (fileEnd.getTime() - convertStart.getTime())) / 1000.0;
        double overallRecordsPerSecond = ((double) recs_in) / overallDuration;
        LOG.info("    Overall records/sec:  " + String.format("%.1f", overallRecordsPerSecond));
      } // end over all files

      LinkedHashMap<String, Object> outprops = new LinkedHashMap<String, Object>();
      outprops.put("files_in",            (Integer) inputfiles.length);
      outprops.put("records_in_counted",  (Long) recs_in);
      outprops.put("records_out_counted", (Long) recs_out);
      outprops.put("records_with_errors", (Long) recs_err);
      outprops.put("partitions",          totalPartitions);
      outprops.put("columns",             ColumnInfo.serializeAllInstances());
      outprops.putAll( getMemoryInfo() );

      // send back data to the python layer
      System.out.println(JSONValue.toJSONString(outprops));


    } catch(Throwable t) {
      LOG.error("Exception", t);
      System.exit(1);
    }
  } // main

  @SuppressWarnings("unchecked")
  static Class<Message> getPBufClass(String classname) {
    Class<Message> r = null;

    try {
      r = (Class<Message>) Class.forName(classname);
    } catch(ClassNotFoundException e) { System.err.println("Could not find protobuf class " + classname);
    } catch(ClassCastException e)     { System.err.println(classname + " does not derive from com.google.protobuf.Message");
    }

    return r;
  }

  static LinkedHashMap<String, Object> getMemoryInfo() throws PatternSyntaxException, IOException {
    int         BINMB = 1048576;
    int        KBINMB = 1024;

    long      lVmPeak = 0;
    long      lVmSize = 0;
    long      lRsPeak = 0;
    long      lRsSize = 0;

    String procstatus = new String(Files.readAllBytes(Paths.get("/proc/self/status")));
    Matcher   mVmPeak = Pattern.compile("(?s).*VmPeak:\\s*(\\d*)\\s*kB.*").matcher(procstatus);
    Matcher   mVmSize = Pattern.compile("(?s).*VmSize:\\s*(\\d*)\\s*kB.*").matcher(procstatus);
    Matcher   mVmHWM  = Pattern.compile( "(?s).*VmHWM:\\s*(\\d*)\\s*kB.*").matcher(procstatus);
    Matcher   mVmRSS  = Pattern.compile( "(?s).*VmRSS:\\s*(\\d*)\\s*kB.*").matcher(procstatus);

    if(mVmPeak.matches()) { try { lVmPeak = Long.parseLong( mVmPeak.group(1) ); } catch(Throwable t) { } }
    if(mVmSize.matches()) { try { lVmSize = Long.parseLong( mVmSize.group(1) ); } catch(Throwable t) { } }
    if(mVmHWM .matches()) { try { lRsPeak = Long.parseLong( mVmHWM .group(1) ); } catch(Throwable t) { } }
    if(mVmRSS .matches()) { try { lRsSize = Long.parseLong( mVmRSS .group(1) ); } catch(Throwable t) { } }

    Runtime r = Runtime.getRuntime();

    LinkedHashMap<String, Object> h = new LinkedHashMap<String, Object>(7);
    h.put("JvmLinuxRssMB",            (Long) lRsSize / KBINMB);
    h.put("JvmLinuxRssPeakMB",        (Long) lRsPeak / KBINMB);
    h.put("JvmLinuxVmMB",             (Long) lVmSize / KBINMB);
    h.put("JvmLinuxVmPeakMB",         (Long) lVmPeak / KBINMB);
    h.put("JvmReportedTotalMemoryMB", (Long) r.totalMemory() / BINMB);
    h.put("JvmReportedMaxMemoryMB",   (Long) r.maxMemory()   / BINMB);
    h.put("JvmReportedFreeMemoryMB",  (Long) r.freeMemory()  / BINMB);

    return h;
  }

  static boolean amiSystemUser() {
    // this is just used to have cleaner logging in airflow, not the best impl for sensitive operations!
    String homedir = System.getenv("HOME");

    if(homedir.equals("/home/airflow")) { return true; }
    if(homedir.equals("/home/etl"    )) { return true; }
    if(homedir.equals("/home/bai"    )) { return true; }

    return false;
  }

}

