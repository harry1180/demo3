package nerdwallet.dwh;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import nerdwallet.dwh.ColumnInfo;
import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CapturingLogFilter extends Filter {

  Pattern pqColPattern;
  Pattern pqDictPattern;
  Pattern pqMemPattern;
  long    lastMemColStore;

  private static final Logger LOG = LoggerFactory.getLogger(CapturingLogFilter.class);

  public CapturingLogFilter() {
    super();

    // written 91,080B for [userId] BINARY: 248,504 values, 90,864B raw, 90,864B comp, 3 pages, encodings: [PLAIN_DICTIONARY], dic { 433 entries, 17,289B raw, 433B comp}
    // Flushing mem columnStore to file. allocated memory: 28,788,173
    pqColPattern    = Pattern.compile("written [0-9,]*B for \\[([^]]*)\\] [^:]*: [0-9,]* values, ([0-9,]*)B raw, ([0-9,]*)B comp, ([0-9,]*) pages.*");
    pqDictPattern   = Pattern.compile(".*dic \\{ ([0-9,]*) entries, ([0-9,]*)B raw, ([0-9,]*)B comp\\}");
    pqMemPattern    = Pattern.compile(".*allocated memory: ([0-9,]*)");
    lastMemColStore = -1;
  }


  public int decide(LoggingEvent event) {
    if(event.getLoggerName().equals("org.apache.parquet.hadoop.ColumnChunkPageWriteStore")) {

      String msg = event.getRenderedMessage();
      if(msg == null) { return bye("ColumnChunkPageWriteStore gave us an empty logrecord", ACCEPT); }

      Matcher m1 =  pqColPattern.matcher(msg);
      if(!m1.matches()) { return bye("Unable to parse ColumnChunkPageWriteStore messages", ACCEPT); }

      String colname = m1.group(1);
      int      comma = colname.indexOf(',');
      ColumnInfo  ci = ColumnInfo.getInstanceByPqName( (comma == -1) ? colname : colname.substring(0, comma) );
      if(ci == null) { return bye("parquet-mr gave us logs for a column that we didn't define", ACCEPT); }

      long r = parseVal(m1.group(2));
      long c = parseVal(m1.group(3));
      long z = parseVal(m1.group(4));
      ci.recordColInfo(z, r, c, lastMemColStore);

      Matcher m2 = pqDictPattern.matcher(msg);
      if(m2.matches()) {
        z = parseVal(m2.group(1));
        r = parseVal(m2.group(2));
        c = parseVal(m2.group(3));
        ci.recordDictInfo(z, r, c);
      }

      lastMemColStore = -1;
      return DENY;
    }

    // there is a log message that gives the number of bytes internally by the parquet writer memory buffer
    // (i think, it's not really documented).  we bind it to the first column's columninfo, this is sloppy,
    // but gets the job done.  this means that the python that pulls out the emitted 'stats' json will need
    // to navigate to this value ...

    if(event.getLoggerName().equals("org.apache.parquet.hadoop.InternalParquetRecordWriter")) {
      String msg = event.getRenderedMessage();
      if(msg == null) { return bye("InternalParquetRecordWriter gave us an empty logrecord", ACCEPT); }

      Matcher m = pqMemPattern.matcher(msg);
      if(!m.matches()) { return bye("Unable to parse InternalParquetRecordWriter message: " + msg, ACCEPT); }

      lastMemColStore = parseVal(m.group(1));
      return DENY;
    }

    return NEUTRAL;
  }

  protected int bye(String details, int retval) {
    LOG.warn(details);
    return retval;
  }

  protected long parseVal(String s) {
    long r = -98765;  // this is a value that shows up wickedly in logs despite addition and multiplication,
                      // and this isn't used for real data movement, it's just for parsing parquet lib logs,
                      // so good enough
    try {
      String ss = s.replaceAll(",", "");
      r = Long.parseLong(ss);
    } finally {
      return r;
    }
  }
}

