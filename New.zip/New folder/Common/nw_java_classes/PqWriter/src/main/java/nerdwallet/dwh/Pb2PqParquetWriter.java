package nerdwallet.dwh;

import com.google.protobuf.Message;
import com.google.protobuf.MessageOrBuilder;
import java.io.IOException;
import nerdwallet.dwh.PythonDictEnricher;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.column.ParquetProperties;
import org.apache.parquet.hadoop.ParquetFileWriter;
import org.apache.parquet.hadoop.ParquetWriter;
import org.apache.parquet.hadoop.api.WriteSupport;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;

public class Pb2PqParquetWriter<T extends MessageOrBuilder> extends ParquetWriter<T> {

  @SuppressWarnings({"unchecked", "deprecation"})
  public Pb2PqParquetWriter(Path file, Class<? extends MessageOrBuilder> protoMessage,
                            CompressionCodecName compressionCodecName, int blockSize, 
                            boolean validating, Configuration conf, int maxPaddingSize,
                            PythonDictEnricher pde) throws IOException {

// I should use the below ctor as it's the only non-deprecated version, except that parquet team
// decided to make it package-protected, which means I cannot use it in a subclass.  They have this
// nifty builder scheme now, which I could see as a user of ParquetWriter, but not as a subclass.
// So I make due with a deprecated constructor :-/
// 
//     super(file, ParquetFileWriter.Mode.CREATE, new Pb2PqWriteSupport(protoMessage, pde),
//           compressionCodecName, blockSize, validating, conf, maxPaddingSize,  
//           ParquetProperties.builder().build());

// The unchecked suppression is there because I couldn't get templates to match up, however
// there is very little risk of a ClassCastException at runtime since we are always doing
// the exact same thing, no actual generics here!  This is an oddity of the Parquet API.

// It would be -really- nice to be able to specify column-level parameters, such as compression
// (UNCOMPRESSED, SNAPPY, GZIP, LZO) or encoding (PLAIN, GROUP_VAR_INT, PLAIN_DICTIONARY, RLE, BIT_PACKED,
// etc.:  https://github.com/Parquet/parquet-format/blob/master/Encodings.md) or what-have-you,
// but it's not available in Parquet 1.9.0.
  	
  	super(file, new Pb2PqWriteSupport(protoMessage, pde), compressionCodecName, blockSize, 
  		  ParquetWriter.DEFAULT_PAGE_SIZE, true, validating);  // enableDictionary=true

  }

}

