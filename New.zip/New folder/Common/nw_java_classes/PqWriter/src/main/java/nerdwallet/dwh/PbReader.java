package nerdwallet.dwh;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.MessageOrBuilder;
import com.google.protobuf.Parser;
import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PbReader<T extends Message> {

  protected Parser<T>           pbParser;
  protected MessageOrBuilder    pbClazz;
  protected InputStream         gis;
  protected BufferedInputStream bis;

  protected final int           bufsize = 4194304; // 4MB

  protected long                pboblen;
  protected Message             lastMessage;
  protected long                recno = 0;

  private static final Logger LOG = LoggerFactory.getLogger(PbReader.class);

  public PbReader(Class <? extends Message> clazz, InputStream is) throws FileNotFoundException {

    if(clazz == null) { throw new UnsupportedOperationException("PbReader must have non-nulls in ctor"); }

    try {
      Method m = clazz.getMethod("getDefaultInstance", null);
      Message tmpmsg = (Message) m.invoke(null, null);
      @SuppressWarnings("unchecked") Parser<T> pbp = (Parser<T>) tmpmsg.getParserForType();
      pbParser = pbp;
    } catch(Exception e) {
      LOG.error("Cannot find the parser", e);
      throw new UnsupportedOperationException("I cannot find/use the parser method, which should never happen.");
    }

    gis     = is;
    bis     = new BufferedInputStream(gis, bufsize);
  }

  public void close() throws IOException {
    lastMessage = null;

    bis.close();
    gis.close();
  }

  public T getNextObj() throws Throwable {

    // Each record is prefixed by a 8 byte bigendian unsigned integer which indicates the size of the next serialized object
    // struct.unpack(">Q", 8 byte buffer) in python

    byte[] reclenbuf;
    try {
      reclenbuf = readFully(8);
    } catch(EOFException e) {
      reclenbuf = null;
      return null;  // EOF has been reached
    }

    long pboblen = ByteBuffer.wrap(reclenbuf).order(java.nio.ByteOrder.BIG_ENDIAN).getLong();
    if(pboblen >= Integer.MAX_VALUE) {
      throw new Exception("message size is ridiculously large, is your protobuf file length delimited?");
    }
    int pbobleni = (int) pboblen;

    byte[] objbuf = readFully(pbobleni);
    T lastMessage = pbParser.parseFrom(objbuf);   // this could probably be sped up with parseFrom(byte[], int, int)
    recno++;
    
    reclenbuf = null;
    objbuf    = null; 
    LOG.debug("Message #{}: {} protobuf-serialized bytes", recno, pboblen);

    return lastMessage;
  }

  public long getRecno() {
    return recno;
  }

  public long getLastMessageSerializedSize() {
    return pboblen;
  }

  public byte[] readFully(int bytesToRead) throws IOException {
    byte[] b = null;
    int    n = 0;

    if(bytesToRead > 0) {
      b = new byte[bytesToRead];  // TODO Rewrite this using buffer reuse

      while(n < bytesToRead) {
        int gotten = bis.read(b, n, bytesToRead - n);
        if(gotten < 0) throw new EOFException("Unexpected EOF");
        n += gotten;
      }

    }
    return b;
  }

}
