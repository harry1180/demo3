package nerdwallet.dwh;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Paths;
import com.google.protobuf.MessageOrBuilder;
import com.google.protobuf.Descriptors;
import com.google.protobuf.Descriptors.FieldDescriptor.JavaType;

import org.python.core.Py;
import org.python.core.PyBoolean;
import org.python.core.PyDictionary;
import org.python.core.PyFunction;
import org.python.core.PyList;
import org.python.core.PyUnicode;
import org.python.util.PythonInterpreter;
import org.python.core.PyFloat;
import org.python.core.PyInteger;
import org.python.core.PyLong;
import org.python.core.PyString;
import org.python.core.PySet;
import org.json.simple.JSONValue;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PythonDictEnricher {
  protected PyFunction globalEnricher = null;
  protected PyFunction eventEnricher = null;
  protected Map overrides = new JSONObject();
  protected List eventSchemaAdditions = new JSONArray();
  protected Set<String> globalSchemaAdditions = new PySet();
  private PyDictionary _cachedEnrichedValues = null;
  private boolean _genericEnrichment = false;
  private static final Logger LOG = LoggerFactory.getLogger(PythonDictEnricher.class);

  @SuppressWarnings("unchecked")
  PythonDictEnricher(String eventScriptFileName, String eventEnrichFunctionName, String pqdef, String pqOverrides, String pbClassName, boolean genericEnrichment) throws InvalidPathException, IOException, NoSuchMethodException, SecurityException, ParseException {

    // Store the event-specific schema additions as a list
    if (pqdef != null) {
      List<String> customFields = (List<String>) JSONValue.parseWithException(pqdef);
      if (customFields != null) {
          eventSchemaAdditions.addAll(customFields);
      }
    }

    // Store the overrides as a map
    if (pqOverrides != null) {
        Map customOverrides = (Map) JSONValue.parseWithException(pqOverrides);
        if (customOverrides != null) {
            overrides.putAll(customOverrides);
        }
    }

    // If there's no ++ work, then we're done.
    if (! genericEnrichment && eventEnrichFunctionName == null) {
      return;
    }

    // Jython doesn't read PYTHONPATH, and sometimes (I forget when) the JYTHONPATH, so I have to do this ...
    String pythonpath = System.getenv("PYTHONPATH");
    if(pythonpath != null) {
      pythonpath = pythonpath.replaceAll("^:*", "").replaceAll(":*$", "");
      System.setProperty("python.path", pythonpath);
      LOG.debug("Set python.path ($PYTHONPATH for jython) = {}", System.getProperty("python.path")); 
    }

    // start a jython interpreter
    LOG.info("Initializing Jython interpreter");
    PythonInterpreter pi = new PythonInterpreter();

    // it's bad news to replicate all the installed python packages into jythonland.  This imports that.  
    // this also handles /usr/lib/pymodules/python2.7 via .pkg files
    // see also https://leemendelowitz.github.io/blog/how-does-python-find-packages.html
    LOG.info("Setting Jython site directories");
    pi.exec("import site");
    pi.exec("site.addsitedir('/usr/local/lib/python2.7/dist-packages')");
    pi.exec("site.addsitedir('/usr/lib/python2.7/dist-packages')");

    if(LOG.isDebugEnabled()) {
      pi.exec("import sys");
      PyUnicode syspath = (PyUnicode) pi.eval("u' '.join(sys.path)");
      LOG.debug("sys.path = {}", syspath);
    }

    // the script should NOT behave like a toplevel script, instead make it run like a module, otherwise the protobuf/json process runs ;)
    pi.set("__name__", "Pb2PqWriter");

    // The global enrichment function
    _genericEnrichment = genericEnrichment;
    String globalScriptName = System.getenv("dwh_common_base_dir") + "/nw_python_modules/event_enrichment.py";
    String globalScript = new String(Files.readAllBytes(Paths.get(globalScriptName)));
    LOG.info("Executing " + globalScriptName);
    pi.exec(globalScript);

    // Event-specific enrichment script
    if (eventScriptFileName != null) {
      String theScript = new String(Files.readAllBytes(Paths.get(eventScriptFileName)));
      LOG.info("Executing " + eventScriptFileName);
      pi.exec(theScript);
    }

    // Keep a reference to the global enrich function
    LOG.info("Getting reference to enrich()");
    globalEnricher = (PyFunction) pi.get("enrich");
    if (globalEnricher == null) {
      throw new NoSuchMethodException(globalScriptName + ": enrich()");
    }

    // Keep a reference to the event-specific enrich function
    if (eventEnrichFunctionName != null) {
      LOG.info("Getting reference to " + eventEnrichFunctionName + "()");
      eventEnricher = (PyFunction) pi.get(eventEnrichFunctionName);
      if(eventEnricher == null) {
        throw new NoSuchMethodException(eventScriptFileName + "." + eventEnrichFunctionName);
      }
    }

    // Call the Python function to get the global schema additions
    if (genericEnrichment) {
      LOG.info("Getting reference to get_enriched_parquet_types()");
      PyFunction globalSchemaAddFunction = (PyFunction) pi.get("get_enriched_parquet_types");
      LOG.info("Calling get_enriched_parquet_types()");
      globalSchemaAdditions = (PySet) globalSchemaAddFunction.__call__(new PyString(pbClassName));
    } else {
      globalSchemaAdditions = new PySet();
    }

    LOG.info("Jython setup complete");

  }

  public void clearCache() {
    _cachedEnrichedValues = null;
  }

  public PyDictionary getEnrichedValues(MessageOrBuilder record) {
    if (_cachedEnrichedValues == null) {
      if (globalEnricher != null) {
        PyDictionary dict = new PyDictionary();
        pbufToPydict(record, dict);
        _cachedEnrichedValues = (PyDictionary) globalEnricher.__call__(
          dict,
          eventEnricher == null ? Py.None : eventEnricher,
          new PyBoolean(_genericEnrichment));
      } else {
        _cachedEnrichedValues = new PyDictionary();
      }
    }
    return _cachedEnrichedValues;
  }

  public List<String> getSchemaAdditions() {
    Set<String> additions = new HashSet<String>();
    additions.addAll(globalSchemaAdditions);
    additions.addAll(eventSchemaAdditions);
    ArrayList<String> list = new ArrayList<String>(additions);
    Collections.sort(list);
    return list;
  }

  public String getNameOverride(String fullColName) {
    if (overrides.containsKey(fullColName))
        return (String) ((Map)overrides.get(fullColName)).get("name");
    else return null;
  }

  public String getTypeOverride(String fullColName) {
    if (overrides.containsKey(fullColName)) {
        String typeOverride = (String) ((Map)overrides.get(fullColName)).get("type");
        if (typeOverride != null && !typeOverride.equals("timestamp")) {
            throw new UnsupportedOperationException("Unsupported type override '" + typeOverride + "'");
        }
        return typeOverride;
    } else return null;
  }

  public Boolean getRequiredOverride(String fullColName) {
    if (overrides.containsKey(fullColName))
        return (Boolean) ((Map)overrides.get(fullColName)).get("required");
    else return null;
  }

  // Build python dict equivalent of the input record
  public void pbufToPydict(MessageOrBuilder pbuf, PyDictionary dict) {
      for (Descriptors.FieldDescriptor fieldDescriptor : pbuf.getDescriptorForType().getFields()) {
          addPydictField(pbuf, fieldDescriptor, dict);
      }
  }

  protected void addPydictField(MessageOrBuilder pbuf, Descriptors.FieldDescriptor descriptor, PyDictionary pd) {

    // If this is a message then loop, descend.  Otherwise just write things out.
    if(descriptor.getJavaType() == JavaType.MESSAGE) {

      MessageOrBuilder submsg = (MessageOrBuilder) pbuf.getField(descriptor);
      for(Descriptors.FieldDescriptor subDesc : descriptor.getMessageType().getFields()) {
        addPydictField(submsg, subDesc, pd);
      }

    } else {
      boolean isArray  = descriptor.isRepeated();
      String colName   = descriptor.getName();
      Object  val      = pbuf.getField(descriptor);
      int     recCount = isArray ? pbuf.getRepeatedFieldCount(descriptor) : 1;

      if (pd != null) {
        if(isArray) {
          PyList l = new PyList();
          for(int i = 0; i < recCount; i++) {
            val = pbuf.getRepeatedField(descriptor, i);

            switch(descriptor.getJavaType()) {
              case STRING:      l.pyadd(new PyUnicode((String)  val)); break;
              case INT:         l.pyadd(new PyInteger((Integer) val)); break;
              case LONG:        l.pyadd(new PyLong((Long)       val)); break;
              case FLOAT:       l.pyadd(new PyFloat((Float)     val)); break;
              case DOUBLE:      l.pyadd(new PyFloat((Double)    val)); break;
              case ENUM:        l.pyadd(new PyString( ((Descriptors.EnumValueDescriptor) val).getName() )); break;
              case BOOLEAN:     l.pyadd(new PyBoolean((Boolean) val)); break;
              case BYTE_STRING: l.pyadd(new PyString((String)   val.toString())); break;
              case MESSAGE:     break; // nothing to do
              default:          break; // would be caught above
            }
          }
          /*
           * Here we don't write field names to snake case because the customize_dict function applied to the
           * resulting PyDictionary might try to reference a field by it's original name which may not be
           * snake case
           */
          String nameOverride = getNameOverride(descriptor.getFullName());
          if (nameOverride != null) {
              colName = nameOverride;
          }
          pd.put(new PyUnicode(colName), l);

         } else {
           switch(descriptor.getJavaType()) {
            case STRING:      pd.put(new PyUnicode(colName), new PyUnicode((String)  val)); break;
            case INT:         pd.put(new PyUnicode(colName), new PyInteger((Integer) val)); break;
            case LONG:        pd.put(new PyUnicode(colName), new PyLong((Long)       val)); break;
            case FLOAT:       pd.put(new PyUnicode(colName), new PyFloat((Float)     val)); break;
            case DOUBLE:      pd.put(new PyUnicode(colName), new PyFloat((Double)    val)); break;
            case ENUM:        pd.put(new PyUnicode(colName), new PyString( ((Descriptors.EnumValueDescriptor) val).getName() )); break;
            case BOOLEAN:     pd.put(new PyUnicode(colName), new PyBoolean((Boolean) val)); break;
            case BYTE_STRING: pd.put(new PyUnicode(colName), new PyString((String)   val.toString())); break;
            case MESSAGE:     break; // nothing to do
            default:          break; // would be caught above
           }
         }
      }

    }
  }

}

