package nerdwallet.dwh;

import com.google.protobuf.ByteString;
import com.google.protobuf.Descriptors;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.FieldDescriptor.JavaType;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.MessageOrBuilder;
import com.google.protobuf.TextFormat;
import com.twitter.elephantbird.util.Protobufs;
import java.lang.reflect.Array;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import jodd.datetime.JDateTime;
import nerdwallet.dwh.Pb2PqSchema;
import nerdwallet.dwh.PythonDictEnricher;
import nerdwallet.dwh.VerySimpleCounter;
import org.apache.hadoop.conf.Configuration;
import org.apache.parquet.hadoop.api.WriteSupport;
import org.apache.parquet.io.api.Binary;
import org.apache.parquet.io.api.RecordConsumer;
import org.apache.parquet.schema.MessageType;
import org.apache.parquet.schema.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is the workforce of PqWriter.  It collapses the incoming messages into a flat structure, calls python to
 * Implement the "++" functionality, and more.  Andy used org.apache.parquet.proto.ProtoWriteSupport as a guide
 * because it was not really set up to be extended or customized.
**/


public class Pb2PqWriteSupport<T extends MessageOrBuilder> extends WriteSupport<T> {

  protected Class<? extends Message> protoMessage;
  protected RecordConsumer           recordConsumer;
  protected PythonDictEnricher       enricher;

  // using UTC instead of GMT, it is more correct
  protected ThreadLocal<Calendar>    parquetTsCalendarUtcTl;
  final protected long               NANOS_PER_SECOND = 1000000000;

  protected BigInteger max_long;
  protected BigInteger min_long;

  private static final Logger LOG = LoggerFactory.getLogger(Pb2PqWriteSupport.class);

  public Pb2PqWriteSupport(Class<? extends Message> protobufClass, PythonDictEnricher pde) throws ArithmeticException {
    this.protoMessage  = protobufClass;
    this.enricher      = pde;

    parquetTsCalendarUtcTl = new ThreadLocal<Calendar>();
    parquetTsCalendarUtcTl.set(Calendar.getInstance(TimeZone.getTimeZone("UTC")));  // was UTC (GMT)

    max_long = BigInteger.valueOf(Long.MAX_VALUE);
    min_long = BigInteger.valueOf(Long.MIN_VALUE);
  }

  @Override
  public String getName() {
    return "PqWriter";
  }

  @Override
  public WriteContext init(Configuration configuration) {

    Descriptors.Descriptor messageDescriptor = Protobufs.getMessageDescriptor(protoMessage);
    //String pbufdesc = TextFormat.shortDebugString(messageDescriptor.toProto()); // sadly this doesn't descend to submessages
    String pbufdesc = TextFormat.printToString(messageDescriptor.toProto());

    LOG.debug("Protobuf Schema = {}", pbufdesc);

    MessageType rootSchema = Pb2PqSchema.getDestPqSchema(protoMessage, enricher);
    LOG.debug("Parquet Schema = \n{}", rootSchema.toString());

    //TODO: add full field names to metadata
    Map<String, String> extraMetaData = new HashMap<String, String>();
    extraMetaData.put("pqwriter.protobuf.descriptor", pbufdesc);
    extraMetaData.put("pqwriter.protobuf.class", protoMessage.getName());
    extraMetaData.put("pqwriter.extrafields", Pb2PqSchema.extraFieldsSchema);
    extraMetaData.put("pqwriter.class", this.getClass().getName());
    return new WriteContext(rootSchema, extraMetaData);
}

  @Override
  public void prepareForWrite(RecordConsumer recordConsumer) {
    this.recordConsumer = recordConsumer;
  }

  @Override
  public void write(T record) {
    try {

      LOG.debug("Inbound protobuf\n{\n{}\n}", record);

      VerySimpleCounter c = new VerySimpleCounter(0);

      // Get enriched/++ fields
      Map extraFields = enricher.getEnrichedValues(record);

      recordConsumer.startMessage();

      // Write protobuf fields
      for (Descriptors.FieldDescriptor fieldDescriptor : record.getDescriptorForType().getFields()) {
              writeField(recordConsumer, record, fieldDescriptor, c, extraFields);
      }

      // Write control fields, pull the timestamp for dw_eff_ts out of the bucket to be set to the enrichment function
      Descriptors.FieldDescriptor tsFieldDesc = record.getDescriptorForType().findFieldByName("timestamp");

      Object  eventts_o = (tsFieldDesc == null) ? extraFields.get("zzz_timestamp") : record.getField(tsFieldDesc);
      Long    eventts   = null;

      if     (eventts_o == null)               { eventts = null; }
      else if(eventts_o instanceof BigInteger) { eventts = ((BigInteger) eventts_o).longValue(); }
      else if(eventts_o instanceof Long)       { eventts = (Long) eventts_o; }
      else                                     { throw new ArithmeticException("pbuf event timestamp being returned as " +
                                                                               eventts_o.getClass().toString()); }
      emitControlFields(c, eventts);

      // make sure that the enrichment value map doesn't attempt to set a value to a column that doesn't have a defined type
      for(Object key : extraFields.keySet()) {
        String colname = (String) key;
        if (colname == "_skipthisrecord") continue;
        if (ColumnInfo.getInstanceBySrcName(colname) == null) {
          LOG.warn("The enrichment function returned a value '" + colname + "' which isn't defined in the schema type map.");
        }
      }

      // Write enriched/++ fields
      for(ColumnInfo ci : ColumnInfo.getOrderedList()) {
        if(ci.isEnrichedColumn == false) { continue; }
        String key = ci.pqName;
        Object val = extraFields.get(ci.srcName);
        int recpos = c.pop();

        // treat empty ++ dictionaries and zero-length strings as empty fields
        if(val instanceof Map && ( ((Map) val).size() == 0) ) {
          val = null;
        } else if (val != null && val instanceof String && ((String) val).length() == 0) {
          val = null;
        }

        if(val != null) {
          recordConsumer.startField(key, recpos);
          LOG.debug("++ {} {} {}", key, val.getClass().getName(), ci.pqType);
          if (ci.pqType.endsWith("INT96")) {
            Long int96;
            if(val instanceof BigInteger) {
              int96 = ((BigInteger) val).longValue();
            } else {
              int96 = (Long) val;
            }
            recordConsumer.addBinary(makeHiveNanoTime(int96));
          } else {
            if(val instanceof String)     { recordConsumer.addBinary(Binary.fromString((String) val)); }
            if(val instanceof Integer)    { recordConsumer.addInteger((Integer) val); }
            if(val instanceof Long)       { recordConsumer.addLong((Long) val); }
            if(val instanceof BigInteger) { // returned sometimes instead of Long
                                            BigInteger biv = (BigInteger) val;
                                            if(biv.compareTo(max_long) == 1 || biv.compareTo(min_long) == -1) {
                                              throw new ArithmeticException("++ field " + key + " out of range: " + biv.toString());
                                            }
                                            recordConsumer.addLong(biv.longValue()); }
            if(val instanceof Double)     { recordConsumer.addDouble((Double) val); }
            if(val instanceof Boolean)    { recordConsumer.addBoolean((Boolean) val); }
          }

          if(ci.pqType.equals("OPTIONAL MSAS") || ci.pqType.equals("REQUIRED MSAS")) {
             if(! (val instanceof Map)) {
               throw new UnsupportedOperationException("MSAS type defined for " + key + " but something other than a Dict<String, List<String>> came back from the enrichment function");
             }

             recordConsumer.startGroup(); // toplevel map
             recordConsumer.startField("key_value", 0);

             for(Object kk : ((Map) val).keySet()) {

               recordConsumer.startGroup(); // keys/values in key_value
               recordConsumer.startField("key", 0);
               recordConsumer.addBinary( Binary.fromString( (String) kk ));
               recordConsumer.endField("key", 0);
               recordConsumer.startField("value", 1);
               recordConsumer.startGroup(); // list in value
               recordConsumer.startField("list", 0);

               Object vv = ((Map) val).get(kk);
               if(! (vv instanceof List)) {
                 throw new UnsupportedOperationException("MSAS type defined for " + key + " but something other than a Dict<String, List<String>> came back from the enrichment function");
               }

               for(Object va : (List) vv) {
                 recordConsumer.startGroup();
                 recordConsumer.startField("element", 0);
                 recordConsumer.addBinary( Binary.fromString( (String) va ));
                 recordConsumer.endField("element", 0);
                 recordConsumer.endGroup(); // elements in value
               }

               recordConsumer.endField("list", 0);
               recordConsumer.endGroup(); // elements in value
               recordConsumer.endField("value", 1);
               recordConsumer.endGroup(); // keys/values in key_value
             }

             recordConsumer.endField("key_value", 0);
             recordConsumer.endGroup(); // toplevel map

          } // MSAS

          if(ci.pqType.equals("OPTIONAL AMSS") || ci.pqType.equals("REQUIRED AMSS")) {
             if(! (val instanceof List)) {
               throw new UnsupportedOperationException("AMSS type defined for " + key + " but something other than a List<Dict<String,String>> came back from the enrichment function");
             }

             recordConsumer.startGroup(); // toplevel list
             recordConsumer.startField("list", 0);

             for(Object obj : (List) val) {

               if(! (obj instanceof Map)) {
                   throw new UnsupportedOperationException("AMSS type defined for " + key + " but something other than a List<Dict<String,String>> came back from the enrichment function");
               }

               recordConsumer.startGroup(); // inner map
               recordConsumer.startField("map", 0);
               recordConsumer.startGroup(); // repeated key/value pair
               recordConsumer.startField("key_value", 0);

               for(Object kk: ((Map) obj).keySet()) {
                   recordConsumer.startGroup();
                   recordConsumer.startField("key", 0);
                   recordConsumer.addBinary( Binary.fromString( (String) kk ));
                   recordConsumer.endField("key", 0);

                   recordConsumer.startField("value", 1);
                   recordConsumer.addBinary( Binary.fromString( (String) ((Map)obj).get(kk) ));
                   recordConsumer.endField("value", 1);
                   recordConsumer.endGroup();
               }

               recordConsumer.endField("key_value", 0);
               recordConsumer.endGroup(); // repeated key/value pair
               recordConsumer.endField("map", 0);
               recordConsumer.endGroup(); // inner map
             }

             recordConsumer.endField("list", 0);
             recordConsumer.endGroup(); // toplevel list

          } // AMSS

          recordConsumer.endField(key, recpos);
        }
        LOG.debug("Adding ++ {}: {}={}", recpos, key, val);
      }

   } catch (RuntimeException e) {
      Message m = (record instanceof Message.Builder) ? ((Message.Builder) record).build() : (Message) record;
      LOG.error("Cannot write message because {}:\n{}\n{}", e.getMessage() == null ? "" : e.getMessage(), e, m);
      throw e;
    }
    recordConsumer.endMessage();
  }

  protected void writeField(RecordConsumer rc, MessageOrBuilder pbuf, Descriptors.FieldDescriptor descriptor, VerySimpleCounter c, Map extraFields) {

    if(LOG.isDebugEnabled()) {
     LOG.debug("-- {} {} {} {}", descriptor.getName(), descriptor.getJavaType(),
       descriptor.isRepeated() ? "repeated" : "scalar",
       descriptor.isRepeated() ? Integer.toString(pbuf.getRepeatedFieldCount(descriptor)) : "");
    }

    // If this is a message then loop, descend.  Otherwise just write things out.
    if(descriptor.getJavaType() == JavaType.MESSAGE) {
      MessageOrBuilder submsg = (MessageOrBuilder) pbuf.getField(descriptor);

      for(Descriptors.FieldDescriptor subDesc : descriptor.getMessageType().getFields()) {
        writeField(rc, submsg, subDesc, c, extraFields);
      }

    } else {

      boolean isArray = descriptor.isRepeated();
      int recCount = isArray ? pbuf.getRepeatedFieldCount(descriptor) : 1;
      int recpos = c.pop();
      Object val;

      // Use the transformed value of the field if it was modified in the ++ logic (i.e. appears in extraFields)
      if (extraFields.containsKey(descriptor.getName())) {
          val = extraFields.get(descriptor.getName());
      } else if (isArray || pbuf.hasField(descriptor)) {
          val = pbuf.getField(descriptor);
      } else if (descriptor.hasDefaultValue()) {
          val = descriptor.getDefaultValue();
      } else {
          val = null;
      }

      // 0-length strings in pbuf turn into NULLs in the db, this is for scalars.  it's going to be a pain to deal with arrays of size > 1
      // whose values include nulls, which I think is highly unlikely, they'll just turn into zero length strings in hive.
      if ((isArray && recCount == 1 && isEmptyString(pbuf.getRepeatedField(descriptor, 0), descriptor.getJavaType()))
              || (!isArray && isEmptyString(val, descriptor.getJavaType()))) {
          val = null;
      }

      if (val != null && recCount != 0) {
        rc.startField(ColumnInfo.getInstance(recpos).pqName, recpos);

        if (isArray) {
            writeArray(rc, pbuf, descriptor, recCount);
        } else {
            writePrimitive(rc, descriptor, val);
        }

        rc.endField(ColumnInfo.getInstance(recpos).pqName, recpos);

      } // end 'is there work to do?'

    }   // end 'is not a message'

  }     // end writeField()

  // Write a single primitive element
  private void writePrimitive(RecordConsumer rc, Descriptors.FieldDescriptor descriptor, Object val) {
      LOG.debug("    [{}] {}", val.getClass(), val);

      String typeOverride = enricher.getTypeOverride(descriptor.getFullName());
      if (typeOverride != null && typeOverride.equals("timestamp")) {
          rc.addBinary( makeHiveNanoTime((Long) val) );
          return;
      }

      // see also https://github.com/Parquet/parquet-format/blob/master/LogicalTypes.md :)
      switch (descriptor.getJavaType()) {
        case STRING:      rc.addBinary(Binary.fromString((String) val));                                      break;
        case INT:         rc.addInteger((Integer) val);                                                       break;
        case LONG:        rc.addLong((Long) val);                                                             break; 
        case FLOAT:       rc.addFloat((Float) val);                                                           break;
        case DOUBLE:      rc.addDouble((Double) val);                                                         break;
        case ENUM:        rc.addBinary(Binary.fromString(((Descriptors.EnumValueDescriptor) val).getName())); break;
        case BOOLEAN:     rc.addBoolean((Boolean) val);                                                       break;
        case BYTE_STRING: Binary binary = Binary.fromConstantByteArray( ((ByteString) val).toByteArray());
                          rc.addBinary(binary);                                                               break;
        case MESSAGE:     break;  // nothing to do .. we already done it 
        default:          throw new UnsupportedOperationException("Cannot convert Protocol Buffer: unknown type for " + 
                                                                descriptor.getName() + " (" + descriptor.getJavaType() + ")");
      }
  }

  // Write a repeated field and its elements in the standard nested structure
  private void writeArray(RecordConsumer rc, MessageOrBuilder pbuf, Descriptors.FieldDescriptor descriptor, int recCount) {
      rc.startGroup();
      rc.startField("list", 0);

      for (int i = 0; i < recCount; i++) {
          recordConsumer.startGroup();
          recordConsumer.startField("element", 0);
          writePrimitive(rc, descriptor, pbuf.getRepeatedField(descriptor, i));
          recordConsumer.endField("element", 0);
          recordConsumer.endGroup();
      }

      rc.endField("list", 0);
      rc.endGroup();
  }

  public void emitControlFields(VerySimpleCounter c, Long eventts) {
      long now    = System.currentTimeMillis();
      long eff_ts = (eventts != null) ? eventts.longValue() : now;

      int cDwEffDt = c.pop();
      recordConsumer.startField("dw_eff_dt", cDwEffDt);
      recordConsumer.addInteger((int) (eff_ts / 86400000L));
      recordConsumer.endField(  "dw_eff_dt", cDwEffDt);

      int cDwLoadTs = c.pop();
      recordConsumer.startField("dw_load_ts", cDwLoadTs);
      recordConsumer.addBinary(makeHiveNanoTime( now ));
      recordConsumer.endField(  "dw_load_ts", cDwLoadTs);

      // dw_last_updt_ts and dw_last_updt_tx are always null at row creation
      int cDwLastUpdtTs = c.pop();
      int cDwLastUpdtTx = c.pop();
  }

  public Binary makeHiveNanoTime(long ms_utc) {
    // see https://github.com/apache/hive/blob/master/ql/src/java/org/apache/hadoop/hive/ql/io/parquet/timestamp/NanoTime.java
    // and NanoTimeUtils.java, and the current release at branch-1.0.1 :-/
    // this is a cloned version since we're going to have a hive upgrade.  jodd is 3.5.2 in hive master and 1.0.1 (current hive ver)

    Calendar parquetTsCalendar = parquetTsCalendarUtcTl.get();

    parquetTsCalendar.setTimeInMillis(ms_utc);

    JDateTime jdt = new JDateTime(parquetTsCalendar.get(Calendar.YEAR),
                                  parquetTsCalendar.get(Calendar.MONTH) + 1,
                                  parquetTsCalendar.get(Calendar.DAY_OF_MONTH));
    int julianDay = jdt.getJulianDayNumber();

    long timeOfDayNanos = parquetTsCalendar.get(Calendar.HOUR_OF_DAY) * NANOS_PER_SECOND * 3600 +
                          parquetTsCalendar.get(Calendar.MINUTE)      * NANOS_PER_SECOND * 60   +
                          parquetTsCalendar.get(Calendar.SECOND)      * NANOS_PER_SECOND        +
                          ((ms_utc % 1000) * 1000000);

    if(LOG.isDebugEnabled()) {
      LOG.debug("Timestamp debug {} : y {} m {} d {} / h {} m {} s {} n {} // j {} todn {}",
               ms_utc,
               parquetTsCalendar.get(Calendar.YEAR), parquetTsCalendar.get(Calendar.MONTH) + 1, parquetTsCalendar.get(Calendar.DAY_OF_MONTH),
               parquetTsCalendar.get(Calendar.HOUR_OF_DAY), parquetTsCalendar.get(Calendar.MINUTE), parquetTsCalendar.get(Calendar.SECOND),
               ((ms_utc % 1000) * 1000000), julianDay, timeOfDayNanos);
    }

    ByteBuffer buf = ByteBuffer.allocate(12);
    buf.order(ByteOrder.LITTLE_ENDIAN);
    buf.putLong(timeOfDayNanos);
    buf.putInt(julianDay);
    buf.flip();
    return Binary.fromReusedByteBuffer(buf);
  }

  protected boolean isEmptyString(Object s, JavaType t) {
    if(s == null)            { return true; }
    if(t != JavaType.STRING) { return false; }
    String ss = (String) s;
    if(ss.length() == 0)     { return true; }
    return false;
  }

  public static String pullBinaryApart(byte[] ba, String stringrep) {  // for debug printing
    StringBuilder sb = new StringBuilder();

    for(int i=0; i < ba.length; i++) {
      sb.append(String.format("%02x", ba[i])).append(" ");
    }
    sb.append("| ");

    for(int i=0; i < ba.length; i++) {
      int by = ba[i] & 0xff;  // remove 2's compliment, aka negative number conversion  :)
      sb.append(String.format("%8s", Integer.toString(by, 2)).replace(' ', '0')).append(" ");
    }

    sb.append("| ").append(ba.length * 8).append(" bits | ").append(stringrep);
    return sb.toString();
  }


}

