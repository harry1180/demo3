package nerdwallet.dwh;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class SnakeCaseTest extends TestCase {

    public SnakeCaseTest( String testName ) {
        super(testName);
    }

    public static Test suite() {
        return new TestSuite( SnakeCaseTest.class );
    }

    public void testSnakeCase() {
      assertEquals("camel_case", Pb2PqSchema.snakeCase("CamelCase"));
      assertEquals("camel_case", Pb2PqSchema.snakeCase("camelCase"));
      assertEquals("camel_case_word", Pb2PqSchema.snakeCase("camelCaseWord"));
      assertEquals("camel_case", Pb2PqSchema.snakeCase("camelCASE"));
      assertEquals("camel_case", Pb2PqSchema.snakeCase("CAMELCase"));
      assertEquals("b2b_filter", Pb2PqSchema.snakeCase("B2BFilter"));
      assertEquals("camel_case_a", Pb2PqSchema.snakeCase("CamelCaseA"));
      assertEquals("camel_case", Pb2PqSchema.snakeCase("camel_case"));
      assertEquals("camel_case_word", Pb2PqSchema.snakeCase("Camel_Case_Word"));
    }
}
