"""
Assumes access to hive/presto/spark is available in the environment

Run from the command line:

    python -m unittest TestPqWriter

The unittest module takes care of running the following in order:
    1) setUpClass
    2) functions starting with 'test'
    3) tearDownClass
"""

import unittest
import shutil
import struct
import os
import re

from pyhive import hive, presto
from pyspark.sql import SparkSession
from requests.auth import HTTPBasicAuth

from nwpyschemas.event.UnitTestEvent_pb2 import UnitTestAllTypesEvent
from event_modules import run_pqwriter
from s3_modules import s3_file_upload
from nwpyschemas import util
import nw_hive

GLOBALCONN = None
EMR_SERVER = "nerdlake-etl.east1.prod.nerdwallet.com"
EMR_USERNAME, EMR_PASSWORD = nw_hive.get_hive_credentials()
OUTDIR = 'tmpTestPqWriter/'
PBFILE = OUTDIR + 'input/2017/01/01/unitTestAllTypesEvent.protobuf'
PBCLASS = 'event.UnitTestEventProto$UnitTestAllTypesEvent'

# WARNING: We are creating/dropping a MANAGED table at TESTLOCATION
S3BUCKET = 'east1-prod-nerdlake-0'
S3PATH = 'dwnl_workarea/UnitTestAllTypesEvent'
TESTLOCATION = 's3://' + S3BUCKET + '/' + S3PATH 
TABLE = 'dwnl_workarea.UnitTestAllTypesEvent'

# key: (value, hivetype)
TESTRECORD = {
      'optionalBool': (True, 'boolean')
    , 'optionalInt': (1, 'int')
    , 'optionalLong': (10L, 'bigint')
    , 'optionalFloat': (1.5, 'float')
    , 'optionalDouble': (10.5, 'double')
    , 'optionalByteString': ('testbytestring', 'binary')
    , 'optionalString': ('teststring', 'string')
    , 'optionalEnum': ('A', 'string')

    , 'repeatedBool': ([True, False], 'array<boolean>')
    , 'repeatedInt': ([-1, 1], 'array<int>')
    , 'repeatedLong': ([-10L, 10L], 'array<bigint>')
    , 'repeatedFloat': ([-1.5, 1.5], 'array<float>')
    , 'repeatedDouble': ([-10.5, 10.5], 'array<double>')
    , 'repeatedByteString': (['testbytestring1', 'testbytestring2'], 'array<binary>')
    , 'repeatedString': (['teststring1', 'teststring2'], 'array<string>')
    , 'repeatedEnum': (['A', 'B'], 'array<string>')
}

def write_protobuf():
    print('\nWriting test protobuf file {}...'.format(PBFILE))
    testdata = {}
    # Extract test values
    for key in TESTRECORD:
        testdata[key] = TESTRECORD[key][0]
    pb = util.dict_to_protobuf(testdata, UnitTestAllTypesEvent)
    os.makedirs(os.path.dirname(PBFILE))
    with open(PBFILE, 'wb') as f:
        # Write message length delimiter, then the message
        f.write(struct.pack('>Q', pb.ByteSize()))
        f.write(pb.SerializeToString())

def write_parquet():
    print('\nRunning PqWriter...')
    stats = run_pqwriter(PBFILE, PBCLASS, debuglevel='ERROR')
    error_count = stats[2]
    partitions = stats[3]
    if (error_count > 0):
        raise Exception('An error occurred while running PqWriter')
    return partitions[0]

def upload_parquet(outfile):
    print('\nUploading parquet file {} to S3...'.format(outfile))
    s3_file_upload(outfile, S3BUCKET, S3PATH)

def open_global_connection():
    global GLOBALCONN
    GLOBALCONN = nw_hive.connect()

def snake_case(s):
    # Simple convert camelCase to snake_case
    return re.sub('([A-Z]+)', '_\\1', s).lower()

def create_table():
    print('\nCreating managed table {}...'.format(TABLE))
    coldefs = ['`{}` {}'.format(snake_case(col), TESTRECORD[col][1]) for col in TESTRECORD]
    ddltemplate = "create table {} (\n{}\n)\nSTORED AS PARQUET LOCATION '{}'"
    testddl = ddltemplate.format(TABLE, ',\n'.join(coldefs), TESTLOCATION)
    GLOBALCONN.cursor().execute(testddl)

def drop_table():
    print('\nDropping managed table {}...'.format(TABLE))
    # With our current infrastructure configuration, dropping the
    # managed table doesn't delete the files from S3 for some reason
    GLOBALCONN.cursor().execute('drop table {}'.format(TABLE))

def delete_tmp_files():
    if os.path.exists(OUTDIR):
        print('\nDeleting temporary output directory {}...'.format(OUTDIR))
        shutil.rmtree(OUTDIR)


class TestPqWriter(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        try:
            write_protobuf()
            upload_parquet(write_parquet())
            open_global_connection()
            create_table()
        finally:
            delete_tmp_files()

    @classmethod
    def tearDownClass(self):
        drop_table()

    def query_test(self, executor, column, indexstr, engine, expectedval):
        query = 'select {}{} as val from {}'.format(snake_case(column), indexstr, TABLE)
        if engine == 'spark':
            dataframe = executor.sql(query)
            result = dataframe.first()['val']
        else:
            executor.execute(query)
            result = executor.fetchone()[0]
        self.assertEquals(result, expectedval)

    def run_query_tests(self, executor, engine):
        for column in TESTRECORD:
            expectedval = TESTRECORD[column][0]
            if isinstance(expectedval, list):
                # presto indexes arrays starting from 1 :(
                start = 1 if engine == 'presto' else 0
                for index, element in enumerate(expectedval, start):
                    indexstr = '[' + str(index) + ']'
                    self.query_test(executor, column, indexstr, engine, expectedval[index - start])
            else:
                self.query_test(executor, column, '', engine, expectedval)

    def test_hive_read(self):
        print('\nReading from {} with Hive...'.format(TABLE))
        # Reuse the global connection
        self.run_query_tests(GLOBALCONN.cursor(), 'hive')

    def test_presto_read(self):
        print('\nReading from {} with Presto...'.format(TABLE))
        cursor = presto.connect(host=EMR_SERVER,
                                port=8446,
                                protocol="https",
                                username=EMR_USERNAME,
                                requests_kwargs={
                                    'auth': HTTPBasicAuth(EMR_USERNAME, EMR_PASSWORD),
                                    'verify': '/etc/truststore/nerdlake-etl/nerdlake-truststore.pem'
                                },
                                session_props={'hive.parquet_optimized_reader_enabled': False}).cursor()
        self.run_query_tests(cursor, 'presto')
        cursor.close()

    def test_spark_read(self):
        print('\nReading from {} with Spark...'.format(TABLE))
        spark = SparkSession.builder.enableHiveSupport().getOrCreate()
        self.run_query_tests(spark, 'spark')

