#!/bin/bash

# Until we move the process to gradle, this is just a simple build script to build PqWriter.  
#
# Developers making changes to the java code in .../dwh/Common/nw_java_classes/PqWriter MUST rebuild to generate
# PqWriter.jar and have that jar checked into git.  Run this script to do that :)  Note that Pb2PqWriter does NOT
# need changes when there's a change to the schemata, everything is bound dynamically.  
#
# On a mac, the dependencies are as follows:
# - install jdk:  brew cask install java
#                 (we are currently using jdk version 1.8)
# - install maven: brew install maven
# - (to compile the schemas repo, you also need brew install protobuf250.  Pb2PqWriter doesn't need events.jar
#    during build, only runtime.)
#
# On UNIX, chef scripts must have run to:
# - install the JDK on the build (jenkins) server, or the JRE on DwhAdmin* and Dwh Airflows.  
# - install jython to /opt/jython2.7
# - install event.jar from the schemas repo to /opt/dwh-jarlib/nw/events.jar
# - install a series of jars from the internet into /opt/dwh-jarlib/nw/inet-sourced
#
#
# Note that this uses maven under the covers, which pulls down jars from the internet and stores them in your
# local maven repo at ~/.m2.  This is not good practice (we should use an 'airgapped' build server.  We will
# fix this when we move to gradle.  

if [ -s "pom.xml" ] ; then
  mvn clean
  mvn package
  cp target/PqWriter-0.1-SNAPSHOT.jar ../PqWriter.jar
  rm -rf target
else
  echo "You must run build.sh in the same directory as where pom.xml is located."
  exit 1
fi

