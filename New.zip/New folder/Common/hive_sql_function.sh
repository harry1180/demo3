#!/bin/bash

job_name='hive_sql_function'

source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

## Usage: Embed variables :v1 and/or :v2 at sql file, and accept command-line input parameters
## Example:
## 1. presto_sql_function.sh step00_url_stage_s_del.sql
## 2. presto_sql_function.sh step00_url_stage_s_del.sql param.json

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    if [ -n "$PASS_PIPE" ] && [ -e "$PASS_PIPE" ]
    then
        rm $PASS_PIPE
    fi
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    echo "An error occurred. Exiting while performing *****************SQL Step" >&2
    exit 1
}
trap 'abort' 0
set -e

if [ $# -lt 1 ]
then
    echo "Usage: hive_sql_function.sh <filename.sql> [beeline options ...]"
    exit 1
fi

# If this script is running from within a job, the temporary directory will be set to a subdirectory within the job's
# data directory. If not, let's use /tmp.
Linux_Temp=${Linux_Temp:-/tmp}
if [ ! -d $Linux_Temp ]
then
    echo "WARNING: $Linux_Temp: no such directory, using /tmp instead"
    Linux_Temp=/tmp
fi

sql_file="$1"
if [ ! -e $sql_file ]
then
    echo "SQL script [$sql_file] doesn't exist."
    exit 1
fi

shift # Remove the first argument from $@

# Get the LDAP password
echo "Getting the LDAP password"
if [ $(id -un) = "airflow" ]
then
    PROD_CREDS_FILENAME="/etc/dwh_secured_tokens/airflow.json"
    echo "Retrieving LDAP password from $PROD_CREDS_FILENAME"
    readarray -n 2 -t LDAP_CREDS_ARR <<< "$(python <<EOF
import json
with open ('$PROD_CREDS_FILENAME') as fh:
    creds = json.load(fh)
print("{}\n{}".format(
    creds["active_directory"]["airflow"]["user"],
    creds["active_directory"]["airflow"]["password"]))
EOF
    )"
    LDAP_USER=${LDAP_CREDS_ARR[0]}
    LDAP_PASSWORD=${LDAP_CREDS_ARR[1]}
    unset LDAP_CREDS_ARR
else
    LDAP_USER=$(id -un)
    read -s -p "Okta Password: " LDAP_PASSWORD
    echo ""
fi
if [ -z "$LDAP_PASSWORD" ]
then
    echo "ERROR: Blank password, aborting"
    exit 1
fi

# Create a named pipe and write the user's password to it. Run this in the background because this will block until
# the password is actually read by another program.
# NOTE: The echo command is a Bash command and not a separate executable so this will not be visible using 'ps'
PASS_PIPE=$(mktemp --tmpdir=/tmp pp_XXXXXXXXXX)
rm $PASS_PIPE
mknod -m u=rw,go= $PASS_PIPE p
echo "$LDAP_PASSWORD" >> $PASS_PIPE &

# Submit the SQL file through Hive
nw-hive \
    -n "$LDAP_USER@nerdwallet.com" \
    -w $PASS_PIPE \
    --color=false \
    --fastConnect=true \
    --force=false \
    -f "$sql_file" \
    "$@"

rm $PASS_PIPE

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
