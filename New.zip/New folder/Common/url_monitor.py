#!python

import hashlib
import re
import requests
import sys
from   time import gmtime, strftime

import boto3
from   botocore.exceptions import ClientError
import requests

# the purpose of this script is to watch for changes to documentation, and alert oncall folks if it
# does.  the initial use case is with appsflyer, whose schema and IP whitelist can change "at any
# time".  when the content of a url changes, it fails the job with instructions for the oncall
# person.  this script is also appsflyer-ish in that it attemps to parse out a last-update-date from
# the content, but it's cool to extend this looking at different patterns, it is used in preference
# to a checksum of the page content because folks stick often stick guids into page content

# this program is partially thread-unsafe in the sense that, if there are two programs running,
# analyzing the same url, there is a race condition when the update happens.  i could use conditional
# updates, but for the intended use, it's prob okay.

# note that the aws region is manually set here.  this is what andy and dataops (manish, evan)
# agreed to until we clean up the dwh build/release process to use appconfigs

def main():
  if len(sys.argv) < 3:
    print 'Usage: python url_monitor.py <responsible_team> <url1> <url2> ...'
    sys.exit(1)

  should_abend = checkURLs(sys.argv[2:], sys.argv[1])
  sys.exit(1 if should_abend else 0)

def checkURLs(urls, responsible_team):
  should_abend = False

  # appsflyer has a documentation timestamps:
  #   Last update: <time datetime="2018-01-04T09:29:01Z" title="2018-01-04T09:29:01Z" data-datetime="calendar">
  re_appsflyer_last_update = re.compile(r'Last update: <time datetime="([0-9TZ:-]*)"')

  dyn = boto3.resource('dynamodb', region_name='us-east-1')
  urlmt = dyn.Table('dwh-url-monitor')
  try:
    trash = urlmt.creation_date_time
  except ClientError as ex:
    print 'Unable to connect to Dynamo table dwh-url-monitor:'
    print ex
    return True

  for url in urls:
    print '---------------------------------------------------------------'
    now = strftime('%Y-%m-%dT%H:%M:%S', gmtime())

    body = None
    try:
      r = requests.get(url, timeout=15)
      body = r.content
    except Exception as ex:
      print 'Unable to retrieve URL: {}'.format(url)
      print ex
      should_abend = True
      continue

    # get a checksum
    content_sha256 = None
    bodylength = 0
    if body:
        content_sha256 = hashlib.sha256(body).hexdigest()
        bodylength = len(body)

    # if it exists, look for the the Last Updated timestamp.
    last_stated_update = None
    if body:
      r = re_appsflyer_last_update.search(body)
      if r:
        last_stated_update = r.group(1)

    # query for the last state
    last_seen = urlmt.get_item(Key={'url': url}, ConsistentRead=False)

    if 'Item' in last_seen:
      print 'URL                       {}'.format(url)
      print 'Previous check (UTC):     {}'.format(last_seen['Item']['last_checked_utc'])
      print 'Current  check (UTC):     {}'.format(now)
      print 'Previous content sha256:  {}'.format(last_seen['Item']['content_sha256'])
      print 'Current  content sha256:  {}'.format(content_sha256)
      print 'Previous page updated at: {}'.format(last_seen['Item'].get('last_update'))
      print 'Current  page updated at: {}'.format(last_stated_update)
      print ''

      if last_seen['Item']['content_sha256'] == content_sha256:
        print 'Status:                   No change detected.'

        last_seen['Item']['last_checked_utc'] = now
        urlmt.put_item(Item=last_seen['Item'])

      elif 'last_update' in last_seen['Item'] and last_stated_update and \
           last_seen['Item']['last_update'] == last_stated_update:
        print 'Status:                   Stated update date didn\'t change but checksum did.'

        last_seen['Item']['last_checked_utc'] = now
        last_seen['Item']['content_sha256'] = content_sha256
        urlmt.put_item(Item=last_seen['Item'])

      else:
        print 'Status:                   CHECKSUM CHANGED!'
        print ''
        print 'This URL has had its content change, which means that the DWH team may have to'
        print 'take action.  Please escalate to the {} team as a high priority on'.format(responsible_team)
        print 'the next business day.  This job will continue failing until resolution is made,'
        print 'but dwh oncall ought to mark this job as complete for now.'
        print ''
        print 'To the {} team, please assess impact and rectify the situation.  When it\'s time'.format(responsible_team)
        print 'to \'acknowledge\' the new content, please remove the record in dynamo at'
        print 'https://console.aws.amazon.com/dynamodb/home?region=us-east-1#tables:selected=dwh-url-monitor'
        print 'The existing content (truncated to 390kb) is in the content field, if a comparison'
        print 'is needed.'

        should_abend = True

    else:
      print 'URL                       {}'.format(url)
      print 'Current  check (UTC):     {}'.format(now)
      print 'Current  content sha256:  {}'.format(content_sha256)
      print 'Current  page updated at: {}'.format(last_stated_update)
      print ''
      print 'Status:                   New URL requested.'

      now_seen = {'url': url,
                  'content': body[0:390000],  # dynamo stores only 400k/item
                  'content_sha256': content_sha256,
                  'last_checked_utc': now }
      if last_stated_update:
        now_seen['last_update'] = last_stated_update

      urlmt.put_item(Item=now_seen)

  print '---------------------------------------------------------------'
  return should_abend


if __name__ == '__main__':
  main()
