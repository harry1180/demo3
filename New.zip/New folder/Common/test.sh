echo '*******aflt_transaction_commission_junction_started*******'
bash /data/etl/Scripts/aflt_tran_commission_junction/shellscripts/aflt_tran_commission_junction.sh 20
echo '*******aflt_transaction_commission_junction_completed*******'
echo '*******aflt_transaction_flex_offer_client_started*******'
bash /data/etl/Scripts/aflt_tran_flex_offers/shellscripts/aflt_tran_flex_offers_client.sh 20
echo '*******aflt_transaction_flex_offer_client_completed*******'
echo '*******aflt_transaction_flex_offer_publisher_started*******'
bash /data/etl/Scripts/aflt_tran_flex_offers/shellscripts/aflt_tran_flex_offers_publisher.sh 20
echo '*******aflt_transaction_flex_offer_publisher_completed*******'
echo '*******aflt_transaction_link_share_broker_started*******'
bash /data/etl/Scripts/aflt_tran_link_share/shellscripts/aflt_tran_link_share_brokers.sh 20
echo '*******aflt_transaction_link_share_broker_completed*******'
echo '*******aflt_transaction_link_share_coupons_started*******'
bash /data/etl/Scripts/aflt_tran_link_share/shellscripts/aflt_tran_link_share_coupons.sh 20
echo '*******aflt_transaction_link_share_coupons_completed*******'
echo '*******aflt_transaction_consolidated_started******'
bash /data/etl/Scripts/aflt_tran_consolidated_fact/shellscripts/aflt_tran_consolidated_fact.sh
echo '*******aflt_transaction_consolidated_completed******'
