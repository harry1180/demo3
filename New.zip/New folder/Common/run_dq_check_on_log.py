import sys, pprint
from datetime import date, timedelta
import base64
import pandas as pd
import pandas.io.sql as psql
#import seaborn as sns
import psycopg2
#from pandas import ExcelWriter
#from pandas.io.parsers import ExcelWriter
from openpyxl.writer.excel import ExcelWriter
from collections import OrderedDict

import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders
import json
import re
from email.mime.text import MIMEText
from subprocess import Popen, PIPE
from nw_generic_utils_modules import fetch_creds

####################################       methods        ####################################

def fetch_query_results (run_query,conn):
    print "\n ********* Running query ********* \n"
    #print "run_query : ",run_query
    df = psql.read_sql_query(run_query,conn)
    return df

def log_dq_results (conn,pretty_dq_json,dq_return_code,df_html_table_email):
    print "\n ********* Logging DQ Results ********* \n"
    
    cursor = conn.cursor();

    log_query="INSERT INTO dw_report.DQ_Job_Log \n (DQ_Job_Name,dw_eff_dt,DQ_Job_ts,DQ_Job_Group_Level1,DQ_Job_Group_Level2 ,DQ_Job_Group_Level3,DQ_Job_Desc \n ,Email_TO ,Email_CC ,Email_FROM ,Fail_On_Error ,DQ_Query ,DQ_Status ,DQ_Result, dw_load_ts) \n VALUES \n (" 
    log_query=log_query+" '"+str(pretty_dq_json['DQ_Job_Name'])+"'"
    log_query=log_query+', trunc(sysdate)'
    log_query=log_query+', sysdate'
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Job_Group_Level1'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Job_Group_Level2'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Job_Group_Level3'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Job_Desc'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['Email_TO'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['Email_CC'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['Email_FROM'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['Fail_On_Error'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['DQ_JSON']).replace(r"'",r"\'")+"'"
    log_query=log_query+", '"+dq_return_code+"'"
    #log_query=log_query+", '"+str(df_html_table_email).replace(r"'",r"\'")+"'"
    log_query=log_query+", substring('"+str(df_html_table_email).replace(r"'",r"\'")+"',1,65000)"
    log_query=log_query+', sysdate) ; \n '
    
    #print log_query
    cursor.execute(log_query);
    conn.commit()
    conn.close()

def send_dq_email(dq_json_info, df_html_table_email):

    fromaddr = dq_json_info['Email_FROM']
    toaddr = dq_json_info['Email_TO']
    #toaddr = 'ssundara@nerdwallet.com ; acheng@nerdwallet.com'
    msg = MIMEMultipart()

    msg['From'] = fromaddr
    msg['To'] = toaddr

    dq_status="NOTIFY"

    if 'FAILURE' in str(dq_json_info['log_txt']):
        dq_status='FAILURE'
    elif 'WARNING' in str(dq_json_info['log_txt']):
        dq_status='WARNING'
    elif 'SUCCESS' in str(dq_json_info['log_txt']):
        dq_status='SUCCESS'
    else:
        dq_status="NOTIFY"    
    
    print "dq_status : ",dq_status
    msg['Subject'] = dq_status+" : DQ report for "+str(dq_json_info['DQ_Job_Name'])

    body = str(dq_json_info['DQ_Job_Desc'])+'<p></p>'+str(dq_json_info['log_txt']).replace('\n', '<p></p>')+'<p></p><p></p><p></p><p></p>'+df_html_table_email+'<p></p><p></p><p></p><p></p>'

    msg.attach(MIMEText(body, 'html'))

    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    p.communicate(msg.as_string())

    return dq_status


####################################       main          ####################################
def main():
    
    dq_script_file                = sys.argv[1]
    dq_json = open(dq_script_file)
    pretty_dq_json = json.loads(dq_json.read().replace('\n',' ').replace('\r',' '),strict=False)
    dq_job_name=pretty_dq_json['DQ_Job_Name']
    run_query=pretty_dq_json['DQ_JSON'] 
    
    psql_prod_database=fetch_creds('psql_prod_database')
    psql_prod_port=fetch_creds('psql_prod_port')
    psql_prod_username=fetch_creds('psql_prod_username')
    psql_prod_password=fetch_creds('psql_prod_password')
    psql_prod_dbHost=fetch_creds('psql_prod_dbHost')

    raw_conn_string = "dbname='"+psql_prod_database+"' port='"+psql_prod_port+"' user='"+psql_prod_username+"' password='"+psql_prod_password+"' host='"+psql_prod_dbHost+"'"
    #conn_string = "dbname='",psql_prod_database,"' port='",psql_prod_port,"' user='",psql_prod_username,"' password='",psql_prod_password,"' host='",psql_prod_dbHost,"'";
    conn_string=raw_conn_string.replace('\n',"")
    #print "Connecting to database\n        ->%s" % (conn_string)
    conn = psycopg2.connect(conn_string);
    #cursor = conn.cursor();
 
    df_html_table_email=""
    pd.set_option('display.max_colwidth', 1000)
 
    #query_df=fetch_query_results(run_query,conn)
        
    # Convert the dataframe to html table.                                     
    #raw_df_html_table_email=query_df.to_html()
   
    log_file_txt="" 
    if str(pretty_dq_json['DQ_Log']).strip(): 
        log_file_nm = open(pretty_dq_json['DQ_Log'], 'r')
        log_file_txt=log_file_nm.read()
    
    #print log_file_txt
    
    raw_df_html_table_email=""
    #print str(pretty_dq_json['DQ_JSON'])
    if str(pretty_dq_json['DQ_JSON']).strip():
        #query_df=pd.read_json(str(pretty_dq_json['DQ_JSON']))
        data = json.load(open(pretty_dq_json['DQ_JSON']), object_pairs_hook=OrderedDict)
        if data:
            header = [h for h in data[0].keys()]
        else:
            header = []
        query_df = pd.DataFrame(data, columns=header)
        raw_df_html_table_email=query_df.to_html()
        #print raw_df_html_table_email


    df_html_table_email=raw_df_html_table_email.encode('utf-8').replace('<td>SUCCESS</td>', '<td><font size="2" color="green"><b>SUCCESS</b></font></td>').replace('<td>WARNING</td>', '<td><font size="2" color="orange"><b>WARNING</b></font></td>').replace('<td>FAILURE</td>', '<td><font size="2" color="red"><b>FAILURE</b></font></td>').replace('<td>NOTIFY</td>', '<td><font size="2" color="orange"><b>NOTIFY</b></font></td>') 
    
    pretty_dq_json['log_txt']=log_file_txt.replace('SUCCESS', '<font size="2" color="green"><b>SUCCESS</b></font>').replace('WARNING', '<font size="2" color="orange"><b>WARNING</b></font>').replace('FAILURE', '<font size="2" color="red"><b>FAILURE</b></font>').replace('NOTIFY', '<font size="2" color="orange"><b>NOTIFY</b></font>')   
    print dq_job_name, "dq process completed"                                                                   
    
    #send result as email
    dq_return_code=send_dq_email(pretty_dq_json,df_html_table_email)    
    
    log_dq_results(conn,pretty_dq_json,dq_return_code,df_html_table_email)
    #send return code to bash
    #if dq_return_code=='FAILURE':
    #    print "dq job return code : -1"
    #    #sys.exit(-1)
    
    #else :
    #    print "dq job return code : 0"
    #    #sys.exit(0)

                                                                                             
if __name__ == '__main__':                                                                      
    main() 
