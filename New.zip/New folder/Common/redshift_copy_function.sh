source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

var_header=$4
if [ -n "$var_header" ]; then
   query="copy "$1" from '"$s3_bucket_name$2$3"' credentials '$s3_prod_load_creds' gzip delimiter '\t' dateformat 'auto' NULL AS 'NULL' IGNOREHEADER AS 1 ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF TRUNCATECOLUMNS TRIMBLANKS maxerror 150;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
else
    query="copy "$1" from '"$s3_bucket_name$2$3"' credentials '$s3_prod_load_creds' gzip delimiter '\t' dateformat 'auto' NULL AS 'NULL' ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF TRUNCATECOLUMNS TRIMBLANKS maxerror 150;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
fi

