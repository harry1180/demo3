source set_dwh_env_variables.sh
source "$dwh_common_base_dir/set_dwh_schema_variables.sh"

job_name=$1

Linux_Input=${dwh_data_base_dir}/${job_name}/input/
Linux_Output=${dwh_data_base_dir}/${job_name}/output/
Linux_Archive=${dwh_data_base_dir}/${job_name}/archive/
Linux_Temp=${dwh_data_base_dir}/${job_name}/tmp/
S3_Input=/s3mnt-dwh-staging/${job_name}/input/
S3_Output=/s3mnt-dwh-staging/${job_name}/output/
S3_Archive=/s3mnt-dwh-staging/${job_name}/archive/
S3_Events_Input=${job_name}/input/
S3_Events_Output=${job_name}/output/
S3_Events_Archive=${job_name}/archive/
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+  Common Variables   +----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo 'dwh_credentials_file_dir   :-   '${dwh_credentials_file_dir}
echo 'dwh_scripts_base_dir       :-   '${dwh_scripts_base_dir}
echo 'dwh_common_base_dir        :-   '${dwh_common_base_dir}
echo 'dwh_data_base_dir          :-   '${dwh_data_base_dir}
echo 'Linux_Input                :-   '${Linux_Input}
echo 'Linux_Output               :-   '${Linux_Output}
echo 'Linux_Archive              :-   '${Linux_Archive}
echo 'S3_Input                   :-   '${S3_Input}
echo 'S3_Output                  :-   '${S3_Output}
echo 'S3_Archive                 :-   '${S3_Archive}
echo 'S3_Events_Input            :-   '${S3_Events_Input}
echo 'S3_Events_Output           :-   '${S3_Events_Output}
echo 'S3_Events_Archive          :-   '${S3_Events_Archive}
echo '+----------+----------+----------+----------+----------+----------+'

# Replaces AWS keys in credentials file with temporary keys
python ${dwh_common_base_dir}/update_dwh_credentials.py  || exit
