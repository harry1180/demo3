#!/usr/bin/env python

import logging
import os
import sys

import psycopg2

logging.basicConfig(format='[%(asctime)s] %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

if len(sys.argv) != 2:
    print('Usage: redshift_char_col_max.py <schema.table>')
    sys.exit(1)

logging.info('Execution begins')
postgres_host = 'redshift.east1.prod.nerdwallet.com'
postgres_port = 5439
postgres_database = 'dev'
postgres_username = os.environ['USER']
fq_postgres_table = sys.argv[1]

postgres_password = None

# Try reading from $HOME/.pgpass
if postgres_password is None:
    try:
        pgpass_filename = '{}/.pgpass'.format(os.environ.get('HOME', ''))
        with open(pgpass_filename, 'r') as fh:
            pgpass_line_start = "{}:{}:{}:{}:".format(
                postgres_host,
                postgres_port,
                postgres_database,
                postgres_username)
            for line in fh:
                if line.strip().lower().startswith(pgpass_line_start.lower()):
                    postgres_password = line[len(pgpass_line_start):].rstrip('\r\n')
                    logging.info("Retrieved password for {} from {}".format(postgres_username, pgpass_filename))
                    break
    except IOError:
        pass

if not postgres_password:
    logging.critical('Unable to get Postgres password')
    sys.exit(1)

logging.info('Connecting to Postgres on {}:{}/{} as {}'.format(postgres_host, postgres_port, postgres_database, postgres_username))
conn = psycopg2.connect(
    host=postgres_host,
    port=postgres_port,
    user=postgres_username,
    password=postgres_password,
    dbname=postgres_database,
    connect_timeout=30,
    application_name='redshift_char_col_max.py'
    )

# Get the list of tables in our schema
sql = 'SELECT column_name FROM information_schema.columns WHERE table_schema = %s and table_name = %s and data_type = \'character varying\' order by ordinal_position'
columns = list()
with conn.cursor() as curs:
    params = fq_postgres_table.lower().split('.', 1)
    curs.execute(sql, params)
    row = curs.fetchone()
    while row is not None:
        columns.append(row[0])
        row = curs.fetchone()

max_field_name_length = max([len(col) for col in columns])

for column in columns:
    sql = ('select count({column_name}), max(length({column_name})) from {table_name}').format(
        table_name=fq_postgres_table.lower(),
        column_name=column)
    with conn.cursor() as curs:
        curs.execute(sql)
        column_value_count, max_field_length = curs.fetchone()
        print('{column_name: <{pad_length}}: {value_count: >10} values, max length = {max_length: >10}'.format(
            pad_length=max_field_name_length,
            column_name=column,
            value_count=column_value_count,
            max_length='-' if max_field_length is None else max_field_length))

conn.close()
logging.info('Execution ends')
