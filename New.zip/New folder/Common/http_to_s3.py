#!/usr/bin/env python

import argparse
import logging
import json
import os
import pwd
import sys
import tempfile
from urlparse import urlparse

import boto3
import requests

from nw_retry import nw_retry, REQUEST_EXCEPTIONS
logger = logging.getLogger()


def store_file(local_filename, dest_filespec):
    if dest_filespec.lower().startswith('s3://'):
        s3_url = urlparse(dest_filespec)
        s3_bucket = s3_url.netloc
        s3_key = s3_url.path[1:]
        logger.info('Uploading {} to s3://{}/{}'.format(local_filename, s3_bucket, s3_key))
        s3 = boto3.resource('s3')
        s3.Bucket(s3_bucket).upload_file(local_filename, s3_key)
    else:
        logger.info('Moving {} to {}'.format(local_filename, dest_filespec))
        if os.path.exists(dest_filespec):
            os.remove(dest_filespec)
        os.rename(local_filename, dest_filespec)


@nw_retry(REQUEST_EXCEPTIONS, tries=7, delay=30, backoff=2)
def url_to_file(url, local_filename):
    r = requests.get(url, stream=True)
    with open(local_filename, 'w') as fhout:
        for chunk in r.iter_content(chunk_size=65536):
            if chunk:
                fhout.write(chunk)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', required=True, help='URL to retrieve data from')
    parser.add_argument('--output', required=True, help='Local filename or S3 URL to store the data in')
    parser.add_argument('--array-to-lines', required=False, action='store_true',
                        help='Retrieved data is a JSON array to be split into lines')
    parser.add_argument('--tmp-dir', required=False, help='Directory to store temporary files in')
    parser.add_argument('--transform', required=False,
                        help='Filename of a Python module that contains a function \'transform\' that should ' +
                             'transform the object before writing it')
    args = parser.parse_args()

    if args.transform:
        raise NotImplemented('Parameter \'transform\' is not yet supported')

    logging.getLogger('botocore').setLevel(logging.WARNING)
    if pwd.getpwuid(os.getuid()).pw_name == 'airflow':
        logging.basicConfig(format='[%(levelname)-8s] %(name)s - %(message)s', level=logging.INFO)
    else:
        logging.basicConfig(format='[%(asctime)s] [%(levelname)-8s] %(name)s - %(message)s', level=logging.INFO)
    logger.info('Execution begins')

    # Retrieve the data and store it into a local file
    fh_local = tempfile.NamedTemporaryFile(
        dir=args.tmp_dir or '/tmp',
        prefix='http_to_s3_',
        suffix='.raw',
        delete=False
        )
    fh_local.close()
    logger.info('Getting data from {} and storing it to {}'.format(args.url, fh_local.name))
    url_to_file(args.url, fh_local.name)
    logger.info('Stored {} bytes'.format(os.path.getsize(fh_local.name)))

    if not args.array_to_lines:
        store_file(fh_local.name, args.output)
        if os.path.exists(fh_local.name):
            os.remove(fh_local.name)
        logger.info('Execution ends')
        sys.exit(0)

    with open(fh_local.name, 'r') as fhin:
        obj = json.load(fhin)
    os.remove(fh_local.name)
    fh_lines = tempfile.NamedTemporaryFile(
        dir=args.tmp_dir or '/tmp',
        prefix='http_to_s3_',
        suffix='.json',
        delete=False
        )
    line_count = 0
    for obj_element in obj:
        line_count += 1
        fh_lines.write(json.dumps(obj_element))
        fh_lines.write('\n')
    fh_lines.close()
    logger.info('Translated object into {} records'.format(line_count))

    store_file(fh_lines.name, args.output)
    if os.path.exists(fh_lines.name):
        os.remove(fh_lines.name)

    logger.info('Execution ends')
