#!/usr/bin/env bash

if [ $# -lt 4 ]
then
    echo 'Usage: gs_to_table.sh <spreadsheet_url> <sheet_name> <table_schema> <table_name>'
    exit 1
fi

spreadsheet_url="$1"
sheet_name="$2"
table_schema="$3"
table_name="$4"

set -e
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh "$event_name"
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh

echo "Purging $table_schema.$table_name"
python $dwh_common_base_dir/redshift_purge_table.py "$table_schema.$table_name"

echo "Loading worksheet \"$sheet_name\" into table $table_schema.$table_name"
python -c "from google_spreadsheet import gs_to_table;
gs_to_table(url='$spreadsheet_url', worksheet='$sheet_name', schema='$table_schema', table='$table_name', file_out_dir='$LinuxOutput')"
