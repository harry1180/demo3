#!/bin/bash

if [ $# -lt 1 ] || [ $# -gt 2 ]
then
    echo "Usage: presto_sql_function.sh <filename.sql> [params.json]"
    exit 1
fi

# This script handles passwords so explicitly disable command echoing
set +x
job_name='presto_sql_function'

source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    if [ -n "$PRESTO_OUTPUT" ] && [ -e "$PRESTO_OUTPUT" ]
    then
        rm $PRESTO_OUTPUT
    fi
    if [ -n "$parsed_sql_file" ] && [ -e "$parsed_sql_file" ]
    then
        rm "$parsed_sql_file"
    fi
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    echo "An error occurred. Exiting while performing *****************SQL Step" >&2
    exit 1
}
trap 'abort' 0
set -e

if [ $# -lt 1 ] || [ $# -gt 2 ]
then
    echo "Usage and Example:
## 1. presto_sql_function.sh step00_url_stage_s_del.sql
## 2. presto_sql_function.sh step00_url_stage_s_del.sql param.json
"
    exit 1
fi

# If this script is running from within a job, the temporary directory will be set to a subdirectory within the job's
# data directory. If not, let's use /tmp.
Linux_Temp=${Linux_Temp:-/tmp}
if [ ! -d $Linux_Temp ]
then
    echo "WARNING: $Linux_Temp: no such directory, using /tmp instead"
    Linux_Temp=/tmp
fi

sql_file="$1"
if [ ! -e $sql_file ]
then
    echo "SQL script [$sql_file] doesn't exist."
    exit 1
fi
orig_sql_file="$sql_file"

if [ $# -ge 2 ]
then
    if [[ "$2" != *.json ]]
    then
        echo "Second parameter must be a *.json file"
        exit 1
    fi
    parsed_sql_file=$(mktemp --tmpdir=$Linux_Temp $(basename $sql_file)_XXXXXXXXXX)
    echo "Replacing JSON parameters in $sql_file, writing to $parsed_sql_file"
    param_file=$2
    python $dwh_common_base_dir/replace_params.py $sql_file $param_file > $parsed_sql_file
    sql_file=$parsed_sql_file
fi

if [ ! -s $sql_file ]
then
    echo "SQL file is empty: $sql_file"
    exit 1
fi

# Get the LDAP password
echo "Getting the LDAP password"
if [ $(id -un) = "airflow" ]
then
    PROD_CREDS_FILENAME="/etc/dwh_secured_tokens/airflow.json"
    echo "Retrieving LDAP password from $PROD_CREDS_FILENAME"
    readarray -n 2 -t LDAP_CREDS_ARR <<< "$(python <<EOF
import json
with open ('$PROD_CREDS_FILENAME') as fh:
    creds = json.load(fh)
print("{}\n{}".format(
    creds["active_directory"]["airflow"]["user"],
    creds["active_directory"]["airflow"]["password"]))
EOF
    )"
    LDAP_USER=${LDAP_CREDS_ARR[0]}
    LDAP_PASSWORD=${LDAP_CREDS_ARR[1]}
    unset LDAP_CREDS_ARR
else
    LDAP_USER=$(id -un)
    read -s -p "Okta Password: " LDAP_PASSWORD
    echo ""
fi
if [ -z "$LDAP_PASSWORD" ]
then
    echo "ERROR: Blank password, aborting"
    exit 1
fi

# Only way to detect failures in the presto-cli command is to look for error messages in the output. Not great, but
# better than nothing.
echo "Executing Presto to run $sql_file"
start_time=$(date +%s.%N)
PRESTO_OUTPUT=$(mktemp --tmpdir=$Linux_Temp --suffix=.out presto_cli_XXXXXXXXXX)
expect 1> >(tee $PRESTO_OUTPUT) 2>&1 <<EOF
set timeout 90
spawn nw-presto \
    --user $LDAP_USER \
    --password \
    --file "$sql_file" \
    --session hive.parquet_optimized_reader_enabled=false \
    --source "$(basename $orig_sql_file) in $(dirname $orig_sql_file)"
expect {
    timeout { exit 1 }
    eof { exit 1 }
    "Password: "
}
send "$(echo "$LDAP_PASSWORD" | sed -r 's/([]\[\\$"])/\\\1/g')\n"
expect eof
lassign [ wait ] pid spawnid os_error_flag os_rc
if {\$os_error_flag != 0} {
    puts "OS Error: \$os_rc"
    exit 1
}

exit \$os_rc
EOF
printf 'Elapsed time: %.*f seconds\n' 3 $(echo "$(date +%s.%N) - $start_time" | bc)

if [ -n "$parsed_sql_file" ]
then
    rm $parsed_sql_file
fi

# Search the output for an error message
# Note: The grep command's exit values aren't the typical Unix return values. An exit code of '1' means that no matches
#       were found which means the presto command worked as expected. Any other exit code from grep should be treated as
#       a failure.
set +e
grep -qP '^(Query [^ ]+ failed:|Error running command:)' $PRESTO_OUTPUT
GREP_RC=$?
set -e
rm $PRESTO_OUTPUT
if [ $GREP_RC -ne 1 ]
then
    exit 1
fi

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
