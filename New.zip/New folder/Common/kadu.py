import argparse
import json
import logging
import os
import sys

from botocore.exceptions import ClientError
from boto3.session import Session
from boto3.dynamodb.conditions import Key
from datetime import datetime, timedelta
from prettytable import PrettyTable
from struct import pack

from kadu_modules import KaduParams, KaduRunLog
from nw_dynamodb import get_table, put_item_in_table
from nw_kafka import connect, get_partitions, get_topic_partitions


def setup_logging(debug=False):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(format='[%(levelname)-8s]:%(asctime)s %(message)s', level=level, datefmt='%Y/%m/%d %H:%M:%S')

    # Change the default logging level for the boto3, pyhive, amd kafka modules to WARN.
    loggers_to_set_to_warn = [
        'botocore',
        'pyhive',
        'kafka'
    ]
    for logger_to_set_to_warn in loggers_to_set_to_warn:
        logger = logging.getLogger(logger_to_set_to_warn)
        logger.setLevel(logging.WARN)


def get_historical_offsets(hist_offset_table_nm, topic, aws_profile, aws_region):
    """
    Returns most recently added offset information from historical offset dynamodb table for a topic
    :param hist_offset_table_nm: Historical offset table ame
    :param topic: Topic name
    :param aws_profile: aws profile
    :param aws_region: aws region
    :return: DynamoDB item
    """
    historical_offset_table = get_table(hist_offset_table_nm, aws_profile, aws_region)
    try:
        item = historical_offset_table.query(
            KeyConditionExpression=Key('kafka_topic_nm').eq(topic),
            Limit=1,
            ScanIndexForward=False
        ).get('Items', {})[0]
    except Exception as e:
        logging.error(e)
        logging.error('Error retrieving historical offsets from {}nw for {}'.format(hist_offset_table_nm, topic))
        sys.exit(1)
    return item


def get_start_offsets(offset_table, topic, aws_profile, aws_region):
    """
    Returns current offset information from offset dynamodb table for a topic
    :param offset_table: Offset table name
    :param topic: Topic Name
    :param aws_profile: aws profile
    :param aws_region: aws region
    :return: DynamoDB item
    """
    offset_table = get_table(offset_table, aws_profile, aws_region)
    try:
        item = offset_table.get_item(
            Key={'kafka_topic_nm': topic},
            ConsistentRead=True,
        ).get('Item', {})
    except Exception as e:
        logging.error(e)
        logging.error('Error retrieving offsets from {} for {}'.format(offset_table, topic))
        sys.exit(1)
    return item


def get_end_offsets(kafka_consumer, topic_partitions, partitions):
    """
    Uses KafkaConsumer to get end offsets for a topic.
    :param kafka_consumer: Instantiated KafkaConsumer object
    :param topic_partitions: List of topic partitions
    :param partitions: List of partitions
    :return: Dictionary of offsets
    """
    end_offsets = kafka_consumer.end_offsets(topic_partitions)
    end_offsets_dict = {}
    for partition in partitions:
        k = 'partition_' + str(partition)
        end_offsets_dict[k] = end_offsets[topic_partitions[partition]] - 1
    return end_offsets_dict


def get_newest_upload_file(topic, s3_bucket, kadu_parameters, aws_profile=None):
    """
    Gets newest kadu generated s3 file for a topic.
    :param topic: Topic name
    :param s3_bucket: s3 Bucket
    :param kadu_parameters: kadu parameters
    :param aws_profile: prod or dev aws_profile
    :return: S3 item
    """
    session = Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    _today = datetime.today()
    days_to_lookback = 0

    while days_to_lookback < 30:
        prefix = _today.strftime('{}/%Y/%m/%d'.format(topic))
        if kadu_parameters.s3_key_format == 'stage_s3_key':
            prefix = _today.strftime('kadu/{}/%Y/%m/%d'.format(topic))
        logging.info('Searching for newest file in {}/{}'.format(s3_bucket, prefix))
        items = s3_client.list_objects_v2(Bucket=s3_bucket, Prefix=prefix)
        contents = items.get('Contents', [])
        contents = [s3_obj for s3_obj in contents if 'counts' not in s3_obj['Key']]
        if contents:
            sorted_contents = sorted(contents, key=lambda y: y['LastModified'], reverse=True)
            newest_item = sorted_contents[0]
            logging.info('File found: {}'.format(str(newest_item)))
            return newest_item
        else:
            logging.warn('No file found in s3 in {}/{}'.format(s3_bucket, prefix))
            _today -= timedelta(days=1)
            days_to_lookback += 1

    raise Exception('No files found: Human intervention needed')


def check_s3_file_exist(dest_s3_file, kadu_params):
    """
    Checks if kadu generated s3 file exist
    :param dest_s3_file: s3 Object
    :param kadu_params: kadu params
    :return: True if file exist else False
    """
    existing_size = 0
    existing_mtime = None

    try:
        existing_size = dest_s3_file.content_length
        existing_mtime = dest_s3_file.last_modified
    except ClientError as ex:
        pass
    if existing_size > 0 or existing_mtime is not None:
        logging.info('s3://{}/{} exists (modified {}, {} bytes) and shall not be overwritten.'.format(
            kadu_params.s3_bucket, kadu_params.s3_key, existing_mtime, existing_size))
        return True
    else:
        return False


def get_dest_s3_object(s3_bucket, s3_key, aws_profile):
    session = Session(profile_name=aws_profile)
    s3 = session.resource('s3')
    return s3.Object(s3_bucket, s3_key)


def update_counts_file(kadu_parameters, counts):
    """
    Updates or creates a counts file in s3 for topic
    :param kadu_parameters: kadu paramts
    :param counts: Counts dictionary with count information
    :return:
    """
    tmp_counts_file = kadu_parameters.now.strftime('/tmp/{}counts.json'.format(kadu_parameters.topic))
    s3_counts_key = kadu_parameters.now.strftime('kadu/{}/%Y/%m/%d/counts.json'.format(kadu_parameters.topic))
    logging.info('writing count.json to {}/{}'.format(kadu_parameters.s3_bucket, s3_counts_key))
    s3_counts_object = get_dest_s3_object(kadu_parameters.s3_bucket, s3_counts_key)

    counts_row = {
        'platform': 's3',
        'event_name': kadu_parameters.topic,
        'key': kadu_parameters.s3_key,
        'record_count': sum(counts.values())
    }

    try:
        s3_counts_object.download_file(tmp_counts_file)
    except ClientError:
        pass

    with open(tmp_counts_file, 'a+') as countf:
        countf.write(json.dumps(counts_row) + '\n')

    s3_counts_object.put(Body=open(tmp_counts_file, 'rb'))
    return


def run_kadu(kadu_parameters):
    logging.info('Beginning kadu for {}'.format(kadu_parameters.topic))

    # Assign destination file and check if it already exists in S3. If file exist then abort. Running multiple times in
    # one hour will overwrite the file from last run because of the granularity of s3 filename
    logging.info('Checking if {}/{} exist in s3'.format(kadu_parameters.s3_bucket, kadu_parameters.s3_key))
    dest_s3_object = get_dest_s3_object(kadu_parameters.s3_bucket, kadu_parameters.s3_key, kadu_parameters.aws_profile)

    if check_s3_file_exist(dest_s3_object, kadu_parameters):
        if kadu_parameters.no_recovery:
            logging.warning('{}/{} exist in s3. In --no_recovery mode continuing with kadu'.format(kadu_parameters.s3_bucket, kadu_parameters.s3_key))
        else:
            logging.warning('{}/{} exist in s3. Exiting without uploading to s3, or updating checkpoints.'.format(kadu_parameters.s3_bucket, kadu_parameters.s3_key))
            sys.exit(1)
    else:
        logging.debug('{}/{} does not exist in s3. Continuing with kadu'.format(kadu_parameters.s3_bucket, kadu_parameters.s3_key))

    # Get kafka partitions
    logging.info('Instantiating Kafka Consumer and retrieving partitions / topic partitions')
    kafka_consumer = connect(kadu_parameters.kafka_servers, kadu_parameters.kafka_client_id, max_poll_records=10000)
    partitions = get_partitions(kafka_consumer, kadu_parameters.topic)
    logging.debug(partitions)
    topic_partitions = get_topic_partitions(partitions, kadu_parameters.topic)
    logging.debug('Topic Partitions: {}'.format(str(topic_partitions)))

    # Get Historical/Start/End Offsets and instantiate current offset log
    logging.info('Retrieving Start Offsets')
    if kadu_parameters.manual_start_offsets:
        start_offsets_dict = kadu_parameters.manual_start_offsets
    else:
        start_offsets_dict = get_start_offsets(kadu_parameters.offset_table,
                                               kadu_parameters.topic,
                                               kadu_parameters.aws_profile,
                                               kadu_parameters.aws_region)
    start_log = KaduRunLog(name='start_offsets', offset_dict=start_offsets_dict, topic=kadu_parameters.topic)
    logging.info(str(start_log))

    logging.info('Retrieving End Offsets')
    if kadu_parameters.manual_end_offsets:
        end_offsets_dict = kadu_parameters.manual_end_offsets
    else:
        end_offsets_dict = get_end_offsets(kafka_consumer, topic_partitions, partitions)
    end_log = KaduRunLog(name='end_offsets', offset_dict=end_offsets_dict, topic=kadu_parameters.topic)
    logging.info(str(end_log))

    logging.debug('Instantiating Current Offset Log')
    curr_log = KaduRunLog(name='curr_offset_log', topic=kadu_parameters.topic)
    logging.debug(str(curr_log))

    # Validate record from last run matches our logs
    if kadu_parameters.no_recovery:
        logging.info('In --no_recovery mode. Not validating that last run succeeded and continuing with kadu')
    elif start_log.get_partition_count() > 0:
        # if n offsets is > 0 then assume regular run
        logging.info('Validating that last run completed successfully')
        s3_file = get_newest_upload_file(kadu_parameters.topic, kadu_parameters.s3_bucket, kadu_parameters)
        if (s3_file['Size'] == start_log.get_file_size()) and (s3_file['Key'] == start_log.get_file_s3_key()):
            logging.info('Last upload to S3 matches our logs, continuing kadu normally')
        else:
            logging.warn('Last upload to S3 does not match our logs because the program terminated after uploading to \
                          s3 but before the offset table was updated. Checking historical logs for offsets')
            historical_offsets_dict = get_historical_offsets(kadu_parameters.offset_hist_table,
                                                             kadu_parameters.topic,
                                                             kadu_parameters.aws_profile,
                                                             kadu_parameters.aws_region)
            hist_log = KaduRunLog(name='hist_offsets', offset_dict=historical_offsets_dict, topic=kadu_parameters.topic)
            logging.info(str(hist_log))
            if (s3_file['Size'] == hist_log.get_file_size()) and (s3_file['Key'] == hist_log.get_file_s3_key()):
                logging.info('Last upload to S3 matches our historical logs. Using historical logs as offset starting point')
                start_log = hist_log
            else:
                logging.error('Human interaction needed because prior run\'s s3 file does not match with checkpoints\
                               but it is possible that downstream ETL could have processed s3 file')
                sys.exit(1)
    else:
        # if n offsets = 0  then assume it is a first run and skip validation
        logging.warn('No offsets found in dwh-kadu-offsets, assuming first run')

    # For each partition consume messages from start offset to end offset and write to local outfile
    counts = dict()
    with open(kadu_parameters.local_out, 'wb') as outf:
        for partition in partitions:
            logging.info('Beginning kafka consumption for partition_{}'.format(partition))
            counts[partition] = 0
            assigned_partition = topic_partitions[partition]
            logging.debug('KafkaConsumer subscribing to {}'.format(assigned_partition))
            kafka_consumer.assign([assigned_partition])
            logging.debug('Adding partition_{} to {}'.format(partition, curr_log.name))
            curr_log.add_partition(partition)

            if start_log.get_offset(partition):
                logging.info('Start offset found for partition_{}'.format(partition))
                beginning_offset = start_log.get_offset(partition) + 1
                kafka_consumer.seek(assigned_partition, beginning_offset)
                curr_log.set_offset(partition, beginning_offset)
                logging.info('kadu beginning at offset {} for {}'.format(beginning_offset, assigned_partition))
            else:
                logging.info('No starting offset found for partition_{}. Starting at earliest offset'.format(partition))
                kafka_consumer.seek_to_beginning(assigned_partition)
                beginning_offset = kafka_consumer.position(assigned_partition)
                curr_log.set_offset(partition, beginning_offset)
                logging.info('kadu beginning at offset {} for {}'.format(beginning_offset, assigned_partition))

            done = False
            logging.info('Kafka polling beginning')
            logging.debug(str(counts))
            if beginning_offset > end_log.get_offset(partition):
                curr_log.set_offset(partition, beginning_offset - 1)
                pass
            else:
                while not done:
                    res = kafka_consumer.poll(timeout_ms=kadu_parameters.poll_timeout_ms)
                    if len(res) == 0:
                        continue
                    for subpartition in res:
                        for msg in res[subpartition]:
                            curr_log.set_offset(partition, msg.offset)
                            counts[partition] += 1
                            if kadu_parameters.protocol == 'pbuf':
                                outf.write(pack('>Q', len(msg.value)))
                                outf.write(msg.value)
                            else:
                                outf.write(msg.value)
                                outf.write('\n')
                            if msg.offset >= end_log.get_offset(partition):
                                done = True
                                break
            logging.info('{} messages consumed from {}'.format(counts[partition], topic_partitions[partition]))

    # Enrich current offset with local output file size and and key for s3 destination
    logging.info('Adding s3 file size to {}'.format(curr_log.name))
    curr_log.set_file_size(os.stat(kadu_parameters.local_out).st_size)
    logging.info('Adding s3 file key to {}'.format(curr_log.name))
    curr_log.set_file_s3_key(kadu_parameters.s3_key)
    logging.info('Adding upload_ts to {}'.format(curr_log.name))
    curr_log.set_upload_ts(long((datetime.utcnow() - datetime.utcfromtimestamp(0)).total_seconds() * 1000.0))
    logging.info('Get dynamodb item for {}'.format(curr_log.name))
    curr_offset_payload = curr_log.get_payload()

    # print stats before upload attempts
    pt = PrettyTable(['Topic Partition', 'Start Offset', 'End Offset', 'Messages Consumed'])
    # TODO add more metrics here
    for partition in partitions:
        pt.add_row([
            topic_partitions[partition],
            start_log.get_offset(partition),
            curr_log.get_offset(partition),
            counts[partition]
        ])
    pt.add_row(['OVERALL', '-', '-', sum(counts.values())])
    print pt

    if kadu_parameters.read_only:
        logging.info('In --read_only mode, skipping logging to s3 and dynamo')
    elif not kadu_parameters.save:
        logging.info('Not in --save mode, skipping logging to s3 and dynamo')
    else:
        # Upload current offset to dwh-kadu-offsets-hist table
        try:
            logging.info('Uploading current offset to dwh-kadu-offsets-hist table')
            res = put_item_in_table(kadu_parameters.offset_hist_table,
                                    curr_offset_payload,
                                    kadu_parameters.aws_profile,
                                    kadu_parameters.aws_region)
            logging.debug(res)
            status_code = res['ResponseMetadata']['HTTPStatusCode']
            if status_code != 200:
                raise Exception('Status Code: {}'.format(status_code), res)
            logging.info('Upload dwh-kadu-offsets-hist table successful')
        except Exception as e:
            logging.error(e)
            logging.error('Unable to upload current offset logs to dynamo table {}'.format(kadu_parameters.offset_hist_table))
            sys.exit(1)

        # On successful upload of offset item into dwh-kadu-offsets-hist upload local output file to s3
        if kadu_parameters.no_s3:
            logging.info('In --no_s3 mode, skipping upload of s3 file')
        else:
            logging.info('Uploading {local_file} to s3://{bucket}/{s3_key}'.format(
                local_file=kadu_parameters.local_out,
                bucket=kadu_parameters.s3_bucket,
                s3_key=kadu_parameters.s3_key
            ))
            try:
                session = Session(profile_name=kadu_parameters.aws_profile)
                s3 = session.resource('s3')
                s3.Bucket(kadu_parameters.s3_bucket).upload_file(kadu_parameters.local_out, kadu_parameters.s3_key)
            except Exception as e:
                logging.error(e)
                logging.error('Unable to upload file to S3, exiting job')
                sys.exit(1)

        # On successful s3 upload of local output file to s3  update offset record in dwh-kadu-offsets
        try:
            logging.info('Updating offset record in dwh-kadu-offsets')
            res = put_item_in_table(kadu_parameters.offset_table,
                                    curr_offset_payload,
                                    kadu_parameters.aws_profile,
                                    kadu_parameters.aws_region)
            logging.debug(res)
            status_code = res['ResponseMetadata']['HTTPStatusCode']
            if status_code != 200:
                raise Exception('Status Code: {}'.format(status_code), res)
            logging.info('Upload of dwh-kadu-offsets table successful')
        except Exception as e:
            logging.error(e)
            logging.error('Unable to update dwh-kadu-offsets ending job normally')
            sys.exit(1)

    logging.info('kadu completed successfully!')

if __name__ == '__main__':
    setup_logging()
    clparser = argparse.ArgumentParser(description='Dump kafka data using nw conventions into s3.')
    clparser.add_argument('--topic', required=True, help='Kafka topic.')
    clparser.add_argument('--protocol', required=True, choices=['pbuf', 'json'], help='Payload protocol.')
    clparser.add_argument('--kafka_servers', required=True, help='Kafka servers')
    clparser.add_argument('--s3_key_format', required=True, choices=['prod_s3_key', 'stage_s3_key'], help='Whether or not to include /kadu/ in s3_key')
    clparser.add_argument('--dynamo_environment', required=True, choices=['prodenv', 'stageenv', 'kafka10test'], help='What dynamo tables to write in')
    clparser.add_argument('--s3_bucket', help='Destination s3-bucket')
    clparser.add_argument('--aws_profile', choices=['nwprod', 'nwdev'], help='What AWS profile to use')
    clparser.add_argument('--aws_region', default='us-east-1', help='aws region')
    clparser.add_argument('--s3', help='Override s3 file generated')
    clparser.add_argument('--save', action='store_true', help='Log s3 file and updated offsets of run')
    clparser.add_argument('--read_only', action='store_true', help='Don\'t save offsets, if you\'re privileged.')
    clparser.add_argument('--no_s3', action='store_true', help='Do not upload to s3, and keep the local file; unsafe unless using --readonly.')
    clparser.add_argument('--out', help='Local output file.')
    clparser.add_argument('--no_recovery', action='store_true', help='Override recovery processing.')
    clparser.add_argument('--start_offsets', help='Manual starting offsets. Format: \'{"partition_0":offset_0, ..., "partition_n":offset_n}\'')
    clparser.add_argument('--end_offsets', help='Manual ending offsets. Format: \'{"partition_0":offset_0, ..., "partition_n":offset_n}\'')
    clparser.add_argument('--poll_timeout_ms', default=5000, help='Set Kafka poll timeout in ms')

    logging.info(str(clparser.parse_args()))
    args = clparser.parse_args()
    kadu_parameters = KaduParams(args)
    run_kadu(kadu_parameters)
