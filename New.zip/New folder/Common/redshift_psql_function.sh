#!/bin/bash
set -e

if [ $# -lt 1 ]
then
    echo "Usage: redshift_psql_function.sh <filename.sql> [psql parameters...]"
    exit 1
fi

source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl
source "$dwh_common_base_dir/set_dwh_schema_variables.sh"

## Usage: Execute a SQL statement against Redshift using the 'psql' client
##     command, optionally specifying additional psql parameters.
##
## Examples:
##     redshift_psql_function.sh step00_url_stage_s_del.sql
##     redshift_psql_function.sh step00_url_stage_s_del.sql -v proc_date=2018-03-05
##
## Sample SQL: SELECT * FROM :dbname.test WHERE dw_eff_dt = :'proc_date';

# psql variables, these are set in 'set_dwh_common_variables.sh'
if [ -z "$stagedb" ]
then
    echo "Variable 'stagedb' not set"
    exit 1
fi
if [ -z "$reportdb" ]
then
    echo "Variable 'reportdb' not set"
    exit 1
fi
if [ -z "$pudstagedb" ]
then
    echo "Variable 'pudstagedb' not set"
    exit 1
fi
if [ -z "$pudreportdb" ]
then
    echo "Variable 'pudreportdb' not set"
    exit 1
fi

psql -e \
    -h "$pdbHost" \
    -p "$pport" \
    -d "$pdatabase" \
    -U "$pusername" \
    -v ON_ERROR_STOP=on \
    -v stagedb="$stagedb" \
    -v reportdb="$reportdb" \
    -v pudstagedb="$pudstagedb" \
    -v pudreportdb="$pudreportdb" \
    -f "$@"
