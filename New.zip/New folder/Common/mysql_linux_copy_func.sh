source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

job_name='MySql Copy Function'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

#######################################
#Main Script
######################################
echo "
#########################################################################################
##                                                                                     ##
## This function is for MySql to copy the data to redshift                             ##
## It takes 3 Arguments 1) SQL Query 2) Output File 3) Database (Optional)             ##
## Optional Paramerter:- If not specified it connects to Old Mysql else bcc or dbetl   ##
##                                                                                     ##
#########################################################################################
"
if [ -z $3 ]; then
    source_database='Mysql_DB'
    mdbHost=$mdbHost
    musername=$musername
    mdatabase=$mdatabase
    mpassword=$mpassword
elif [ "$3" == "bcc_app" ]; then 
    source_database='BCC APP'
    mdbHost=$bcc_app_prod_dbHost
    musername=$bcc_app_prod_username
    mdatabase=$bcc_app_prod_database
    mpassword=$bcc_app_prod_password
else 
    source_database='Aurora_DBETL'
    mdbHost=$auroradbetlHost
    musername=$auroradbetusername
    mdatabase=$auroradbetpassword
    mpassword=$auroradbetdatabase
fi

if [[ ( "$#" -lt 2 ) || ( "$#" -gt 3 ) ]]; then
    echo "Parameters Did not match"
    exit 1
else
    echo "Connection to Database  : "$source_database
fi



query=`cat $1`

outfile=$2

# count(*) query to compare with the file generated
# first remove the ";" from the file

insel=`echo $query | tr -d ';'`
#echo $insel

# build count(*) query from the input file in selquery variable
#selquery="select count(*) from ( $insel "
#selquery+=" ) as a ;"

selquery="select count(*) from ( $insel ) as a ;"
#echo $selquery
Processing_Step="Getting the counts"
echo "______________"$Processing_Step"______________"
mysql --host="$mdbHost" --user="$musername" --database="$mdatabase" --password="$mpassword" --column-names=0 --connect_timeout=28800 --execute="$selquery" > $outfile.cnt

cnt=`cat $outfile.cnt`

#echo $selquery
Processing_Step="Running actual query to pull the data"
echo "______________"$Processing_Step"______________"
mysql --host="$mdbHost" --user="$musername" --database="$mdatabase" --password="$mpassword" --column-names=0 --connect_timeout=28800 --execute="$query" > $outfile.tmp

# remove unwanted characters in the file
#tr -d '' < $outfile.tmp > $outfile

rm $outfile.tmp
# get the number of rows in the file
filecnt=`wc -l $outfile | cut -d " " -f 1`

#Replace the zeroDateTimeBehavior with null i.e 0000-00-00 00:00:00 with Null
sed -i "s/0000-00-00 00:00:00/NULL/g" "$outfile"
#test for file count and expected count

if  [ $cnt -eq $filecnt ];
then
 echo "Number of rows in file is:$filecnt, while number of rows in select are $cnt" 
else
 echo "Counts are mismatching"
fi

rm $outfile.cnt


trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
