import sys
import requests
import csv

from nw_retry import nw_retry, REQUEST_EXCEPTIONS

@nw_retry(REQUEST_EXCEPTIONS)
def call_api(url):
    response = requests.get(url, allow_redirects=True, timeout=1200, stream=True)
    response.raise_for_status()
    return response


def main(start_date, end_date, output_file, input_token):

    api_file = output_file.split('.')[0] + '.tmp'

    print "******Executing Python Script for following date parameters ***********************"
    print 'Date range for API call: Start Date: ' + start_date + ' End Date: ' + end_date
    print 'API output written in: ' + api_file + ' Final output in: ' + output_file

    url = "https://ran-reporting.rakutenmarketing.com/en/reports/media-optimization-report/filters?start_date=" + start_date + "&end_date=" + end_date + "&include_summary=N&network=1&tz=GMT&date_type=process&token=" + input_token
    r = call_api(url)
    with open(api_file, 'w') as f:
        try:
            f.write(r.text)
        except UnicodeEncodeError:
            print "The issue with the API data(UnicodeEncodeError) for the time frame:"+start_date+"and"+end_date
            sys.exit()

    with open(api_file, "r") as apiin:
        filereader = csv.reader(apiin, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        with open(output_file, "w") as writefile:
            filewriter = csv.writer(writefile, delimiter="\t")
            for line in filereader:
                filewriter.writerow(line)


if __name__ == '__main__':
    start_date = sys.argv[1]
    end_date = sys.argv[2]
    input_token = sys.argv[3]
    output_file = sys.argv[4]

    main(start_date, end_date, output_file, input_token)

