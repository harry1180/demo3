#!/usr/bin/env python

import argparse
import csv
import hashlib
import json
import os
import pwd
import requests
import StringIO
import sys
import uuid

from datetime import datetime
from decimal import Decimal

import nw_hive

from loopback_modules import LoopbackDB
from redshift_modules import load_creds
from s3_modules import ensure_clean_s3, s3_head, set_key_acl_policy

from boto.s3.connection import S3Connection
from boto.s3.key import Key
from psycopg2 import ProgrammingError

# See docs at https://github.com/NerdWallet/dwh/blob/loopback-push-docs/docs/loopback-push.rst

# This script does four things:
# 0. Builds a snapshot table for each target.
# 1. Extracts the data for the named target. 
# 2. Optionally moves the data to stage
# 3. Sends notification using yak

# This program runs dynamic SQL, in the sense that snapshot tablenames are parameterized using a
# schema.table template from the transmission configuration file, and the transmission instance
# sequence number.  We are using python substitution rather than psycopg2.sql.SQL.format() because
# the sources are trusted (not from the internet), and to avoid more challenging substitution
# mechanics in the materialization SQL because it typically contains both DDL and insertive DML.

# TODO: purge snapshot tables


def loopback_push(parmfile, forcefd, prodmode, jobname, dateoverride, notouchsnaps):
    
    aws_profile = None
    if current_user() != 'airflow':
        aws_profile = 'nwprod'

    xmitguid  = str(uuid.uuid4())
    now       = datetime.now()
    extractts = now.strftime('%Y-%m-%d %H:%M:%S')
    batchdt   = extractts.split(' ')[0] if dateoverride is None else dateoverride

    p = json.loads(slurp(parmfile))
    nerdlake_in = True if p.get('platform', '').lower() == 'nerdlake' else False

    if forcefd is None:
        t = now if dateoverride is None else datetime.strptime(dateoverride, '%Y-%m-%d')        
        fullmode = eval(p['full-mode-when'])   # full-mode-when parm uses 't' as its test value
    else:
        fullmode = True if forcefd == 'full' else False

    db_handler = None
    seqno    = None

    try:
        db_handler = LoopbackDB(nerdlake_in)
        s3_conn = S3Connection(profile_name=aws_profile)
        bucket = p['dest-bucket-prod'] if prodmode else p['dest-bucket-stage']
        s3_buck = s3_conn.get_bucket(bucket)
        s3_conn_prod = S3Connection(profile_name='nwprod') if current_user() != 'airflow' else S3Connection()

        # s3_pbuck() will always need connection to 'nw_prod'
        s3_pbuck = s3_conn_prod.get_bucket(p['dest-bucket-prod'])
        st_ptrna = 'snapshot-table-ptrn-prod' if prodmode else 'snapshot-table-ptrn-stage'

        (seqno, is_rerunning) = mark_journal_running(db_handler.journal_conn, p['transmission-name'], prodmode,
                                                     xmitguid, fullmode, extractts, batchdt, job_label(jobname), bucket)
        seqno_today = '{:010}'.format(seqno)
        seqno_ysday = '{:010}'.format(seqno-1) if seqno > 0 else '**********'    # *s should never happen, but selected this val to give errors

        # if we are in delta mode, make sure that we have a prior snap for yesterday for each target, else fall back to full.
        # this code runs for seqno==0 when fullmode==False also, in case people forget.
        if not fullmode:
            fulloverride = False
            for tp in p['targets']:  # tp = target parameters
                snapshot_table_y = tp[st_ptrna].format(seqno_ysday)
                if not does_table_exist(db_handler.ddl_conn, snapshot_table_y, nerdlake_in):
                    print 'WARNING: We are in delta mode by virtue of param full-mode-when or commandline parm --force, but ' \
                          'yesterday snapshot {} does not exist.'.format(snapshot_table_y if seqno > 0 else '')
                    fulloverride = True
            if fulloverride:
                print 'WARNING: Falling back to full extract mode for all targets.'
                fullmode = True
                mark_journal_deltatofull(db_handler.journal_conn, p['transmission-name'], prodmode, seqno, xmitguid)

        ensure_clean_s3(bucket, '{}/{}-{}/'.format(p['transmission-name'], batchdt.replace('-', '/'), seqno_today), aws_profile=aws_profile)
        if not prodmode:
            ensure_clean_s3(bucket, 'stagebounce_{}/'.format(stageguid(xmitguid)), aws_profile=aws_profile)

        donetargets = []
        for tp in p['targets']:
            print ''
            print '------------------------'
            print 'Working on transmission {} sequence {} target {} under mode {}/{}.'.format(p['transmission-name'], seqno_today, 
                  tp['target-name'], 'prod' if prodmode else 'stage', 'full' if fullmode else 'delta')

            snapshot_table_t = tp[st_ptrna].format(seqno_today)
            snapshot_table_y = tp[st_ptrna].format(seqno_ysday)
            extract_sqlfile  = tp['{}-{}-sql'.format('prod' if prodmode else 'stage', 'full' if fullmode else 'delta')]
            s3unloadpath     = 's3://{}/{}/{}-{}/{}/'.format(bucket, p['transmission-name'], batchdt.replace('-', '/'),
                                                             seqno_today, tp['target-name'])
            if not prodmode:
                s3stagepath  = s3unloadpath
                s3unloadpath = 's3://{}/stagebounce_{}/{}/'.format(p['dest-bucket-prod'], stageguid(xmitguid), tp['target-name'])

            # default output to CSV for backwards compatibility
            output_data_format = tp.get('format', 'csv')

            # create snapshot
            print 'Performing snapshot creation of {} using {}.'.format(snapshot_table_t, tp['materialization-sql'])
            sql = pslurp(tp['materialization-sql']).format(snap_today=snapshot_table_t, snap_ysday=snapshot_table_y)
            ddl_sql = None
            if nerdlake_in:
                ddl_sql = pslurp(tp['materialization-ddl']).format(snap_today=snapshot_table_t)
            create_snapshot(db_handler.sql_conn, db_handler.ddl_conn, sql, ddl_sql, snapshot_table_t, notouchsnaps, nerdlake_in, aws_profile=aws_profile)

            # extract the data
            print 'Extracting using {} to {}.'.format(extract_sqlfile, s3unloadpath)
            sql = pslurp(extract_sqlfile).format(snap_today=snapshot_table_t, snap_ysday=snapshot_table_y)
            outfiles = unload(db_handler.sql_conn, db_handler.ddl_conn, snapshot_table_t, sql, s3_pbuck, s3unloadpath, nerdlake_in, aws_profile=aws_profile)
            output_data_compression = 'gzip' if outfiles[0].endswith('.gz') else None
            print '  ... {} {} subfiles emitted with {} compression'.format(len(outfiles), output_data_format,
                                                                            output_data_compression)

            # move the data to stage s3 if we're in stage mode
            if not prodmode:
                print '  ... moving files to stage {}'.format(s3stagepath)
                ensure_clean_s3(bucket, s3stagepath, aws_profile=aws_profile)
                stageoutfiles = []
                for outfile in outfiles:
                    stagefile = s3stagepath + outfile.split('/')[-1]
                    copysrc   = '/'.join(outfile.split('/')[3:])
                    copydst   = '/'.join(s3stagepath.split('/')[3:]) + outfile.split('/')[-1]

                    s3_buck.copy_key(copydst, p['dest-bucket-prod'], copysrc)
                    set_key_acl_policy(bucket, copydst, policy='bucket-owner-full-control', aws_profile=aws_profile)
                    s3_pbuck.delete_key(copysrc)
                    stageoutfiles.append(stagefile)
                outfiles = stageoutfiles

            # ensure that the first several lines of the first extracted file fits with the schema definition.  65536 is a 64kB buffer which
            # oughtta be longer than any one record/line
            column_names = []
            column_types = []
            if len(outfiles) > 0:
                for col in tp['schema']:
                    column_names.append(col['field'])
                    column_types.append(col['type'])

                firstfilekey = '/'.join(outfiles[0].split('/')[3:])
                buf = s3_head(s3_buck, firstfilekey, 65536, aws_profile=aws_profile)
                if len(buf) == 0:
                    print '  ... data/schema validation attempted, but no data was extracted when looking at s3://{}/{}.'.format(
                          bucket, firstfilekey)
                else:
                    if not buf.endswith('\n'):
                        buf = buf[0:buf.rfind('\n')]  # remove any incomplete last line
                    h = StringIO.StringIO(buf)
                    line_number = 1
                    if output_data_format == 'csv':
                        hr = csv.reader(h, delimiter='|', quotechar='"', quoting=csv.QUOTE_ALL, escapechar='\\')
                        for fields in hr:
                            line_number += 1
                            typeverify(fields, column_types, line_number)
                    elif output_data_format == 'json':
                        for json_row in h:
                            line_number += 1
                            fields = [json.loads(json_row, parse_float=Decimal)[key] for key in column_names]
                            typeverify(fields, column_types, line_number)
                    analyzedlines = line_number
                    h.close()
                    print '  ... data/schema validated successfully on the first {} bytes / {} records.'.format(
                        len(buf), analyzedlines)
            else:
                print '  ... data/schema validation was skipped.'

            extract_checksum_body = pslurp(tp['materialization-sql']) + json.dumps(tp['schema'])

            donetargets.append({ 'target_name':        tp['target-name'],
                                 'extractor_checksum': hashlib.sha1(extract_checksum_body).hexdigest(),
                                 's3paths':            outfiles,
                                 'format':             output_data_format,
                                 'column_names':       column_names,
                                 'column_types':       column_types} )

        print '------------------------'

        manipath = '{}/{}-{}/manifest.json'.format(p['transmission-name'], batchdt.replace('-','/'), seqno_today)
        print 'Emitting manifest to yak and, as a backup, s3://{}/{} :'.format(bucket, manipath)

        mani = { 'manifest_format_version':   '1.0',
                 'transmission_guid':         xmitguid,
                 'extract_timestamp':         extractts,
                 'transmission_name':         p['transmission-name'],
                 'transmission_sequence_num': seqno_today,
                 'processing_mode':           'full' if fullmode else 'delta',
                 'target_environment':        'prod' if prodmode else 'stage',
                 'creator_job':               job_label(jobname),
                 'targets':                   donetargets }
        manij = json.dumps(mani, indent=2, separators=(',', ': '))
        print manij

        manikey = Key(s3_buck)
        manikey.key = manipath
        manikey.set_contents_from_string(manij)
        set_key_acl_policy(bucket, manikey.key, policy='bucket-owner-full-control', aws_profile=aws_profile)

        # this is to support pre-yak consumption by UDC
        manikey.key = 'manifesthist/{}-{}-{}-manifest.json'.format(extractts.replace(' ', '-'), p['transmission-name'], seqno_today)
        manikey.set_contents_from_string(manij)
        set_key_acl_policy(bucket, manikey.key, policy='bucket-owner-full-control', aws_profile=aws_profile)

        yakmsg = {
           'envelope': { 'id': xmitguid, 'queueId': p['yak-queue-prod'] if prodmode else p['yak-queue-stage'], 
                          'type': mani['transmission_name'], 'subType': mani['creator_job'] },
            'payload':  mani }

        if prodmode:
            print 'yak is not yet in prod so I am not sending a yak'
            # yakresp = requests.post('http://yak/asynch/v1/send', data=json.dumps(yakmsg))
            # print yakresp
        else:
            print ' '
            print 'In stage mode, due to firewall policy, you have to send the yak message manually.  Please'
            print 'log into stage-dwhadmin-6, and copy-paste-run this:' 
            print ' '
            print "curl -i -X POST -H 'Content-Type: application/json' -d '{}' http://yak/asynch/v1/send".format(
                  json.dumps(yakmsg, separators=(',',':')))
            print ' '

        mark_journal_success(db_handler.journal_conn, manij, p['transmission-name'], prodmode, seqno, xmitguid)

    except:
        if seqno is not None:    # if we recorded job start...
            mark_journal_error(db_handler.journal_conn, p['transmission-name'], prodmode, seqno, xmitguid)
        raise


################################################
# Primary snapshot, extract, and verify routines
################################################

def create_snapshot(sql_conn, ddl_conn, materializesql, materializeddl, snapshot_table_t, notouchsnaps, nerdlake=False, aws_profile=None):
    if does_table_exist(ddl_conn, snapshot_table_t, nerdlake):
        if notouchsnaps:
            print '  ... table exists and is being left as-is.'
            return
        else:
            print '  ... table exists and will be overwritten.'
    else:
        if notouchsnaps:
            raise RuntimeError('--notouchtoday was specified, but there is no existing snapshot table for today {}'.format(snapshot_table_t))

    if nerdlake:
        snapshot_schema, snapshot_table_nm = snapshot_table_t.split('.')
        snapshot_loc = 's3://{}/{}/{}'.format(nw_hive.S3_NERDLAKE_BUCKET_NAME, snapshot_schema, snapshot_table_t)
        snapshot_loc_new = 's3://{}/{}/{}'.format(nw_hive.S3_NERDLAKE_BUCKET_NAME, snapshot_schema, snapshot_table_nm)
        materialize_ddl = materializeddl.replace(snapshot_loc, snapshot_loc_new)

        # run create table statement in HIVE first
        for ddl_statement in materialize_ddl.split(';'):
            if ddl_statement.strip():
                nw_hive.exec_hive_sql_ddl(ddl_conn, ddl_statement)

        # then make sure snap today is empty before inserting
        # having issues removing s3 files via "DELETE FROM ..." so we zap files directly instead
        ensure_clean_s3(nw_hive.S3_NERDLAKE_BUCKET_NAME, '{}/{}/'.format(snapshot_schema, snapshot_table_nm), aws_profile=aws_profile)
        extract_cur = sql_conn.cursor()
        for sql_statement in materializesql.split(';'):
            if sql_statement.strip():
                extract_cur.execute(sql_statement)
                print('\n{}\n'.format(sql_statement))
                extract_cur.fetchall()
        extract_cur.close()

    else:
        with sql_conn.cursor() as cur:
            cur.execute(materializesql)


def unload(sql_conn, ddl_conn, snapshot_table_t, extsql, s3_buck, s3path, nerdlake=False, aws_profile=None):
   
    emitted = []
    if nerdlake:
        unload_schema, snapshot_table_nm = snapshot_table_t.split('.')
        unload_snapshot_table = '{}_unload'.format(snapshot_table_nm)
        unload_loc = 's3://{}/{}/{}'.format(nw_hive.S3_NERDLAKE_BUCKET_NAME, unload_schema, unload_snapshot_table)

        nw_hive.drop_delete_table(ddl_conn, '{}.{}'.format(unload_schema, unload_snapshot_table))

        create_table_sql = "CREATE TABLE {}.{} LIKE {} LOCATION '{}'".format(unload_schema, unload_snapshot_table,
                                                                             snapshot_table_t, unload_loc)
        nw_hive.exec_hive_sql_ddl(ddl_conn, create_table_sql)

        extract_cur = sql_conn.cursor()
        # strip away trailing semicolon
        extract_sql = extsql.split(';')[0]
        unload_sql = 'INSERT INTO hive.{}.{} {}'.format(unload_schema, unload_snapshot_table, extract_sql)
        extract_cur.execute(unload_sql)
        # need to poll the presto query to make sure it completes since it runs in background
        extract_cur.fetchall()
        extract_cur.close()

        # move "unload" files to destination
        unload_s3_buck = S3Connection(profile_name=aws_profile).get_bucket(nw_hive.S3_NERDLAKE_BUCKET_NAME)
        for key in unload_s3_buck.list(prefix='{}/{}'.format(unload_schema, unload_snapshot_table)):
            if key.size > 0:
                copysrc = key.name
                copydst = os.path.join('/'.join(s3path.split('/')[3:]), key.name.split('/')[-1])
                s3_buck.copy_key(copydst, unload_s3_buck.name, copysrc)
                emitted.append('s3://{}/{}'.format(s3_buck.name, copydst))

        # clean up unload table
        nw_hive.drop_delete_table(ddl_conn, '{}.{}'.format(unload_schema, unload_snapshot_table))
        
        return emitted
    else:
        with sql_conn.cursor() as cur:
            # not used:  parallel=false, null as null-string
            unload_sql = "UNLOAD ('{}') TO '{}' " \
                         "ACCESS_KEY_ID '{}' SECRET_ACCESS_KEY '{}' {} " \
                         "DELIMITER AS '|' " \
                         "ADDQUOTES ESCAPE MANIFEST;"
            using_temp_creds = 's3_prod_session_token' in g_creds
            session_token_parm    = "SESSION_TOKEN '{}'".format(g_creds['s3_prod_session_token']) if using_temp_creds else ""
            session_token_printed = "SESSION_TOKEN 'TOLKIEN'"                                 if using_temp_creds else ""
            print (unload_sql.format(extsql, s3path, 'KEY_ID', 'SECRET', session_token_printed))
            cur.execute(unload_sql.format(extsql, s3path, g_creds['AWS_ACCESS_KEY_ID'], g_creds['AWS_SECRET_ACCESS_KEY'], session_token_parm))

        # get, then remove, the manifest file
        s3a = s3path.split('/')
        s3k = Key(s3_buck)
        s3k.key = '{}manifest'.format('/'.join(s3a[3:]))
        mani = json.loads(s3k.get_contents_as_string())
        s3_buck.delete_key(s3k.key)

        for k in mani['entries']:
            emitted.append(k['url'])
    return emitted


def typeverify(fields, types, rn):
    # when reporting data issues, both record number and field number are 1-indexed, not 0-indexed.
    if len(fields) <> len(types):
        raise ValueError('Column mismatch: dumped data has {} fields in record {}, the schema has {}.'.format(len(fields), rn, len(types)))
    if len(fields) < 1:
        raise ValueError('How can one export less than one column of data?')

    for i, f in enumerate(fields):

        if len(str(f).strip('"')) == 0 or f is None:
            # NULLs are always considered okay
            continue

        # convert to string since CSV assumes everything is a string -- only needed because of new JSON format
        f = str(f).strip('"')
        torig = types[i].lower()
        tfull = types[i].lower().replace(',', ' ').replace('(', ' ').replace(')', ' ').split(' ')
        t = tfull[0]

        if t == 'varchar':
            if len(f) > int(tfull[1]):
                typefail('Field is {} chars long, too large for varchar({})'.format(len(f), tfull[1]), rn, i, fields)
        elif t == 'timestamp':
            ok = False
            try:
                datetime.strptime(f, '%Y-%m-%d %H:%M:%S.%f')
                ok = True
            except ValueError: pass
            try:
                datetime.strptime(f, '%Y-%m-%d %H:%M:%S')
                ok = True
            except ValueError: pass
            try:
                datetime.strptime(f, '%Y-%m-%dT%H:%M:%S.%f')
                ok = True
            except ValueError: pass
            if not ok:
                typefail('Field is not in timestamp format', rn, i, fields)
        elif t == 'bigint':  # signed 8 byte
            if f.lstrip('-').isdigit():
                fi = long(f)
                if (fi < -9223372036854775808 or fi > 9223372036854775808):
                    typefail('Field too large for bigint', rn, i, fields)
            else:
                typefail('Field is not numeric', rn, i, fields)
        elif t == 'integer': # signed 4 byte
            if f.lstrip('-').isdigit():
                fi = long(f)
                if(fi < -2147483648L or fi > 2147483647L):
                    typefail('Field too large for integer', rn, i, fields)
            else:
                typefail('Field is not numeric', rn, i, fields)
        elif t == 'smallint': # signed 2 byte
            if f.lstrip('-').isdigit():
                fi = long(f)
                if(fi < -32768L or fi > 32767L):
                    typefail('Field too large for smallint:', rn, i, fields)
            else:
                typefail('Field is not numeric', rn, i, fields)
        elif t == 'decimal' or t == 'numeric':
            (f1, trashdot, f2) = f.lstrip('-').partition('.')
            m1 = int(tfull[1]) - int(tfull[2])     # digits before the decimal point
            m2 = int(tfull[2])                     #        after

            if ( (len(f1) > 1 and (not f1.isdigit() or len(f1) > m1)) or 
                 (len(f2) > 1 and (not f2.isdigit() or len(f2) > m2)) ):
                typefail('Field is not a {}'.format(torig), rn, i, fields)
        elif t == 'boolean':
            if f <> 't' and f <> 'f':
                typefail('Field is not a boolean', rn, i, fields)
        elif t == 'date':
            try:
                datetime.strptime(f, '%Y-%m-%d')
            except ValueError:
                typefail('Field is not in date format', rn, i, fields)
        else:
            raise ValueError('Type "{}" in position {} is unknown to loopback-push.py, please update this script!'.format(t, i+1))

    return


def typefail(msg, rn, posn, fields):
    of = []
    for i, f in enumerate(fields):
        if i == posn:
            of.append(' >>> "{}" <<< '.format(f))
        else:
            of.append('"{}"'.format(f))

    raise ValueError('{}: [{}][line#={},field#={}]'.format(msg, ', '.join(of), rn, posn+1))


#############################
# journal management routines
#############################

def mark_journal_running(dwh_conn, transname, prodmode, xmitguid, fullmode, extractts, batchdt, creator_job, bucket):
    # figures out the next sequence number (look for the most recent -successful- run in the same
    # environment and increment by one, but if it's the first run, use 0).  if the job appears to be
    # running, abend.  record the 'running' record in the journal.  if it looks like we are rerunning,
    # because the prior run was an error, reuse the sequence number and return that we are rerunning.
    # transmission_stat_cd: R=running S=success E=error P=purged
    seqno = -1
    am_rerunning = False

    sql = "SELECT MAX(transmission_seq_nr) FROM dw_stage.ctl_loopback_journal " \
          "WHERE transmission_nm=%s AND environment_cd=%s AND transmission_stat_cd='S'"
    with dwh_conn.cursor() as cur:
        cur.execute(sql, (transname, db_env_cd(prodmode)))
        if cur.rowcount == 0:
            seqno = 0
        elif cur.rowcount == 1:
            seqno = cur.fetchone()[0]
            seqno = seqno + 1 if seqno is not None else 0
        else:
            raise ProgrammingError('Multiple rows returned in transmission_seq_nr retriever')

    sql = 'SELECT transmission_stat_cd, transmission_guid, execute_ts, extract_user_nm ' \
          '  FROM dw_stage.ctl_loopback_journal ' \
          ' WHERE transmission_nm=%s AND environment_cd=%s AND transmission_seq_nr=%s ' \
          'ORDER BY execute_ts DESC LIMIT 1'
    lastjob = None
    with dwh_conn.cursor() as cur:
        cur.execute(sql, (transname, db_env_cd(prodmode), seqno))
        lastjob = cur.fetchone()
    if lastjob is not None:
        if lastjob[0] == 'E':
            print 'WARNING: Loopback rerun detected, last run was at {} by {} identified by guid {}.'.format(
                  lastjob[2], lastjob[3], lastjob[1])
            am_rerunning = True
        elif lastjob[0] == 'P':
            raise ProgrammingError('Something is very wrong.  We calculated the transmission sequence number, but when ' \
                               'we look at records for that serial number, it looks like the sequence snapshot has ' \
                               'already been purged.')
        else:
            raise RuntimeError('This loopback seems to be already running per dw_stage.ctl_loopback_journal: ' \
                               'started {} by {} identified by guid {}.  To override, remove the running ' \
                               'record from this table for this guid.'.format(lastjob[3], lastjob[2], lastjob[1]))

    sql = 'INSERT INTO dw_stage.ctl_loopback_journal ' \
          '(transmission_nm, transmission_seq_nr, transmission_guid, transmission_stat_cd, environment_cd, delta_full_cd, ' \
          ' execute_ts, purge_snap_at_ts, extract_user_nm, processing_dt, creator_job_nm, dest_bucket_nm) VALUES ' \
          '(%s, %s, %s, %s, %s, %s, %s, SYSDATE + 14, %s, %s, %s, %s);'
    with dwh_conn.cursor() as cur:
        cur.execute(sql, (transname, seqno, xmitguid, 'R', db_env_cd(prodmode), db_fulldelta_cd(fullmode),
                          extractts, current_user(), batchdt, creator_job, bucket))
    dwh_conn.commit()
    return (seqno, am_rerunning)


def mark_journal_success(dwh_conn, manifest, transname, prodmode, seqno, xmitguid):
    sql = "UPDATE dw_stage.ctl_loopback_journal SET transmission_stat_cd='S', manifest_json=%s " \
          "WHERE transmission_nm=%s AND environment_cd=%s AND transmission_seq_nr=%s AND transmission_guid=%s"
    redshift_safe_update_onerow(dwh_conn, sql, (manifest, transname, db_env_cd(prodmode), seqno, xmitguid))


def mark_journal_error(dwh_conn, transname, prodmode, seqno, xmitguid):
    sql = "UPDATE dw_stage.ctl_loopback_journal SET transmission_stat_cd='E' " \
          "WHERE transmission_nm=%s AND environment_cd=%s AND transmission_seq_nr=%s AND transmission_guid=%s"
    redshift_safe_update_onerow(dwh_conn, sql, (transname, db_env_cd(prodmode), seqno, xmitguid))


def mark_journal_deltatofull(dwh_conn, transname, prodmode, seqno, xmitguid):
    sql = "UPDATE dw_stage.ctl_loopback_journal SET delta_full_cd='F' " \
          "WHERE transmission_nm=%s AND environment_cd=%s AND transmission_seq_nr=%s AND transmission_guid=%s"
    redshift_safe_update_onerow(dwh_conn, sql, (transname, db_env_cd(prodmode), seqno, xmitguid))


def db_env_cd(prodmode):
    return 'P' if prodmode else 'S'


def db_fulldelta_cd(fullmode):
    return 'F' if fullmode else 'D'


################
# misc functions
################

def validate_parms(parms):
    # make sure snapshot-basename is in a good format
    pass


def does_table_exist(dwh_conn, tablename, nerdlake=False):
    if nerdlake:
        return nw_hive.hive_table_exists(dwh_conn, tablename)
    else:
        (schema, dottrash, table) = tablename.partition('.')
        with dwh_conn.cursor() as cur:
            cur.execute('SELECT COUNT(*) FROM pg_tables WHERE schemaname=%s AND tablename=%s;', (schema, table))
            tableexists = True if cur.fetchone()[0] == 1 else False
        return tableexists


def redshift_safe_update_onerow(dwh_conn, sql, parms):
    # adding in the BEGIN appears to prevent the redshift autocommit and any psycopg autocommit from happening
    # http://docs.aws.amazon.com/redshift/latest/dg/r_BEGIN.html
    # http://initd.org/psycopg/docs/connection.html#connection.commit (probably not a factor)

    sql = 'BEGIN; ' + sql
    with dwh_conn.cursor() as cur:
        cur.execute(sql, parms)
        ok = True if cur.rowcount == 1 else False
    if ok:
        with dwh_conn.cursor() as cur:
            cur.execute('COMMIT;')
    else:
        with dwh_conn.cursor() as cur:
            cur.execute('ROLLBACK;')
            raise ProgrammingError('Loopback journal update updated more than one record, so we rolled back, ' \
                                   'something is badly wrong with the code.')


def slurp(filename):
    r = ''
    with open(filename, 'r') as f:
        for l in f:
            r = r + l + ' '
    return r


def pslurp(filename):
    return slurp(os.path.join(g_pbase, filename))


def stageguid(xmitguid):
    return '{}-{}'.format(current_user(), xmitguid)


def current_user():
    return pwd.getpwuid(os.geteuid())[0]


def job_label(job_name):
    if current_user() in ['airflow', 'etl', 'bai']:
        return job_name
    else:
        return 'adhoc'


if __name__ == '__main__':
    clparser = argparse.ArgumentParser(description='Extract data from DWH to S3, optionally copy to stage, then send a yak to the consumer.')

    clparser.add_argument('--parms', required=True, help='Path to JSON parameter file.')
    clparser.add_argument('--force', choices=['delta','full'], help='Override extract mode.')
    clparser.add_argument('--stage', action='store_true', help='Enable stage mode.')
    clparser.add_argument('--job', default='adhoc', help='Airflow job name, for logging.')
    clparser.add_argument('--date', help='Date override, as YYYY-MM-DD')
    clparser.add_argument('--notouchtoday', action='store_true', help="Do not attempt to recreate today's snapshot")
    args = clparser.parse_args()

    if args.date is not None:
        try:
            datetime.strptime(args.date, '%Y-%m-%d')
        except ValueError:
            print '\nERROR: --date must be in the form of YYYY-MM-DD\n'
            clparser.print_help()
            sys.exit(1) 

    g_creds = load_creds()
    g_now   = datetime.utcnow()
    g_pbase = os.path.dirname(os.path.realpath(args.parms))
       
    loopback_push(args.parms, args.force, not args.stage, args.job, args.date, args.notouchtoday)
