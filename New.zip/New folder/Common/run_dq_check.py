#!/usr/bin/env python
"""
based on https://github.com/NerdWallet/dwh/blob/master/Common/run_dq_check.py
"""
import sys, pprint
import json
import re
from subprocess import Popen, PIPE
import os
from datetime import date, timedelta
import pandas as pd
import psycopg2
import traceback

import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders
from email.mime.text import MIMEText

morepath1=os.path.join(os.path.dirname(__file__),'nw_python_modules')
morepath2='/data/etl/Common/nw_python_modules'
if 'dwh_common_base_dir' in os.environ:
    sys.path.append(os.path.join(os.environ['dwh_common_base_dir'],'nw_python_modules'))
elif os.path.exists(morepath1):
    sys.path.append(morepath1)
elif os.path.exists(morepath2):
    sys.path.append(morepath2)
else:
    logr.warn('did not find dw_common_base_dir env variable, nor default location for nw_python_modules')

from redshift_modules import load_creds, redshift_connect
from mysql_modules import mysql_connect, mysql_exec
import nw_presto

import argparse
from argparse import Namespace
import logging
logr = logging.getLogger(__name__)

pd.set_option('display.max_colwidth', 1000)

## ############# helper functions ################
DQ_PRIORITY_COLORS = {
    'p0': 'red',
    'p1': 'orange',
    'p2': '#666666'
}

dq_status_values = Namespace(**{
    'failure' : ('FAILURE', 'FAIL', 'ERROR', 'RED', 'ALARM', 'BAD', 'FAILED'),
    'warning' : ('WARNING', 'WARN', 'YELLOW', 'ALERT'),
    'success' : ('SUCCESS', 'PASS', 'GREEN', 'GOOD'),
    'notify' : ('NOTIFY', 'INFO')
    })

def colorcode(val):
    if not isinstance(val,(str,unicode)):
        color = 'white'
    elif val in dq_status_values.failure:
        color = 'red'
    elif val in dq_status_values.warning:
        color = 'orange'
    elif val in dq_status_values.success:
        color = 'green'
    elif val in dq_status_values.notify:
        color = 'cyan'
    else:
        color = 'gray'
    return color

def colorize(val):
    color = colorcode(val)
    return '<font style="background-color:{color};">{val}</font>'.format(**locals())

def boolify(val):
    if isinstance(val,bool):
        return val
    elif isinstance(val,(str,unicode)):
        if val.lower() in ['yes','y','true','t','1']:
            return True
        elif val.lower() in ['no','n','false','f','0','']:
            return False
        else:
            raise "cannot boolify [%s]"%val
    elif isinstance(val,(int,float)):
        if val==0:
            return False
        else:
            return True
    
## ############# class to manage dq check configuration ################

class DQSpec():
    """ class to read and manage a dq JSON spec file """
    
    def __init__(self, fname):
        """ read json spec """
        logr.info("loading dq spec json %s",fname)
        s = open(fname).read().replace('\n',' ').replace('\t',' ').replace('\r',' ')
        spec = json.loads(s)

        # validate and clean the spec
        self.spec = self.validate_spec(spec)
        logr.debug("spec = %s", self.spec)

        # internalize the spec for notational convenience
        self.__dict__.update(self.spec)

    def validate_spec(self,spec):
        """ clean up the spec, make sure some optional fields are there with default values """
        # lowercase the keys
        spec = dict([[k.lower(),v] for k,v in spec.items()])
        # check for required fields
        required_s = "dq_job_name dq_query".split()
        for k in required_s:
            assert k in spec, "spec needs to have field [%s]"%k

        # initialize other fields if not in the spec

        # clean strings
        usual_s = """dq_action dq_job_desc dq_job_group_level1 dq_job_group_level2 dq_job_group_level3
                     email_to email_cc github_code""".split()
        for k in usual_s:
            if k not in spec:
                spec[k] = ''
        spec['email_from'] = spec.get('email_from','bai-dq@nerdwallet.com')

        # clean booleans
        usual_b = 'fail_on_error fail_on_warning run_as_command suppress_email suppress_log email_ignore_success dq_summary_logging_in_db allow_redshift_log'.split()
        for k in usual_b:
            spec[k] = boolify(spec.get(k,False))
            
        # convert priority
        spec['dq_priority_group'] = spec.get('dq_priority_group','P?')
        return(spec)
        
    def respec(self, d=None, **kw):
        """ alter the spec with dictionary and/or keyword arguments """
        if d:
            self.spec.update(d)
        if kw and len(kw)>0:
            self.spec.update(kw)
        self.__dict__.update(self.spec)

    def command_run(self):
        """ run the contents of dq_query as if it were a bash script """
        pipe = Popen(str(self.dq_query), shell=True, stdout=PIPE).stdout
        df = pd.read_csv(pipe,sep="\t")
        return df
        
    def run_query(self, conn):
        """ run dq query and get data frame as result and html """
        if self.run_as_command:
            logr.warn("running command line instead of SQL query")
            self.df = self.command_run()
        else:
            # Swap out environment variables in our SQL statement
            sql = os.path.expandvars(self.dq_query)
            logr.info("running dq query getting")
            try:
                self.df = pd.read_sql(sql, conn)
            except:
                logr.error("something wrong with your SQL")
                raise
            
        # normalize dq_status to uppercase
        if 'dq_status' in self.df.columns:
            self.df['dq_status'] = self.df['dq_status'].apply(lambda x: x.upper())
        else:
            self.df['dq_status'] = 'NOTIFY'
        # some ****s have duplicated column names, need to fix that if it happens
        cols = self.df.columns
        if len(cols) != len(set(cols)):
            newcols = []
            for c in cols:
                i=1
                nc = c
                while nc in newcols:
                   nc = c + "_" + str(i)
                   i += 1
                newcols.append(nc)
            self.df.columns = newcols
        
        logr.info("received %d columns and %d records", len(self.df.columns), len(self.df))
        logr.debug("dq_result = \n%s",self.df)
        self.df.columns = [x.lower() for x in self.df.columns]
        self.dq_status = 'NOTIFY'
        if 'dq_status' in self.df.columns:
            #self.df.sort_values('dq_status',inplace=True)
            # gather stats
            self.dq_status_counts = self.df.dq_status.value_counts()
            logr.info(self.dq_status_counts.to_json())
            # have a copy of html for email, and colorize it, leave off index, don't escape our colorizing html
            df2 = self.df.copy()
            df2.dq_status = df2.dq_status.apply(lambda x: colorize(x))
            columns = None # By default means include all columns
            if hasattr(self, 'email_report') and self.email_report.lower()=='yes': # If "Email_Report":"Yes" then not include 'dq_status' column
                columns = list(df2)
                columns.remove('dq_status')
            self.dfhtml = df2.to_html(index=False, escape=False, columns=columns)
            # get the overall status
            if len( set(dq_status_values.failure) & set(self.df.dq_status) )>0:
                self.dq_status = 'FAILURE'
            elif len( set(dq_status_values.warning) & set(self.df.dq_status) )>0:
                self.dq_status = 'WARNING'
            elif len( set(dq_status_values.notify) & set(self.df.dq_status) )>0:
                self.dq_status = "NOTIFY"
            elif len( set(dq_status_values.success) & set(self.df.dq_status) )>0:
                self.dq_status = 'SUCCESS'
            else:
                self.dq_status = 'UNKNOWN'
        logr.info('overall dq_status =  %s',self.dq_status)
        return self

  # dq_job_name         varchar(128),        -- dq identifying name
  # dw_eff_dt           DATE,                -- date of dq check
  # dq_job_ts           timestamp,           -- timestamp of jobrun (currently redundant to dw_load_ts)
  # dq_job_group_level1 varchar(128),        -- grouping field 1
  # dq_job_group_level2 varchar(128),        -- grouping field 2
  # dq_job_group_level3 varchar(128),        -- grouping field 3
  # dq_job_desc         varchar(65000) encode lzo,      -- verbose description
  # dq_action           varchar(65000)        -- info what to do after email with dq check results
  # email_to            varchar(128),        -- email to field
  # email_cc            varchar(128),        -- email cc field
  # email_from          varchar(128),        -- email from field
  # fail_on_error       bool,                -- flag to hard-stop if error is found
  # dq_query            varchar(65000) encode lzo,      -- query string or command string to run 
  # dq_status           varchar(32),         -- final status of job (most errorful status)
  # dq_result           varchar(65000) encode lzo,      -- dq query results as html
  # dw_load_ts          timestamp,           -- timestamp of job
  # -- additions
  # run_as_command      bool,                -- flag the the dq_query is the command to run
  # dq_priority_group         varchar(32),         -- priority of the job
  # dq_result_tsv       varchar(65000) encode lzo,      -- tab separated table of results (loadable by pandas)
  # dq_result_json      varchar(65000) encode lzo,      -- json version of results (orient=row)
  # dq_spec_json        varchar(65000) encode lzo,      -- json of dq check parameters
  # dq_status_counts    varchar(6500)        -- counts of all of each dq_status in json 
    # query for dq_job_log
    qry_dq_job_log = u"""
insert into dw_report.dq_job_log values (
'{dq_job_name}',
trunc(sysdate),
sysdate,
'{dq_job_group_level1}',
'{dq_job_group_level2}',
'{dq_job_group_level3}',
'{dq_job_desc}',
'{dq_action}',
'{email_to}',
'{email_cc}',
'{email_from}',
'{fail_on_error}',
'{dq_query}',
'{dq_status}', --
substring('{dq_result}',1,64000), --
sysdate,
{run_as_command},
'{dq_priority_group}',
substring('{dq_result_tsv}',1,64000), --
substring('{dq_result_json}',1,64000), --
substring('{dq_spec_json}',1,64000), --
substring('{dq_status_counts}',1,64000) --
) ;
            """

    
    def dq_format_fields(self):
        """ log the test in the dq_job_log table """

        # construct formatting of query
        fmt = self.spec.copy()
        fmt['dq_status'] = self.dq_status
        fmt['dq_result'] = self.dfhtml
        fmt['dq_result_tsv'] = self.df.to_csv(sep='\t', index=False, encoding='utf8')
        fmt['dq_result_json'] = self.df.to_json(orient='records')
        fmt['dq_status_counts'] = json.dumps(self.dq_status_counts.to_dict())
        parm=self.spec.copy()
        del parm['dq_query']
        fmt['dq_spec_json'] = json.dumps(parm, sort_keys=True, indent=4, separators=(',', ': '))
        fmt['dq_status_counts'] = self.dq_status_counts.to_json()

        # let's get rid of non-ascii
        #fmt['dq_result_tsv'] = fmt['dq_result_tsv'].encode('ascii','ignore')
        
        # escape ticks for strings
        for k,v in fmt.items():
            if isinstance(v, unicode):
                fmt[k] = v.replace(r"'",r"\'")
            if isinstance(v, str):
                fmt[k] = v.decode('utf-8').replace(r"'",r"\'")
            if v is None:
                fmt[k] = 'NULL'
        return(fmt)
        

    def dq_job_log(self, conn):
        fmt = self.dq_format_fields()
        # assemble and run the query
        try:
            qry_dq_job_log = self.qry_dq_job_log.format(**fmt)
        except:
            fmt['dq_result_tsv'] = re.sub(r'[^\x00-\x7f]',r' ',fmt['dq_result_tsv'])
            qry_dq_job_log = self.qry_dq_job_log.format(**fmt)
        logr.debug("dq_job_log query = \n%s",qry_dq_job_log)
        if self.suppress_log:
            logr.warn("suppressing job logging")
            return
        if hasattr(self,'allow_redshift_log') and self.allow_redshift_log:
            logr.info("writing dq run to redshift dq_job_log")
            cursor=conn.cursor()
            cursor.execute(qry_dq_job_log)
            cursor.close()
            conn.commit()

# schema for mysql dwh_stats.ctl_job_log_f
# 'dq_job_sk','bigint(20)','NO','PRI',NULL,'auto_increment'
# 'dq_job_name_tx','varchar(255)','YES','MUL',NULL,''
# 'dw_eff_dt','date','YES','',NULL,''
# 'dq_job_ts','timestamp','YES','',NULL,''
# 'dq_job_group_level1_tx','varchar(255)','YES','',NULL,''
# 'dq_job_group_level2_tx','varchar(255)','YES','',NULL,''
# 'dq_job_group_level3_tx','varchar(255)','YES','',NULL,''
# 'dq_job_desc_tx','varchar(255)','YES','',NULL,''
# 'dq_action_tx','varchar(65000)','YES','',NULL,''
# 'email_to_tx','varchar(255)','YES','',NULL,''
# 'email_cc_tx','varchar(255)','YES','',NULL,''
# 'email_from_tx','varchar(255)','YES','',NULL,''
# 'fail_on_error_tx','varchar(255)','YES','',NULL,''
# 'dq_query_tx','blob','YES','',NULL,''
# 'run_as_command_tx','varchar(255)','YES','',NULL,''
# 'dq_priority_group_tx','varchar(255)','YES','',NULL,''
# 'dq_table_name_tx','varchar(255)','YES','MUL',NULL,''
# 'dq_check_type_tx','varchar(255)','YES','MUL',NULL,''
# 'dq_pod_tx','varchar(255)','YES','MUL',NULL,''
# 'dq_spec_json_tx','blob','YES','',NULL,''
# 'dq_status_tx','varchar(255)','YES','',NULL,''
# 'dq_status_counts_tx','varchar(255)','YES','',NULL,''
# 'dq_result_tx','varchar(255)','YES','',NULL,''
# 'dq_result_tsv_tx','blob','YES','',NULL,''
# 'dq_result_json_tx','blob','YES','',NULL,''
    rds_table_cols = u"""
    dq_job_name_tx
    dw_eff_dt
    dq_job_ts
    dq_job_group_level1_tx
    dq_job_group_level2_tx
    dq_job_group_level3_tx
    dq_job_desc_tx
    dq_action_tx
    email_to_tx
    email_cc_tx
    email_from_tx
    fail_on_error_tx
    dq_query_tx
    run_as_command_tx
    dq_priority_group_tx
    dq_table_name_tx
    dq_check_type_tx
    dq_pod_tx
    dq_spec_json_tx
    dq_status_tx
    dq_status_counts_tx
    dq_result_tx
    dq_result_tsv_tx
    dq_result_json_tx
    """.strip().split()
        
    def rds_job_log(self, mconn):
        fmt = self.dq_format_fields()
        qd = dict(dw_eff_dt='current_date', dq_job_ts='sysdate()')
        skipped=[]
        for k,v in fmt.items():
            ktx = k + '_tx'        # look for the key with _tx extension
            if ktx in self.rds_table_cols:
                vv = unicode(v).encode('ascii','ignore').replace('\n','\\n')
                vv = vv[:64000]     # limit string size
                if vv == 'NULL':   # handle NULL separately
                    qd[ktx] = vv
                else:              # pass as sql string
                    #qd[ktx] = """'{v}'""".format(v=vv)
                    qd[ktx] = "'" + vv + "'"
            else:
                skipped.append(k)
                
        if len(skipped)>0:
            logr.warn("rds log skipping fields {}".format(skipped))
        qdkeys = qd.keys()
        qdvals = [qd[x] for x in qdkeys]
        qdkeys_str = ', '.join(qdkeys)
        qdvals_str =  ', '.join(qdvals)
        rds_qry = """ insert into ctl_dq_job_f ({qdkeys_str}) values ({qdvals_str}); """.format(**locals())
        logr.debug(rds_qry)
        if self.suppress_log:
            logr.warn("suppressing mysql job logging")
            return
        logr.info("writing rds dq run to ctl_job_log_f")
        mysql_exec(rds_qry, conn=mconn)

  # dq_job_name CHARACTER VARYING(128),
  # dq_job_desc CHARACTER VARYING(65000),
  # dq_action CHARACTER VARYING(65000),
  # dq_job_group_level1 CHARACTER VARYING(128),
  # dq_job_group_level2 CHARACTER VARYING(128),
  # dq_job_group_level3 CHARACTER VARYING(128),
  # dq_priority_group CHARACTER VARYING(32),
  # dw_eff_dt DATE,
  # dq_status CHARACTER VARYING(32),
  # github_code CHARACTER VARYING(6500),
  # metric_nm_1 CHARACTER VARYING(6500),
  # metric_val_1 CHARACTER VARYING(6500),
  # metric_nm_2 CHARACTER VARYING(6500),
  # metric_val_2 CHARACTER VARYING(6500),
  # metric_nm_3 CHARACTER VARYING(6500),
  # metric_val_3 CHARACTER VARYING(6500),
  # metric_nm_4 CHARACTER VARYING(6500),
  # metric_val_4 CHARACTER VARYING(6500),
  # metric_nm_5 CHARACTER VARYING(6500),
  # metric_val_5 CHARACTER VARYING(6500),
  # metric_nm_6 CHARACTER VARYING(6500),
  # metric_val_6 CHARACTER VARYING(6500),
  # metric_nm_7 CHARACTER VARYING(6500),
  # metric_val_7 CHARACTER VARYING(6500),
  # metric_nm_8 CHARACTER VARYING(6500),
  # metric_val_8 CHARACTER VARYING(6500),
  # metric_nm_9 CHARACTER VARYING(6500),
  # metric_val_9 CHARACTER VARYING(6500),
  # metric_nm_10 CHARACTER VARYING(6500),
  # metric_val_10 CHARACTER VARYING(6500),
  # metric_json CHARACTER VARYING(6500),
  # dw_load_ts TIMESTAMP DEFAULT getdate()

    def dq_job_results_log(self,conn):
        """ write to results table """
        if not self.dq_summary_logging_in_db or self.suppress_log:
            logr.warn("suppressing results logging")
            return
        logr.info("writing dq results to dq_job_results_log")

        dq_output_dict = self.df.to_dict("records")  #exec_query(pretty_dq_json['DQ_Query'])
        #print dq_output_dict
        dq_output_dict_summary = []

        #cursor = conn.cursor()
        # collect row information
        today = date.today().strftime('%Y-%m-%d')
        for row in dq_output_dict:
            summary_row={}
            metric_number=1
            json_dict={}
            for col in row.viewkeys() :

                if col.lower() in ['dw_eff_dt'] :
                    #summary_row[col]=str(row[col]).replace('datetime.date','').replace('(','').replace(')','').replace(',','-')
                    summary_row[col]=row[col].strftime('%Y-%m-%d')
                elif col.lower() in ['dq_status'] :
                    summary_row[col]=row[col].upper()
                else:
                    var_metric_nm='metric_nm_'+str(metric_number)
                    var_metric_val='metric_val_'+str(metric_number)
                    summary_row[var_metric_nm]=col
                    summary_row[var_metric_val]=row[col]
                    json_dict[col]=row[col] 
                    metric_number += 1
            logr.debug(json_dict)
            summary_row['dq_job_name']=self.dq_job_name
            summary_row['dq_job_desc']=self.dq_job_desc
            summary_row['dq_action']=self.dq_action
            summary_row['dq_job_group_level1']=self.dq_job_group_level1
            summary_row['dq_job_group_level2']=self.dq_job_group_level2
            summary_row['dq_job_group_level3']=self.dq_job_group_level3
            summary_row['dq_priority_group']=self.dq_priority_group
            summary_row['metric_json']=json.dumps(json_dict)
            if self.github_code == '':
                summary_row['github_code'] = ''
            else:
                summary_row['github_code']='''<a href="{github_code}">{dq_job_name}</a>'''.format(**self.spec)
            if 'dw_eff_dt' not in summary_row.keys():
                summary_row['dw_eff_dt'] = today
            
            dq_output_dict_summary.append(summary_row)

            key_string = ",".join(summary_row.keys())
            val_string = "'"+"','".join(str(v).replace(r"'",r"\'") for v in summary_row.values())+"'"
            summary_row_insert_qry="INSERT INTO dw_report.dq_job_results_log ("+key_string+") VALUES ( "+val_string+" );"
            logr.debug(summary_row_insert_qry)
            #cursor.execute(summary_row_insert_qry)
        #conn.commit()
        logr.info( "DQ Summary results logged at dw_report.dq_job_results_log" )
        
    def send_dq_email(self):
        """ send an email """
        if self.suppress_email:
            logr.warn('suppressing email')
            return
        if self.email_to == "" or self.email_to is None:
            logr.warn('no email addressees, not emailing')
            return
        if self.email_ignore_success and self.dq_status == 'SUCCESS':
            logr.warn('ignoring email on success')
            return
        if self.df is None or len(self.df)==0:
            logr.warn('empty results table... skipping email')
            return

        msg = MIMEMultipart()
        msg['From'] = self.email_from
        msg['To'] = self.email_to
        if ("marketing" in self.email_to) and (self.dq_status == 'FAILURE' or self.dq_status == 'WARNING'):
            msg['CC'] = self.email_cc + ', o2h5c1k1l5p7e3z9@nerdwallet.slack.com'
        else:
            msg['CC'] = self.email_cc
        msg['Subject'] = self.dq_job_name  if hasattr(self, 'email_report') and self.email_report.lower()=='yes' else self.dq_status + \
                         " : DQ report for " + self.dq_job_name # If "Email_Report":"Yes" then pass job_name only as sublject
        body = '<b>Description:&nbsp;&nbsp;</b>' + self.dq_job_desc + '<br><br>'
        body += '<b>Priority:&nbsp;&nbsp;</b>' + '<span style="color: white; background-color: {color}">&nbsp;'.format(color=DQ_PRIORITY_COLORS.get(self.dq_priority_group.lower(), 'green')) + self.dq_priority_group.upper() + '&nbsp;</span>' + '<br><br>'
        body += '<b>Action:&nbsp;&nbsp;</b>' + self.dq_action + '<br><br>'
        body += '<b>GitHub Code:&nbsp;&nbsp;</b><a href="{link}">{link}</a><br><br>'.format(link=self.github_code)
        body += self.dfhtml + '<br><br><br><br>'
        body = re.sub(r'[^\x00-\x7f]',r' ',body)
        msg.attach(MIMEText(body, 'html'))

        logr.info("sending email")
        p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
        p.communicate(msg.as_string())

    def go(self,conn, mconn=None):
        self.run_query(conn)
        self.dq_job_log(conn)
        if mconn is not None:
            self.rds_job_log(mconn)
        self.dq_job_results_log(conn)
        self.send_dq_email()

## ############# functions ################

def dq_check(*sysargs):

    ## argument parsing for future functionality
    parser = argparse.ArgumentParser(add_help=True, description="Run a DQ check from a JSON DQ spec")
    parser.add_argument('dq_script_file', nargs='?', help="json spec file")
    parser.add_argument('-d', '--debug_level', nargs='?', default='INFO',
                        choices='DEBUG INFO WARN ERROR CRITICAL'.split(), help="debug level")
    parser.add_argument('-f','--force_fail_on_error', action="store_true", help="force a failure on error")
    parser.add_argument('-F','--force_fail_on_warning', action="store_true", help="force a failure on warning")

    parser.add_argument('-e','--suppress_email', action="store_true", help="force disable sending email")
    parser.add_argument('-l','--suppress_log', action="store_true", help="disable logging to table")
    parser.add_argument('-p','--printtab', action="store_true", help="print table to stdout")
    parser.add_argument('-s','--printfail', action="store_true", help="print table of failures to stdout")
    parser.add_argument('-P','--printhtml', action="store_true", help="print table to stdout as html")
    parser.add_argument('-R','--no_rds', action="store_false", default=True, dest='rds', help="don't log to mysql RDS")
    parser.add_argument('--presto', action="store_true", default=False, help="Run DQ check using Presto")

    opts = parser.parse_args(sysargs)
    logr.setLevel(opts.debug_level.upper())    # set the logging level
    logr.debug(opts)
    if isinstance(opts.dq_script_file,(list,tuple)):
        dq_script_file  = opts.dq_script_file[0]
    else:
        dq_script_file = opts.dq_script_file

    dq = DQSpec(dq_script_file)
    if opts.suppress_email:
        dq.respec(email_to="", suppress_email="yes")
    if opts.suppress_log:
        dq.respec(suppress_log="yes")
    if opts.force_fail_on_error:
        dq.respec(fail_on_error="yes")
    if opts.force_fail_on_warning:
        dq.respec(fail_on_error="yes",fail_on_warning="yes")
    creds = load_creds()
    if not opts.presto:
        conn = redshift_connect()
    else:
        conn = nw_presto.connect()
    mconn = None
    if opts.rds:
        mconn = mysql_connect(creds)
    try:
        dq.go(conn,mconn)
    except:
        print "DQ PROCESS FAILED"
        print(traceback.format_exc())
        sys.exit(0)
        
    if opts.printtab:
        print dq.df.to_csv(sep='\t',index=False)
    if opts.printfail:
        print dq.df[~dq.df.dq_status.isin(['SUCCESS','GREEN'])].to_csv(sep='\t',index=False)
    if opts.printhtml:
        print dq.dfhtml

    if (dq.dq_status == 'FAILURE' and dq.fail_on_error) or (dq.dq_status == 'WARNING' and dq.fail_on_warning):
        logr.error("exiting with dq %s",dq.dq_status)
        sys.exit(-1)
    else:
        logr.info("finished")
        sys.exit(0)

def main():
    dq_check(*sys.argv[1:])
    #print "dq check disabled"
    #sys.exit(0)

if __name__ == '__main__':
    #logging.basicConfig(level=10, format="[%(module)s.%(funcName)s:%(lineno)s:%(levelname)s] %(message)s")
    logging.basicConfig(level=10, format="[%(levelname)-8s] %(message)s")
    main()
