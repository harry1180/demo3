# Given a start and end date, this function returns all dates between the two
# dates, inclusive.
date_range()
{
    local date_list
    curr_date=$1
    last_date=$2
    while [[ ! "$curr_date" > "$last_date" ]]
    do
        echo "$curr_date"
        curr_date=$(date --date="$curr_date + 1 day" +%Y-%m-%d)
    done
}
