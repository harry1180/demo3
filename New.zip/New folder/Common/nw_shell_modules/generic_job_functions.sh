source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/environment.ctrl

echo_processing_step()
{
    #This Function Takes 3 parameters
    #1) Job_name
    #2) Task_name 
    #3) Status_of_Task
    input_user=$(whoami)
    Processing_Step=$2
    task_status=$3
    export DateStamp=`date '+%m-%d-%Y'`
    export TimeStamp=`date '+%H:%M:%S'`
    if [[ $HOSTNAME = *"stage"* ]]
    then 
        echo '**** Warning:- Running on stage host and will not log task status in RDS ****'  
    elif [ ${input_user} == 'airflow' ] || [ ${input_user} == 'etl' ] || [ ${input_user} == 'bai' ]
    then
        if [ $# -eq 3 ]
        then

            if [ "${task_status}" == 'Started' ]
            then
                Processing_Step=$2
                echo ""
                echo "______________"$Processing_Step" $task_status @ "$DateStamp" "$TimeStamp"______________"
                echo ""
                processing_query="insert into dwh_stats.ctl_task_status (job_tracking_id,job_date,job_name,task_name,task_start_time, task_end_time ,task_status,dw_load_ts) values (DATE_FORMAT(SYSDATE(), '%Y%m%d'),date(SYSDATE()), '"$1"' , '"$2"' ,SYSDATE(),null, '"$3"' ,SYSDATE());"
                mysql --defaults-extra-file=/etc/.rds.cnf --host="$rdsdbHost" --user="$rdsusername" --database="$rdsdatabase" --column-names=0 --connect_timeout=28800 --execute="$processing_query"
            else
                echo ""
                echo "______________"$Processing_Step" $task_status @ "$DateStamp" "$TimeStamp"______________"
                echo ""
                processing_query="update dwh_stats.ctl_task_status set task_end_time = SYSDATE(), task_status = '"$3"' where job_name = '"$1"' and task_end_time is null and task_status = 'Started';"
                mysql --defaults-extra-file=/etc/.rds.cnf --host="$rdsdbHost" --user="$rdsusername" --database="$rdsdatabase" --column-names=0 --connect_timeout=28800 --execute="$processing_query"
            fi
        else
            echo "This echo_processing_step function takes three prameters 1) Job_name 2) Task_name 3) Status_of_Task"
            exit 1
        fi
    else
        echo ""
        echo "______________"$Processing_Step" $task_status @ "$DateStamp" "$TimeStamp"______________"
        echo ""
    fi
}


list_job_related_files()
{
    echo "Linux_Input:"$Linux_Input
    ls -tlrah $Linux_Input || true
    echo "Linux_Output:"$Linux_Output
    ls -tlrah $Linux_Output || true
    echo "Linux_Archive:"$Linux_Archive
    ls -tlrah $Linux_Archive || true
    echo "S3 Output:"$S3_Output
    ls -tlrah $S3_Output || true
}


email_users()
{
    local from_email_address=${1:-"dwh@nerdwallet.com"}
    local distribution_list=${2:-"dwh@nerdwallet.com"}
    local attachment=$3
    local message_file=$4
    local subject_line=$5

    if [ -n "$attachment" ];
    then
        mail -s "${subject_line}" -a "From: ${from_email_address}" ${distribution_list} -A ${attachment} < ${message_file}
    else
        mail -s "${subject_line}" -a "From: ${from_email_address}" ${distribution_list} < ${message_file}
    fi

}




rds_tmp_echo_processing_step()
{
    #This Function Takes 3 parameters
    #1) Job_name
    #2) Task_name 
    #3) Status_of_Task
    input_user=$(whoami)
    if [ ${input_user} == 'airflow' ] || [ ${input_user} == 'etl' ] || [ ${input_user} == 'bai' ]
    then
        if [ $# -eq 3 ]
        then
            export DateStamp=`date '+%m-%d-%Y'`
            export TimeStamp=`date '+%H:%M:%S'`

            task_status=$3
            if [ ${task_status} == 'Started' ]
            then
                Processing_Step=$2
                echo ""
                echo "______________"$Processing_Step" $3 @ "$DateStamp" "$TimeStamp"______________"
                echo ""
                processing_query="insert into dwh_stats.ctl_task_status (job_tracking_id,job_date,job_name,task_name,task_start_time, task_end_time ,task_status,dw_load_ts) values (DATE_FORMAT(SYSDATE(), '%Y%m%d'),date(SYSDATE()), '"$1"' , '"$2"' ,SYSDATE(),null, '"$3"' ,SYSDATE());"
                mysql --defaults-extra-file=/etc/.rds.cnf --host="$rdsdbHost" --user="$rdsusername" --database="$rdsdatabase" --column-names=0 --connect_timeout=28800 --execute="$processing_query"
            else
                processing_query="update dwh_stats.ctl_task_status set task_end_time = SYSDATE(), task_status = '"$3"' where job_name = '"$1"' and task_end_time is null and task_status = 'Started';"
                mysql --defaults-extra-file=/etc/.rds.cnf --host="$rdsdbHost" --user="$rdsusername" --database="$rdsdatabase" --column-names=0 --connect_timeout=28800 --execute="$processing_query"
            fi
        else
            echo "This echo_processing_step function takes three prameters 1) Job_name 2) Task_name 3) Status_of_Task"
            exit 1
        fi
    else
        echo '**** Warning:- User is not whitelisted to log the task status of job in RDS ****' 
    fi
}
