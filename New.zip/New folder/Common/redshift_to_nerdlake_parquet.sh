#!/bin/bash
set -e

if [ $# -lt 3 ]
then
    echo "Usage: redshift_to_nerdlake_parquet.sh <job_name> <redshift_schema.redshift_table> <hive_schema.hive_table> [options]"
    exit 1
fi

job_name="${1}"
redshift_table="${2}"
hive_table="${3}"

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source "${dwh_common_base_dir}/set_dwh_common_variables.sh" "${job_name}"
source "${dwh_credentials_file_dir}/credentials.ctrl"
source "${dwh_common_base_dir}/environment.ctrl"
source "${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh"
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 "
********************************
*** ${job_name} LOAD STARTED ***
********************************
"
abort()
{
    echo >&2 "
**************************************
*** ERROR CODE ${job_name} ABORTED ***
**************************************
"
	bash "${dwh_common_base_dir}/dwh_job_fail_script.sh" "${job_name}"
    echo "An error occurred. Exiting while performing *****************${Processing_Step}" >&2
    exit 1
}
trap 'abort' 0

Processing_Step="Setting Variables, Running Preprocess scripts and Creating DIR Structures"
echo_processing_step "${job_name}" "${Processing_Step}" "Started"
bash "${dwh_common_base_dir}/dwh_job_start_script.sh" "${job_name}"
bash "${dwh_common_base_dir}/setup_dir_structure.sh" "${job_name}"
export Linux_Output

echo_processing_step "${job_name}" "${Processing_Step}" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

Processing_Step="Removing leftover files"
echo_processing_step "${job_name}" "${Processing_Step}" "Started"
if [ -n "${Linux_Output}" ]
then
    find "${Linux_Output}" -mindepth 1 -maxdepth 1 -type f -print -delete
fi
echo_processing_step "${job_name}" "${Processing_Step}" "Completed"

Processing_Step="Copying ${redshift_table} to ${hive_table}"
echo_processing_step "${job_name}" "${Processing_Step}" "Started"
s3_prod_load_creds="$s3_prod_load_creds" python "${dwh_common_base_dir}/redshift_table_to_nerdlake.py" \
    --redshift-table "${redshift_table}" \
    --hive-table "${hive_table}" \
    --redshift-export-format PARQUET \
    "${@:4}"
echo_processing_step "${job_name}" "${Processing_Step}" "Started"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step "${job_name}" "Calling End Script" "Started"
bash "${dwh_common_base_dir}/dwh_job_end_script.sh" "${job_name}"
echo_processing_step "${job_name}" "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : $(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds"
trap : 0
echo >&2 "
************************************
***  ${job_name} LOAD COMPLETED  ***
************************************"
