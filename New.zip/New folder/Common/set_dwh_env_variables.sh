#!/bin/bash

dwh_scripts_base_dir=${dwh_scripts_base_dir:-/data/etl/Scripts}
dwh_common_base_dir=${dwh_common_base_dir:-/data/etl/Common}
dwh_data_base_dir=${dwh_data_base_dir:-/data/etl/Data}
dwh_credentials_file_dir=${dwh_credentials_file_dir:-/data/etl/Common}
common_environment_file_dir=${dwh_credentials_file_dir:-/data/etl/Common}
dwh_chef_credentials_file_dir=${dwh_chef_credentials_file_dir:-/etc/}
export JAVA_HOME=$(readlink -f /usr/bin/java | sed "s:bin/java::")
export HADOOP_HOME=/usr/lib/hadoop
export AWS_CONFIG_FILE=/etc/boto.cfg

# this makes stdout unbuffered in python, which is useful to keep job log
# records visible in airflow immediately, and keeps the timestamps that
# airflow adds valid.  see also
# https://docs.python.org/2/using/cmdline.html#envvar-PYTHONUNBUFFERED

export PYTHONUNBUFFERED=True

