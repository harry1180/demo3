#!/bin/env python
"""
nosetests for run_dq_check.py

Add your tests here to make sure the script works prior to pull requests

normal convention:  make the setup, teardown, and test functions (setup and teardown are individually optional of course)
* setup_descriptivename()
* teardown_descriptivename()
* test_descriptivename()

Usage:
> nosetests test_run_dq_check.py
"""
from nose.tools import with_setup, assert_raises

from run_dq_check import *

## -----------------------------------------------------
## test that it works with a minimalist json file
jsonfile="/tmp/x.json"
def setup_minimal_json():
    with open(jsonfile,'w') as ofp:
        ofp.write('''
{
    "DQ_Job_Name": "Test DQ mimial JSON",
    "DQ_Query": "
create temp table x (col1 int, col2 int, dq_status varchar(16));
insert into x values
(1,2,'SUCCESS'),
(3,4,'WARNING'),
(5,6,'FAILURE') ;
select * from x ;
"
}
''')

def teardown_minimal_json():
    os.unlink(jsonfile)

@with_setup(setup_minimal_json, teardown_minimal_json)
def test_minimal_json():
    with assert_raises(SystemExit):  # the script uses sys.exit, so need to catch
        dq_check(jsonfile)

## -----------------------------------------------------
## test that it can handle Dongmin's json files which has microsoft newlines
## also tests creating with spec using the raw contents string instead of a file
def test_microsoft_newline():
    from StringIO import StringIO as sio
    jsontext = '{\r\n    "DQ_Job_Name": "Test DQ JSON - Dongmin",\r\n    "DQ_Job_Group_Level1": "Level1",\r\n    "DQ_Job_Group_Level2": "Level2",\r\n    "DQ_Job_Group_Level3": "Level3",\r\n    "DQ_Job_Desc": "Small \'DQ\' job test",\r\n    "Email_TO": "dcai@nerdwallet.com",\r\n    "Email_CC": "",\r\n    "Email_FROM": "bai-dq@nerdwallet.com",\r\n    "Fail_On_Error": "No",\r\n    "DQ_Query": "\r\ninsert into x\r\nselect case when distinct_cnt=cnt and cnt>0 then \'SUCCESS\'\r\n  else \'FAILURE\' end as dq_status \r\nfrom\r\n  (\r\n    select count(1) as cnt, count(distinct dw_page_sk) as distinct_cnt\r\n    from dw_ba_report.ba_monetizing_pages_static\r\n  );\r\n"\r\n}'
    dq = DQSpec(sio(jsontext), is_contents=True)
    
