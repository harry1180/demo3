source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

v="$6"

if [ -n "$v" ]; then
  ## if the length of "v" is non-zero.
  query="copy "$1" from '"$s3_bucket_name$2$3"' credentials 'aws_access_key_id="$s3_access_key";aws_secret_access_key="$s3_secret_key"' JSON as '"$s3_bucket_name$4$5"' TIMEFORMAT AS '"$v"'  ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF;"
else
  query="copy "$1" from '"$s3_bucket_name$2$3"' credentials 'aws_access_key_id="$s3_access_key";aws_secret_access_key="$s3_secret_key"' JSON as '"$s3_bucket_name$4$5"' TIMEFORMAT AS 'auto'  ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF;"
fi

psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
