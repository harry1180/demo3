source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

input_user=$(whoami)
if [ ${input_user} == 'airflow' ] || [ ${input_user} == 'etl' ] || [ ${input_user} == 'bai' ]
   then
       processing_query="insert into dwh_stats.ctl_jobs_status(job_tracking_id,job_date,job_name,job_start_time,job_end_time,job_status,dw_load_ts) values(DATE_FORMAT(SYSDATE(), '%Y%m%d'),date(SYSDATE()),'"$1"' ,SYSDATE(),null,'Started',SYSDATE());"
       mysql --defaults-extra-file=/etc/.rds.cnf --host="$rdsdbHost" --user="$rdsusername" --database="$rdsdatabase" --column-names=0 --connect_timeout=28800 --execute="$processing_query"

   else
       echo '**** Warning:- User is not whitelisted to log the status of job in RDS ****'
fi
