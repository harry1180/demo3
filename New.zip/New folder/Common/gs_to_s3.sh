#!/usr/bin/env bash

##############################################################################################################################
# This script converts google spreadsheets to CSVs and uploads them to S3
#
# Input Parameters
# [1] spreadsheet_url: Spreadsheet url
# [2] filename: name of CSV file that will be produced. NOTE if multiple worksheets are passed in and append=False.,
#               then each CSV file produced will be filename_worksheet.csv
# [3] s3_bucket: bucket to place uploaded CSV
# [4] s3_path: s3 path to place uploaded CSV
# [5] append: 'True'|'False' -- When passing in multiple sheets, append sheets to single file ('True') or output separate
#              files for each sheet ('False') with the naming convention filename_worksheet.csv
# [6] worksheets: Comma separated strings of worksheets to upload as CSVs to S3. If left empty, all sheets will be used
##############################################################################################################################


if [ $# -lt 5 ]
then
    echo 'Usage: gs_to_s3.sh <spreadsheet_url> <filename> <s3_bucket> <s3_path> <append> [worksheet1] [worksheet2]'
    exit 1
fi

spreadsheet_url="$1"
filename="$2"
s3_bucket="$3"
s3_path="$4"
append="$5"
worksheets=("${@:6}")

set -e
job_name='gs_to_s3'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh "$job_name"
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh

function clean_up_and_fail() {
  echo "$1 failed"
  echo "Cleaning up local directory ${local_output_dir}"
  rm -rf "${local_output_dir}"
  exit 1
}

pyargs=""
for sheet in "${worksheets[@]}"
do
    if [ -n "$pyargs" ]
    then
        pyargs="$pyargs,"
    fi
    pyargs="${pyargs}'${sheet/"'"/\\"'"}'"
done

# Extract spreadsheet_id to use for temporary local directory
gid=$(python -c "import google_spreadsheet; print google_spreadsheet.get_id_from_url('${spreadsheet_url}')")
local_output_dir="${Linux_Output}${gid}"_"$(date +%s)"/
echo "Creating local directory ${local_output_dir}"
mkdir -p "${local_output_dir}"

full_output_path=${local_output_dir%%/}${local_output_dir:+/}${filename}
echo ${full_output_path}

echo "Converting worksheet(s) ${pyargs} into CSVs"
python -c "from google_spreadsheet import gs_to_csv;
append = True if '${append}'.lower() == 'true' else False;
gs_to_csv(url='${spreadsheet_url}', file_out='${full_output_path}', worksheet=[$pyargs], append=append)" || clean_up_and_fail "gs_to_csv()"

for file in "${local_output_dir}"*; do
    if [ -f "${file}" ]; then
        echo "Moving ${file} to s3"
        python -c "from s3_modules import s3_file_upload; s3_file_upload('${file}', '${s3_bucket}', '${s3_path}')"  || clean_up_and_fail "s3_file_upload()"
    fi
done

echo "Cleaning up local directory ${local_output_dir}"
rm -rf "${local_output_dir}"
echo "Completed"
