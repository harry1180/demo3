source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

input_user=$(whoami)
if [[ $HOSTNAME = *"stage"* ]]
then 
    echo '**** Warning:- Running on stage host and will not log the status of job in RDS ****'   
elif [ ${input_user} == 'airflow' ] || [ ${input_user} == 'etl' ] || [ ${input_user} == 'bai' ]
then
   processing_query="update dwh_stats.ctl_jobs_status set job_end_time = SYSDATE(), job_status = 'Completed' where job_name = '"$1"' and job_end_time is null and job_status = 'Started';"
   mysql --defaults-extra-file=/etc/.rds.cnf --host="$rdsdbHost" --user="$rdsusername" --database="$rdsdatabase" --column-names=0 --connect_timeout=28800 --execute="$processing_query"

else
    echo '**** Warning:- User is not whitelisted to log the status of job in RDS ****'
fi
