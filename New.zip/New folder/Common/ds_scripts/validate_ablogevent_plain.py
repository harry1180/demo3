#!/usr/bin/python

from __future__ import division

from datetime import datetime, timedelta
import os
import pwd
import s3_modules


class ValidateABLogEvent:
    SRC_BUCKET = 'nw-event-data-stage'
    DEST_BUCKET = 'east1-stage-dwh-ds-shared-s3'
    EVENT_NAME = 'ablogevent_plain',

    def __init__(
            self,
            utc_time=datetime.utcnow() - timedelta(hours=1)):
        self.utc_time = utc_time
        self.AWS_PROFILE = None
        if pwd.getpwuid(os.getuid()).pw_name != 'airflow':
            self.AWS_PROFILE = 'nwdev'

    def download_file(self, key_path):
        return s3_modules.s3_file_download(
            self.SRC_BUCKET, '', key_path, '/tmp/', to_file=True, retry=0,
            aws_profile=self.AWS_PROFILE)

    def upload_file(self, key_path, upload_filename):
        elems = key_path.split('/')
        file_name = elems[-1]
        del elems[-1]
        path = "/".join(elems)
        s3_modules.s3_file_upload(
            upload_filename, self.DEST_BUCKET, path,
            s3_file_nm=file_name, aws_profile=self.AWS_PROFILE)

    def validate(self, line):
        return True

    def cleanup(self, download_filename, upload_filename):
        os.remove(download_filename)
        os.remove(upload_filename)

    # def get_current_datetime():
        # return '2018/05/29'
        # partition = get_current_datetime()

    def transform(self, dfile, ufile):
        with open(dfile, "rU") as df:
            with open(ufile, "w") as uf:
                for dline in df:
                    if self.validate(dline):
                        uf.write(dline + "\n")

    def ingest(self):
        self.utc_time.strftime('/%Y/%m/%d/%H.json')
        key_path = '{}/{}'.format(
            self.EVENT_NAME,
            self.utc_time.strftime('/%Y/%m/%d/%H.json'))
        self.ingest_key(key_path)

    def ingest_key(self, key_path):
        upload_filename = '/tmp/xt.json'
        download_filename = self.download_file(key_path)
        self.transform(download_filename, upload_filename)
        self.upload_file(key_path, upload_filename)
