import sys, pprint
from datetime import date, timedelta
import base64
import pandas as pd
import pandas.io.sql as psql
#import seaborn as sns
import psycopg2
#from pandas import ExcelWriter
#from pandas.io.parsers import ExcelWriter
from openpyxl.writer.excel import ExcelWriter

import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders
import json
import re
from email.mime.text import MIMEText
from subprocess import Popen, PIPE
from redshift_modules import exec_query

####################################       methods        ####################################

def fetch_creds(input_var_name):
    creds = open('/data/etl/Common/credentials.ctrl')

    for line in creds:
        if input_var_name in line:
            #print line
            psql_prod_username=line.split('=')[1].replace('"',"")
            return str(psql_prod_username)

def fetch_query_results (run_query,conn):
    print "\n ********* Running query ********* \n"
    #print "run_query : ",run_query
    pd.set_option('display.max_colwidth', 1000)
    #psql.set_option('display.max_colwidth', 1000) 
    df = psql.read_sql_query(run_query,conn)
    return df

def log_dq_results (conn,pretty_dq_json,dq_return_code,df_html_table_email):
    print "\n ********* Logging DQ Results ********* \n"
    
    cursor = conn.cursor();

    log_query="INSERT INTO dw_report.DQ_Job_Log \n (DQ_Job_Name,dw_eff_dt,DQ_Job_ts,DQ_Job_Group_Level1,DQ_Job_Group_Level2 ,DQ_Job_Group_Level3,DQ_Job_Desc \n ,Email_TO ,Email_CC ,Email_FROM ,Fail_On_Error ,DQ_Query ,DQ_Status ,DQ_Result, dw_load_ts) \n VALUES \n (" 
    log_query=log_query+" '"+str(pretty_dq_json['DQ_Job_Name'])+"'"
    log_query=log_query+', trunc(sysdate)'
    log_query=log_query+', sysdate'
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Job_Group_Level1'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Job_Group_Level2'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Job_Group_Level3'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Job_Desc'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['Email_TO'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['Email_CC'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['Email_FROM'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['Fail_On_Error'])+"'"
    log_query=log_query+", '"+str(pretty_dq_json['DQ_Query']).replace(r"'",r"\'")+"'"
    log_query=log_query+", '"+dq_return_code+"'"
    #log_query=log_query+", '"+str(df_html_table_email).replace(r"'",r"\'")+"'"
    log_query=log_query+", substring('"+str(df_html_table_email).replace(r"'",r"\'")+"',1,65000)"
    log_query=log_query+', sysdate) ; \n '
    
    #print log_query
    cursor.execute(log_query);
    conn.commit()
    conn.close()

def send_dq_email(dq_json_info, df_html_table_email,qry_df):

    fromaddr = dq_json_info['Email_FROM']
    toaddr = dq_json_info['Email_TO']

    msg = MIMEMultipart()

    msg['From'] = fromaddr
    msg['To'] = toaddr

    dq_status="NOTIFY"
    if 'FAILURE' in df_html_table_email:
        dq_status='FAILURE'
    elif 'WARNING' in df_html_table_email:
        dq_status='WARNING'
    elif 'SUCCESS' in df_html_table_email:
        dq_status='SUCCESS'
    else:
        dq_status="NOTIFY"
    
#    if ( len(qry_df.axes[0]) > 0 ):
#        try:
#            dq_status=qry_df['dq_status'][0]
#        except:
#            print "column dq_status doesnt exist in result set" 

    print "dq_status : ",dq_status
    msg['Subject'] = dq_status+" : DQ report for "+str(dq_json_info['DQ_Job_Desc'])

    body = str(dq_json_info['DQ_Job_Desc'])+'<p></p><p></p><p></p><p></p>'+df_html_table_email+'<p></p><p></p><p></p><p></p>'
   
#    print "Record count of query : ", len(qry_df.axes[0]) 

    if ( len(qry_df) > 0 ):
        msg.attach(MIMEText(body, 'html'))
        p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
        p.communicate(msg.as_string())

    return dq_status


####################################       main          ####################################
def main():
    
    dq_script_file                = sys.argv[1]
    dq_json = open(dq_script_file)
    pretty_dq_json = json.loads(dq_json.read().replace('\n',' ').replace('\r',' '),strict=False)
    dq_job_name=pretty_dq_json['DQ_Job_Name']
    run_query=pretty_dq_json['DQ_Query'] 
    
    psql_prod_database=fetch_creds('psql_prod_database')
    psql_prod_port=fetch_creds('psql_prod_port')
    psql_prod_username=fetch_creds('psql_prod_username')
    psql_prod_password=fetch_creds('psql_prod_password')
    psql_prod_dbHost=fetch_creds('psql_prod_dbHost')

    raw_conn_string = "dbname='"+psql_prod_database+"' port='"+psql_prod_port+"' user='"+psql_prod_username+"' password='"+psql_prod_password+"' host='"+psql_prod_dbHost+"'"
    #conn_string = "dbname='",psql_prod_database,"' port='",psql_prod_port,"' user='",psql_prod_username,"' password='",psql_prod_password,"' host='",psql_prod_dbHost,"'";
    conn_string=raw_conn_string.replace('\n',"")
    #print "Connecting to database\n        ->%s" % (conn_string)
    conn = psycopg2.connect(conn_string);
    #cursor = conn.cursor();
 
    df_html_table_email=""
    pd.set_option('display.max_colwidth', 1000)
    #query_df=fetch_query_results(run_query,conn)
    #print type(query_df)
    #print query_df 
   
    summary_results_list=exec_query(run_query)
    #print type(summary_results_list)
    #print summary_results_list
    
    summary_results_html=""
    for r in summary_results_list:
        if 'Failure' in str(r['dq_status']) or 'Success' in str(r['dq_status']):
            summary_results_html+='<p></p><p></p><p></p><p></p>'
            summary_results_html+='<b>'+'dq_job_name : '+str(r['dq_job_name'])+'</b>'
            summary_results_html+='<p></p><p></p><p></p><p></p>'

            summary_results_html+='dw_eff_dt : '+str(r['dw_eff_dt'])
            summary_results_html+='<br>'
            summary_results_html+='dq_job_group_level1 : '+str(r['dq_job_group_level1'])
            summary_results_html+='<br>'
            summary_results_html+='dq_job_group_level2 : '+str(r['dq_job_group_level2'])
            summary_results_html+='<br>'
            summary_results_html+='dq_job_group_level3 : '+str(r['dq_job_group_level3'])
            summary_results_html+='<br><br><br>'
            summary_results_html+=str(r['dq_result'])   
    #print "summary_results_html :"
    #print summary_results_html
    #query_df.set_option('display.max_colwidth', -1)     
    # Convert the dataframe to html table.                                     
    #raw_df_html_table_email=query_df.to_html()
    #print summary_results_html
    summary_results_html=summary_results_html.replace('<td>Success</td>', '<td><font size="2" color="green"><b>SUCCESS</b></font></td>').replace('<td>WARNING</td>', '<td><font size="2" color="orange"><b>WARNING</b></font></td>').replace('Failure', '<font size="2" color="red"><b>FAILURE</b></font>').replace('<td>NOTIFY</td>', '<td><font size="2" color="orange"><b>NOTIFY</b></font></td>') 
       
    print dq_job_name, "dq process completed"                                                                   
    
    #send result as email
    dq_return_code=send_dq_email(pretty_dq_json,summary_results_html,summary_results_list)    
    
    #log_dq_results(conn,pretty_dq_json,dq_return_code,df_html_table_email)
    #send return code to bash
    #if dq_return_code=='FAILURE':
    #    print "dq job return code : -1"
        #sys.exit(-1)
    
    #else :
    #    print "dq job return code : 0"
        #sys.exit(0)

                                                                                             
if __name__ == '__main__':                                                                      
    main() 
