#!/usr/bin/env python

import argparse
import filecmp
import json
import logging
import os
import pwd
import sys
import tempfile
import textwrap
from urlparse import urlparse

import boto3
import botocore
import psycopg2

import event_modules
import redshift_modules


def write_dict_to_s3(dictionary, s3_key_url, aws_profile='nwprod'):
    """
    Given a Python dictionary, writes it to the specified S3 location.
    :param dictionary: A dictionary object
    :param s3_key_url: The location on S3 to write the file, formatted as a URL
    :param aws_profile: AWS credentials profile name, defaults to 'nwprod'
    :return:
    """
    if not isinstance(dictionary, dict):
        raise ValueError('write_jsonpaths_to_s3: jsonpaths_dict must be a dictionary')

    parsed_s3_key_url = urlparse(s3_key_url)
    if parsed_s3_key_url.scheme.lower() != 's3':
        raise ValueError('write_jsonpaths_to_s3: S3 URL must start with \'s3://\'')

    s3_bucket_name = parsed_s3_key_url.netloc
    s3_key = parsed_s3_key_url.path[1:]

    # Write the jsonpaths to a temporary file
    new_file = tempfile.NamedTemporaryFile(
        dir=args.tmp_dir,
        prefix=os.path.basename(s3_key) + '_',
        delete=False)
    json.dump(dictionary, new_file, indent=4)
    new_file.close()

    # Download the existing S3 file (if one exists)
    existing_file = tempfile.NamedTemporaryFile(
        dir=args.tmp_dir,
        prefix=os.path.basename(s3_key) + '_',
        delete=False)
    existing_file.close()
    os.remove(existing_file.name)

    aws_session = boto3.session.Session(profile_name=aws_profile)
    s3 = aws_session.client('s3')
    try:
        s3.download_file(s3_bucket_name, s3_key, existing_file.name)
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] != '404':
            raise

    # If the file exists on S3 and it's the same as the locally generated file, nothing to do.
    if os.path.exists(existing_file.name):
        if filecmp.cmp(new_file.name, existing_file.name):
            return

    # Upload our file to S3
    s3.upload_file(new_file.name, s3_bucket_name, s3_key)


def store_jsonpaths_on_s3(column_names, s3_url, aws_profile='nwprod'):
    """
    Given a list of column names, generates a JSONPATHS file for those columns and stores it on S3.
    :param column_names: List of column names
    :param s3_url: The location on S3 to store the JSONPATHS file.
    :return:
    """
    jsonpaths = {
        'jsonpaths': list()
    }
    for column_name in column_names:
        jsonpaths['jsonpaths'].append('$[\'{}\']'.format(column_name))

    logging.info('Writing JSONPATHS to {}'.format(s3_url))
    write_dict_to_s3(jsonpaths, s3_url, aws_profile)


def copy_data_to_redshift_table(conn, fq_table_name, col_names, manifest_url, jsonpaths_url, credentials):
    """
    Copies data from S3 to a Redshift table using the COPY command.
    :param conn: Redshift connection
    :param fq_table_name: Fully qualified table name
    :param col_names: List of column names
    :param manifest_url: S3 URL of the manifest file
    :param jsonpaths_url: S3 URL of the JSONPATHS file
    :param credentials: S3 credentials used by the Redshift COPY command
    :return:
    """
    # Generate the COPY command
    copy_lines = list()
    copy_lines.append('COPY {} ('.format(fq_table_name))
    col_list = '"{}"'.format('", "'.join(col_names))
    copy_lines.extend(['    ' + line for line in textwrap.wrap(col_list, 116)])
    copy_lines.append(')')
    copy_lines.append('FROM \'{}\''.format(manifest_url))
    copy_lines.append('CREDENTIALS %s')
    copy_lines.append('JSON AS \'{}\''.format(jsonpaths_url))
    copy_lines.append('TIMEFORMAT AS \'epochmillisecs\'')
    copy_lines.append('BLANKSASNULL EMPTYASNULL ACCEPTINVCHARS COMPUPDATE OFF MAXERROR 50 MANIFEST')
    copy_cmd = '\n'.join(copy_lines)
    logging.info(copy_cmd)

    with conn.cursor() as curs:
        try:
            curs.execute(curs.mogrify(copy_cmd, [credentials]))
        except psycopg2.Error as ex:
            if ex.diag.severity in ['ERROR', 'FATAL', 'PANIC']:
                logging.error('COPY failure: [{}] {}'.format(ex.pgcode, ex.diag.message_primary))
                sys.exit(1)

            if ex.diag.severity == 'WARNING':
                logging.warning('COPY warning: [{}] {}'.format(ex.pgcode, ex.diag.message_primary))
            else:
                logging.info('COPY warning: [{}] {}'.format(ex.pgcode, ex.diag.message_primary))

        # This displays the number of records that were loaded
        # e.g.: INFO:  Load into table 'table_name_s' completed, 8 record(s) loaded successfully.
        for notice in conn.notices:
            logging.info(notice.rstrip())


def load(pb_class_name, fq_table_name, manifest_s3_url, s3_credentials, overrides=None):
    manifest_s3_url_parsed = urlparse(manifest_s3_url)

    logging.info('Building CREATE TABLE statement')
    create_table_ddl, mixed_case_column_names = event_modules.protobuf_class_to_redshift_table(
        pb_class_name=pb_class_name,
        fq_table_name=fq_table_name,
        overrides=overrides)

    if not create_table_ddl:
        logging.critical('No table DDL generated')
        sys.exit(1)

    # Re-create the table
    logging.info('Connecting to Redshift')
    conn = redshift_modules.redshift_connect()
    redshift_modules.recreate_redshift_table(conn, fq_table_name, create_table_ddl)

    # Generate the JSONPATHs file and upload it to S3 using the same path as the manifest file
    aws_profile = None
    if pwd.getpwuid(os.getuid()).pw_name != 'airflow':
        aws_profile = 'nwprod'
    s3_path = os.path.dirname(manifest_s3_url_parsed.path)
    jsonpaths_url = 's3://{s3_bucket}{s3_path}/{fq_table_name}.jsonpaths'.format(
        s3_bucket=manifest_s3_url_parsed.netloc,
        s3_path=s3_path,
        fq_table_name=args.table_name.lower()
    )
    store_jsonpaths_on_s3(mixed_case_column_names, jsonpaths_url, aws_profile)

    # Copy the data from S3 JSON files to a Redshift table
    copy_data_to_redshift_table(
        conn=conn,
        fq_table_name=args.table_name,
        col_names=mixed_case_column_names,
        manifest_url=args.manifest_s3_url,
        jsonpaths_url=jsonpaths_url,
        credentials=s3_credentials)

    logging.info('Disconnecting from Redshift')
    conn.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Load a ProtoBuf event\'s JSON data into a Redshift staging table')
    parser.add_argument('--pb-class-name', required=True, help='Name of the ProtoBuf class, e.g. \'PageViewEvent\'')
    parser.add_argument('--table-name', required=True, help='Fully qualified name of the Redshift table')
    parser.add_argument('--manifest-s3-url', required=True, help='S3 URL of the COPY command\'s manifest file')
    parser.add_argument('--overrides-filename', required=False, help='Filename that contains overrides for events')
    parser.add_argument('--redshift-s3-creds-envar', required=False,
                        help='Environment variable that holds the Redshift/S3 credentials string')
    parser.add_argument('--tmp-dir', required=False, default='/tmp', help='Directory to use for small temporary files')
    args = parser.parse_args()

    if args.overrides_filename:
        overrides_filename = args.overrides_filename
    else:
        overrides_filename = '{}/event_overrides.json'.format(os.environ['dwh_common_base_dir'])

    schema, table_name = args.table_name.split('.', 1)
    if schema.lower() != 'dw_workarea' and not schema.lower().endswith('_stage'):
        print('ERROR: Schema \'{}\' is invalid, must be \'dw_workarea\' or end in \'_stage\'')
        sys.exit(1)

    if pwd.getpwuid(os.getuid()).pw_name == "airflow":
        # Airflow includes the timestamp at the beginning of each line in its logging
        logging.basicConfig(format="[%(levelname)-8s] %(name)s - %(message)s", level=logging.INFO)
    else:
        logging.basicConfig(format="[%(asctime)s] [%(levelname)-8s] %(name)s - %(message)s", level=logging.INFO)
    logging.getLogger('botocore').setLevel(logging.WARNING)

    logging.info('Execution begins')
    logging.info('ProtoBuf Class Name: ' + args.pb_class_name)
    logging.info('Table Name: ' + args.table_name)
    logging.info('Overrides JSON Filename: ' + overrides_filename)

    overrides = None
    if overrides_filename:
        with open(overrides_filename, 'r') as fh:
            overrides = json.load(fh)
        logging.info('Loaded overrides for {} fields'.format(len(overrides_filename)))

    copy_credentials = None
    if args.redshift_s3_creds_envar:
        copy_credentials = os.environ[args.redshift_s3_creds_envar]

    load(args.pb_class_name, args.table_name, args.manifest_s3_url, copy_credentials, overrides=overrides)

    logging.info('Execution ends')
