#!/usr/bin/env python

import argparse
import logging
import json
import os
import pwd
import sys
import tempfile
from urlparse import urlparse

import boto3
import requests

from nw_retry import nw_retry, REQUEST_EXCEPTIONS
logger = logging.getLogger()


def store_file(local_filename, dest_filespec):
    if dest_filespec.lower().startswith('s3://'):
        s3_url = urlparse(dest_filespec)
        s3_bucket = s3_url.netloc
        s3_key = s3_url.path[1:]
        logger.info('Uploading {} to s3://{}/{}'.format(local_filename, s3_bucket, s3_key))
        s3 = boto3.resource('s3')
        s3.Bucket(s3_bucket).upload_file(local_filename, s3_key)
    else:
        logger.info('Moving {} to {}'.format(local_filename, dest_filespec))
        if os.path.exists(dest_filespec):
            os.remove(dest_filespec)
        os.rename(local_filename, dest_filespec)


@nw_retry(REQUEST_EXCEPTIONS, tries=7, delay=30, backoff=2)
def url_to_file(url, local_filename):
    r = requests.get(url, stream=True)
    with open(local_filename, 'w') as fhout:
        for chunk in r.iter_content(chunk_size=65536):
            if chunk:
                fhout.write(chunk)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', required=True, help='URL to retrieve data from')
    parser.add_argument('--output', required=True, help='Local filename or S3 URL to store the data in')
    parser.add_argument('--tmp-dir', required=False, help='Directory to store temporary files in')
    parser.add_argument('--transform', required=False,
                        help='Filename of a Python module that contains a function \'transform\' that should ' +
                             'transform the object before writing it')
    args = parser.parse_args()

    if args.transform:
        raise NotImplemented('Parameter \'transform\' is not yet supported')

    logging.getLogger('botocore').setLevel(logging.WARNING)
    if pwd.getpwuid(os.getuid()).pw_name == 'airflow':
        logging.basicConfig(format='[%(levelname)-8s] %(name)s - %(message)s', level=logging.INFO)
    else:
        logging.basicConfig(format='[%(asctime)s] [%(levelname)-8s] %(name)s - %(message)s', level=logging.INFO)
    logger.info('Execution begins')

    fh_full = tempfile.NamedTemporaryFile(
        dir=args.tmp_dir or '/tmp',
        prefix=os.path.basename(args.output) + '_XXXXXXXXXX',
        suffix='.json',
        delete=False
    )

    logger.info('Getting data from {} and storing it to {}'.format(args.url, fh_full.name))

    # Retrieve the data and store it into a local file
    page_no = 0
    retrieved_count = 0
    while True:
        page_no += 1
        fh_local = tempfile.NamedTemporaryFile(
            dir=args.tmp_dir or '/tmp',
            prefix=os.path.basename(args.output) + '_page{}_XXXXXXXXXX'.format(page_no),
            suffix='.json',
            delete=False
            )
        fh_local.close()
        page_url = args.url + '?page={page_no}&per_page={per_page}'.format(page_no=page_no, per_page=50)
        logger.info('Getting data from {} and storing it to {}'.format(page_url, fh_local.name))
        url_to_file(page_url, fh_local.name)
        logger.info('Stored {} bytes'.format(os.path.getsize(fh_local.name)))

        with open(fh_local.name, 'r') as fh_in:
            obj = json.load(fh_in)

        if len(obj) < 1:
            break
        retrieved_count += len(obj)
        for item in obj:
            json.dump(item, fh_full)
            fh_full.write('\n')

    fh_full.close()
    logger.info('Retrieved {} items across {} pages'.format(retrieved_count, page_no))

    store_file(fh_full.name, args.output)

    logger.info('Execution ends')
