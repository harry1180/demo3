#!/usr/bin/env python

import argparse
import logging
import os
import pwd
import shutil
import subprocess
import tempfile
from urlparse import urlparse

import boto3
import psycopg2

import redshift_modules

logging.basicConfig(format='[%(asctime)s] [%(levelname)-8s] %(name)s - %(message)s', level=logging.DEBUG)
logger = logging.getLogger()
logging.getLogger('botocore').setLevel(logging.WARNING)
logging.getLogger('s3transfer').setLevel(logging.WARNING)


def _is_iterable(var):
    """
    Returns whether or not the specified variable can be iterated over. Does not return True for strings.

    :param var:
    :return:
    """
    try:
        i = iter(var)
        return True
    except TypeError as e:
        return False


def get_pgpass_password(server, port, database, username):
    pgpass_filename = os.environ.get('PGPASSFILE', os.environ.get('HOME', '') + '/.pgpass')

    with open(pgpass_filename, 'r') as fh:
        pgpass_line_start = "{}:{}:{}:{}:".format(server, port, database, username)
        for line in fh:
            if line.strip().lower().startswith(pgpass_line_start.lower()):
                return line[len(pgpass_line_start):].rstrip('\r\n')

    return None


def get_copy_command(table_name, cols, output_filename, column_names=None, where_clause=None, skip_header=False):
    """
    Generates a psql '\copy' command that extracts data from the specified source into the specified output filename.

    :param table_name:
    :param cols:
    :param output_filename:
    :param column_names:
    :param where_clause:
    :param skip_header:
    :return:
    """
    # Make sure column_names is a list or a tuple or some other iterable -- i.e., not a string
    if column_names and not _is_iterable(column_names):
        raise ValueError('get_copy_command.column_names is not iterable')

    # Translate the array of dictionaries passed in as 'cols' to a dictionary of column names and types
    table_cols = dict()
    for col in cols:
        table_cols[col['name']] = col['type']

    # Build a list of SELECT clause fields
    select_cols = list()
    if column_names:
        for column_name in column_names:
            column_name = column_name.lower()
            if column_name not in table_cols:
                raise RuntimeError('Column \'{}\' could not be found in {}'.format(column_name, table_name))
            if table_cols[column_name] in ('character', 'character varying'):
                select_cols.append(u'TRANSLATE({0}, chr(10) || chr(13), \'\u240a\u240d\') as {0}'.format(column_name))
            else:
                select_cols.append(column_name)
    else:
        for column_name, column_type in table_cols.iteritems():
            if column_type in ('character', 'character varying'):
                select_cols.append(u'TRANSLATE({0}, chr(10) || chr(13), \'\u240a\u240d\') as {0}'.format(column_name))
            else:
                select_cols.append(column_name)

    cmd = u'\\copy ( SELECT {column_names} FROM {table_name}'.format(
        column_names=u', '.join(select_cols),
        table_name=table_name
    )

    if where_clause:
        cmd += u' WHERE {}'.format(where_clause)

    cmd += u' ) to \'{}\' '.format(output_filename)
    cmd += u'with ( format csv'
    if not skip_header:
        cmd += u', header true'
    cmd += u' )'

    return cmd.rstrip()


def run_psql_script(server, port, database, username, sql_filename):
    """
    Executes a SQL script using psql.

    :param server:
    :param port:
    :param database:
    :param username:
    :param sql_filename:
    :return:
    """
    cmd = [
        'psql',
        '-h', server,
        '-p', str(port),
        '-d', database,
        '-U', username,
        '-v', 'ON_ERROR_STOP=on',
        '-f', sql_filename]
    rc = subprocess.call(cmd)
    if rc != 0:
        return False

    return True


def export_table(server, port, database, username, table_name, output, columns=None, where_clause=None,
                 compress_output=False, skip_header=False):

    if output.lower().startswith('s3://'):
        tf = tempfile.NamedTemporaryFile(dir=os.environ.get('Linux_Output'), prefix=table_name + '_', suffix='.csv')
        tf.close()
        if os.path.exists(tf.name):
            os.remove(tf.name)
        output_filename = tf.name
    elif output.lower().endswith('.gz'):
        output_filename = output[0:len(output)-3]
    else:
        output_filename = output

    # Connect to the PostgreSQL server, used to get table structure
    postgresql_password = get_pgpass_password(server, port, database, username)
    if postgresql_password is None:
        raise RuntimeError('Failed to find password for {username}@{server}:{port}/{database}'.format(
            username=username, server=server, port=port, database=database
        ))
    conn = psycopg2.connect(host=server, port=port, dbname=database, user=username, password=postgresql_password)
    if '.' in table_name:
        fq_table_name = table_name
    else:
        fq_table_name = 'public.' + table_name
    table_cols = redshift_modules.get_table_columns(conn, fq_table_name)
    conn.close()

    # Get the \copy command and write it to a temporary file
    copy_command = get_copy_command(table_name, table_cols, output_filename, columns, where_clause, skip_header=skip_header)
    tf = tempfile.NamedTemporaryFile(dir=os.environ.get('Linux_Temp'), prefix=table_name + '_', suffix='.sql',
                                     delete=False)
    tf.write((copy_command + '\n').encode('utf-8'))
    tf.close()

    logger.info(copy_command)
    copy_success = run_psql_script(server, port, database, username, tf.name)
    os.remove(tf.name)
    if not copy_success:
        if os.path.exists(output_filename):
            os.remove(output_filename)
        raise RuntimeError('psql command failed')

    if compress_output:
        logger.info('Compressing output file')
        rc = subprocess.call(['gzip', '-v', output_filename])
        if rc != 0:
            raise Exception('Failed to compress output file')
        logger.info('Compression complete')
        if not output_filename.lower().endswith('.gz'):
            output_filename += '.gz'

    if output.lower().startswith('s3://'):
        logger.info('Moving {} to {}'.format(output_filename, output))
        output_url = urlparse(output)
        s3_bucket_name = output_url.netloc
        s3_key = output_url.path[1:]
        aws_profile = None
        if pwd.getpwuid(os.getuid()).pw_name not in ['airflow']:
            aws_profile = 'nwprod'
        aws_session = boto3.session.Session(profile_name=aws_profile)
        s3 = aws_session.client('s3')
        s3.upload_file(output_filename, s3_bucket_name, s3_key)
        os.remove(output_filename)
    elif output != output_filename:
        logger.info('Moving {} to {}'.format(output_filename, output))
        shutil.move(output_filename, output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Export data from a PostgreSQL database server')
    parser.add_argument('--server', required=True)
    parser.add_argument('--port', required=False, default=5432, type=int)
    parser.add_argument('--database', required=True)
    parser.add_argument('--username', required=False)
    parser.add_argument('--table-name', required=True)
    parser.add_argument('--column-names', required=False)
    parser.add_argument('--table-filter', required=False)
    output_group = parser.add_mutually_exclusive_group(required=True)
    output_group.add_argument('--output-filename', required=False)
    output_group.add_argument('--output-s3-url', required=False)
    parser.add_argument('--compress-output', action='store_true', required=False)
    parser.add_argument('--skip-header', action='store_true', required=False)

    args = parser.parse_args()

    logger.info('Execution begins')

    column_names = None
    if args.column_names:
        column_names = list()
        for column_name in args.column_names.split(','):
            column_names.append(column_name.strip())

    export_table(
        server=args.server,
        port=args.port,
        database=args.database,
        username=args.username,
        table_name=args.table_name,
        output=args.output_filename or args.output_s3_url,
        columns=column_names,
        where_clause=args.table_filter,
        compress_output=args.compress_output,
        skip_header=args.skip_header)

    logger.info('Execution ends')
