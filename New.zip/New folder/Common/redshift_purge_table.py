#!/usr/bin/env python

"""
Purge a table in Redshift.

Calls redshift_modules.purge_table() which attempts to use the TRUNCATE command. If that fails because the table isn't
owned by the person running the command, then it attempts to use a DELETE command instead.
"""

import argparse
import logging
import os
import pwd
import sys

import redshift_modules

parser = argparse.ArgumentParser()
parser.add_argument(
    '--force',
    required=False,
    action='store_true',
    help='Attempt to purge a production table even when not production user')
parser.add_argument(
    'table_name',
    action='store',
    help='Fully qualified table name to purge')
args = parser.parse_args()

if '.' not in args.table_name:
    sys.stderr.write('ERROR: You must specify a fully-qualified table name including both the schema and table name')
    sys.exit(1)

logging_format = '[%(levelname)-8s] %(name)s - %(message)s'
if pwd.getpwuid(os.geteuid())[0] != 'airflow':
    logging_format = '%(asctime)s ' + logging_format
logging.basicConfig(format=logging_format, level=logging.INFO)

logging.info('Execution begins')

schema, table_name = args.table_name.split('.')

if pwd.getpwuid(os.getuid()).pw_name != 'airflow':
    if schema.lower() in ['dw_ba_report', 'dw_pud_report', 'dw_report']:
        logging.error('Non-production user can\'t purge a production table')
        sys.exit(1)

logging.info('Connecting to Redshift')
conn = redshift_modules.redshift_connect()

logging.info('Purging ' + args.table_name)
redshift_modules.purge_table(conn, '{}.{}'.format(schema.lower(), table_name.lower()))

logging.info('Execution ends')
