"""
Replace Prod/Dev s3 AWS keys in credentials.ctrl file with the temporary keys generated via `awslogin analytics`
This is to be called in Common/set_dwh_common_variables.sh
"""
import os
import pwd
import sys
import time

from datetime import datetime, timedelta

from ConfigParser import ConfigParser


AWS_CREDS_FILE = os.path.join(os.path.expanduser('~'), '.aws', 'credentials')
DWH_CREDS_FILE = os.path.join(os.path.expanduser('~'), 'dwh', 'Common', 'credentials.ctrl')


def aws_keys_expired(expiration_time_str):
    """
    Check if the aws keys are expired by comparing the expiration timestamp to current UTC date. Expiration timestamp
    is located in the aws credentials file and contains a timezone offset that allows us to convert to UTC.
    """

    # Adjust for timezone -- convert to UTC
    expr_time = datetime.strptime(expiration_time_str[0:19], '%Y-%m-%dT%H:%M:%S')
    if expiration_time_str[19] == '+':
        expr_time -= timedelta(hours=int(expiration_time_str[20:22]), minutes=int(expiration_time_str[23:]))
    elif expiration_time_str[19] == '-':
        expr_time += timedelta(hours=int(expiration_time_str[20:22]), minutes=int(expiration_time_str[23:]))

    # Check if keys need to be refreshed
    if expr_time <= datetime.utcnow() + timedelta(minutes=5):
        return True

    return False


def build_creds_string(profile, s3_config):
    """
    Construct a single string that can be used along with the CREDENTIALS parameter when loading/unloading data
    into redshift.
    See https://docs.aws.amazon.com/redshift/latest/dg/copy-usage_notes-access-permissions.html
    """
    if profile not in ['nwprod', 'nwdev']:
        raise Exception('mode must: "nwprod" or "nwdev"')
    creds = '\'aws_access_key_id={};aws_secret_access_key={};token={}\''.format(
        s3_config.get(profile, 'aws_access_key_id'),
        s3_config.get(profile, 'aws_secret_access_key'),
        s3_config.get(profile, 'aws_session_token'))
    return creds


def replace_s3_creds(s3_config, dwh_creds_file):
    """
    Replace various s3 parameters in the DWH credentials.ctrl file based on the contents of ~/.aws/credentials
    """

    output_rows = []
    with open(dwh_creds_file) as dwh_creds_in:
        for row in dwh_creds_in:

            # replace prod keys
            if row.split('=')[0] == 's3_prod_access_key':
                edited_row = 's3_prod_access_key={}\n'.format(s3_config.get('nwprod', 'aws_access_key_id'))
            elif row.split('=')[0] == 's3_prod_secret_Key':
                edited_row = 's3_prod_secret_Key={}\n'.format(s3_config.get('nwprod', 'aws_secret_access_key'))
            elif row.split('=')[0] == 'AWS_ACCESS_KEY_ID':
                edited_row = 'AWS_ACCESS_KEY_ID={}\n'.format(s3_config.get('nwprod', 'aws_access_key_id'))
            elif row.split('=')[0] == 'AWS_SECRET_ACCESS_KEY':
                edited_row = 'AWS_SECRET_ACCESS_KEY={}\n'.format(s3_config.get('nwprod', 'aws_secret_access_key'))
            elif row.split('=')[0] == 's3_prod_session_token':
                edited_row = 's3_prod_session_token={}\n'.format(s3_config.get('nwprod', 'aws_session_token'))
            elif row.split('=')[0] == 's3_prod_load_creds':
                edited_row = 's3_prod_load_creds={}\n'.format(build_creds_string('nwprod', s3_config))

            # replace dev keys
            elif row.split('=')[0] == 's3_dev_access_key':
                edited_row = 's3_dev_access_key={}\n'.format(s3_config.get('nwdev', 'aws_access_key_id'))
            elif row.split('=')[0] == 's3_dev_secret_Key':
                edited_row = 's3_dev_secret_Key={}\n'.format(s3_config.get('nwdev', 'aws_secret_access_key'))
            elif row.split('=')[0] == 's3_dev_session_token':
                edited_row = 's3_dev_session_token={}\n'.format(s3_config.get('nwdev', 'aws_session_token'))
            elif row.split('=')[0] == 's3_dev_load_creds':
                edited_row = 's3_dev_load_creds={}\n'.format(build_creds_string('nwdev', s3_config))

            # leave everything else unchanged
            else:
                edited_row = row

            output_rows.append(edited_row)

    # swap previous creds file with updated version
    os.rename(dwh_creds_file, '{}.bak'.format(dwh_creds_file))
    with open(dwh_creds_file, 'w') as creds_out:
        for output_row in output_rows:
            creds_out.write(output_row)


if __name__ == '__main__':

    current_username = pwd.getpwuid(os.getuid()).pw_name

    # Only replace credentials if user is NOT airflow
    if current_username != "airflow":

        if not os.path.exists(AWS_CREDS_FILE):
            sys.stderr.write('Unable to find ~/.aws/credentials file. Please run `awslogin analytics`.')
            sys.exit(1)

        config = ConfigParser()
        config.read(AWS_CREDS_FILE)

        # Check if keys need to be refreshed
        parsed_expr_time_str = config.get('nwprod', 'x_security_token_expires')
        if aws_keys_expired(parsed_expr_time_str):
            sys.stderr.write('\x1b[0;30;43m+-------------------------------------------------------------------------+\x1b[0m\n')
            sys.stderr.write('\x1b[0;30;43m| Your AWS keys have expired. Please run \'awslogin analytics\'             |\x1b[0m\n')
            sys.stderr.write('\x1b[0;30;43m+-------------------------------------------------------------------------+\x1b[0m\n')
            time.sleep(1)
            sys.exit(0)

        # Print out cred value to be set as env variable
        replace_s3_creds(config, DWH_CREDS_FILE)

    else:
        pass
