set -e
identity_profile="$1"
job_name=${identity_profile}"_stage_load_nerdlake"
job_start_time=$(date +%s)

echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
source ${dwh_common_base_dir}/set_dwh_schema_variables.sh
export dwh_common_base_dir
export dwh_scripts_base_dir
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
  bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0

bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
s3_output="s3://$nerdlake_dwh_bucket/${hive_pudstagedb}/idb_${identity_profile}_pre_s/idb_${identity_profile}_s.csv.gz"
stage_table="hive.${hive_pudstagedb}.idb_${identity_profile}_s" 
pre_stage_table="hive.${hive_pudstagedb}.idb_${identity_profile}_pre_s"
where_clause="updated_at >= date_trunc('day', current_timestamp at time zone 'utc')"

echo "identity_prod_dbHost     :- $identity_prod_dbHost"
echo "identity_prod_port       :- $identity_prod_port"
echo "identity_prod_database   :- $identity_prod_database"
echo "identity_prod_username   :- $identity_prod_username"
echo "s3_output                :- $s3_output"
echo "stage_table              :- $stage_table"
echo "pre_stage_table          :- $pre_stage_table"
echo "where_clause             :- $where_clause"
echo "force_extract_mode       :- $force_extract_mode"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

Processing_Step="Extracting data from public.${identity_profile}"
echo_processing_step ${job_name} "$Processing_Step" "Started"

python $dwh_common_base_dir/identity_stg_table_export.py \
    --server "$identity_prod_dbHost" \
    --port "$identity_prod_port" \
    --database "$identity_prod_database" \
    --username "$identity_prod_username" \
    --idb_profile "$identity_profile" \
    --s3_output "$s3_output" \
    --stage_table "$stage_table" \
    --pre_stage_table "$pre_stage_table" \
    --where_clause "$where_clause" "${@:2}"

echo_processing_step ${job_name} "Calling End Script" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
