# This script sets variables for psql which represent things like database schemas. These variables are set based
# on who is running the script, allowing for simpler development.

# Redshift
stagedb=dw_qa_stage
reportdb=dw_qa_report
pudstagedb=dw_pud_workarea
pudreportdb=dw_pud_workarea
pudviews=dw_pud_views
if [ $(id -un) == 'airflow' ] || [ $(id -un) == 'etl' ] || [ $(id -un) == 'bai' ] || [ -n "${DWH_PROD_RUN}" ]
then
    stagedb=dw_stage
    reportdb=dw_report
    pudstagedb=dw_pud_stage
    pudreportdb=dw_pud_report
    pudviews=dw_pud_views
fi

export stagedb
export reportdb
export pudstagedb
export pudreportdb

# Hive
hive_stagedb=dwnl_workarea
hive_datadb=dwnl_workarea
hive_pudstagedb=dwnl_pud_workarea
hive_puddatadb=dwnl_pud_workarea
if [ $(id -un) == 'airflow' ] || [ $(id -un) == 'etl' ] || [ $(id -un) == 'bai' ] || [ -n "${DWH_PROD_RUN}" ]
then
    hive_stagedb=dwnl_stage
    hive_datadb=dwnl_data
    hive_pudstagedb=dwnl_pud_stage
    hive_puddatadb=dwnl_pud_data
fi

export hive_stagedb
export hive_datadb
export hive_pudstagedb
export hive_puddatadb
