import argparse
import logging
import nw_hive
import nw_presto


logging.basicConfig(format='[%(levelname)-8s]:%(asctime)s %(message)s', level=logging.DEBUG, datefmt='%Y/%m/%d %H:%M:%S')


def step01_recreate_work_table(hive_conn, work_table, target_table, location_ts):
    """
    Alter location of work table.
    :param hive_conn: nw_hive connection
    :param work_table: full work table name
    :param target_table: full target table name
    :param location_ts: timestamp for work table location
    """
    logging.info('Step01: Dropping and recreating {}'.format(work_table))
    target_table_schema, target_table_nm = target_table.split('.')[1:]
    work_table_schema, work_table_nm = work_table.split('.')[1:]
    path = '\'s3://east1-prod-nerdlake-0/{}/{}/{}\''.format(target_table_schema, target_table_nm, location_ts)

    fq_work_table = '.'.join([work_table_schema, work_table_nm])
    fq_target_table = '.'.join([target_table_schema, target_table_nm])

    nw_hive.drop_table(hive_conn, fq_work_table)
    nw_hive.create_table_like(hive_conn, fq_work_table, fq_target_table, 'ORC', path)
    logging.info('Step01: Work table recreated')


def step02_work_table_ins_stg(presto_conn, stage_table, work_table, work_cols):
    """
    Insert records from stage table into work table
    :param presto_conn: nw_preto connection
    :param stage_table: full stage table name
    :param work_table: full work table name
    :param work_cols: work table columns
    """
    logging.info('Step02: Insert records from {} to {}'.format(stage_table, work_table))

    stage_cols_trans = stage_cols_transformation(work_cols)

    sql = 'INSERT INTO {}(\n'.format(work_table)
    sql += '{}\n)\n'.format(',\n'.join(col for col in work_cols))
    sql += 'SELECT\n'
    sql += '  {}\n'.format(',\n  '.join(col for col in stage_cols_trans))
    sql += 'FROM {} stg\n'.format(stage_table)
    sql += 'WHERE dw_eff_dt = (SELECT MAX(dw_eff_dt) FROM {})\n'.format(stage_table)
    sql += 'AND dw_load_ts = (SELECT MAX(dw_load_ts) FROM {})\n'.format(stage_table)
    logging.debug(sql)

    presto_curs = presto_conn.cursor()
    presto_curs.execute(sql)
    records_inserted = presto_curs.fetchall()[0][0]
    logging.info('Step02: {} records inserted into {}'.format(records_inserted, work_table))


def step03_work_table_ins_tgt(prest_conn, work_table, target_table, work_cols, stage_table):
    """
    Insert records from target table to work table (this is only done if in partial mode)
    :param prest_conn: nw_presto connection
    :param work_table: full work table name
    :param target_table: full target table name
    :param work_cols: work table columns
    :param stage_table: full stage table name (used to determine if in full or partial mode)
    """
    logging.info('Step03: Insert records from {} to {}'.format(target_table, work_table))

    sql = 'INSERT INTO {}(\n'.format(work_table)
    sql += '{}\n)\n'.format(',\n'.join(col for col in work_cols))
    sql += 'SELECT\n'
    sql += '  {}\n'.format(',\n  '.join('dim.' + col for col in work_cols))
    sql += 'FROM {} dim\n'.format(target_table)
    sql += 'LEFT JOIN {} stg\n'.format(work_table)
    sql += 'ON dim.id = stg.id\n'
    sql += 'WHERE stg.id IS NULL\n'
    sql += 'AND EXTRACT(HOUR FROM (SELECT MAX(dw_load_ts) FROM {})) <> 0'.format(stage_table)
    logging.debug(sql)

    presto_curs = prest_conn.cursor()
    presto_curs.execute(sql)
    records_inserted = presto_curs.fetchall()[0][0]
    logging.info('Step03: {} records inserted into {}'.format(records_inserted, work_table))


def step04_alter_table_locations(hive_conn, target_table, work_table, location_ts):
    """
    Point target table to same location as work table. Point work table to neutral location
    :param hive_conn: nw_hive connection
    :param target_table: full target table name
    :param work_table: full work table mame
    :param location_ts: location timestamp
    """
    logging.info('Step04: Alter location of {}'.format(target_table))
    target_table_schema, target_table_nm = target_table.split('.')[1:]
    path = '\'s3://east1-prod-nerdlake-0/{}/{}/{}\''.format(target_table_schema, target_table_nm, location_ts)

    nw_hive.alter_table_location(hive_conn, '.'.join([target_table_schema, target_table_nm]), path)

    logging.info('Step04: Alter location of {}'.format(work_table))
    work_table_schema, work_table_nm = work_table.split('.')[1:]
    path = '\'s3://east1-prod-nerdlake-0/{}/{}/\''.format(work_table_schema, work_table_nm)

    nw_hive.alter_table_location(hive_conn, '.'.join([work_table_schema, work_table_nm]), path)

    logging.info('step04: Alter tables complete')


def stage_cols_transformation(stage_cols):
    transformed_cols = []
    for col in stage_cols:
        if col == 'id':
            col = 'stg.id'
        elif col == 'dw_eff_dt':
            col = 'DATE(stg.dw_load_ts) AS dw_eff_dt'
        elif col == 'dw_load_ts':
            col = 'stg.dw_load_ts'
        transformed_cols.append(col)

    return transformed_cols


def load_tgt_table(target_table, work_table, stage_table, location_ts):
    hive_conn = nw_hive.connect()
    presto_conn = nw_presto.connect()

    # Point work table to target table location in s3
    step01_recreate_work_table(hive_conn, work_table, target_table, location_ts)

    # Get work/stage columns formatted
    work_table_columns = nw_presto.get_column_names(presto_conn, work_table, True)
    work_cols = [t[0] for t in work_table_columns]

    # Insert all stage records into work table
    step02_work_table_ins_stg(presto_conn, stage_table, work_table, work_cols)

    # Insert target records that are not in work table
    step03_work_table_ins_tgt(presto_conn, work_table, target_table, work_cols, stage_table)

    # alter table of target table
    step04_alter_table_locations(hive_conn, target_table, work_table, location_ts)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Insert date into Nerdlake target identity table')
    parser.add_argument('--target_table', required=True)
    parser.add_argument('--work_table', required=True)
    parser.add_argument('--stage_table', required=True)
    parser.add_argument('--location_ts', required=True)

    args = parser.parse_args()
    logging.info('Beginning idb target table load')

    load_tgt_table(
        args.target_table,
        args.work_table,
        args.stage_table,
        args.location_ts
    )

    logging.info('Target table load complete')

