log_file='/data/etl/Common/job_load_logs/dwh_logs/dwh_complete_load_2015050911.log'



#if grep -i 'error' dwh_complete_load_`date +\%Y\%m\%d\%H`.log
if grep -i 'error' $log_file
 then
  grep -i 'error' $log_file > /data/etl/Common/job_load_logs/dwh_logs/job_status/job_failed_`date +\%Y\%m\%d`.txt
  mail -s "PROD Error ETL Job Failed and Error Log Attached "`date +\%Y-\%m-\%d` -a "From: east1-prod-ses-0@nerdwallet.com"  puneeth@nerdwallet.com  < /data/etl/Common/job_load_logs/dwh_logs/job_status/job_failed_`date +\%Y\%m\%d`.txt
 else
  touch /data/etl/Common/job_load_logs/dwh_logs/job_status/job_success.txt
fi
