
echo '*******Heart Beat Event Stage Started************'
/bin/bash /data/etl/Scripts/heart_beat_event/shellscripts/heart_beat_event_load.sh 
echo '*******Heart Beat Event Stage Completed**********'

echo '*******Heart Beat Event and Rollup Started************'
/bin/bash /data/etl/Scripts/dw_pv_heart_beat_rollup_f/shellscripts/dw_pv_heart_beat_rollup_f.sh
echo '*******Heart Beat Event and Rollup Completed************'
