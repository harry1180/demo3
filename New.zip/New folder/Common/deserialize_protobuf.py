#!/usr/bin/python

import argparse
from datetime import date, datetime, timedelta
import imp
import json
import logging
import os
import platform
import pwd
import socket
import sys
import tempfile
import time

from event_modules import Emit_protobuf_enhanced
import mysql_modules
import redshift_modules
import s3_modules


def prod_user():
    """
    Determines if the current executing user should be treated as production or not.
    :return: True or False, indicating if the current user should be treated as production or not.
    """
    try:
        if pwd.getpwuid(os.getuid())[0] in ["airflow", "etl", "bai"]:
            return True
    except KeyError:
        pass

    return False


def stage_host():
    """
    Determines if the current executing user is running on stage or not.
    :return: True or False, indicating if the current user is running from stage or not.
    """
    if "stage" in socket.gethostname():
        return True

    return False


def log_processing_job(job_name, job_status):
    """
    Logs current job status into RDS table DWH_STATS.CTL_JOBS_STATUS
    :param job_name: Event name, suffixed with '_nerdlake' if the destination is NerdLake.
    :param job_status: Started, Completed, or Failed
    """
    if stage_host():
        return

    # TODO: Remove this if statement when DataOps creates the DWH_STATS_DEV database in RDS
    if not prod_user():
        return

    log_db_name = "dwh_stats"
    if not prod_user():
        log_db_name = "dwh_stats_dev"

    conn = mysql_modules.mysql_connect(redshift_modules.load_creds())
    curs = conn.cursor()
    if job_status.lower() == "started":
        sql = """
        INSERT INTO """ + log_db_name + """.ctl_jobs_status
        ( job_tracking_id, job_date, job_name, job_start_time, job_end_time,
          job_status, dw_load_ts )
        VALUES ( DATE_FORMAT(CURRENT_DATE, '%%Y%%m%%d'), CURRENT_DATE, %s,
          SYSDATE(), NULL, %s, SYSDATE() )
        """
        vals = (job_name, job_status)
        curs.execute(sql, vals)
    else:
        sql = """
        UPDATE """ + log_db_name + """.ctl_jobs_status
        SET job_end_time = SYSDATE(),
          job_status = %s
        WHERE job_name = %s
        AND job_end_time IS NULL
        AND job_status = 'Started'
        """
        vals = (job_status, job_name)
        curs.execute(sql, vals)
    curs.close()
    conn.close()


def log_processing_step(job_name, task_name, task_status):
    """
    Logs current step status into RDS table DWH_STATS.CTL_TASK_STATUS
    :param job_name: Event name suffixed with '_nerdlake' if the destination is NerdLake
    :param task_name: String that represents the activity
    :param task_status: Started, Completed, or Failed
    """
    if stage_host():
        return

    log_db_name = "dwh_stats"
    if not prod_user():
        log_db_name = "dwh_stats_dev"

    # TODO: Remove this if statement when DataOps creates the DWH_STATS_DEV database in RDS
    if not prod_user():
        return

    conn = mysql_modules.mysql_connect(redshift_modules.load_creds())
    curs = conn.cursor()
    if task_status.lower() == "started":
        sql = """
        INSERT INTO """ + log_db_name + """.ctl_task_status
        ( job_tracking_id, job_date, job_name, task_name,
          task_start_Time, task_end_time, task_status, dw_load_ts )
        VALUES ( DATE_FORMAT(CURRENT_DATE, '%%Y%%m%%d'), CURRENT_DATE, %s, %s,
          SYSDATE(), NULL, %s, SYSDATE() )
        """
        vals = (job_name, task_name, task_status)
        curs.execute(sql, vals)
    else:
        sql = """
        UPDATE """ + log_db_name + """.ctl_task_status
        SET task_end_time = SYSDATE(),
          task_status = %s
        WHERE job_name = %s
        AND task_end_time IS NULL
        AND task_status = 'Started'
        """
        vals = (task_status, job_name)
        curs.execute(sql, vals)
    curs.close()
    conn.close()


def _nested_dict_merge(main, subset):
    """
    Merges subset into main using recursion. Modifies the main dictionary.
    :param main:
    :param subset:
    :return:
    """
    for key in subset:
        if key not in main:
            main[key] = subset[key]
        elif isinstance(main[key], dict) and isinstance(subset[key], dict):
            _nested_dict_merge(main[key], subset[key])
        else:
            main[key] = subset[key]


def get_config(event_name, base_param_filename=None):
    """
    Identifies the *.json files that should be read and then loads them into a dictionary object. When run by a
    developer, the function bootstraps itself by reading $HOME/event_params.json to determine the Common directory.
    Production users default this to /data/etl/Common.

    :return: A ConfigParser object
    """

    common_dir = "/data/etl/Common"
    if not prod_user():
        with open("{}/event_params.json".format(os.environ["HOME"]), "r") as cfg_fh:
            user_cfg = json.load(cfg_fh)
            if "dirs" in user_cfg and "common" in user_cfg["dirs"]:
                common_dir = os.path.expandvars(user_cfg["dirs"]["common"])

    cfg_files = []
    if base_param_filename:
        cfg_files.append(base_param_filename)
    else:
        cfg_files.append("{}/event_params.json".format(common_dir))

    if not prod_user():
        cfg_files.append("{}/event_params.json".format(os.environ["HOME"]))

    event_cfg = "{}/../Scripts/deserialize_event/{}/event_params.json".format(common_dir, event_name)
    if os.path.exists(event_cfg):
        cfg_files.append(event_cfg)

    cfg = dict()
    for cfg_file in cfg_files:
        logging.info("Reading configuration from {}".format(os.path.abspath(cfg_file)))
        with open(cfg_file, "r") as cfg_fh:
            this_cfg = json.load(cfg_fh)
            _nested_dict_merge(cfg, this_cfg)

    return cfg


def deserialize_protobuf(event_name, dest_system, nerdlake_table_name=None, start_date=None, end_date=None,
                         overwrite_output=None, base_param_filename=None):

    # Check the types of our parameters so calling routines don't try to pass strings instead of objects
    if start_date is not None and not isinstance(start_date, date):
        raise TypeError("Argument 'start_date' must be a Python date object")
    if end_date is not None and not isinstance(end_date, date):
        raise TypeError("Argument 'end_date' must be a Python date object")
    if overwrite_output is not None and not isinstance(overwrite_output, bool):
        raise TypeError("Argument 'overwrite_output' must be a Python True or False boolean value")

    logging.info("Begin deserialize_protobuf('{}', '{}', {}, {}, {}, {}, '{}')".format(
        event_name,
        dest_system,
        "None" if nerdlake_table_name is None else "'{}'".format(nerdlake_table_name),
        "None" if start_date          is None else "'{}'".format(start_date.strftime("%Y-%m-%d")),
        "None" if end_date            is None else "'{}'".format(end_date.strftime("%Y-%m-%d")),
        overwrite_output,
        base_param_filename))

    job_name = event_name
    if dest_system.lower() == "nerdlake":
        job_name += "_nerdlake"
    step_name = None

    log_processing_job(job_name, "Started")

    try:

        job_metrics = dict()
        job_metrics_params = dict()
        job_metrics_params["event_name"] = event_name
        job_metrics_params["dest_system"] = dest_system
        job_metrics_params["nerdlake_table_name"] = nerdlake_table_name
        job_metrics_params["start_date"] = None if start_date is None else start_date.strftime("%Y-%m-%d")
        job_metrics_params["end_date"] = None if end_date is None else end_date.strftime("%Y-%m-%d")
        job_metrics_params["overwrite_output"] = overwrite_output
        job_metrics_params["base_param_filename"] = base_param_filename
        job_metrics["params"] = job_metrics_params
        job_metrics["job_type"] = "PB2" + dest_system.upper()
        job_metrics["job_start_time"] = long(time.time() * 1000.0)
        job_metrics["platform_node"] = platform.node()
        job_metrics["python_version"] = platform.python_version()
        job_metrics["user_id"] = os.getuid()
        try:
            pwd_entry = pwd.getpwuid(os.getuid())
            job_metrics["user_name"] = pwd_entry[0]
        except KeyError:
            pass

        step_name = "Loading configuration file(s)"
        log_processing_step(job_name, step_name, "Started")

        # Load the configuration files
        cfg = get_config(event_name, base_param_filename)

        log_processing_step(job_name, step_name, "Completed")
        step_name = None

        # Load our job metadata.
        step_name = "Loading job metadata"
        log_processing_step(job_name, step_name, "Started")

        log_processing_step(job_name, step_name, "Completed")
        step_name = None

        step_name = "Setting variables"
        log_processing_step(job_name, step_name, "Started")

        # Set the start and end dates
        if start_date:
            start_date_source = "passed-in value"
        elif "dates" in cfg:
            if "start" in cfg["dates"] and cfg["dates"]["start"]:
                start_date = datetime.strptime(cfg["dates"]["start"], "%Y-%m-%d").date()
                start_date_source = "date from event_params.json"
            elif "start_offset" in cfg["dates"] and cfg["dates"]["start_offset"] is not None:
                start_date = date.today() + timedelta(int(cfg["dates"]["start_offset"]))
                start_date_source = "date offset from event_params.json"
        if not start_date:
            start_date = date.today() + timedelta(-2)
            start_date_source = "default"
        logging.info("Start Date:         {} ({})".format(start_date.strftime("%Y-%m-%d"), start_date_source))
        job_metrics["start_date"] = start_date.strftime("%Y-%m-%d")

        if end_date:
            end_date_source = "passed-in value"
        elif "dates" in cfg:
            if "end" in cfg["dates"] and cfg["dates"]["end"]:
                end_date = datetime.strptime(cfg["dates"]["end"], "%Y-%m-%d").date()
                end_date_source = "date from event_params.json"
            elif "end_offset" in cfg["dates"] and cfg["dates"]["end_offset"] is not None:
                end_date = date.today() + timedelta(int(cfg["dates"]["end_offset"]))
                end_date_source = "date offset from event_params.json"
        if not end_date:
            end_date = date.today() + timedelta(1)
            end_date_source = "default"
        logging.info("End Date:           {} ({})".format(end_date.strftime("%Y-%m-%d"), end_date_source))
        job_metrics["end_date"] = end_date.strftime("%Y-%m-%d")

        # Set the source and target S3 locations
        source_bucket = cfg["s3_buckets"]["protobuf"]
        source_aws_profile = cfg["s3_aws_profile"]["protobuf"] if pwd.getpwuid(os.getuid())[0] != "airflow" else None
        source_path = event_name
        if event_name == "ABLog":
            source_path = "ablogevent"
        if "s3_key_prefixes" in cfg and "protobuf" in cfg["s3_key_prefixes"] and cfg["s3_key_prefixes"]["protobuf"] is not None:
            source_path = os.path.expandvars(cfg["s3_key_prefixes"]["protobuf"]) + source_path

        logging.info("Source:             s3://{}/{} ({})".format(source_bucket, source_path, source_aws_profile))
        job_metrics["source"] = "s3://{}/{}".format(source_bucket, source_path)

        if dest_system.lower() == "redshift":
            dest_bucket = cfg["s3_buckets"]["jsondata"]
            dest_aws_profile = cfg["s3_aws_profile"]["jsondata"] if pwd.getpwuid(os.getuid())[0] != "airflow" else None
            dest_path = event_name
            if "s3_key_prefixes" in cfg and "jsondata" in cfg["s3_key_prefixes"] and cfg["s3_key_prefixes"]["jsondata"] is not None:
                dest_path = os.path.expandvars(cfg["s3_key_prefixes"]["jsondata"]) + dest_path
        elif dest_system.lower() == "nerdlake":
            dest_bucket = cfg["s3_buckets"]["nerdlake"]
            dest_aws_profile = cfg["s3_aws_profile"]["nerdlake"] if pwd.getpwuid(os.getuid())[0] != "airflow" else None
            dest_path = "{}/{}_s".format(
                os.path.expandvars(cfg["nerdlake"]["stage_db"]), event_name)
        else:
            raise ValueError("Destination system '{}' is not valid".format(dest_system))

        logging.info("Destination:        s3://{}/{} ({})".format(dest_bucket, dest_path, dest_aws_profile))
        job_metrics["destination"] = "s3://{}/{}".format(dest_bucket, dest_path)

        # Clean up the NerdLake staging table name and add the database name if it's not already set.
        if dest_system.lower() == "nerdlake":
            if not nerdlake_table_name:
                nerdlake_table_name = event_name.lower() + "_s"
            if "." not in nerdlake_table_name:
                nerdlake_table_name = "{}.{}".format(
                        os.path.expandvars(cfg["nerdlake"]["stage_db"]),
                        nerdlake_table_name)
            job_metrics["nerdlake_table_name"] = nerdlake_table_name
            logging.info("NerdLake Table:     {}".format(nerdlake_table_name))

        log_processing_step(job_name, step_name, "Completed")
        step_name = None

        step_name = "Loading enhancement script"
        log_processing_step(job_name, step_name, "Started")

        # Find the event-specific Python script, if any, and its associated enhancement functions and overrides
        enhancement_script = "{0}/deserialize_event/{1}/pythonscripts/{1}.py".format(os.path.expandvars(cfg["dirs"]["script"]), event_name)
        enhancement_function = enhancement_overrides = enhancement_custom_fields = None
        if not os.path.exists(enhancement_script):
            enhancement_script = None
        else:
            logging.info("Enhancement Script: {}".format(enhancement_script))
            job_metrics["enhancement_script"] = enhancement_script
            try:
                event_mod = imp.load_source(event_name, enhancement_script)
            except Exception as e:
                logging.critical("Exception loading '{}': {}".format(enhancement_script, e))
                raise Exception("Exception loading '{}': {}".format(enhancement_script, e))
            if "customize_dict" in dir(event_mod):
                enhancement_function = event_mod.customize_dict
            if "overrides" in dir(event_mod):
                enhancement_overrides = event_mod.overrides
            if "custom_fields" in dir(event_mod):
                enhancement_custom_fields = event_mod.custom_fields

        log_processing_step(job_name, step_name, "Completed")
        step_name = None

        step_name = "Purging data directories"
        log_processing_step(job_name, step_name, "Started")

        # Purge our local staging directories
        local_input_path = "{}/{}/input".format(os.path.expandvars(cfg["dirs"]["data"]), event_name)
        local_output_path = "{}/{}/output".format(os.path.expandvars(cfg["dirs"]["data"]), event_name)
        local_archive_path = "{}/{}/archive".format(os.path.expandvars(cfg["dirs"]["data"]), event_name)
        logging.info("Input Path:         {}".format(local_input_path))
        logging.info("Output Path:        {}".format(local_output_path))
        logging.info("Archive Path:       {}".format(local_archive_path))
        logging.info("Cleaning data directories {}/{}/*".format(os.path.expandvars(cfg["dirs"]["data"]), event_name))
        for local_path in [local_input_path, local_output_path, local_archive_path]:
            if not os.path.exists(local_path):
                continue
            for dir_path, dir_names, file_names in os.walk(local_path, topdown=False):
                for file_name in file_names:
                    logging.debug("Removing {}".format(os.path.join(dir_path, file_name)))
                    os.remove(os.path.join(dir_path, file_name))

        log_processing_step(job_name, step_name, "Completed")
        step_name = None

        step_name = "Converting and enhancing protobuf files and loading into {}-bound S3".format(dest_system)
        log_processing_step(job_name, step_name, "Started")

        logging.info("Converting ProtoBuf files into {}-bound S3".format(dest_system))
        file_metrics = Emit_protobuf_enhanced(
                pb_class_nm=event_name,
                src_bucket=source_bucket,
                src_aws_profile=source_aws_profile,
                src_path=source_path,
                start_date=start_date.strftime("%Y-%m-%d"),
                end_date=end_date.strftime("%Y-%m-%d"),
                local_input_path=local_input_path,
                local_output_path=local_output_path,
                dst_bucket=dest_bucket,
                dst_aws_profile=dest_aws_profile,
                dst_path=dest_path,
                dst_system=dest_system,
                ovrd_flag="True" if overwrite_output else "False",
                enhancement_function=enhancement_function,
                schema_list=enhancement_custom_fields,
                custom_overrides=enhancement_overrides,
                pymodulename=enhancement_script,
                compression="None",
                tablename=nerdlake_table_name
                )
        job_metrics["file_details"] = file_metrics
        logging.info("Conversion complete")
        job_metrics["job_end_time"] = long(time.time() * 1000.0)
        job_metrics["success"] = True

        log_processing_step(job_name, step_name, "Completed")
        step_name = None

        if "log" in cfg["dirs"] and cfg["dirs"]["log"]:
            step_name = "Writing statistics *.json file".format(dest_system)
            log_processing_step(job_name, step_name, "Started")

            # Write the statistics to a JSON file. If the destination is S3, we will then upload the file to S3
            # and delete the local file.
            write_job_metrics(os.path.expandvars(cfg["dirs"]["log"]), job_metrics)

            log_processing_step(job_name, step_name, "Completed")
            step_name = None

        logging.info("End deserialize_protobuf()")
        log_processing_job(job_name, "Completed")

    except Exception:
        # noinspection PyBroadException
        try:
            if job_name:
                if step_name:
                    log_processing_step(job_name, step_name, "Failed")
                log_processing_job(job_name, "Failed")
        except Exception:
            pass
        raise


def write_job_metrics(log_dest, metrics):
    """
    Write job metrics to a JSON file and upload it to S3 if appropriate.
    :param log_dest: Location to write the log file. Can be a directory on the local file system or an S3 location,
    formatted s3://bucket/path.
    :param metrics: Dictionary containing job metrics
    """
    send_to_s3 = False
    if log_dest[0:5].lower() == "s3://":
        send_to_s3 = True
        local_dir = "/tmp"
    else:
        local_dir = log_dest

    log_time = datetime.utcnow()
    log_time_epochms = long((log_time - datetime.utcfromtimestamp(0)).total_seconds() * 1000.0)
    logfile = tempfile.NamedTemporaryFile(
        prefix="pb2dwh_{}_".format(log_time_epochms),
        suffix=".json",
        dir=local_dir,
        delete=False)
    json.dump(metrics, logfile)
    logfile.close()
    os.chmod(logfile.name, 0o644)  # -rw-r--r--

    if send_to_s3:
        log_s3_bucket, log_s3_key_prefix = log_dest[5:].split("/", 1)
        log_s3_key_prefix = "{}/dw_eff_dt={}".format(
            log_s3_key_prefix.rstrip("/"),
            log_time.strftime("%Y-%m-%d")
        )
        log_s3_key_name = "event_deserialize_{}_{}.json".format(log_time_epochms, metrics["params"]["event_name"])
        s3_modules.s3_file_upload(logfile.name, log_s3_bucket, log_s3_key_prefix, log_s3_key_name)
        os.remove(logfile.name)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Deserialize ProtoBuf files into the desired format")
    parser.add_argument("event_name", help="Name of the event to deserialize")
    parser.add_argument("dest_system", help="Name of the destination system: redshift or nerdlake")
    parser.add_argument("start_date", nargs="?", help="Date to start processing on")
    parser.add_argument("end_date", nargs="?", help="Date to stop processing on")
    parser.add_argument("overwrite", nargs="?", help="True or False, indicating if S3 files should be overwritten")
    parser.add_argument("--base-param-file", help="Parameter file to use instead of the standard event_params.json")

    args = parser.parse_args()

    param_start_date = None
    if args.start_date:
        param_start_date = datetime.strptime(args.start_date, "%Y-%m-%d").date()

    param_end_date = None
    if args.end_date:
        param_end_date = datetime.strptime(args.end_date, "%Y-%m-%d").date()

    overwrite_output = False
    if args.overwrite:
        if args.overwrite.lower() in ['true', 't', 'yes', '1']:
            overwrite_output = True

    # Calling logging.basicConfig() should only have an effect if Python logging hasn't already been initialized
    # elsewhere. If this is called from Airflow using the PythonOperator, then this shouldn't do anything.
    logging_format = "[%(levelname)-8s] %(message)s"
    if pwd.getpwuid(os.getuid())[0] != "airflow":
        logging_format = "[%(asctime)s] " + logging_format
    logging.basicConfig(format=logging_format, level=logging.INFO)

    deserialize_protobuf(
        event_name=args.event_name,
        dest_system=args.dest_system,
        start_date=param_start_date,
        end_date=param_end_date,
        overwrite_output=overwrite_output,
        base_param_filename=args.base_param_file)
