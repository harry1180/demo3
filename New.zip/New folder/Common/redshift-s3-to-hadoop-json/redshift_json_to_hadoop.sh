#######################################
# Example Usage:
# ./redshift_json_to_hadoop.sh 2016 06 01
# Or to get the last two days use no parameters
# ./redshift_json_to_hadoop.sh
#######################################

startScript=`date +%s`
job_name='redshift_json_to_hadoop_json'
trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'

abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

#######################################
#Main Script
#######################################

	destination_bucket="s3://east1-stage-dwh-0-hdfs/"
	source_bucket="s3://east1-prod-dwh-s3-0/"	
#echo $1

if [ -z $1 ] ; then
	
	Processing_Step="Setting automatic dates ranges to process"
	echo "______________"$Processing_Step"______________"
	todaysyear=`date +%Y`
	todaysmonth=`date +%m`
	todaysday=`date +%d`

	yesterdaysyear=`date -v -1d +%Y`
	yesterdaysmonth=`date -v -1d +%m`
	yesterdaysday=`date -v -1d +%d`

	twodaysagoyear=`date -v -2d +%Y`
	twodaysagomonth=`date -v -2d +%m`
	twodaysagosday=`date -v -2d +%d`

	includetoday="*archive/$todaysyear/$todaysmonth/$todaysday/*.json"
	includeyesterday="*archive/$yesterdaysyear/$yesterdaysmonth/$yesterdaysday/*.json"
	includetwodaysago="*archive/$twodaysagoyear/$twodaysagomonth/$twodaysagoday/*.json"
else
	todaysyear=$1
	todaysmonth=$2
	todaysday=$3

	includetoday="*archive/$todaysyear/$todaysmonth/$todaysday/*.json"
	includeyesterday="*.none"
	includetwodaysago="*.none2"
fi
	

if [ -z $source_bucket ]; then
	Processing_Step="No source bucket found in variables"
	echo "______________"$Processing_Step"______________"
	source_bucket="s3://east1-prod-dwh-s3-0/"
fi

if [ -z $destination_bucket ]; then
	Processing_Step="No destination bucket found in variables"
	echo "______________"$Processing_Step"______________"
	destination_bucket="s3://east1-prod-dwh-hdfs/"
fi
rm -rf ./data || true
mkdir data
cd data

Processing_Step="Pulling last three days of data from s3"
echo "______________"$Processing_Step"______________"

aws s3 cp $source_bucket ./ --exclude '*' --exclude "*.gz" --include "$includetoday"  --include "$includeyesterday"  --include "$includetwodaysago" --exclude "*.gz" --exclude "*.xml" --recursive

Processing_Step="Removing hadoop files if they exist"
echo "______________"$Processing_Step"______________"

find . -type f -name '*hadoop*' -delete || true
find . -name "archive" -execdir bash -c 'mv {} hadoop' \; || true

Processing_Step="Moving archive folder to hadoop"
echo "______________"$Processing_Step"______________"

find . -name \*.json -print > ./modify.txt
Processing_Step="Get all json file name to parse"
echo "______________"$Processing_Step"______________"


while read line;
do
echo $line
stringFind=".json"
stringReplace="_hadoop.json"
newoutputfile=${line/%$stringFind/$stringReplace}
echo $newoutputfile
tr -d '\n\r' <  $line | sed "s/}{/}\\$(echo -e '\r'){/g" > $newoutputfile

Processing_Step="Replacing current json file $line with hadoop ready verion $newoutputfile"
echo "______________"$Processing_Step"______________"

mv $newoutputfile $line
done < modify.txt
rm ./modify.txt

Processing_Step="Uploading new hadoop files to s3"
echo "______________"$Processing_Step"______________"

aws s3 cp . $destination_bucket --recursive --exclude "*" --include "*/hadoop/*.json"

cd ..
rm -rf ./data

endScript=`date +%s`

runtimeScript=$((endScript-startScript))


trap : 0
echo >&2 '
***************************************
*** '$job_name' LOAD COMPLETED in '$runtimeScript' ***
***************************************
'




