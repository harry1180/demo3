import logging
import nw_hive
import sys

logger = logging.getLogger('nerdwallet.dwh.exchange_partitions')
logging.basicConfig(format='[%(levelname)s]:%(message)s', level=logging.INFO)
logger = logging.getLogger('pyhive')
logger.setLevel(logging.WARN)


def main(param_dict):
    conn = nw_hive.connect()
    full_hive_src_table_name = "{sourcedb}.{source_table}".format(**param_dict)
    full_hive_tgt_table_name = "{targetdb}.{target_table}".format(**param_dict)

    nw_hive.msck_repair_table(conn, full_hive_tgt_table_name)
    nw_hive.exchange_all_partitions(conn, full_hive_src_table_name, full_hive_tgt_table_name, delete_partition=True)
    return

if __name__ == '__main__':
    param_dict = dict()

    if len(sys.argv) != 5:
        logging.error('Incorrect number of arguments passed. Please provide the following:\n 1. sourcedb\n 2. source_table\n 3. targetdb\n 4. target_table')
        logging.error('Exiting script')
        sys.exit(1)
    else:
        param_dict['sourcedb'] = sys.argv[1]
        param_dict['source_table'] = sys.argv[2]
        param_dict['targetdb'] = sys.argv[3]
        param_dict['target_table'] = sys.argv[4]
        logging.info('Input Parameters {}'.format(param_dict))
        main(param_dict)
