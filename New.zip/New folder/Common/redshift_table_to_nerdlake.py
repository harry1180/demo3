#!/usr/bin/env python

import argparse
import logging
import os
import pwd
import sys
import tempfile
import time
from urlparse import urlparse

import boto3
import psycopg2

import nw_hive
import nw_presto
import nw_pyarrow
import redshift_modules


def postgres_table_to_parquet_file(fq_table_name, columns, parquet_filename, table_filter=None):
    """
    Extracts data from a PostgreSQL table and writes it to a Parquet file.

    :param fq_table_name: Fully qualified table name.
    :param columns: List of columns in the table, stored as a list of dictionaries.
    :param parquet_filename: Output Parquet file name.
    :param table_filter: Optional filter (WHERE clause) to be applied to the table.
    :return:
    """

    # If the Parquet filename is an S3 URL, use a local file to write the data into.
    local_filename = parquet_filename
    if parquet_filename.lower().startswith('s3://'):
        local_file = tempfile.NamedTemporaryFile(
            dir=os.environ.get('Linux_Output', '/tmp'),
            prefix='postgres_to_nerdlake_',
            suffix='.pq',
            delete=True
        )
        local_filename = local_file.name
        local_file.close()

    logging.info('Writing data to ' + local_filename)

    conn = redshift_modules.redshift_connect(autocommit=False)

    select_sql = redshift_modules.get_select_sql(
        fq_table_name=fq_table_name,
        columns=columns,
        table_filter=table_filter,
        translate_tsv_breaking_characters=False)

    # Open a server-side cursor to reduce memory usage
    logging.info(select_sql)
    with conn.cursor(name='copy_to_parquet_' + fq_table_name) as curs:
        curs.arraysize = 2000
        psycopg2.extensions.register_type(psycopg2.extensions.UNICODE, curs)  # Not needed in Python 3
        logging.info('Executing SQL using server-side cursor')
        curs.execute(select_sql)
        nw_pyarrow.cursor_to_parquet_file(curs, columns, local_filename)

    conn.close()

    if parquet_filename.lower().startswith('s3://'):
        print('Copying {} to {}'.format(local_filename, parquet_filename))
        s3_url = urlparse(parquet_filename)
        s3 = boto3.resource('s3')
        s3.Bucket(s3_url.netloc).upload_file(local_filename, s3_url.path[1:])
        os.remove(local_filename)


def get_hive_raw_ddl(hive_fq_table_name, columns, s3_bucket, storage_clause, source_fq_table_name=None,
                     table_properties=None):
    """
    :param hive_fq_table_name: Fully qualified Hive table name.
    :param columns: List of Postgres columns
    :param source_fq_table_name: Fully qualified Postgres table name, used only for documentation purposes.
    :param s3_bucket: S3 bucket that the Hive table's data is on.
    :param storage_clause: Hive table storage clause
    :param table_properties: Optional dictionary containing list of Hive table properties
    :return: SQL containing a 'CREATE EXTERNAL TABLE' statement.
    """
    hive_cols = list()
    for column in columns:
        quoted_column_name = column['name']
        if column['name'].upper() in nw_hive.reserved_words:
            quoted_column_name = '`{}`'.format(column['name'])

        if column['type'] in ('character', 'character varying'):
            hive_type = 'string'
        elif column['type'] == 'timestamp without time zone':
            hive_type = 'timestamp'
        elif column['type'] == 'numeric':
            hive_type = 'decimal({},{})'.format(column['precision'], column.get('scale', 0))
        else:
            hive_type = column['type']

        if 'description' in column:
            hive_type += '\n        COMMENT \'{}\''.format(column['description'].replace("'", "''"))

        hive_cols.append('{col_name:<32}    {type}'.format(col_name=quoted_column_name, type=hive_type))

    hive_cols.append('extract_ts timestamp\n        COMMENT \'Timestamp when the data was extracted from Redshift\'')

    sql = 'CREATE EXTERNAL TABLE {} (\n'.format(hive_fq_table_name)
    sql += '    ' + ',\n    '.join(hive_cols)
    sql += '\n)\n'
    sql += storage_clause + '\n'
    sql += 'LOCATION \'s3://{bucket}/{schema}/{table_name}\''.format(
        bucket=s3_bucket,
        schema=hive_fq_table_name.split('.', 1)[0],
        table_name=hive_fq_table_name.split('.', 1)[1],
    )
    props = dict()
    if source_fq_table_name:
        props['comment'] = 'Copied from {}'.format(source_fq_table_name)
    if table_properties:
        props.update(table_properties)
    if props:
        sql += '\nTBLPROPERTIES (\n'
        for i, prop_name in enumerate(sorted(props.keys())):
            if i > 0:
                sql += ',\n'
            sql += '    \'{prop_name}\' = \'{prop_val}\''.format(
                prop_name=prop_name,
                prop_val=props[prop_name].replace("'", "''"))
        sql += '\n)'
    return sql


def get_hive_native_ddl(hive_fq_table_name, columns, s3_bucket, hive_file_format='ORC', source_table_name=None):
    """

    :param hive_fq_table_name: Fully qualified Hive table name
    :param columns: Columns for the new table, stored as a list of dictionaries
    :param s3_bucket: S3 bucket that the data for the new table will be stored on.
    :param hive_file_format: File format that the data for the table should be stored in, defaults to 'ORC'
    :param source_table_name: Source table name which is stored as a comment on the table.
    :return:
    """
    hive_cols = list()
    for column in columns:
        if column['name'].lower() == 'dw_load_ts':
            continue
        quoted_column_name = column['name']
        if column['name'].upper() in nw_hive.reserved_words:
            quoted_column_name = '`{}`'.format(column['name'])

        if column['type'] in ('character', 'character varying'):
            hive_type = 'string'
        elif column['type'] == 'timestamp without time zone':
            hive_type = 'timestamp'
        else:
            hive_type = column['type']

        hive_cols.append(quoted_column_name + ' ' + hive_type)

    hive_cols.append('extract_ts timestamp')
    hive_cols.append('dw_load_ts timestamp')

    sql = 'CREATE TABLE {} (\n'.format(hive_fq_table_name)
    sql += '    ' + ',\n    '.join(hive_cols)
    sql += '\n)\n'
    sql += 'STORED AS {}\n'.format(hive_file_format)
    sql += 'LOCATION \'s3://{bucket}/{schema}/{table_name}\''.format(
        bucket=s3_bucket,
        schema=hive_fq_table_name.split('.', 1)[0],
        table_name=hive_fq_table_name.split('.', 1)[1],
    )
    if source_table_name:
        sql += '\nTBLPROPERTIES ("comment" = "Copied from table {}" )'.format(source_table_name)
    return sql


def get_hive_text_native_copy_sql(hive_text_fq_table_name, columns, hive_native_fq_table_name, delimiter=u'\t'):
    """
    Builds a Presto INSERT statement that copies TSV data to a Hive table, decoding Unicode control picture characters.

    :param hive_text_fq_table_name: Fully qualified Hive table name whose data is stored in TSV format.
    :param columns: List of columns in the Hive table stored as a list of dictionaries.
    :param hive_native_fq_table_name: Fully qualified Hive table name that the decoded data will be inserted into.
    :return:
    """
    insert_fields = list()
    select_fields = list()
    for column in columns:
        # Don't copy the original table's DW_LOAD_TS data into the new table
        if column['name'].lower() == 'dw_load_ts':
            continue
        quoted_col_name = column['name']
        if column['name'].upper() in nw_presto.reserved_words:
            quoted_col_name = u'"{}"'.format(column['name'])
        insert_fields.append(quoted_col_name)

        if column['type'] in ('character', 'character varying'):
            field_sql = u"REPLACE({}, '\u2400', CHR(0))".format(quoted_col_name)
            replacements = {
                u'\u240a': u'CHR(10)',
                u'\u240d': u'CHR(13)',
            }
            if delimiter == u'\t':
                replacements[u'\u2409'] = u'CHR(9)'
            elif delimiter == u'|':
                replacements[u'\u00a6'] = u"'|'"
            elif delimiter == u',':
                replacements[u'\ufe50'] = u"','"
            for replacement_from, replacement_to in replacements.items():
                field_sql = u"REPLACE({}, '{}', {})".format(field_sql, replacement_from, replacement_to)
            field_sql = u"{} as {}".format(field_sql, quoted_col_name)
            select_fields.append(field_sql)
        else:
            select_fields.append(quoted_col_name)

    insert_fields.append(u'extract_ts')
    select_fields.append(u'extract_ts')
    insert_fields.append(u'dw_load_ts')
    select_fields.append(u'CAST(CURRENT_TIMESTAMP AT TIME ZONE \'UTC\' AS TIMESTAMP) AS dw_load_ts')

    sql = u'INSERT INTO hive.{} (\n'.format(hive_native_fq_table_name)
    sql += u'    ' + ',\n    '.join(insert_fields)
    sql += u'\n)\n'
    sql += u'SELECT\n'
    sql += u'    ' + ',\n    '.join(select_fields)
    sql += u'\nFROM hive.{}'.format(hive_text_fq_table_name)
    return sql


def main(redshift_fq_table_name, redshift_table_filter, redshift_s3_creds, s3_bucket, hive_raw_fq_table_name,
         redshift_export_type='TSV', hive_decoded_fq_table_name=None, purge_target_s3=True,
         hive_decoded_file_format='ORC'):
    redshift_conn = redshift_modules.redshift_connect()
    redshift_cols = redshift_modules.get_table_columns(redshift_conn, redshift_fq_table_name)

    if purge_target_s3:
        logging.info('Removing files from s3://{}/{}/'.format(s3_bucket, hive_raw_fq_table_name.replace('.', '/')))
        s3 = boto3.resource('s3')
        bucket = s3.Bucket(s3_bucket)
        s3_prefix = '{}/'.format(hive_raw_fq_table_name.replace('.', '/'))
        for obj in bucket.objects.filter(Prefix=s3_prefix):
            logging.info('    ' + obj.key)
            if '/' in obj.key[len(s3_prefix):]:
                logging.critical('S3 key to be deleted looks like it\'s in a subdirectory of the target directory')
                sys.exit(1)
            obj.delete()

    if redshift_export_type == 'TSV':
        # Unload the Redshift table. This will fail if there are already files in the destination
        tsv_select_sql = redshift_modules.get_select_sql(
            fq_table_name=redshift_fq_table_name,
            columns=redshift_cols,
            table_filter=redshift_table_filter,
            translate_tsv_breaking_characters=True)

        unload_sql = redshift_modules.get_tsv_unload_sql(
            select_sql=tsv_select_sql,
            s3_bucket=s3_bucket,
            s3_key_path=hive_raw_fq_table_name.replace('.', '/')
        )
        logging.info(unload_sql)
        with redshift_conn.cursor() as curs:
            try:
                curs.execute(curs.mogrify(unload_sql, [redshift_s3_creds]))
            except psycopg2.Error as ex:
                if ex.diag.severity in ['ERROR', 'FATAL', 'PANIC']:
                    logging.error(u'UNLOAD failure: [{}] {}'.format(ex.pgcode, ex.diag.message_primary))
                    sys.exit(1)

                if ex.diag.severity == 'WARNING':
                    logging.warning(u'UNLOAD warning: [{}] {}'.format(ex.pgcode, ex.diag.message_primary))
                else:
                    logging.info(u'UNLOAD warning: [{}] {}'.format(ex.pgcode, ex.diag.message_primary))
        for notice in redshift_conn.notices:
            logging.info(notice.rstrip())
    elif redshift_export_type == 'PARQUET':
        # Export the Redshift table to Parquet
        s3_output = 's3://{bucket}/{schema}/{table_name}/{file_name}'.format(
            bucket=s3_bucket,
            schema=hive_raw_fq_table_name.split('.', 1)[0],
            table_name=hive_raw_fq_table_name.split('.', 1)[1],
            file_name=redshift_fq_table_name + '.parquet')
        postgres_table_to_parquet_file(
            fq_table_name=redshift_fq_table_name,
            columns=redshift_cols,
            table_filter=redshift_table_filter,
            parquet_filename=s3_output)
    else:
        raise ValueError('Export type \'{}\'must be TSV or PARQUET'.format(redshift_export_type))

    redshift_conn.close()

    # Create the hive external table used to access the exported data
    hive_conn = nw_hive.connect()

    if redshift_export_type == 'TSV':
        hive_ddl = get_hive_raw_ddl(
            hive_fq_table_name=hive_raw_fq_table_name,
            columns=redshift_cols,
            s3_bucket=s3_bucket,
            storage_clause='ROW FORMAT DELIMITED FIELDS TERMINATED BY \'\\t\'',
            source_fq_table_name=redshift_fq_table_name,
            table_properties={'serialization.null.format': ''})
    elif redshift_export_type == 'PARQUET':
        hive_ddl = get_hive_raw_ddl(
            hive_fq_table_name=hive_raw_fq_table_name,
            columns=redshift_cols,
            s3_bucket=s3_bucket,
            storage_clause='STORED AS PARQUET',
            source_fq_table_name=redshift_fq_table_name)
    else:
        raise ValueError('export type \'{}\' not recognized'.format(redshift_export_type))

    for sql in ['DROP TABLE ' + hive_raw_fq_table_name, hive_ddl]:
        nw_hive.exec_hive_sql_ddl(hive_conn, sql)

    # Create the hive "native" table which contains the decoded control characters and is stored in ORC, Parquet, or
    # some other native Hadoop file format.
    if redshift_export_type == 'TSV' and hive_decoded_fq_table_name:
        # Purge the target S3 folder
        if purge_target_s3:
            logging.info('Removing files from s3://{}/{}/'.format(s3_bucket,
                                                                  hive_decoded_fq_table_name.replace('.', '/')))
            s3 = boto3.resource('s3')
            bucket = s3.Bucket(s3_bucket)
            s3_prefix = '{}/'.format(hive_decoded_fq_table_name.replace('.', '/'))
            for obj in bucket.objects.filter(Prefix=s3_prefix):
                logging.info('    ' + obj.key)
                if '/' in obj.key[len(s3_prefix):]:
                    logging.critical('S3 key to be deleted looks like it\'s in a subdirectory of the target directory')
                    sys.exit(1)
                obj.delete()

        # Create the Hive native table
        hive_ddl = get_hive_native_ddl(
            hive_fq_table_name=hive_decoded_fq_table_name,
            columns=redshift_cols,
            s3_bucket=s3_bucket,
            hive_file_format=hive_decoded_file_format,
            source_table_name=redshift_fq_table_name)
        curs = hive_conn.cursor()
        for sql in ['DROP TABLE ' + format(hive_decoded_fq_table_name), hive_ddl]:
            logging.info(sql)
            curs.execute(sql)
        curs.close()

        # Copy the data over
        copy_sql = get_hive_text_native_copy_sql(
            columns=redshift_cols,
            hive_text_fq_table_name=hive_raw_fq_table_name,
            hive_native_fq_table_name=hive_decoded_fq_table_name)
        logging.info(copy_sql)
        presto_conn = nw_presto.connect()
        curs = presto_conn.cursor()
        curs.execute(copy_sql)
        status = curs.poll()
        insert_status = status['stats']['state']
        logging.info('INSERT status: {}'.format(insert_status))
        while insert_status == 'RUNNING':
            time.sleep(1)
            status = curs.poll()
            if insert_status != status['stats']['state']:
                insert_status = status['stats']['state']
                logging.info('INSERT status: {}'.format(insert_status))
        curs.close()
        presto_conn.close()

        if insert_status != 'FINISHED':
            raise RuntimeError('Failed to insert data into decoded Hive table')

        hive_conn.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--redshift-table', required=True, help='Redshift table to copy to Hive')
    parser.add_argument('--redshift-table-filter', required=False,
                        help='WHERE clause to be applied to the source table when unloading it from Redshift')
    parser.add_argument('--redshift-export-format', required=False, default='TSV',
                        help='Format of the file exported from Redshift: TSV or PARQUET')
    parser.add_argument('--hive-table', required=True, dest='hive_tsv_table',
                        help='Hive table to copy the Redshift data to, in TSV format. Control characters 0x00, [TAB],' +
                             ' [CR], and [LF] are translated to their Unicode control picture equivalents. This ' +
                             'table is dropped and re-created if it already exists.')
    parser.add_argument('--decoded-hive-table', required=False,  dest='hive_native_table',
                        help='Hive table to decode the TSV data into. Unicode control picture characters are ' +
                             'translated back into their original control characters. The decoded table is stored ' +
                             'in ORC format by default; see --decoded-hive-table-format.')
    parser.add_argument('--decoded-hive-file-format', required=False, default='ORC',
                        help='File format of the decided Hive table, defaults to \'ORC\'.')
    parser.add_argument('--s3-bucket', default='east1-prod-nerdlake-0',
                        help='Name of the S3 bucket that the data should be written to')
    parser.add_argument('--creds-environment-variable', required=False,
                        help='Name of the environment variable that contains the Redshift S3 credentials')
    args = parser.parse_args()

    logging_format = '[%(levelname)-8s] %(name)s - %(message)s'
    if pwd.getpwuid(os.geteuid()).pw_name != 'airflow':
        logging_format = '%(asctime)s ' + logging_format

    logging.basicConfig(format=logging_format, level=logging.INFO)
    for logger_to_set_to_warn in ('botocore', 'pyhive'):
        logger = logging.getLogger(logger_to_set_to_warn)
        logger.setLevel(logging.WARN)

    logging.info('Execution begins')

    # Build a list of the allowed schema suffixes for the current user
    if pwd.getpwuid(os.getuid()).pw_name == 'airflow':
        allowed_schema_suffixes = {'_stage'}
    else:
        allowed_schema_suffixes = {'_workarea'}

    # Make sure the TSV output is going into a valid schema
    hive_tsv_schema = args.hive_tsv_table.split('.', 1)[0].lower()
    allowed_schema = False
    for allowed_schema_suffix in allowed_schema_suffixes:
        if hive_tsv_schema.endswith(allowed_schema_suffix):
            allowed_schema = True

    if not allowed_schema:
        logging.error('{}: Hive schema does not end in one of the following: {}'.format(
            args.hive_tsv_table,
            ', '.join(sorted(allowed_schema_suffixes))))
        sys.exit(1)

    # Make sure the native Hive output (if any) is going into a valid schema
    if args.hive_native_table:
        hive_native_schema = args.hive_native_table.split('.', 1)[0].lower()
        allowed_schema = False
        for allowed_schema_suffix in allowed_schema_suffixes:
            if hive_native_schema.endswith(allowed_schema_suffix):
                allowed_schema = True

        if not allowed_schema:
            logging.error('{}: Hive schema does not end in one of the following: {}'.format(
                args.hive_native_table,
                ', '.join(sorted(allowed_schema_suffixes))))
            sys.exit(1)

    main(
        redshift_export_type=args.redshift_export_format.upper(),
        redshift_fq_table_name=args.redshift_table,
        redshift_table_filter=args.redshift_table_filter,
        redshift_s3_creds=os.environ.get(args.creds_environment_variable),
        s3_bucket=args.s3_bucket,
        hive_raw_fq_table_name=args.hive_tsv_table,
        hive_decoded_fq_table_name=args.hive_native_table,
        hive_decoded_file_format=args.decoded_hive_file_format,
    )

    logging.info('Execution ends')
