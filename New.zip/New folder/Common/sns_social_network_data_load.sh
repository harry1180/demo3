echo '##############################'
echo '####### Unloading URLs #######'
echo '##############################'

/bin/bash /data/etl/Scripts/sns_unload_url/shellscripts/sns_unload_url.sh

echo '##############################'
echo '### Unloading URLs Complete ##'
echo '##############################'


echo '##############################'
echo '###### Loading FB Data #######'
echo '##############################'


/bin/bash /data/etl/Scripts/sns_facebook/shellscripts/sns_facebook.sh "D"


echo '##############################'
echo '## Loading FB Data Complete ##'
echo '##############################'


echo '##############################'
echo '###### Loading TW Data #######'
echo '##############################'

/bin/bash /data/etl/Scripts/sns_twitter/shellscripts/sns_twitter.sh "D"

echo '##############################'
echo '## Loading TW Data Complete ##'
echo '##############################'


echo '##############################'
echo '###### Loading LN Data #######'
echo '##############################'

/bin/bash /data/etl/Scripts/sns_linkedin/shellscripts/sns_linkedin.sh "D"

echo '##############################'
echo '## Loading LN Data Complete ##'
echo '##############################'

