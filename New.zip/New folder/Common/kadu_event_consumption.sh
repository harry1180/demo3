#!/bin/bash
set -e

source set_dwh_env_variables.sh
export PYTHONPATH=$PYTHONPATH:/data/etl/Common/nw_python_modules

if [ $# -lt 3 ]
then
    echo 'Usage: kadu_event_consumption.sh <Topic> <Environment> <s3_key_format>'
    exit 1
fi

topic="$1"
environment="$2"
s3_key_format="$3"
Linux_Output=${dwh_data_base_dir}/kadu_${environment}_${topic}/output/

# Make sure Linux_Output exists
if [ ! -d ${Linux_Output} ];
then
    echo "Directory doesnt exists creating "${Linux_Output}
    mkdir -p ${Linux_Output}
    chmod -R 777 ${Linux_Output}
else
    echo "Structure already exists for "${Linux_Output}
fi  
export Linux_Output

# On failure make sure all files cleared from Linux_Output
abort() {
    echo '**************************************'
    echo '***    ERROR CODE KADU ABORTED     ***'
    echo '**************************************'
    echo 'Removing kadu output from '${Linux_Output}
    ls -ls ${Linux_Output}
    rm -f ${Linux_Output}*
    echo 'Files successfully removed from '${Linux_Output}
    exit 1
}
trap abort err

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

if [ ${environment} = "prod" ]
then
    s3_bucket=nw-event-data-prod
    kafka_servers=kafka10-1:6667,kafka10-2:6667,kafka10-3:6667
    dynamo_environment=prodenv
    if [ $(id -un) != "airflow" ]
    then
        aws_profile="--aws_profile nwprod"
    fi
elif [ ${environment} = "stage" ]
then
    s3_bucket=nw-event-data-stage
    kafka_servers=kafka10-1:6667,kafka10-2:6667,kafka10-3:6667
    dynamo_environment=stageenv
    if [ $(id -un) != "airflow" ]
    then
        aws_profile="--aws_profile nwdev"
    fi
else
    echo 'Environment must be of value stage, prod, or kafka10test'
    exit 1
fi

declare -A json_topics
json_topics[ablogevent_plain]=1
json_topics[ApiResponseEvent]=1
json_topics[BackendModelExecutionEvent]=1
json_topics[CLOUserTokenRequestEvent]=1
json_topics[minusworld]=1
json_topics[shadowrealm]=1
if [ ${json_topics[${topic}]} ]
then
    protocol=json
else
    protocol=pbuf
fi

echo "topic               :- $topic"
echo "s3_bucket           :- $s3_bucket"
echo "kafka_servers       :- $kafka_servers"
echo "protocol            :- $protocol"
echo "environment         :- $environment"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+-----Running kadu----+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

python ${dwh_common_base_dir}/kadu.py --topic ${topic} --protocol ${protocol} --s3_bucket ${s3_bucket} \
                                      --kafka_servers ${kafka_servers} --s3_key_format ${s3_key_format} \
                                      --dynamo_environment ${dynamo_environment} ${aws_profile} --save

echo 'Removing kadu output from '${Linux_Output}
ls -ls ${Linux_Output}
rm -f ${Linux_Output}* 
echo 'Files successfully removed from '${Linux_Output}
