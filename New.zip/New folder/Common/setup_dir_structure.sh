source set_dwh_env_variables.sh

directory_name=$1

#Settingup Data Directory Structure if not exists
data_dir=${dwh_data_base_dir}/${directory_name}
data_input=${data_dir}"/input"
data_output=${data_dir}"/output"
data_archive=${data_dir}"/archive"
data_tmp=${data_dir}"/tmp"

check_create_directories () {
if [ ! -d "$1" ];
then
        echo "Directory doesnt exists creating "$1
        mkdir -p $1
        chmod -R 777 $1
        chgrp -R etl $1
else
        echo "Structure already exists for "$1
fi

}



echo "____________________________________________"
echo "___  Creating Directory Structure        ___"
echo "____________________________________________"
check_create_directories $data_dir
check_create_directories $data_input
check_create_directories $data_output
check_create_directories $data_archive
check_create_directories $data_tmp
echo "____________________________________________"
echo "____________________________________________"
