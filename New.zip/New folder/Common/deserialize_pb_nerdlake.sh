#!/bin/bash

if [ $# -lt 1 ]
then
    echo 'Usage: deserialize_pb_nerdlake.sh <EventName> [from_date=YYYY-MM-DD] [to_date=YYYY-MM-DD] [--base-param-file base_param_filename]'
    exit 1
fi

event_name="$1"

set -e
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh "${event_name}_nerdlake"
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh

export dwh_common_base_dir       # framework doesn't export this, and needed to refer to java libs

python $dwh_common_base_dir/deserialize_protobuf.py "$event_name" nerdlake "${@:2}"
