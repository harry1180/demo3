#!/usr/bin/env python

import logging
import os
import pwd
import sys

logging_format = '[%(levelname)-8s] %(name)s - %(message)s'
if pwd.getpwuid(os.geteuid())[0] != 'airflow':
    logging_format = '%(asctime)s ' + logging_format

logging.basicConfig(format=logging_format, level=logging.INFO)

import redshift_modules


def main(database_objects):
    logging.info('Connecting to Redshift')
    if pwd.getpwuid(os.getuid()).pw_name == 'airflow':
        conn = redshift_modules.redshift_connect(input_db='superuser')
    else:
        conn = redshift_modules.redshift_connect()
    with conn.cursor() as curs:
        curs.execute('set wlm_query_slot_count to 3')
    logging.info('Building list of tables that need to be vacuumed')
    tables = set()
    for database_object in database_objects:
        if '.' in database_object:
            logging.info('    Adding ' + database_object.lower())
            tables.add(database_object.lower())
        else:
            logging.info('    Checking schema \'{}\' for tables that need to be vacuumed'.format(database_object))
            schema_tables = redshift_modules.tables_to_vacuum(conn, database_object)
            tables.update(schema_tables)
    logging.info('Vacuuming and analyzing {} tables'.format(len(tables)))
    for table in sorted(tables):
        logging.info(table)
        ignore_owner_failure = table.lower().startswith('dw_workarea.')
        redshift_modules.vacuum_table(conn, table, ignore_owner_failure=ignore_owner_failure)
    conn.close()


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: vacuum_tables.py <schema|schema.table> [<schema|schema.table> ...]')
        sys.exit(1)

    logging.info('Execution begins')

    schema_names = set(sys.argv[1:])
    logging.info('Schemas/tables to vacuum: {}'.format(', '.join(sorted(schema_names))))
    main(schema_names)

    logging.info('Execution ends')
