job_name='redshift_sql_function'

source set_dwh_env_variables.sh
source ${common_environment_file_dir}/environment.ctrl

## Usage: Embed variables :v1 and/or :v2 at sql file, and accept command-line input parameters
## Example:
## 1. redshift_sql_function.sh step00_url_stage_s_del.sql
## 2a. redshift_sql_function.sh step00_url_stage_s_del.sql param.json
## Sample Json: {"process_date":"2016-07-20"}
## Sample SQL: SELECT * FROM dw_stage.test WHERE dw_eff_dt='process_date';
## 2b. redshift_sql_function.sh step00_url_stage_s_del.sql daily
## 3. redshift_sql_function.sh step00_url_stage_s_del.sql daily QA

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    echo "An error occurred. Exiting while performing *****************SQL Step" >&2
    exit 1
}
trap 'abort' 0
set -e




if [ "$#" -eq "1" ] ; then
  sql_file="$1"
  if [ ! -e ${sql_file} ] ; then echo "SQL script [${sql_file}] doesn't exist." ; exit -1; fi
  query=`cat ${sql_file}`
elif [ "$#" -eq "2" ] && [[ "$2" = *.json ]] && [ -e "$2" ] ; then
  sql_file=$1  
  if [ ! -e ${sql_file} ] ; then echo "SQL script [${sql_file}] doesn't exist." ; exit -1; fi
  echo "passing JSON parameters"
  full_filename=$(basename "$sql_file")
  param_file=$2
  export DateStamp=`date '+%m%d%Y'`
  echo "DateStamp=$DateStamp"
  export TimeStamp=`date '+%H%M%S'`
  echo "TimeStamp=$TimeStamp"
  rs_run_file=/tmp/${full_filename}.${DateStamp}_${TimeStamp}.run
  echo "replacing params and sql generating run file @ "${rs_run_file}
  query=`stdbuf -oL python ${dwh_common_base_dir}/replace_params.py ${sql_file} ${param_file}` #> ${rs_run_file}
  #query=`cat ${rs_run_file}`
  #echo "$query" 
elif [ "$#" -eq "2" ] ; then
  sql_file="$1"
  if [ ! -e ${sql_file} ] ; then echo "SQL script [${sql_file}] doesn't exist." ; exit -1; fi
  var1="$2"
  query=`cat ${sql_file} | sed -e "s|:v1|$var1|g"` 
  echo "$query"
elif [ "$#" -eq "3" ] ; then
  sql_file="$1"
  if [ ! -e ${sql_file} ] ; then echo "SQL script [${sql_file}] doesn't exist." ; exit -1; fi
  var1="$2"
  var2="$3"
  query=`cat ${sql_file} | sed -e "s|:v1|$var1|g" | sed -e "s|:v2|$var2|g"` 
  echo "$query"
else
  echo "Usage and Example:
## 1. redshift_sql_function.sh step00_url_stage_s_del.sql
## 2a. redshift_sql_function.sh step00_url_stage_s_del.sql param.json
## 2b. redshift_sql_function.sh step00_url_stage_s_del.sql daily
## 3. redshift_sql_function.sh step00_url_stage_s_del.sql daily QA"
  exit 0
fi

if [ ! -z "${query}" ] ; then
  psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
else
  echo "Query is empty."
  exit -1
fi

#cleanup run sql file
if [ -f "${rs_run_file}" ]
then
   rm ${rs_run_file}
fi

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

