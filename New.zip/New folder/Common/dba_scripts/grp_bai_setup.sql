/* Power user group ius for WLM not for rights*/
/* BA user is for rights */

select usesysid, usename, nvl(groname,'default') from pg_user u 
left join pg_group g on ','||array_to_string(grolist,',')||','
  like '%,'||cast(usesysid as varchar(10))||',%' 
where groname = 'grp_power_users'
-- usename='johnlee' 
order by 2,1
;

select  'alter group grp_ba_users add user '|| usename ||';'from pg_user u 
left join pg_group g on ','||array_to_string(grolist,',')||','
  like '%,'||cast(usesysid as varchar(10))||',%' 
where groname = 'grp_power_users'
-- usename='johnlee' 
;

-- create the group 
create group GRP_BA_USERS ;

-- add people
alter group grp_ba_users add user johnlee;
alter group grp_ba_users add user mlee;
alter group grp_ba_users add user leonardchang;
alter group grp_ba_users add user anuragk;
alter group grp_ba_users add user asingh;
alter group grp_ba_users add user cwhittle;
alter group grp_ba_users add user mshire;
alter group grp_ba_users add user slu;
alter group grp_ba_users add user sgupta;

--- check if this is the etl account for bai
alter group grp_ba_users add user dw_bai_reports;

alter group grp_ba_users add user dw_etl_load;
alter group grp_ba_users add user puneethpotu;
alter group grp_ba_users add user ppotu;
alter group grp_ba_users add user vaibhavjajoo;
alter group grp_ba_users add user ssundara;
alter group grp_ba_users add user asingh;
alter group grp_ba_users add user jyoo;
alter group grp_ba_users add user acheng;
alter group grp_ba_users add user akhajekar;
alter group grp_ba_users add user rkarunanidhi;
alter group grp_ba_users add user dcai, sgupta, kjoshi,erowe, slu, skadow ;

-- bai stage schema 
create schema dw_ba_stage authorization nw_dwh;

-- grants to the schema
grant all on schema dw_ba_stage to group grp_etl; 
grant all on schema dw_ba_stage to group grp_ba_users;

grant usage on schema dw_ba_stage to group grp_ba_users;
grant usage on schema dw_ba_stage to group grp_data_users;
grant usage on schema dw_ba_stage to group grp_etl;

create schema dw_ba_report authorization nw_dwh;

grant all on schema dw_ba_report to group grp_etl; 
grant all on schema dw_ba_report to group grp_ba_users;

grant usage on schema dw_ba_report to group grp_ba_users;
grant usage on schema dw_ba_report to group grp_data_users;
grant usage on schema dw_ba_report to group grp_etl;

commit;


commit;

