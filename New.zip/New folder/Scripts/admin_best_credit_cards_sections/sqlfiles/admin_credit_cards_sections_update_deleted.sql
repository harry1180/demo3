update dw_report.dw_admin_best_credit_cards_sections_d
   SET dw_expr_dt = sysdate, curr_in = 0
  FROM
(select * from (
select a.section_id, b.id as record_exists from (select * from dw_report.dw_admin_best_credit_cards_sections_d where curr_in =1) a
left outer join
dw_stage.admin_best_credit_cards_sections_s b
on     a.section_id = b.id
           ) where record_exists is null) b
WHERE     dw_report.dw_admin_best_credit_cards_sections_d.section_id = b.section_id;
