

job_name='admin_best_credit_cards_sections'



job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
	bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}


Linux_Input=${dwh_data_base_dir}/${job_name}/input/
Linux_Output=${dwh_data_base_dir}/${job_name}/output/
Linux_Archive=${dwh_data_base_dir}/${job_name}/archive/
S3_Input=/s3mnt-dwh-staging/${job_name}/input/
S3_Output=/s3mnt-dwh-staging/${job_name}/output/
S3_Archive=/s3mnt-dwh-staging/${job_name}/archive/
echo '+----------+----------+----------+----------+----------+----------+'
echo 'dwh_credentials_file_dir   :-   '${dwh_credentials_file_dir}
echo 'dwh_scripts_base_dir       :-   '${dwh_scripts_base_dir}
echo 'dwh_common_base_dir        :-   '${dwh_common_base_dir}
echo 'dwh_data_base_dir          :-   '${dwh_data_base_dir}
echo 'Linux_Input                :-   '${Linux_Input}
echo 'Linux_Output               :-   '${Linux_Output}
echo 'Linux_Archive              :-   '${Linux_Archive}
echo 'S3_Input                   :-   '${S3_Input}
echo 'S3_Output                  :-   '${S3_Output}
echo 'S3_Archive                 :-   '${S3_Archive}
echo '+----------+----------+----------+----------+----------+----------+'
#Custom Variables



bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'


echo_processing_step ${job_name} "Cleaning S3 and data direcotries" "Started"
rm $Linux_Input*admin* || true
rm $S3_Input*admin* || true
echo_processing_step ${job_name} "Cleaning S3 and data direcotries" "Completed"

echo_processing_step ${job_name} "Pulling MySql Data into Source File system" "Started"
bash ${dwh_common_base_dir}/mysql_linux_copy_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/admin_credit_cards_sections_view_pull.sql ${dwh_data_base_dir}/${job_name}/admin_credit_cards_sections.csv
echo_processing_step ${job_name} "Pulling MySql Data into Source File system" "Completed"

echo_processing_step ${job_name} "GZIP file and moving to S3" "Started"
gzip ${dwh_data_base_dir}/${job_name}/admin_credit_cards_sections.csv
mv ${dwh_data_base_dir}/${job_name}/admin_credit_cards_sections.csv.gz /s3mnt-dwh-staging/admin_best_credit_cards_sections/
chmod 775 /s3mnt-dwh-staging/admin_best_credit_cards_sections/admin_credit_cards_sections.csv.gz
chgrp etl /s3mnt-dwh-staging/admin_best_credit_cards_sections/admin_credit_cards_sections.csv.gz
echo_processing_step ${job_name} "GZIP file and moving to S3" "Completed"

echo_processing_step ${job_name} "Delete data from Stage table" "Started"
query_stage_delete="delete from dw_stage.admin_best_credit_cards_sections_s;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo_processing_step ${job_name} "Delete data from Stage table" "Completed"

echo_processing_step ${job_name} "Copy Data to stage table" "Started"
Processing_Step="Copy Data to stage table"
bash ${dwh_common_base_dir}/redshift_copy_function.sh dw_stage.admin_best_credit_cards_sections_s /admin_best_credit_cards_sections/ admin_credit_cards_sections
echo_processing_step ${job_name} "Copy Data to stage table" "Completed"

echo_processing_step ${job_name} "Loading data to final table Type2" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/admin_credit_cards_sections_insert_new.sql
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/admin_credit_cards_sections_update_existing.sql
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/admin_credit_cards_sections_insert_existing.sql
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/admin_credit_cards_sections_update_deleted.sql
echo_processing_step ${job_name} "Loading data to final table Type2" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
