import sys
import csv
import json
import requests
import time

from amplitude_modules import generate_nested_json_dict, set_none_to_output_key, convert_csv_to_amp_json, send_data_to_amplitude

field_name_list = [
 "site_uv_id"
,"user_id"
,"dw_suspected_bot_in"
,"last_activity_utc_ts_epoch"
,"last_activity_ts"
]

amp_dict = {
 "user_id":"user_id"
,"device_id":"site_uv_id"
,"event_type":"BOT_DETECTED_EVENT"
,"time":"last_activity_utc_ts_epoch"
,"event_properties":
{
 "last_activity_utc_ts":"last_activity_ts"
}
,"user_properties":
{
 "is_bot":"dw_suspected_bot_in"
,"last_activity_ts":"last_activity_ts"
}
}


def main():
    """
    called by amp_modify_user_property only to post data to Amplitude
    """
    if len(sys.argv) != 5:
        print 'Input %d arguments:\n%s' % (len(sys.argv), str(sys.argv))
        print main.__doc__
        print "Exit."
        return

    amp_api_key      = {'api_key': sys.argv[1]}
    amp_api_url      = sys.argv[2]

    input_csv_file   = sys.argv[3]
    output_json_file = sys.argv[4]
    
    convert_csv_to_amp_json(input_csv_file, field_name_list, output_json_file, amp_dict)
    
    send_data_to_amplitude(amp_api_url, amp_api_key, output_json_file, 'event', output_json_file + '.unsent')
    
if __name__ == '__main__':
    main()
