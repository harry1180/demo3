('
select 
  site_uv_id
, user_id 
, dw_suspected_bot_in
, cast(date_part(epoch, last_activity_ts) as bigint) as last_activity_utc_ts_epoch
, last_activity_ts
from dw_stage.dw_cookie_user_bot_all
where dw_snapshot_dt = trunc(sysdate)
  and incremental_in = 1
  and length(trim(site_uv_id)) < 45 
  and site_uv_id not like \'%\'\'%\' 
  and site_uv_id not like \'%\'\'/%\'
  and site_uv_id not like \'%\'\'\%\'
  and site_uv_id not like \'%@%\'
  and site_uv_id not like \'%+%\'
  and site_uv_id not like \'%(%\'
  and site_uv_id not like \'%)%\'
  and site_uv_id not like \'%\'\'%%\'
')
