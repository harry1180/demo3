"""
API Documentation (need to login using CJ creds in DWH 1Password vault:
https://cjcommunity.force.com/s/article/Commission-Detail-Service-API-4777175
"""

import json
import os
import requests
import sys

from datetime import datetime, timedelta
from xml.etree import cElementTree as ET

from nw_retry import nw_retry, REQUEST_EXCEPTIONS


url = 'https://commission-detail.api.cj.com/v3/commissions?date-type=posting&start-date={}&end-date={}'
details_url = 'https://commission-detail.api.cj.com/v3/item-detail/{}'


@nw_retry(REQUEST_EXCEPTIONS)
def call_api(session, url_str, auth_str):
    response = session.get(url_str, headers={'authorization': auth_str}, timeout=300)
    response.raise_for_status()
    return response.text


def process_transactions(session, file_handler, transactions):
    """
    This function takes in a list of CJ transactions from the "commissions" endpoint, and batch calls the "item-detail"
    endpoint to get the SKU value. The SKU value is added as a new field to the transaction and then written to a
    JSON output file.
    :param session: request session object
    :param file_handler: output file handler
    :param transactions: dict of lists (transactions)
    """

    # Build comma separated list of transaction ids for batch API processing
    batch_ids = ','.join(transactions.keys())

    # Call item details endpoint and add SKU field to corresponding transaction
    details_xml_text = call_api(session, details_url.format(batch_ids), api_key)
    details_root = ET.fromstring(details_xml_text)
    for action_id in details_root.iter('item-details'):
        id_val = action_id.attrib['original-action-id']
        for details_elem in action_id.iter('item'):
            for details_child in details_elem:
                if details_child.tag == 'sku':
                    transactions[id_val]['sku'] = details_child.text
                    break

    # Dump transactions to JSON file
    for row in transactions.values():
        json.dump(row, file_handler, sort_keys=True)
        file_handler.write('\n')


if __name__ == '__main__':

    if len(sys.argv) < 5:
        print('Usage: {} <start_date> <end_date> <api_key> <output_file>'.format(os.path.basename(__file__)))
        print('Exiting.')
        sys.exit(1)

    start_date = sys.argv[1]
    end_date = sys.argv[2]
    api_key = sys.argv[3]
    output_json_file = sys.argv[4]

    with open(output_json_file, 'w') as flocal:

        cj_session = requests.Session()

        # Large date ranges can cause timeouts, so we break them up into 7 day intervals
        start_date_obj = datetime.strptime(start_date, '%Y-%m-%d')
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
        while start_date_obj < end_date_obj:

            iter_end_date_obj = min(end_date_obj, start_date_obj + timedelta(days=7))

            # Get all transactions from the given date range
            commissions_url = url.format(start_date_obj.strftime('%Y-%m-%d'), iter_end_date_obj.strftime('%Y-%m-%d'))
            commissions_xml_text = call_api(cj_session, commissions_url, api_key).encode('utf-8')
            root = ET.fromstring(commissions_xml_text)
            children = root.find('commissions').findall('commission')

            print('Processing {} transactions between {} and {}'.format(len(children),
                                                                        start_date_obj.strftime('%Y-%m-%d'),
                                                                        iter_end_date_obj.strftime('%Y-%m-%d')))

            # Loop through transactions to get details for each one (needed to get SKU field)
            # For performance reasons, we batch call the details endpoint 50 transactions at a time
            transactions = dict()
            for child in children:
                row = {field.tag: field.text for field in child if field.text}
                transactions[row['original-action-id']] = row

                if len(transactions) == 50:
                    process_transactions(cj_session, flocal, transactions)
                    id_list = []
                    transactions = dict()
                else:
                    continue

            if len(transactions) > 0:
                process_transactions(cj_session, flocal, transactions)

            start_date_obj = iter_end_date_obj

        cj_session.close()
