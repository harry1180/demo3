-- Update sku since it might be updated after loading
UPDATE :reportdb.dw_aflt_tran_comm_junc_f
    SET sku = b.sku
    FROM :stagedb.aflt_tran_comm_junc_post_stg b
WHERE :reportdb.dw_aflt_tran_comm_junc_f.aflt_network_tran_id = b.aflt_network_tran_id
	AND COALESCE(:reportdb.dw_aflt_tran_comm_junc_f.sku, 'XXXXX') <> COALESCE(b.sku, 'XXXXX')
;
