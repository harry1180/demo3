INSERT INTO :reportdb.dw_aflt_tran_comm_junc_f
(
    aflt_network_tran_id,
    aflt_network_id,
    aflt_fin_tran_type_cd,
    dw_eff_dt,
    tran_post_dt,
    tran_click_dt,
    tran_post_ts,
    tran_click_ts,
    src_prod_nm,
    prog_nm,
    src_unique_click_id,
    dw_site_visitor_id,
    prod_src_sys_id,
    dw_site_prod_sk,
    dw_site_prod_nm,
    commission_am,
    merchant_am,
    catg_nm,
    action_status,
    sku,
    aid,
    country,
    locking_dt,
    order_id,
    original,
    original_action_id,
    website_id,
    action_tracker_id,
    category_id,
    order_discount,
    dw_load_ts
)
SELECT
    ps.aflt_network_tran_id,
    ps.aflt_network_id,
    ps.aflt_fin_tran_type_cd,
    ps.dw_eff_dt,
    ps.tran_post_dt,
    ps.tran_click_dt,
    ps.tran_post_ts,
    ps.tran_click_ts,
    ps.src_prod_nm,
    case when lower(ps.prog_nm) like 'loyal3' then 'Loyal3'
         when lower(ps.prog_nm) like 'etoro%' then 'eToro Standard'
         else ps.prog_nm end as prog_nm,
    ps.src_unique_click_id,
    ps.dw_site_visitor_id,
    ps.prod_src_sys_id,
    ps.dw_site_prod_sk,
    ps.dw_site_prod_nm,
    ps.commission_am,
    ps.merchant_am,
    ps.catg_nm,
    ps.action_status,
    ps.sku,
    ps.aid,
    ps.country,
    ps.locking_dt,
    ps.order_id,
    ps.original,
    ps.original_action_id,
    ps.website_id,
    ps.action_tracker_id,
    ps.category_id,
    ps.order_discount,
    ps.dw_load_ts
FROM :stagedb.aflt_tran_comm_junc_post_stg ps
LEFT OUTER JOIN
:reportdb.dw_aflt_tran_comm_junc_f tgt
ON ps.aflt_network_tran_id = tgt.aflt_network_tran_id
AND ps.aflt_network_id = tgt.aflt_network_id
WHERE tgt.aflt_network_tran_id is null
;
