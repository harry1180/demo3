

job_name='aflt_tran_commission_junction'



job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
source /etc/passwords.ctrl
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
# Set up our start and end dates
start_date=$(date -d "-7 days" +%Y-%m-%d)
end_date=$(date -d "+1 days" +%Y-%m-%d)
if [ $# -ge 1 ]
then
    start_date=$1
fi
if [ $# -ge 2 ]
then
    end_date=$2
fi

stage_table="$stagedb.aflt_tran_comm_junc"
post_stage_table="$stagedb.aflt_tran_comm_junc_post_stg"

process_time=$(date +%Y-%m-%d_%H:%M:%S)
output_file=${Linux_Output}post_cj.json
archive_path=${S3_Events_Archive}${end_date}
archive_file=post_cj_${process_time}.json
aflt_tran_id=1

echo 'start_date                       :-   '${start_date}
echo 'end_date                         :-   '${end_date}
echo 'stage_table                      :-   '${stage_table}
echo 'post_stage_table                 :-   '${post_stage_table}
echo 'output_file                      :-   '${output_file}
echo 'archive_path                     :-   '${archive_path}
echo 'archive_file                     :-   '${archive_file}
echo 'aflt_tran_id                     :-   '${aflt_tran_id}
echo '+----------+----------+----------+----------+----------+----------+'



bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Removing Local Data Files" "Started"
find $Linux_Output -name \*.json -exec rm {} \; || true
echo_processing_step ${job_name} "Removing Local Data Files" "Completed"

echo_processing_step ${job_name} "Removing Stale S3 Files" "Started"
python -c "from s3_modules import delete_key; delete_key('$S3_Events_Output','$Events_dwh_bucket','*.json')" || true
echo_processing_step ${job_name} "Removing Stale S3 Files" "Completed"

echo_processing_step ${job_name} "Calling Python script to bring in the API Data" "Started"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/aflt_tran_commission_junction.py $start_date $end_date $cj_api_key $output_file
echo_processing_step ${job_name} "Calling Python script to bring in the API Data" "Completed"

echo_processing_step ${job_name} "Moving JSON files to S3" "Started"
python -c "from s3_modules import s3_file_upload; s3_file_upload('$output_file', '$Events_dwh_bucket', '$S3_Events_Output')"
echo_processing_step ${job_name} "Moving JSON files to S3" "Completed"

Processing_Step="Purging $stage_table"
echo_processing_step ${job_name} "$Processing_Step" "Started"
python $dwh_common_base_dir/redshift_purge_table.py "$stage_table"
echo_processing_step ${job_name} "$Processing_Step" "Completed"

echo_processing_step ${job_name} "Copy Data to stage table" "Started"
query="COPY $stage_table
       FROM '"$s3_bucket_name"/aflt_tran_commission_junction/output'
       CREDENTIALS '"$s3_prod_load_creds"'
       JSON as '"$s3_bucket_name"/json/aflt_tran_commission_junction/"$stagedb"/aflt_tran_comm_junc.json'
       TRUNCATECOLUMNS
       ACCEPTINVCHARS
       COMPUPDATE OFF
       TRIMBLANKS
       BLANKSASNULL
       DATEFORMAT 'auto'
       TIMEFORMAT 'auto';"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase" -c "$query"
echo_processing_step ${job_name} "Copy Data to stage table" "Completed"

Processing_Step="Purging $post_stage_table"
echo_processing_step ${job_name} "$Processing_Step" "Started"
python $dwh_common_base_dir/redshift_purge_table.py "$post_stage_table"
echo_processing_step ${job_name} "$Processing_Step" "Completed"

sql_scripts="insert_commission_junction_post_stage.sql
insert_commission_junction_fact.sql
update_commission_junction_fact.sql
update_commission_junction_fact_citi_cpa.sql
 "
for sql_script in $sql_scripts
do
    echo_processing_step ${job_name} "$sql_script" "Started"
    bash ${dwh_common_base_dir}/redshift_psql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/$sql_script
    echo_processing_step ${job_name} "$sql_script" "Completed"
done

Processing_Step="Archiving $output_file to $archive_path/$archive_file"
echo_processing_step ${job_name} "$Processing_Step" "Started"
python -c "from s3_modules import s3_file_upload; s3_file_upload('$output_file', '$Events_dwh_bucket', '$archive_path', '$archive_file')"
echo_processing_step ${job_name} "$Processing_Step" "Completed"

echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Started"
python -c "from tran_log_modules import insert_log; insert_log($aflt_tran_id);"
echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

