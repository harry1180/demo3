--DROP TABLE "dw_stage"."aflt_tran_comm_junc";
CREATE TABLE "dw_stage"."aflt_tran_comm_junc"
(
	"action_status" VARCHAR(256)
	,"action_tracker_id" BIGINT
	,"action_tracker_name" VARCHAR(256)
	,"advertiser_name" VARCHAR(256)
	,"action_type" VARCHAR(256)
	,"aid" BIGINT
	,"cid" BIGINT
	,"commission_amount" NUMERIC(10,2)
	,"commission_id" VARCHAR(256)
	,"country" VARCHAR(256)
	,"event_date" TIMESTAMPTZ -- source data comes as timestamp with timezone
	,"locking_date" DATE
	,"order_discount" NUMERIC(10,2)
	,"order_id" VARCHAR(256)
	,"original" BOOLEAN
	,"original_action_id" BIGINT
	,"posting_date" TIMESTAMPTZ  -- source data comes as timestamp with timezone
	,"sale_amount" NUMERIC(10,2)
	,"sid" VARCHAR(256)
	,"sku" VARCHAR(256)
	,"website_id" BIGINT
)
DISTSTYLE ALL
;
