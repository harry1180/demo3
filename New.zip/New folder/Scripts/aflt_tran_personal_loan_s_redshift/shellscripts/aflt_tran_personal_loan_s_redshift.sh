job_name='aflt_tran_personal_loan_s_redshift'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
        bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
# the source_path is the directory the previous task aflt_tran_process_edu_loan writes to.
source_path=aflt_tran_process_personal_loans/output/



## can pass the start date and end date through command line, esp. for deserializing historical data
echo '+----------+----------+---Custom Variables--+----------+----------+'
if [ -z $1 ] ; then
  from_date="$(date -d '-3 days' '+%Y-%m-%d')"
else
  from_date="$1"
fi

if [ -z $2 ] ; then
  to_date="$(date -d '1 days' +'%Y-%m-%d')"
else
  to_date="$2"
fi

echo 'source_path 		       :-   '${source_path}
echo 'Events_dwh_bucket                :-   '${Events_dwh_bucket}
echo 'from_date                        :-   '${from_date}
echo 'to_date                          :-   '${to_date}
echo '+----------+----------+----------+----------+----------+----------+'


bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"


echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Deleting data from Poststage-Error table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/aflt_tran_personal_loan_s_redshift/sqlfiles/truncate_poststg_error.sql
echo_processing_step ${job_name} "Deleting data from Poststage-Error table" "Ended"

echo_processing_step ${job_name} "Calling Python script to write data to stage and post-stage" "Started"
echo "python ${dwh_common_base_dir}/nw_python_modules/lender_transformer/load_stage_poststage.py $Events_dwh_bucket $source_path ${dwh_scripts_base_dir}/aflt_tran_personal_loan_s_redshift/pythonscripts/email_info.json 'dw_stage.aflt_tran_personal_loan_s' 'dw_stage.aflt_tran_personal_loan_post_s' ${dwh_scripts_base_dir}/aflt_tran_personal_loan_s_redshift/sqlfiles/aflt_tran_personal_loans_post_s.sql $s3_access_key $s3_secret_key $Events_dwh_bucket/json/aflt_transactions/aflt_tran_personal_loans_test.jsonpaths 25 ${from_date} ${to_date} src_lendername"
python ${dwh_common_base_dir}/nw_python_modules/lender_transformer/load_stage_poststage.py $Events_dwh_bucket $source_path ${dwh_scripts_base_dir}/aflt_tran_personal_loan_s_redshift/pythonscripts/email_info.json "dw_stage.aflt_tran_personal_loan_s" "dw_stage.aflt_tran_personal_loan_post_s" ${dwh_scripts_base_dir}/aflt_tran_personal_loan_s_redshift/sqlfiles/aflt_tran_personal_loans_post_s.sql $s3_access_key $s3_secret_key $Events_dwh_bucket/json/aflt_transactions/aflt_tran_personal_loans.jsonpaths 25 ${from_date} ${to_date} "src_lendername"
echo_processing_step ${job_name} "Calling Python script to write data to stage and post-stage" "Ended"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'


echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"
job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
***************************************
*** '$job_name' LOAD COMPLETED  ***
***************************************
'
