DELETE FROM dw_report.aflt_tran_personal_loan_error;
