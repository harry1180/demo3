DROP TABLE IF EXISTS dw_report.ctl_dw_aflt_tran_growth_f CASCADE;

CREATE TABLE dw_report.ctl_dw_aflt_tran_growth_f
(
   lender        varchar(256),
   validated_in  varchar(256),
   validated_by  varchar(256),
   validated_dt  timestamp,
   validated_tx  varchar(256),
   file_cadence  varchar(100),
);

GRANT  RULE, SELECT, REFERENCES, TRIGGER, DELETE, INSERT, UPDATE ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_etl;
GRANT  SELECT ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_data_users_secured;
GRANT RULE, DELETE, SELECT, REFERENCES, INSERT, TRIGGER, UPDATE ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_dba;
GRANT TRIGGER, REFERENCES, SELECT, RULE, INSERT, UPDATE, DELETE ON dw_report.ctl_dw_aflt_tran_growth_f TO nw_dwh_etl;
GRANT TRIGGER, RULE, UPDATE, INSERT, REFERENCES, SELECT, DELETE ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_etl_secured;
GRANT SELECT ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_bi_tool_users;
GRANT  SELECT ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_meta_nerd;
GRANT SELECT ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_redash;
GRANT  SELECT ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_ba_users;
GRANT  SELECT ON dw_report.ctl_dw_aflt_tran_growth_f TO group grp_data_users;

COMMIT;
