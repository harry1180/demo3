DROP TABLE IF EXISTS dw_report.aflt_tran_smb_loans_source CASCADE;

CREATE TABLE dw_report.aflt_tran_smb_loans_source
(
   aflt_network_tran_id   varchar(256)    encode lzo,
   click_id               varchar(256)    encode lzo,
   cookie_id              varchar(256)    encode lzo,
   product_type		  varchar(256)    encode lzo,
   funnel_status          varchar(256)    encode lzo,
   fico_range             varchar(256)    encode lzo,
   time_in_business       varchar(256)    encode lzo,
   annual_gross_revenue	  numeric(18,2)   encode lzo,
   industry		  varchar(256)    encode lzo,
   create_accnt_dt	  date		  encode lzo,
   prequal_start_dt       date    	  encode lzo,
   prequal_complete_dt    date            encode lzo,
   preapproval            varchar(20)     encode lzo,
   application_start_dt   date            encode lzo,
   application_complete_dt  date          encode lzo,
   approval_dt		  date            encode lzo,
   funded_dt              date            encode lzo, 
   funded_interest_rt     numeric(18,9)  encode lzo,
   funded_apr             numeric(18,9)    encode lzo,
   funded_loan_term	  numeric(18,9)   encode lzo,
   loan_amt_requested 	  numeric(18,9)   encode lzo,
   loan_amt_issued	  numeric(18,9)   encode lzo,
   loan_purpose           varchar(256)    encode lzo,
   decline_reason         varchar(256)    encode lzo,
   total_draws            varchar(256)    encode lzo,
   nerdwallet_commission  numeric(18,9)   encode lzo,  
   src_withdrawal_reason      varchar(256)  encode lzo,
   src_funnel_status      varchar(256)    encode lzo,
   src_fico		  varchar(256)	  encode lzo,
   src_time_in_business   numeric(18,9)   encode lzo,
   src_revenue		  numeric(18,9)   encode lzo,
   src_industry           varchar(256)    encode lzo,
   src_column_1           varchar(256)    encode lzo,
   src_column_2           varchar(256)    encode lzo,
   src_column_3           varchar(256)    encode lzo,
   src_column_4           varchar(256)    encode lzo,
   src_column_5           varchar(256)    encode lzo,
   src_column_6           varchar(256)    encode lzo,
   src_column_7           varchar(256)    encode lzo,
   src_column_8           varchar(256)    encode lzo,
   src_column_9           varchar(256)    encode lzo,
   src_column_10          varchar(256)    encode lzo,
   src_column_11          varchar(256)    encode lzo,
   src_column_12          varchar(256)    encode lzo,
   src_column_13          varchar(256)    encode lzo,
   src_column_14          varchar(256)    encode lzo,
   src_column_15          varchar(256)    encode lzo,
   src_column_16          varchar(256)    encode lzo,
   src_column_17          varchar(256)    encode lzo,
   src_column_18          varchar(256)    encode lzo,
   src_column_19          varchar(256)    encode lzo,
   src_lendername         varchar(256)    encode lzo,
   src_filename           varchar(256)    encode lzo,
   src_file_received_dt   varchar(256)    encode lzo,
   dw_load_ts             timestamp       encode lzo
);

GRANT REFERENCES,  TRIGGER, DELETE, RULE, INSERT, UPDATE, SELECT ON dw_report.aflt_tran_smb_loans_source TO group grp_etl;
GRANT SELECT, REFERENCES, RULE, INSERT, TRIGGER,  UPDATE, DELETE ON dw_report.aflt_tran_smb_loans_source TO group grp_dba;
GRANT TRIGGER, REFERENCES, UPDATE, DELETE, SELECT, RULE,  INSERT ON dw_report.aflt_tran_smb_loans_source TO nw_dwh_etl;
GRANT UPDATE, INSERT, REFERENCES, TRIGGER, SELECT, DELETE, RULE ON dw_report.aflt_tran_smb_loans_source TO group grp_etl_secured;
GRANT REFERENCES, TRIGGER, SELECT,  RULE, UPDATE, INSERT, DELETE ON dw_report.aflt_tran_smb_loans_source TO nw_dwh;
GRANT  SELECT ON dw_report.aflt_tran_smb_loans_source TO group grp_bi_tool_users;
GRANT SELECT ON dw_report.aflt_tran_smb_loans_source TO group grp_ba_users;
GRANT SELECT ON dw_report.aflt_tran_smb_loans_source TO group grp_data_users;

