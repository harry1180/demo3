source /data/etl/Scripts/aflt_process_email_attachments/shellscripts/parm_aflt_process_email_attachments.ctrl

job_name='aflt_process_email_attachments'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e


#######################################
#Main Script
######################################

Processing_Step="Setting up Variables"
echo "______________"$Processing_Step"______________"
EmailBucket="east1-prod-aflt-airdrop-0"
EmailPath="AffiliateEmails"
ArchivePath="Archive"
output_path=$Linux_Input
ProcessedEmailPath=$Linux_Output



Processing_Step="creating directory structure if not exists"
echo "______________"$Processing_Step"______________"
bash /data/etl/Common/setup_dir_structure.sh $job_name

Processing_Step="Deleting input directory"
echo "______________"$Processing_Step"______________"
find $output_path -type f -delete || true
find $ProcessedEmailPath -type f -delete || true

Processing_Step="Running python to Download the email attachments"
echo "______________"$Processing_Step"______________"
python -c "from s3_email_process import email_attachment_extract; email_attachment_extract('$EmailBucket','$EmailPath','$ArchivePath','$output_path','$ProcessedEmailPath')" || true

Processing_Step="Moving Extracted Attachments to S3 Bucket"
echo "______________"$Processing_Step"______________"
s3_bucketname="east1-prod-dwh-s3-0"
s3bucketFolder="aflt_process_email_attachments/output"

for f in "$ProcessedEmailPath"/*
    do
    python -c "from s3_modules import s3_file_upload;s3_file_upload('$f','$s3_bucketname','$s3bucketFolder')" || true
    rm "$f" || true
    done


trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
' 
