analyze  dw_report.dw_aflt_tran_quinstreet_f;
vacuum dw_report.dw_aflt_tran_quinstreet_f;
