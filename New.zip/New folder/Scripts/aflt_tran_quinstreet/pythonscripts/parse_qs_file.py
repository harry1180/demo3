import os
import sys
import csv
import sys
#import ipdb

# Search_ID|Custom|TransactionID|SearchTypeName|MobileCheck|SearchDT|click_ID|clickDT|Accountname|amountname|rateproduct|TermName|SupplierEarningsWPQ|
#  0	      1	        2		3	    4	         5	6	7	8		9	10	    11       12       

## outrow:
##  1           2        3      4        5       6         7                8            9            10       11        12         13
## search_id, custom_tx, uv, click_tx, prod_id, cmpny, transaction_id, SearchTypeName,MobileCheck, SearchDT, click_ID, clickDT, Accountname
##      14         15	       16	  17
## amountname, rateproduct, TermName, SupplierEarningsWPQ


infolder='/data/etl/Data/aflt_tran_quinstreet/input/'
outfolder='/data/etl/Data/aflt_tran_quinstreet/output/'
 	
def text_to_num(text_in):
    chars=['$',',','%',' ']
    for char in chars: 
        text_in = text_in.replace(char,'')
    return text_in

def parse_custom_tx(custom_tx):
    uv =''
    click_tx =''
    prod_id = ''
    cmpny = ''
    if len(custom_tx) == 8:
        return([custom_tx, click_tx, prod_id, cmpny])
    else:
        parts=custom_tx.split('-')
        if len(parts) == 3:
            if len(parts[0]) == 8:
                return([parts[0],click_tx, parts[1], parts[2]])
            else:
                return([uv, parts[0], parts[1], parts[2]])
        if len(parts) == 2:
            if len(parts[0]) == 8:
                return([parts[0],click_tx, parts[1], cmpny])
            else:
                return([uv, parts[0], parts[1], cmpny])
        else: 
            return([uv, click_tx, prod_id, cmpny])

if __name__ == '__main__':

#    if len(sys.argv) <> 3:
#        print 'Needs 1 arguments. Call parse_qs_file.py "in_folder" "out_folder"'
#        sys.exit(-1)

#    infolder=sys.argv[1]  #'/data/etl/Data/aflt_tran_quinstreet/input/'
#    outfolder=sys.argv[2] #'/data/etl/Data/aflt_tran_quinstreet/output/'

    for infile in os.listdir(infolder):
        if 'txt' in infile:
            with open(infolder+infile,'rb') as fr:
                freader =  csv.reader(fr, delimiter='|')
                with open(outfolder+infile,'wr') as fw:
                    fwriter = csv.writer(fw, delimiter = '|')
                    for row in freader:
                        #if len(row) == 12:
                     #print '%s row count %d' %(infile, len(rows))
                        fwriter.writerow([row[0], row[1]]+ parse_custom_tx(row[1]) + [row[2],row[3], row[4], row[5],row[6],row[7],
                               row[8], row[9], row[10], row[11], row[12]])

       
 
