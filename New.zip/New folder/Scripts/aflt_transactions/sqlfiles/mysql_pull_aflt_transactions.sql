SELECT 
    affiliate_transactions_v.network,
    affiliate_transactions_v.network_transaction_id,
    affiliate_transactions_v.action_type,
    affiliate_transactions_v.click_date,
    affiliate_transactions_v.post_date,
    replace(affiliate_transactions_v.product_name,'\n',' ') as product_name,
    affiliate_transactions_v.program_name,
    affiliate_transactions_v.commission_amount,
    affiliate_transactions_v.merchant_amount,
    affiliate_transactions_v.session_id,
    affiliate_transactions_v.category_name,
    affiliate_transactions_v.id
FROM
    nwallet_etl_stage.affiliate_transactions_v;
