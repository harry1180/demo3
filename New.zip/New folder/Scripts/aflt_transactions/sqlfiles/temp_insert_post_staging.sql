INSERT INTO dw_stage.aflt_tran_post_s
   (SELECT a.network_transaction_id,
   		   coalesce (b.aflt_network_id, -999999999),
           sysdate,
		   a.id,
           trunc (a.click_date),
           trunc (a.post_date),
           a.click_date,
           a.post_date,
           a.action_type,
           coalesce (c.dw_site_visitor_id, -999999999),
           a.session_id,
           coalesce (d.src_sys_id, -999999999),
           coalesce (d.src_prod_id, -999999999),
           a.product_name,
           a.program_name,
           a.category_name,
           a.commission_amount,
           a.merchant_amount,
           sysdate
      FROM dw_stage.aflt_tran_s a
           LEFT OUTER JOIN dw_report.dw_aflt_network_d b
              ON coalesce (a.network, 'NA') =
                    coalesce (b.aflt_network_shrt_nm, 'UNKNOWN')
           LEFT OUTER JOIN
           (SELECT DISTINCT m.uv, m.unique_click_id, n.dw_site_visitor_id
              FROM dw_stage.clicks_decrypt_s m, dw_report.site_visitor_d n
             WHERE m.uv = n.site_uv_id AND m.unique_click_id IS NOT NULL) c
              ON coalesce (a.session_id, 'NA') =
                    coalesce (c.unique_click_id, 'UNKNOWN')
           LEFT OUTER JOIN dw_report.dw_prod_d d
              ON coalesce (a.product_name, 'NA') =
                    coalesce (d.prod_nm, 'UNKNOWN'));
