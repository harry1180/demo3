('
select 
  d.site_uv_id
, f.user_id 
, f.aflt_network_tran_id
, f.event_type_nm
, f.quantity_nr
, f.aflt_network_id
, f.aflt_fin_tran_type_cd
, f.dw_eff_dt
, f.nw_click_dt
, f.tran_rev_rlzd_dt
, f.tran_post_dt
, f.tran_click_dt
, cast(date_part(epoch, coalesce(dateadd(m,2,f.src_clicks_utc_ts), convert_timezone(\'PST8PDT\', \'UTC\', f.tran_post_ts)) ) as bigint) as tran_post_utc_ts_epoch
, f.tran_post_ts
, f.tran_click_ts
, cast(f.src_clicks_utc_ts as varchar(19)) as src_clicks_utc_ts
, replace(f.src_prod_nm, \',\', \' \') as src_prod_nm
, f.dw_site_visitor_id
, f.dw_site_prod_sk
, replace(f.dw_site_prod_nm, \',\', \' \') as dw_site_prod_nm
, replace(f.prog_nm, \',\', \' \') as prog_nm
, f.src_unique_click_id
, replace(f.aflt_catg_nm, \',\', \' \') as aflt_catg_nm
, f.dw_click_id
, f.dw_click_src_id
, f.src_sys_id
, f.dw_session_id
, f.dw_page_view_id
, null as dw_suspected_bot_in
, f.logged_ip
, f.dw_click_page_sk
, replace(url.conf_url_tx, \',\', \' \') as url
, replace(f.page_vertical_tx, \',\', \' \') as page_vertical_tx
, replace(f.page_topic_tx, \',\', \' \') as page_topic_tx
, f.dw_click_user_agent_id
, replace(f.dw_catg_nm, \',\', \' \') as dw_catg_nm
, f.commission_am
, f.merchant_am
, f.revenue_tran_in
, f.src_commission_am
, f.src_revenue_tran_in
from dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn f
left join dw_report.site_visitor_d d
on cast(f.dw_site_visitor_id as bigint) = d.dw_site_visitor_id
left join dw_report.dw_url_d url
on f.dw_url_sk = url.dw_url_sk
where f.dw_snapshot_dt = trunc(sysdate)
  and f.incremental_in = 1
')
