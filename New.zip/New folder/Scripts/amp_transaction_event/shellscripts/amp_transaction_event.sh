job_name='amp_transaction_event'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_chef_credentials_file_dir}/passwords.ctrl
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'

input_date="$(date +'%Y%m%d%H%M%S')"
csv_file="${job_name}.csv"
json_file="${job_name}.json"
unsent_file="${job_name}.json.unsent"
gz_csv_file="${job_name}.csv.gz"
gz_json_file="${job_name}.json.gz"
gz_shell_file="${job_name}.sh.gz"
arc_csv_file="${job_name}_${input_date}.csv.gz"
arc_json_file="${job_name}_${input_date}.json.gz"
arc_shell_file="${job_name}_${input_date}.sh.gz"
curl_shell_file="${job_name}.sh"

api_url="https://api.amplitude.com/httpapi"
## NW_Stage
#api_key="8e8ea4af2166f72090499f0bd330e162"
## NW_Prod
api_key="${amplitude_api_key}"

echo 'input_date              :-   '${input_date}
echo 'csv_file                :-   '${csv_file}
echo 'json_file               :-   '${json_file}
echo 'unsent_file             :-   '${unsent_file}
echo 'gz_csv_file             :-   '${gz_csv_file}
echo 'gz_json_file            :-   '${gz_json_file}
echo 'arc_csv_file            :-   '${arc_csv_file}
echo 'arc_json_file           :-   '${arc_json_file}
echo 'arc_shell_file          :-   '${arc_shell_file}
echo 'curl_shell_file         :-   '${curl_shell_file}
echo 'api_url                 :-   '${api_url}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

## step 1: cleanup s3 files
echo_processing_step ${job_name} "Cleaning dwh S3 files" "Started"
python -c "from s3_modules import delete_key; delete_key('$S3_Events_Input','$Events_dwh_bucket','*${job_name}*')" || true
echo_processing_step ${job_name} "Cleaning dwh S3 files" "Completed"

## step 2: cleanup local files
echo_processing_step ${job_name} "Cleaning dwh local files" "Started"
find $Linux_Input    -name \*${job_name}\*         -exec rm {} \; || true
find $Linux_Output   -name \*${job_name}\*.gz      -exec rm {} \; || true
find $Linux_Output   -name \*${job_name}\*.csv     -exec rm {} \; || true
find $Linux_Output   -name \*${job_name}\*.json    -exec rm {} \; || true
find $Linux_Output   -name \*${job_name}\*.unsent  -exec rm {} \; || true
find $Linux_Output   -name \*${job_name}\*.sh      -exec rm {} \; || true
echo_processing_step ${job_name} "Cleaning dwh local files" "Completed"

## step 3: execute sql to create snapshot data at Redshift. moved to separate task amp_load_transaction_event

## step 4: execute unloading data from Redshift to s3
sql_script="unload_amp_transaction_event_from_redshift.sql"
Processing_Step="Unload data from Redshift to S3 using ${sql_script}"
echo_processing_step ${job_name} "$Processing_Step" "Started"
## due to sudo and password problem, disable the lib call
#bash ${dwh_common_base_dir}/redshift_unload_function.sh 
#${dwh_scripts_base_dir}/${job_name}/sqlfiles/unload_amp_transaction_event.sql /${job_name}/input/ ${job_name}

psql_query=`cat ${dwh_scripts_base_dir}/${job_name}/sqlfiles/${sql_script}`
echo "psql_query is ["$psql_query"]"
query="unload "$psql_query" to '"$s3_bucket_name/${job_name}/input/${job_name}"' 
credentials '$s3_prod_load_creds' 
delimiter ',' parallel off;
"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
echo_processing_step ${job_name} "$Processing_Step" "Completed"

## step 5: move data from s3 to local
Processing_Step="Moving S3 file to local"
echo_processing_step ${job_name} "$Processing_Step" "Started"
python -c "from s3_modules import s3_file_download; s3_file_download('$Events_dwh_bucket', '${job_name}', '${S3_Events_Input}${job_name}', '${dwh_data_base_dir}/${job_name}/')" || true
cat ${Linux_Input}${job_name}* > ${Linux_Output}${csv_file} || true
echo "${Linux_Output}${csv_file} file statistics:"
ls -l ${Linux_Output}${csv_file} || true
wc -l ${Linux_Output}${csv_file} || true
echo_processing_step ${job_name} "$Processing_Step" "Completed"

## step 6: covert csv file to json and post to Amplitude
Processing_Step="Covert csv file to Amplitude json format and post to Amplitude"
echo_processing_step ${job_name} "$Processing_Step" "Started"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/convert_csv_to_amp_json.py ${api_key} ${api_url} "${Linux_Output}${csv_file}" "${Linux_Output}${json_file}"
echo_processing_step ${job_name} "$Processing_Step" "Completed"

## step 7: post unsent json data to Amplitude using curl
echo "${Linux_Output}${unsent_file} file statistics:"
ls -l ${Linux_Output}${unsent_file} || true
wc -l ${Linux_Output}${unsent_file} || true

if [ -s ${Linux_Output}${unsent_file} ] ; then
  Processing_Step="Generate curl shell file for unsent json file" 
  echo_processing_step ${job_name} "$Processing_Step" "Started"
  
  # fail to touch file, then report and quit
  > ${Linux_Output}${curl_shell_file} 
  echo "echo \"Start\"" >> ${Linux_Output}${curl_shell_file} 
  echo "cnt_of_read=0" >> ${Linux_Output}${curl_shell_file} 
  echo "cnt_of_sent=0" >> ${Linux_Output}${curl_shell_file} 
  echo "cnt_of_fail=0" >> ${Linux_Output}${curl_shell_file} 

  read_cnt=0
  cat ${Linux_Output}${unsent_file} | while read aline 
  do
    echo "curl --data 'api_key=${api_key}' --data-urlencode 'event=[${aline}]' $api_url" >> ${Linux_Output}${curl_shell_file} 
    echo "rtn_code=\$?" >> ${Linux_Output}${curl_shell_file} 
    echo "echo \"\"" >> ${Linux_Output}${curl_shell_file} 
    echo "cnt_of_read=\$((cnt_of_read+1))" >> ${Linux_Output}${curl_shell_file} 
    echo "if [ \$rtn_code -eq 0 ] ; then cnt_of_sent=\$((cnt_of_sent+1)); else cnt_of_fail=\$((cnt_of_fail+1)); fi" >> ${Linux_Output}${curl_shell_file} 
    read_cnt=$((read_cnt+1))
    ## as per Amplitude, Limit your upload to 100 batches/sec and 1000 events/sec.
    if [ "$(( read_cnt % 900 ))" -eq 0 ] ; then
      echo "sleep 3" >> ${Linux_Output}${curl_shell_file} 
      echo "echo \"\"" >> ${Linux_Output}${curl_shell_file} 
    fi
  done
  echo "echo \"End\"" >> ${Linux_Output}${curl_shell_file}
  echo "echo \"curl sending statistics - \"" >> ${Linux_Output}${curl_shell_file}
  echo "echo \"             read count - \$cnt_of_read\"" >> ${Linux_Output}${curl_shell_file}
  echo "echo \"             sent count - \$cnt_of_sent\"" >> ${Linux_Output}${curl_shell_file}
  echo "echo \"             fail count - \$cnt_of_fail\"" >> ${Linux_Output}${curl_shell_file}
  
  echo "${Linux_Output}${curl_shell_file} file statistics:"
  ls -l ${Linux_Output}${curl_shell_file} || true
  grep 'api_key=' ${Linux_Output}${curl_shell_file} | wc -l || true
  echo_processing_step ${job_name} "$Processing_Step" "Completed"
  
  Processing_Step="Execute curl shell to post unsent json file"
  echo_processing_step ${job_name} "$Processing_Step" "Started"
  bash ${Linux_Output}${curl_shell_file} | grep -v "Xferd" | grep -v "Dload" | grep -v '\-\-:\-\-:\-\-'
  echo_processing_step ${job_name} "$Processing_Step" "Completed"
  
  Processing_Step="Compress and backup curl shell file"
  echo_processing_step ${job_name} "$Processing_Step" "Started"
  gzip ${Linux_Output}${curl_shell_file} || true
  python -c "from s3_modules import s3_file_upload; s3_file_upload('${Linux_Output}${gz_shell_file}', '$Events_dwh_bucket', '$S3_Events_Archive','${arc_shell_file}')" || true
  echo_processing_step ${job_name} "$Processing_Step" "Completed"
  
fi

## step 8: compress files and backup them to s3
Processing_Step="Compress and backup csv and json file"
echo_processing_step ${job_name} "$Processing_Step" "Started"
gzip ${Linux_Output}${csv_file}        || true
gzip ${Linux_Output}${json_file}       || true
python -c "from s3_modules import s3_file_upload; s3_file_upload('${Linux_Output}${gz_csv_file}' ,    '$Events_dwh_bucket', '$S3_Events_Archive','${arc_csv_file}')"   || true
python -c "from s3_modules import s3_file_upload; s3_file_upload('${Linux_Output}${gz_json_file}',    '$Events_dwh_bucket', '$S3_Events_Archive','${arc_json_file}')"  || true
echo_processing_step ${job_name} "$Processing_Step" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
