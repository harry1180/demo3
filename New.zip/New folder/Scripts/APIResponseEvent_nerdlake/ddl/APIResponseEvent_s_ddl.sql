CREATE OR REPLACE VIEW hive.dwnl_stage.ApiResponseEvent_s AS
select 
       payload.api_response_event_id AS api_response_event_id,
       payload.header.guid AS guid,
       FROM_UNIXTIME(payload.header."timestamp" / 1000.0, 'UTC') AS event_ts,
       payload.duration_ms AS duration_ms,
       payload.endpoint AS endpoint,
       payload.request_payload AS request_payload,
       payload.response_data AS response_data,
       payload.response_meta AS response_meta,
       payload.header.environment AS environment,
       payload.header.serviceCallHeader.callerClientId as caller_client_id,
       payload.header.serviceCallHeader.referringCallerClientId as referring_caller_client_id
FROM hive.dwnl_stage.ApiResponseEvent_raw_s;

CREATE OR REPLACE VIEW hive.dwnl_stage_stageenv.ApiResponseEvent_s AS
select 
       payload.api_response_event_id AS api_response_event_id,
       payload.header.guid AS guid,
       FROM_UNIXTIME(payload.header."timestamp" / 1000.0, 'UTC') AS event_ts,
       payload.duration_ms AS duration_ms,
       payload.endpoint AS endpoint,
       payload.request_payload AS request_payload,
       payload.response_data AS response_data,
       payload.response_meta AS response_meta,
       payload.header.environment AS environment,
       payload.header.serviceCallHeader.callerClientId as caller_client_id,
       payload.header.serviceCallHeader.referringCallerClientId as referring_caller_client_id 
FROM hive.dwnl_stage_stageenv.ApiResponseEvent_raw_s;
