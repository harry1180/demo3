create table dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn
(
  incremental_in	        smallint            encode lzo
, dw_snapshot_dt	        date                encode lzo
, aflt_network_tran_id	    varchar(256)        encode lzo
, event_type_nm             varchar(300)        encode lzo
, quantity_nr               integer             encode lzo
, aflt_network_id	        integer             encode delta
, aflt_fin_tran_type_cd	    varchar(256)        encode lzo
, dw_eff_dt	                date                encode lzo
, nw_click_dt	            date                encode lzo
, tran_rev_rlzd_dt	        date                encode lzo
, tran_post_dt	            date                encode delta
, tran_click_dt	            date                encode lzo
, tran_post_ts	            timestamp           encode lzo
, tran_click_ts	            timestamp           encode lzo
, src_clicks_utc_ts	        timestamp           encode lzo
, src_prod_nm	            varchar(256)        encode lzo
, dw_site_visitor_id	    bigint              encode lzo
, dw_site_prod_sk	        varchar(256)        encode lzo
, dw_site_prod_nm	        varchar(256)        encode lzo
, prog_nm	                varchar(256)        encode lzo
, src_unique_click_id	    varchar(256)        encode lzo
, aflt_catg_nm	            varchar(256)        encode lzo
, dw_click_id	            varchar(1000)       encode lzo
, dw_click_src_id	        integer             encode lzo
, src_sys_id	            integer             encode lzo
, user_id	                varchar(256)        encode lzo
, dw_session_id	            varchar(120)        encode lzo
, dw_page_view_id	        varchar(6000)       encode lzo
, dw_suspected_bot_in	    varchar(10)         encode lzo
, logged_ip	                varchar(200)        encode lzo
, dw_click_page_sk	        bigint              encode lzo
, dw_url_sk	                bigint              encode lzo
, page_vertical_tx	        varchar(6000)       encode lzo
, page_topic_tx	            varchar(6000)       encode lzo
, dw_click_user_agent_id	integer             encode lzo
, dw_catg_nm	            varchar(256)        encode lzo
, commission_am	            numeric(10,2)       encode lzo
, merchant_am	            numeric(10,2)       encode lzo
, revenue_tran_in	        varchar(10)         encode lzo
, src_commission_am	        numeric(10,2)       encode lzo
, src_revenue_tran_in	    varchar(10)         encode lzo
, dw_last_updt_ts	        timestamp           encode lzo
, dw_last_updt_tx	        varchar(3000)       encode lzo
, dw_load_ts	            timestamp           encode lzo
)
DISTSTYLE KEY
DISTKEY (aflt_network_tran_id)
SORTKEY (dw_eff_dt)
;

GRANT ALL    ON dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn  TO group grp_etl;

drop   table dw_stage.dw_aflt_tran_consolidated_f_nopush_txn_list ;
create table dw_stage.dw_aflt_tran_consolidated_f_nopush_txn_list 
(
  aflt_network_tran_id	varchar(256) encode lzo
, aflt_network_id	      integer      encode lzo
, prog_nm	              varchar(256) encode lzo
) DISTSTYLE ALL
;

grant ALL    on dw_stage.dw_aflt_tran_consolidated_f_nopush_txn_list to group grp_etl;
grant select on dw_stage.dw_aflt_tran_consolidated_f_nopush_txn_list to group grp_data_users;

insert into dw_stage.dw_aflt_tran_consolidated_f_nopush_txn_list 
(
  aflt_network_tran_id
, aflt_network_id	    
, prog_nm	            
)
select 
  s.aflt_network_tran_id
, s.aflt_network_id	    
, s.campaign_nm as prog_nm	            
from dw_report.dw_aflt_tran_impactradius_f s
left join dw_stage.dw_aflt_tran_consolidated_f_nopush_txn_list t
on s.aflt_network_tran_id = t.aflt_network_tran_id
and s.aflt_network_id = t.aflt_network_id
and s.campaign_nm = t.prog_nm
where lower(s.campaign_nm)<> 'capital one credit cards'
  and dw_load_ts          <= cast('2017-03-28 00:45:59' as timestamp)
group by 1,2,3
;

drop   table dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list ;
create table dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list as select * from dw_report.dw_aflt_tran_consolidated_f limit 0;
grant all on dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list to group grp_etl;


drop   table dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list_arc ;
create table dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list_arc as select * from dw_report.dw_aflt_tran_consolidated_f limit 0;
alter  table dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list_arc add arc_ts timestamp encode lzo;
grant all on dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list_arc to group grp_etl;

