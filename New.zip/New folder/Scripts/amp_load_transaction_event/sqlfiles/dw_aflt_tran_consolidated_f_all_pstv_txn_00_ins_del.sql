drop table if exists temp_dw_aflt_tran_consolidated_f_deleted_txn_list ;
create temp table temp_dw_aflt_tran_consolidated_f_deleted_txn_list sortkey(aflt_network_tran_id) 
as select * from dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list;

insert into dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn
(
  incremental_in
, dw_snapshot_dt
, aflt_network_tran_id
, event_type_nm
, quantity_nr  
, aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, commission_am
, merchant_am
, revenue_tran_in
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, dw_load_ts 
)
select 
  incremental_in
, dw_snapshot_dt
, aflt_network_tran_id
, event_type_nm
, quantity_nr  
, aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, commission_am
, merchant_am
, revenue_tran_in
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, dw_load_ts 
from 
( -- sub
select 
  1                      as incremental_in
, trunc(sysdate)         as dw_snapshot_dt
, txn.aflt_network_tran_id
, 'TRANSACTION_EVENT_DELETED'   as event_type_nm 
, (- stg.rollup_txn_ct)  as quantity_nr -- zero sum the quantity_nr
, txn.aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, txn.prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, (- stg.rollup_commission_am) as commission_am
, merchant_am
, revenue_tran_in
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, dw_load_ts 
from 
(
  select * 
    , row_number() over (partition by aflt_network_tran_id,aflt_network_id,prog_nm order by dw_load_ts desc, dw_eff_dt desc) as dedup_flag
  from temp_dw_aflt_tran_consolidated_f_deleted_txn_list
) txn
inner join 
(
  select aflt_network_tran_id, aflt_network_id, prog_nm
    , sum(commission_am) as rollup_commission_am
    , sum(quantity_nr)   as rollup_txn_ct
  from dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn 
  where dw_eff_dt               >  trunc(sysdate) - 180
  group by 1,2,3
) stg
 on txn.aflt_network_tran_id = stg.aflt_network_tran_id
and txn.aflt_network_id      = stg.aflt_network_id
and txn.prog_nm              = stg.prog_nm
where txn.dedup_flag = 1
) sub
;

insert into dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list_arc 
(
  aflt_network_tran_id
, aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, dw_imprsn_id
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, commission_am
, merchant_am
, revenue_tran_in
, txn_ct
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, dw_load_ts
, arc_ts
)
select   
  aflt_network_tran_id
, aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, dw_imprsn_id
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, commission_am
, merchant_am
, revenue_tran_in
, txn_ct
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, dw_load_ts
, sysdate as arc_ts 
from temp_dw_aflt_tran_consolidated_f_deleted_txn_list;

truncate dw_stage.dw_aflt_tran_consolidated_f_deleted_txn_list;
