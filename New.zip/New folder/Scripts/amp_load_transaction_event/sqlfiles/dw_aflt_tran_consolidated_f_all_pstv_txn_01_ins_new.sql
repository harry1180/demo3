--############################################################################################################################################
--# Modified: 05/09/2017. KM. 
--# Fixed the issue with the skew due to the rewrited of the query by redshift. The NOT IN Clause replaced with LOJ

--#  and (aflt_network_tran_id,aflt_network_id,prog_nm) not in 
--#      (select aflt_network_tran_id,aflt_network_id,prog_nm from dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn where dw_eff_dt > trunc(sysdate) - 180 group by 1,2,3)
--#  and (aflt_network_tran_id,aflt_network_id,prog_nm) not in 
--#      (select aflt_network_tran_id,aflt_network_id,prog_nm from dw_stage.dw_aflt_tran_consolidated_f_nopush_txn_list)
--#
--# LEFT OUTER JOIN and applied the conditions below.
--#
--#  and stg.aflt_network_tran_id is null
--#  and stg.aflt_network_id is null
--#  and stg.prog_nm is  null
--#  and lst.aflt_network_tran_id is null
--#  and lst.aflt_network_id is null
--#  and lst.prog_nm is  null
--#
--#This would alleviate the need for Redshift to rewrite the query.
--############################################################################################################################################


insert into dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn
(
  incremental_in
, dw_snapshot_dt
, aflt_network_tran_id
, event_type_nm
, quantity_nr  
, aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, commission_am
, merchant_am
, revenue_tran_in
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, dw_load_ts 
)
select 
  incremental_in
, dw_snapshot_dt
, aflt_network_tran_id
, event_type_nm
, quantity_nr  
, aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, commission_am
, merchant_am
, revenue_tran_in
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, dw_load_ts 
from 
( -- sub
select 
  1                      as incremental_in
, trunc(sysdate)         as dw_snapshot_dt
,  txn.aflt_network_tran_id
, 'TRANSACTION_EVENT'    as event_type_nm 
, coalesce(txn_ct, 1)    as quantity_nr 
,  txn.aflt_network_id
,  txn.aflt_fin_tran_type_cd
,  txn.dw_eff_dt
,  txn.nw_click_dt
,  txn.tran_rev_rlzd_dt
,  txn.tran_post_dt
,  txn.tran_click_dt
,  txn.tran_post_ts
,  txn.tran_click_ts
,  txn.src_clicks_utc_ts
,  txn.src_prod_nm
,  txn.dw_site_visitor_id
,  txn.dw_site_prod_sk
,  txn.dw_site_prod_nm
,  txn.prog_nm
,  txn.src_unique_click_id
,  txn.aflt_catg_nm
,  txn.dw_click_id
,  txn.dw_click_src_id
,  txn.src_sys_id
,  txn.user_id
,  txn.dw_session_id
,  txn.dw_page_view_id
,  txn.dw_suspected_bot_in
,  txn.logged_ip
,  txn.dw_click_page_sk
,  txn.dw_url_sk
,  txn.page_vertical_tx
,  txn.page_topic_tx
,  txn.dw_click_user_agent_id
,  txn.dw_catg_nm
,  txn.commission_am
,  txn.merchant_am
,  txn.revenue_tran_in
,  txn.src_commission_am
,  txn.src_revenue_tran_in
,  txn.dw_last_updt_ts
,  txn.dw_last_updt_tx
,  txn.dw_load_ts 
, row_number() over (partition by  txn.aflt_network_tran_id, txn.aflt_network_id, txn.prog_nm order by  txn.dw_load_ts desc,  txn.dw_eff_dt desc) as dedup_flag
from dw_report.dw_aflt_tran_consolidated_f txn
LEFT OUTER JOIN 
  dw_stage.dw_aflt_tran_consolidated_f_all_pstv_txn stg
 on txn.aflt_network_tran_id = stg.aflt_network_tran_id
  and txn.aflt_network_id      = stg.aflt_network_id
  and txn.prog_nm              = stg.prog_nm
  and stg.dw_eff_dt > trunc(sysdate) - 180
LEFT OUTER JOIN 
  dw_stage.dw_aflt_tran_consolidated_f_nopush_txn_list lst
 on txn.aflt_network_tran_id = lst.aflt_network_tran_id
  and txn.aflt_network_id      = lst.aflt_network_id
  and txn.prog_nm              = lst.prog_nm
where lower(txn.revenue_tran_in)  =  'true' 
  and txn.aflt_network_id        <>  -999999999
  and (trim(txn.user_id)         <>  '' 
    or txn.dw_site_visitor_id    <>  -999999999
      )
  and txn.dw_eff_dt               >  trunc(sysdate) - 180 
  and stg.aflt_network_tran_id is null
  and stg.aflt_network_id is null
  and stg.prog_nm is  null
  and lst.aflt_network_tran_id is null
  and lst.aflt_network_id is null
  and lst.prog_nm is  null
 ) sub
where dedup_flag = 1
;
