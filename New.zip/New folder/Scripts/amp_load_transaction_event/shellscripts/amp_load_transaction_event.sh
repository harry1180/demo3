job_name='amp_load_transaction_event'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_chef_credentials_file_dir}/passwords.ctrl
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

Processing_Step="Create incremental data inside Redshift"
echo_processing_step ${job_name} "$Processing_Step" "Started"
echo "dw_aflt_tran_consolidated_f_all_pstv_txn_00_ins_del.sql
dw_aflt_tran_consolidated_f_all_pstv_txn_01_ins_new.sql
dw_aflt_tran_consolidated_f_all_pstv_txn_02_ins_exs.sql
dw_aflt_tran_consolidated_f_all_pstv_txn_99_ayz.sql" | while read script other_var
do
  echo_processing_step ${job_name} "$script" "Started"
  bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/${script} 
  echo_processing_step ${job_name} "$script" "Completed"
done
echo_processing_step ${job_name} "$Processing_Step" "Completed"

Processing_Step="DQ check snapshot data before uploading to Amplitude"
echo_processing_step ${job_name} "$Processing_Step" "Started"
echo "dw_aflt_tran_snapshot_check.json" | while read script other_var
do
  Processing_Step="DQ check - ${script}"
  echo_processing_step ${job_name} "${Processing_Step}" "Started"
  python ${dwh_common_base_dir}/run_dq_check.py ${dwh_scripts_base_dir}/${job_name}/pythonscripts/${script}
  echo_processing_step ${job_name} "${Processing_Step}" "Completed"
done
echo_processing_step ${job_name} "$Processing_Step" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
