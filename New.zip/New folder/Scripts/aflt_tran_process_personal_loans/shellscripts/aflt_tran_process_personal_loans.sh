job_name='aflt_tran_process_personal_loans'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source /etc/passwords.ctrl
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+---Custom Variables--+----------+----------+'
# 'redshift_override' flag is controls the generation of redshift file in addition to the Hive partitions.
# if 'redshift_override' = 'no': redshift file will only be generated if no other redshift file has been generated for the day.
# if 'redshift_override' = 'yes': redshift file will always be generated.
# Defaults to 'no'
if [ -z $1 ] ; then
  redshift_override='no'
else
  redshift_override=`echo "$1" | tr '[:upper:]' '[:lower:]'`
fi

# 'sql_engine' flag is used to select between redshift/Hive file generation.
# if 'sql_engine' = 'all': both Redshift file & Hive partitions are generated.
# if 'sql_engine' = 'redshift': only Redshift file is generated (behavior similar to 'redshift_override' = 'yes')
# if 'sql_engine' = 'nerdlake': only Nerdlake/Hive partitions are generated.
# Defaults to 'all'
if [ -z $2 ] ; then
  sql_engine='all'
else
  sql_engine=`echo "$2" | tr '[:upper:]' '[:lower:]'`
fi

# 'hive_write_mode' controls whether to append or over-write existing partitions.
# if 'hive_write_mode' = 'append' : new partitions will be appended to existing partitions.
# if 'hive_write_mode' = 'overwrite' : new partitions will overwrite same existing partitions.
# Defaults to 'append'
if [ -z $3 ] ; then
   hive_write_mode='append'
else
  hive_write_mode=`echo "$3" | tr '[:upper:]' '[:lower:]'`
fi

s3bucketFolder="aflt_tran_process_personal_loans"
wildcard="."
aflt_tran_id=25
hivefile_format="orc"
vertical="pl"

Linux_Base=$dwh_data_base_dir

echo 's3bucketFolder           :-   '${s3bucketFolder}
echo 'aflt_tran_id 	       :-   '${aflt_tran_id}
echo 'vertical		       :-   '${vertical}
echo 'redshift_override	       :-   '${redshift_override}
echo 'sql_engine	       :-   '${sql_engine}
echo 'hive_write_mode	       :-   '${hive_write_mode}
echo 'hivefile_format	       :-   '${hivefile_format}
echo 'Linux_Base	       :-   '${Linux_Base}
echo 'S3_Events_Archive	       :-   '${S3_Events_Archive}

echo '+----------+----------+----------+----------+----------+----------+'
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning data directories:" "Started"
find $Linux_Input -type f -delete || true
find $Linux_Output -type f -delete || true
echo_processing_step ${job_name} "Cleaning data directories:" "Completed"

echo_processing_step ${job_name} "Download raw files from S3" "Started"
python -c "from s3_modules import s3_file_download_wildcard_search; s3_file_download_wildcard_search('$Events_dwh_bucket','$S3_Events_Input','$wildcard','$Linux_Input','$S3_Events_Archive')" || true
echo_processing_step ${job_name} "Download raw files from S3" "Completed"

echo_processing_step ${job_name} "Transforming the files and moving them to S3 Bucket" "Started"
python ${dwh_common_base_dir}/nw_python_modules/lender_transformer/process_raw_to_confirmed_files.py $Linux_Input $Events_dwh_bucket $s3bucketFolder ${dwh_scripts_base_dir}/aflt_tran_nerdlake/pythonscripts/email_info.json $vertical $aflt_tran_id true $hivefile_format $hive_write_mode $redshift_override $sql_engine $Linux_Base
echo_processing_step ${job_name} "Transforming the files and moving them to S3 Bucket" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
