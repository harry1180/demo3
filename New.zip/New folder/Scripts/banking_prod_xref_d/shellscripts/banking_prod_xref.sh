source /data/etl/Scripts/banking_prod_xref_d/shellscripts/banking_prod_xref.ctrl

input_date="$(date +'%Y%m%d%H%M%S')"

rm -f $Linux_Input*banking_prod_xref*

rm -f $S3_Input*banking*

bash /data/etl/Common/mysql_linux_copy_function.sh /data/etl/Scripts/banking_prod_xref_d/sqlfiles/banking_prod_download.sql $Linux_Input/banking_prod_xref.csv

gzip $Linux_Input*.csv

mv $Linux_Input*.gz $S3_Input

query_stage_delete="delete from dw_stage.banking_prod_xref_s;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"

bash /data/etl/Common/redshift_copy_function.sh dw_stage.banking_prod_xref_s /banking_prod_xref_d/input/ banking_prod_xref

query_target_delete="delete from dw_report.banking_prod_xref_d;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_target_delete"

bash /data/etl/Common/redshift_sql_function.sh /data/etl/Scripts/banking_prod_xref_d/sqlfiles/banking_prod_xref_load.sql

bash /data/etl/Common/redshift_sql_function.sh /data/etl/Scripts/banking_prod_xref_d/sqlfiles/banking_prod_xref_analyze.sql

