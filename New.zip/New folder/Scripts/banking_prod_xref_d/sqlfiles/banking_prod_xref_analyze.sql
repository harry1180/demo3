analyze dw_report.banking_prod_xref_d;

vacuum dw_report.banking_prod_xref_d ;
