INSERT INTO dw_report.dw_aflt_tran_link_share_prequal_f
(aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commission_am,
merchant_am,
merchant_id,
sku_num,
quantity,
order_id,
dw_load_ts)
select
aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commision_am,
merchant_am,
merchant_id,
sku_num,
quantity,
order_id,
dw_load_ts
FROM (
SELECT  a.*,
                b.aflt_network_tran_id  as record_check
FROM dw_stage.dw_aflt_tran_link_share_prequal_post_stg a
LEFT OUTER JOIN
dw_report.dw_aflt_tran_link_share_prequal_f b
ON a.aflt_network_tran_id = b.aflt_network_tran_id
AND a.aflt_network_id = b.aflt_network_id)
WHERE
record_check is null;
