import sys
import logging
import sys
import requests
import json
import xml.etree.cElementTree as ET
import csv
import time
import codecs
import os
import lxml.etree 
import urlparse
from nw_retry import nw_retry, REQUEST_EXCEPTIONS


logger = logging.getLogger()
logger.setLevel(logging.INFO)

# stream handler
sh = logging.StreamHandler()
sh.setLevel(logging.DEBUG)
logger.addHandler(sh)

@nw_retry(REQUEST_EXCEPTIONS, tries=2, delay=30, backoff=2)
def cj_get_request(url):
	r = requests.get(url,headers={"authorization":"0091a58a92d3348ca4cdec058fe34fc0a0802b3c54f9de27188c5b318f1d83da2e80400eef03a47147052a015085a677222fa0ba95cfe06ee91035242ccb3dd38b/7b6c4e570816230d51d7ae0af635526670d6b2c4cc0ddf11a5776e32fa6f0ec74ba4caec0271417c64eb03674c0c9acf2a7771dce636067b4af7b0c90d6e20a9"}, allow_redirects=True, timeout=180, stream=True)
	r.raise_for_status()
	return r

@nw_retry(REQUEST_EXCEPTIONS, tries=7, delay=30, backoff=2)
def ir_get_request(session, api_url):
    """
    GET request, returns JSON response. Uses nw_retry decorator for automatic retries.
    """
    response = session.get(api_url, timeout=60)
    response.raise_for_status()
    return response	

@nw_retry(REQUEST_EXCEPTIONS, tries=2, delay=30, backoff=2)
def ls_get_request(url):
	r = requests.get(url, allow_redirects=True, timeout=180, stream=True)
	r.raise_for_status()
	return r

def ir_api_handler(base_url, sid, from_date, to_date, page_size=1000):
    """
    Pull data from api for given date range
    :param from_date: str, start date (YYYY-mm-dd)
    :param to_date: str, end date (YYYY-mm-dd)
    :param page_size: int, number of items per page (max is 1000)
    :return: list, list of dicts that includes all data from range
    """

    # start request session
    session = requests.Session()

    run_url = None
    total_pages = None
    paginate = True
    data_output = []
    while paginate:

        # process first page
        if not run_url:
            run_url = '{0}/Mediapartners/{1}/Actions.json?ActionDateStart={2}T00:00:00-08:00&ActionDateEnd={3}T00:00:00-08:00&PageSize={4}'.format(base_url, sid, from_date, to_date, page_size)
        response = ir_get_request(session, run_url)

        response_dict = response.json()

        if not total_pages:
            total_pages = int(response_dict['@numpages'])
            if total_pages == 0:
                return data_output
        current_page = int(response_dict['@page'])

        logger.info('Processing page {} of {}'.format(str(current_page), str(total_pages)))
        # Collect response contents
        for action in response_dict['Actions']:
            data_output.append(action)

        # exit condition, all pages processed
        if current_page == total_pages:
            paginate = False

        # get url for next page
        else:
            run_url = '{base}{uri}'.format(base=base_url, uri=response_dict['@nextpageuri'])

    return data_output

def ir_api(out_file, from_dt, to_dt, api_sid, api_key):
	base_url = 'https://{sid}:{token}@api.impactradius.com'.format(sid=api_sid, token=api_key)
	with open(out_file, 'w') as csv_outfile:
		writer = csv.writer(csv_outfile)
		count = 0
        	for row in ir_api_handler(base_url, api_sid, from_dt, to_dt):
			if count == 0:
				header = [x.encode('UTF8') for x in row.keys()]
				writer.writerow(header)
				count = 1
			val = [x.encode('UTF8') for x in row.values()]
			writer.writerow(val)

def cj_api(out_file, from_dt, to_dt):
	url = "https://commission-detail.api.cj.com/v3/commissions?date-type=posting&start-date="+from_dt+"&end-date="+to_dt
        r = cj_get_request(url)
	header = ('action-status', 'action-tracker-id', 'action-tracker-name', 'action-type', 'advertiser-name', 'aid', 'cid', 'commission-amount', 'commission-id', 'country', 'event-date', 'is-cross-device', 'locking-date', 'order-discount', 'order-id', 'original', 'original-action-id', 'posting-date', 'sale-amount', 'sid', 'website-id')
	with open(out_file,'w') as f:
		writer = csv.writer(f)
		writer.writerow(header)
		root = lxml.etree.fromstring(r.text.encode('ascii','ignore'))
		for child in root.iter('commission'):
			action_status = child.find('action-status').text
			action_tracker_id = child.find('action-tracker-id').text
			action_tracker_nm = child.find('action-tracker-name').text
			action_type = child.find('action-type').text
			ad_name = child.find('advertiser-name').text
			aid = child.find('aid').text
			cid = child.find('cid').text
			comm_am = child.find('commission-amount').text
			comm_id = child.find('commission-id').text
			cntry = child.find('country').text
			event_dt = child.find('event-date').text
			cross_dvc = child.find('is-cross-device').text
			locking_dt = child.find('locking-date').text
			order = child.find('order-discount').text
			order_id = child.find('order-id').text
			original = child.find('original').text
			orig_action_id = child.find('original-action-id').text
			posting_dt = child.find('posting-date').text
			sale_am = child.find('sale-amount').text
			sid = child.find('sid').text
			web_id = child.find('website-id').text
			row = action_status, action_tracker_id, action_tracker_nm, action_type, ad_name, aid, cid, comm_am, comm_id, cntry, event_dt, cross_dvc, locking_dt, order, order_id, original, orig_action_id, posting_dt, sale_am, sid, web_id 
			writer.writerow(row)

def ls_api(output_file, from_dt, to_dt, api_key):

	url_base = 'https://ran-reporting.rakutenmarketing.com/en/reports/signature-orders-report/'
	url_filters = 'filters?start_date=' + from_dt + '&end_date=' + to_dt + '&include_summary=N&network=1&tz=GMT&date_type=process&token=' + api_key
	url = urlparse.urljoin(url_base, url_filters)

	api_file = output_file.split('.')[0] + '.tmp'

	r = ls_get_request(url)
	
	with open(api_file,'w') as f:
		for chunk in r.iter_content(chunk_size=102400):
			f.write(chunk)
	
	with open(api_file,'r') as apiin:
		filereader = csv.reader(apiin, delimiter=',', quoting=csv.QUOTE_MINIMAL)
		with open(output_file, 'w') as writefile:
			filewriter = csv.writer(writefile)
			for line in filereader:
				filewriter.writerow(line)

def main(output_dir, lender, from_dt, to_dt, api_sid, api_key):

	out_file = os.path.join(output_dir, lender + '_' + time.strftime("%d-%m-%y") + '.csv')

	print '******Executing Python Script for following parameters ***********************'
        print 'Lender: {}\nDate range for API call:\nStart Date: {}\nEnd Date: {}\nOutput file: {}'.format(lender, from_dt, to_dt, out_file)

	if lender == 'commission_junction':
		cj_api(out_file, from_dt, to_dt)
	if lender in ('impact_radius', 'amex_ir'):
		ir_api(out_file, from_dt, to_dt, api_sid, api_key)
	if lender in ('linkshare_coupons','linkshare_prequal'):
		ls_api(out_file, from_dt, to_dt, api_key)

if __name__ == '__main__':
	output_dir = sys.argv[1]
	lender = sys.argv[2]
	from_dt = sys.argv[3]
	to_dt = sys.argv[4]
	try:
		api_key = sys.argv[5]
	except:
		api_key=None
	try:
		api_sid = sys.argv[6]
	except:
		api_sid=None
	main(output_dir, lender, from_dt, to_dt, api_sid, api_key)

