job_name='aflt_tran_cc_consumertrack'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source /etc/passwords.ctrl
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+---Custom Variables--+----------+----------+'
to_date=`(date +'%Y%m%d')`
s3_bucketname=$Events_dwh_bucket
s3bucketFolder="aflt_process_email_attachments/output/"
s3ArchivePath="aflt_process_email_attachments/archive/"
wildcard="consumertrack_cc*"
File_Search="consumertrack_cc"
aflt_tran_id=23

echo 'wildcard                         :-   '${wildcard}
echo 's3_bucketname                    :-   '${s3_bucketname}
echo 's3bucketFolder                   :-   '${s3bucketFolder}
echo 's3bucketFolder                   :-   '${s3bucketFolder}
echo 'File_Search                      :-   '${File_Search}
echo 's3bucketFolder                   :-   '${s3bucketFolder}
echo 's3ArchivePath                    :-   '${s3ArchivePath}
echo 'aflt_tran_id                     :-   '${aflt_tran_id}
echo '+----------+----------+----------+----------+----------+----------+'
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning S3 and data direcotried:" "Started"
find $Linux_Input -name \*.csv -exec rm {} \; || true
find $Linux_Input -name \*.json -exec rm {} \; || true
python -c "from s3_modules import delete_key; delete_key('$S3_Events_Input','$s3_bucketname','${wildcard}')" || true
python -c "from s3_modules import delete_key; delete_key('$S3_Events_Output','$s3_bucketname','${wildcard}')" || true
echo_processing_step ${job_name} "Cleaning S3 and data direcotries:" "Completed"

echo_processing_step ${job_name} "Setting up variables for downloading the files locally" "Started"
echo "S3bucket:"$s3_bucketname" S3folder:"$s3bucketFolder" s3ArchivePath:"$s3ArchivePath" Linux_Input:"$Linux_Input
echo_processing_step ${job_name} "Setting up variables for downloading the files locally" "Completed"


echo_processing_step ${job_name} "Running python script to download the files" "Started"
python -c "from s3_modules import s3_file_download_wildcard_search; s3_file_download_wildcard_search('$s3_bucketname','$s3bucketFolder','$File_Search','$Linux_Input','$s3ArchivePath')" || true
echo_processing_step ${job_name} "Running python script to download the files" "Completed"


echo_processing_step ${job_name} "Renaming the files to remove spaces in file name" "Started"
for f in "$Linux_Input"$wildcard
        do
        if [ -f "$f" ]
                        then
                                echo_processing_step ${job_name} "File Exists continuing through the process" "Started"
                                
                                echo_processing_step ${job_name} "DQ Process" "Started"
                                fileid=$(date +%s%N)
                                echo_processing_step ${job_name} "DQ Process" "Completed"

                                echo_processing_step ${job_name} "Generating output and input file names" "Started"
                                outfile_prefix=$(echo $f | cut -f1 -d.)
                                input_csv_file=$f
                                output_json_file=${outfile_prefix}.json
								echo "Output Json File: " $output_json_file
                                output_json_file_daily=$outfile_prefix_Daily.json
                                echo_processing_step ${job_name} "Generating output and input file names" "Completed"


                                echo_processing_step ${job_name} "Running python script to convert csv to json" "Started"
                                python -c "from excelutils import  csv2json; csv2json('$input_csv_file','$output_json_file',ignoreheadercase=True)" || true
                                echo_processing_step ${job_name} "Running python script to convert csv to json" "Completed"
                               

                                echo_processing_step ${job_name} "Moving the json File to S3" "Started"
                                python -c "from s3_modules import s3_file_upload; s3_file_upload('${output_json_file}',    '$Events_dwh_bucket', '$S3_Events_Output')"  || true
                                echo_processing_step ${job_name} "Moving the json File to S3" "Completed"

                                echo_processing_step ${job_name} "Archiving S3 files" "Started"
                                python -c "from s3_modules import s3_file_upload; s3_file_upload('${output_json_file}',    '$Events_dwh_bucket', '$S3_Events_Archive')"  || true  
                                echo_processing_step ${job_name} "Archiving S3 files" "Completed"

                                echo_processing_step ${job_name} "Delete the data from Stage Table" "Started"
                                query_stage_delete="delete from dw_stage.aflt_tran_fidelity;"
                                psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
                                echo_processing_step ${job_name} "Delete the data from Stage Table" "Completed"
                                

                                
				echo_processing_step ${job_name} "Loading data to stage table using copy command" "Started"                                
                                query_stage_load="copy dw_stage.aflt_tran_fidelity from '"$s3_bucket_name"/$job_name/output/' credentials '$s3_prod_load_creds' JSON as '"$s3_bucket_name"/json/aflt_transactions/aflt_tran_cc_fidelity.jsonpaths' DATEFORMAT AS 'auto' TRUNCATECOLUMNS BLANKSASNULL ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF;"
                                psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query_stage_load"
                                echo_processing_step ${job_name} "Loading data to stage table using copy command" "Completed"
                                


                                echo_processing_step ${job_name} "DQ Process" "Started"
                                #audit_update='update dw_report.ctl_aflt_process_email_attachments set Status='"'"'Completed'"'"', stg_cnt=(select count(1) from dw_stage.aflt_tran_sindeo) where fileid='$fileid''
                               # psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$audit_update"
                                echo_processing_step ${job_name} "DQ Process" "Completed"

                                echo_processing_step ${job_name} "Insert/Update the data to fact Table" "Started"
                                bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/$job_name/sqlfiles/$job_name.sql
                                echo_processing_step ${job_name} "Insert/Update the data to fact Table" "Completed"

                                echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Started"
                                python -c "from tran_log_modules import insert_log; insert_log($aflt_tran_id);"
                                echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Completed"
                     else
                                echo "File Doesnt Exists"
                fi
        done

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
