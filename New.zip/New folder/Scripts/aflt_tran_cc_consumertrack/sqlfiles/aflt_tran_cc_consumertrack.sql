INSERT INTO dw_report.dw_aflt_tran_credit_cards_f
(
  aflt_network_tran_id,
  aflt_network_id,
  aflt_fin_tran_type_cd,
  dw_eff_dt,
  tran_post_dt,
  tran_click_dt,
  tran_approved_dt,
  tran_start_dt,
  tran_application_dt,
  tran_post_ts,
  tran_click_ts,
  tran_approved_ts,
  tran_start_ts,
  tran_application_ts,
  src_prod_nm,
  dw_site_visitor_id,
  dw_site_prod_sk,
  dw_site_prod_nm,
  prog_nm,
  src_unique_click_id,
  aflt_catg_nm,
  dw_click_id,
  dw_click_src_id,
  src_sys_id,
  dw_catg_nm,
  commission_am,
   src_column_1        ,
   src_column_2               ,
   src_clicks_utc_ts,
   dw_session_id,
   dw_click_page_sk,
   dw_click_user_agent_id,
  dw_load_ts
)
SELECT f_str_uuid() AS aflt_network_tran_id,
       23 AS aflt_network_id,
       Case when cast(dw_stage.aflt_tran_fidelity.cpl as Integer)=0 then 'Denied'
            when cast(dw_stage.aflt_tran_fidelity.cpl as Integer)>0 and cast(dw_stage.aflt_tran_fidelity.cpl as Integer)<100 then 'Pending Approved'
            when cast(dw_stage.aflt_tran_fidelity.cpl as Integer)>=100 then 'Instant Approved'
            else 'Started' end as aflt_fin_tran_type_cd,
       to_date(trim(created),'YYYY-MM-DD') AS dw_eff_dt,
       to_date(trim(created),'YYYY-MM-DD') AS tran_post_dt,
       to_date(trim(created),'YYYY-MM-DD') AS tran_click_dt,
       null AS tran_approval_dt,
       null AS tran_start_dt,
       null AS tran_application_dt,
       to_date(trim(created) ,'YYYY-MM-DD HH24:MI:SS') AS tran_post_ts,
       to_date(trim(created),'YYYY-MM-DD HH24:MI:SS') AS tran_click_ts,
       null AS tran_approval_ts,
       null AS tran_start_ts,
       null AS tran_application_ts,
       'Fidelity' AS src_prod_nm,
       '-999999999' AS dw_site_visitor_id,
       '-999999999' AS dw_site_prod_sk,
       'Could not Identify the right product to this Transaction' AS dw_site_prod_nm,
       'Fidelity'  AS prog_nm,
       dw_stage.aflt_tran_fidelity.subid AS src_unique_click_id,
       'Credit Cards' AS aflt_catg_nm,
       'Not Fount In Clicks' AS dw_click_id,
       -999999999 AS dw_click_src_id,
       1 AS src_sys_id,
       NULL AS dw_catg_nm,
       dw_stage.aflt_tran_fidelity.cpl AS commission_am,
       dw_stage.aflt_tran_fidelity.campaignid as src_column_1        ,
       dw_stage.aflt_tran_fidelity.ip as src_column_2                ,      
       null as click_utc_ts,
       null as dw_session_id   ,
       -1   ,
       1,
       sysdate
FROM dw_stage.aflt_tran_fidelity
/*LEFT OUTER JOIN (SELECT min(click_utc_ts) as click_utc_ts, min(dw_session_id) as dw_session_id, min(dw_page_sk) as dw_page_sk, min(dw_user_agent_id) as dw_user_agent_id, min(dw_site_visitor_id) as dw_site_visitor_id, min(dw_site_prod_sk) as dw_site_prod_sk , min(src_prod_nm) as src_prod_nm, min(dw_click_id) as dw_click_id, min(dw_src_sys_id) as dw_src_sys_id, src_unique_click_id
                   FROM dw_report.dw_clicks_event_f
                   WHERE dw_src_sys_id in (1)
                   group by src_unique_click_id ) clicks_event_personal_loans ON coalesce(dw_stage.aflt_tran_fidelity.subid,'NA') = coalesce(clicks_event_personal_loans.src_unique_click_id,'UNKNOWN')
  */
LEFT OUTER JOIN dw_report.dw_aflt_tran_credit_cards_f target
                ON
   coalesce(target.tran_click_ts,sysdate) = coalesce(to_date(trim(dw_stage.aflt_tran_fidelity.created),'YYYY-MM-DD HH24:MI:SS')  ,sysdate)
  and coalesce(trim(target.src_unique_click_id),'##') = coalesce(trim(dw_stage.aflt_tran_fidelity.subid),'##')
  and lower(trim(target.src_column_1))=lower(trim(dw_stage.aflt_tran_fidelity.campaignid))
WHERE target.src_unique_click_id is null and target.aflt_fin_tran_type_cd is null ;
