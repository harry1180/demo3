job_name='aflt_tran_process_investing'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+---Custom Variables--+----------+----------+'
vertical="investing"
aflt_network_id=38
s3_raw_dir="aflt_process_email_attachments"
s3_cleaned_dir="aflt_tran_process_investing"
fetch_files="True"

echo 'vertical                   :-   '${vertical}
echo 'aflt_network_id            :-   '${aflt_network_id}
echo 's3_dir                     :-   '${s3_cleaned_dir}
echo 'fetch_files                :-   '${fetch_files}
echo '+----------+----------+----------+----------+----------+----------+'
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning S3 and data directories:" "Started"
rm -f ${Linux_Output}* || true
rm -f ${Linux_Input}*  || true
echo_processing_step ${job_name} "Cleaning S3 and data directories:" "Completed"

echo_processing_step ${job_name} "Download lender raw files from S3" "Started"
python -c "from lender_transformer.lender_utils import fetch_input_files; fetch_input_files('$vertical', '$Events_dwh_bucket', '$s3_raw_dir', '$Linux_Input')"
echo_processing_step ${job_name} "Download lender raw files from S3" "Completed"

echo_processing_step ${job_name} "Transforming the files and moving them to S3 Bucket" "Started"
python ${dwh_common_base_dir}/nw_python_modules/lender_transformer/process_raw_to_confirmed_files.py $Linux_Input $Events_dwh_bucket $s3_cleaned_dir ${dwh_scripts_base_dir}/${job_name}/pythonscripts/email_info.json $vertical $aflt_network_id
echo_processing_step ${job_name} "Transforming the files and moving them to S3 Bucket" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
