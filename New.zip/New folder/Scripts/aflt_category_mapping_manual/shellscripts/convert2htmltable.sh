nawk 'BEGIN{
FS="\t"
print "Please validate the below records in the table dw_report.dw_aflt_category_map. Once the validation is done please make sure to change the validated_in to YES and the change will take into effect from next days load."
print "Detailed process to update the table can be found here : https://nerdwallet.atlassian.net/wiki/display/BIZANA/dw_aflt_category_map"
print  "<HTML>""<TABLE border="1"><TH>SRC_AFLT_PROD_NM</TH><TH>SRC_AFLT_PROG_NM</TH><TH>SRC_AFLT_CATG_NM</TH><TH>SRC_SYS_ID</TH><TH>VALIDATED_CATG_NM</TH><TH>VALIDATED_IN</TH><TH>VALIDATED_BY_NM</TH><TH>PAGE_PATH</TH><TH>DW_SITE_PROD_NM</TH><TH>RECORDS_AFFECTED</TH><TH>DW_LOAD_TS</TH>" 
}
 {
printf "<TR>"
for(i=1;i<=NF;i++)
printf "<TD>%s</TD>", $i
print "</TR>"
 }
END{
print "</TABLE></BODY></HTML>"
 }
' /data/etl/Data/aflt_category_mapping_manual/input/aflt_catg_non_map.csv > /data/etl/Data/aflt_category_mapping_manual/input/out_aflt_catg_non_map.html
