('SELECT a.src_aflt_prod_nm,
       a.src_aflt_prog_nm,
       a.src_aflt_catg_nm,
       a.src_sys_id,
       a.validated_catg_nm,
       a.validated_in,
       a.valiadated_by_nm,
       b.page_path,
       b.dw_site_prod_nm,
       COALESCE(b.record_count,0) AS TOAL_EFFECTED_RECORDS,
       dw_load_ts
FROM (SELECT src_aflt_prod_nm,
             src_aflt_prog_nm,
             src_aflt_catg_nm,
             src_sys_id,
             validated_catg_nm,
             validated_in,
             valiadated_by_nm,
             dw_load_ts
      FROM dw_report.dw_aflt_category_map
      WHERE validated_in = \'NO\'
      ORDER BY src_sys_id) a
  LEFT OUTER JOIN (
      SELECT *
      FROM (SELECT z.*,
             rank() OVER(PARTITION BY src_prod_nm , prog_nm, aflt_catg_nm ORDER BY record_count DESC) rnk
            FROM (SELECT c.src_prod_nm,
                   c.prog_nm,
                   c.aflt_catg_nm,
                   u.conf_page_path_tx as page_path,
                   c.dw_site_prod_nm,
                   COUNT(*) AS record_count
                   FROM dw_report.dw_aflt_tran_consolidated_f AS c
                   LEFT OUTER JOIN dw_report.dw_page_d AS u
                   on u.dw_page_sk = c.dw_click_page_sk
                   where c.dw_eff_dt >SYSDATE- 180
                   GROUP BY 1,
                            2,
                            3,
                            4,
                            5) z  
              ) d
      WHERE rnk=1) b
      ON a.src_aflt_prod_nm = b.src_prod_nm
      AND a.src_aflt_prog_nm = b.prog_nm
      AND a.src_aflt_catg_nm = b.aflt_catg_nm
      WHERE  b.record_count > 0
ORDER BY TOAL_EFFECTED_RECORDS DESC')
