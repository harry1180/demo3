As of initial implementation, DataOps needs to create dynamodb resources.  Requested:

On production, please create dynamodb table dwh-url-monitor.  Its primary key should be 'url' as a string, with no sort key, using other default (same as admin ui) settings.  This table should have all permissions (put, update, get, query, etc) granted to all dwh nodes AND to the analytics AWS role.  It's okay if table create/drop is not granted.  

-----

(awscli)mbhatt@east1-prod-dwhadmin-5:~$ aws dynamodb describe-table --table-name dwh-url-monitor
{
    "Table": {
        "TableArn": "arn:aws:dynamodb:us-east-1:585529207810:table/dwh-url-monitor",
        "AttributeDefinitions": [
            {
                "AttributeName": "url",
                "AttributeType": "S"
            }
        ],
        "ProvisionedThroughput": {
            "NumberOfDecreasesToday": 0,
            "WriteCapacityUnits": 5,
            "ReadCapacityUnits": 5
        },
        "TableSizeBytes": 0,
        "TableName": "dwh-url-monitor",
        "TableStatus": "ACTIVE",
        "KeySchema": [
            {
                "KeyType": "HASH",
                "AttributeName": "url"
