job_name='aflt_tran_nerdlake'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+---Custom Variables--+----------+----------+'
# ********************ALL POSTSTAGE VARIABLE SHOULD BE DEPRECATED WITH SPARK*********************
s3_nerdlake_bucket="east1-prod-nerdlake-0"
# s3_nerdlake_stg to be changed to 'dwnl_rcd_aflt_tran_stage/aflt_tran_process_files' with SPARK
s3_nerdlake_stg="dwnl_rcd_aflt_tran_stage/aflt_tran_process_files_non_spark/"
s3_nerdlake_post_stg="dwnl_rcd_aflt_tran_stage/aflt_tran_post_stg_non_spark/"
s3_nerdlake_fct="dwnl_rcd_aflt_tran_data/dw_aflt_tran_consolidated_f_non_spark/"
email_json_template="${dwh_scripts_base_dir}/aflt_tran_nerdlake/pythonscripts/email_info.json"
stage_table_nm="dwnl_rcd_aflt_tran_stage.aflt_tran_s_non_spark"
post_stage_table_nm="dwnl_rcd_aflt_tran_stage.aflt_tran_post_s_non_spark"
fact_table_nm="dwnl_rcd_aflt_tran_data.dw_aflt_tran_consolidated_f_non_spark"
# stg_file_format to be changed to 'orc' when using SPARK
stg_file_format="json"
post_stg_file_format="orc"
fact_file_format="orc"
post_stage_ins_scripts=("${dwh_scripts_base_dir}/aflt_tran_nerdlake/sqlfiles/poststage_scripts/aflt_tran_consolidated_post_stg_del.sql" "${dwh_scripts_base_dir}/aflt_tran_nerdlake/sqlfiles/poststage_scripts/aflt_tran_consolidated_post_stg_ins.sql")
fact_ins_scripts=("${dwh_scripts_base_dir}/aflt_tran_nerdlake/sqlfiles/fact_scripts/dw_aflt_tran_consolidated_f_ins.sql" "${dwh_scripts_base_dir}/aflt_tran_nerdlake/sqlfiles/fact_scripts/dw_aflt_tran_consolidated_f_ins_err.sql")
presto_script="${dwh_common_base_dir}/presto_sql_function.sh"
datadb=dwnl_rcd_aflt_tran_workarea
stagedb=dwnl_rcd_aflt_tran_workarea
if [[ $(id -un) == "airflow" ]]
then
    datadb=dwnl_rcd_aflt_tran_data
    stagedb=dwnl_rcd_aflt_tran_stage
fi


echo 's3_nerdlake_bucket               :-   '${s3_nerdlake_bucket}
echo 's3_nerdlake_stg		       :-   '${s3_nerdlake_stg}
echo 's3_nerdlake_fct		       :-   '${s3_nerdlake_fct}
echo 'email_json_template	       :-   '${email_json_template}
echo 'stage_table_nm		       :-   '${stage_table_nm}
echo 'fact_table_nm		       :-   '${fact_table_nm}
echo 'stg_file_format		       :-   '${stg_file_format}
echo 'fact_file_format		       :-   '${fact_file_format}
echo 'fact_ins_scripts		       :-   '${fact_ins_scripts}
echo 'presto script		              :-   '${presto_script}
echo 'stage db                        :- '${stagedb}
echo 'data db                         :-'${datadb}

echo '*****TO BE DEPRECATED WITH SPARK:*********'
echo 's3_nerdlake_post_stg             :-   '${s3_nerdlake_post_stg}
echo 'post_stage_table_nm              :-   '${post_stage_table_nm}
echo 'post_stg_file_format             :-   '${post_stg_file_format}
echo 'post_stage_ins_scripts           :-   '${post_stage_ins_scripts}

echo '+----------+----------+----------+----------+----------+----------+'
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

# ************************ COMMENTED OUT UNTIL WE MOVE TO SPARK****************************
#echo_processing_step ${job_name} "Calling Python script to write data to Stage and Fact - Nerdlake" "Started"
#python ${dwh_common_base_dir}/nw_python_modules/lender_transformer/load_stage_fact_hive.py $s3_nerdlake_bucket $s3_nerdlake_stg $s3_nerdlake_fct $email_json_template $stage_table_nm $fact_table_nm $file_format $presto_script ${fact_ins_scripts[@]} 
#echo_processing_step ${job_name} "Calling Python script to write data to Stage and Fact - Nerdlake" "Ended"

PARM_FILE=$(mktemp --suffix=.json --tmpdir=$Linux_Temp sql_params_XXXXXXXXXX)
echo "{" > $PARM_FILE
echo "    \"\${hivevar:stagedb}\": \"$stagedb\"," >> $PARM_FILE
echo "    \"\${hivevar:datadb}\": \"$datadb\"," >> $PARM_FILE
echo "    \"\${hivevar:start_date}\": \"$proc_date\"," >> $PARM_FILE
echo "    \"\${hivevar:end_date}\": \"$proc_date\"" >> $PARM_FILE
echo "}" >> $PARM_FILE

echo_processing_step ${job_name} "Calling Python script to write data to Stage, Post Stage and Fact - Nerdlake" "Started"
python ${dwh_common_base_dir}/nw_python_modules/lender_transformer/load_stage_fact_hive_non_spark.py $s3_nerdlake_bucket $s3_nerdlake_stg $s3_nerdlake_post_stg $s3_nerdlake_fct $email_json_template $stage_table_nm $post_stage_table_nm $fact_table_nm $stg_file_format $post_stg_file_format $fact_file_format $presto_script ${post_stage_ins_scripts[@]} ${fact_ins_scripts[@]} $PARM_FILE
echo_processing_step ${job_name} "Calling Python script to write data to Stage, Post Stage and Fact - Nerdlake" "Ended"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
