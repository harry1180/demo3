#!/usr/bin/env bash

job_name='ablogevent_plain_nerdlake'
job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

#######################################
# Main Script
#######################################

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'

if [ $1 = 'stageenv' ] ; then
    hive_stage_db="dwnl_stage_stageenv"
else
    hive_stage_db="dwnl_stage"
fi

if [ -z $2 ] ; then
  from_date="$(date -d '-2 days' +'%Y-%m-%d')"
else
  from_date="$1"
fi

if [ -z $3 ] ; then
  to_date="$(date -d '1 days' +'%Y-%m-%d')"
else
  to_date="$2"
fi

hive_stage_table="ablogevent_plain_s"

echo 'from_date                      :-   '${from_date}
echo 'to_date                        :-   '${to_date}
echo 'hive_stage_db                  :-   '${hive_stage_db}
echo 'hive_stage_table               :-   '${hive_stage_table}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Copying ablogevent_plain to nerdlake" "Started"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/copy_ablogevent_plain_to_nerdlake.py "$1" "$from_date" "$to_date"
echo_processing_step ${job_name} "Copying ablogevent_plain to nerdlake" "Completed"

echo_processing_step ${job_name} "Refreshing partitions" "Started"
hive_refresh_sql="MSCK REPAIR TABLE $hive_stage_db.$hive_stage_table"
echo $hive_refresh_sql
python -c "import nw_hive; nw_hive.exec_hive_sql_ddl(nw_hive.connect(), '$hive_refresh_sql')"
echo_processing_step ${job_name} "Refreshing partitions" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds


trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
