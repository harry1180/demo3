CREATE TABLE dwnl_data.ba_mktg_sst_additive (
    model_id                            smallint,
    attr_dw_campaign_id                 string,
    attr_dw_ad_id                       string,
    attr_trfc_src_lvl1_nm               string,
    attr_trfc_src_lvl2_nm               string,
    attr_trfc_src_lvl3_nm               string,
    attribution                         string,
    attr_utm_campaign_id                string,
    attr_utm_content_tx                 string,
    attr_utm_term_tx                    string,
    attr_mktg_img_id                    string,
    attr_mktg_place_id                  string,
    attr_mktg_hline_id                  string,
    attr_mktg_body_id                   string,
    attr_mktg_link_id                   string,
    device                              string,
    os_type                             string,
    mktg_vertical_id                    string,
    membership_status                   string,
    metric_sk                           integer,
    metric_value                        decimal(38,6),
    last_updt_tmstp                     timestamp,
    extract_ts                          timestamp
)
PARTITIONED BY (dw_eff_dt DATE)
STORED AS PARQUET
LOCATION 's3://east1-prod-nerdlake-0/dwnl_data/ba_mktg_sst_additive'

