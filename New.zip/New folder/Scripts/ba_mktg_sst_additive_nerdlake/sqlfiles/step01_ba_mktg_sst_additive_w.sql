DROP TABLE IF EXISTS ${hivevar:stagedb}.ba_mktg_sst_additive_w;

CREATE TABLE ${hivevar:stagedb}.ba_mktg_sst_additive_w
LIKE ${hivevar:datadb}.ba_mktg_sst_additive
STORED AS ORC
LOCATION 's3://east1-prod-nerdlake-0/${hivevar:stagedb}/ba_mktg_sst_additive_w/'
;
 -- Re-map all existing partitions from previous runs
MSCK REPAIR TABLE ${hivevar:stagedb}.ba_mktg_sst_additive_w;