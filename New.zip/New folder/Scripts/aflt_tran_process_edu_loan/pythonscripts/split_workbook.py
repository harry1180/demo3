# Description:      Extract the specific sheets from workbook and export it to separate (.xlsx) files.
# Sample Input :    "Citizens Bank Nerd Wallet.xlsx" with sheets - InSchool_Detail and ERL_Detail.
# Sample Output:    Citizens Bank Nerd Wallet_InSchool_Detail.xlsx
#                   Citizens Bank Nerd Wallet_ERL_Detail.xlsx

import os
import sys
import datetime
import fnmatch
import pandas as pd

VALID_INPUT_EXTS = ['.csv', '.xlsx', '.xls', '.zip', '.gzip']

def split_workbook (src_dir):
    if os.path.exists(src_dir) and os.path.isdir(src_dir):          # Validate if valid directory.
        if not os.listdir(src_dir):                                 # Validate if directory is not empty.
            print("WARNING: Directory " + src_dir + " is empty!")
            return 0
        else:                                                       # Generate list of files with valid extentions.
            files = [os.path.join(src_dir, f) for f in os.listdir(src_dir) if os.path.isfile(os.path.join(src_dir, f)) and os.path.splitext(f)[1] in VALID_INPUT_EXTS]
    else:
        print("ERROR: Directory " + src_dir + " does not exists!")
        return 1


    lender_sheets={
        "Citizen":['InSchool_Detail','ERL_Detail'],
        "CollegeAve":['InSchool_Data','Refi_Data']}                 # Update this dictionary for new lenders.

    for lender in lender_sheets:
        print("-----------------Started the processing for lender = {} -----------------").format(lender)
        sheets = lender_sheets[lender]
        for in_file in files:
            print("in_file=" + in_file)

            rstr="*" + lender + "*"
            if fnmatch.fnmatch(in_file, rstr):                      # Process the files which has lender name as part of file name.
                xlsx = pd.ExcelFile(in_file)
                for sheet in sheets:
                   df1=pd.read_excel(in_file,sheetname=sheet)
                   out_file=src_dir + os.path.basename(in_file).rsplit('.', 1)[0]  + '_' + sheet + '.xlsx'
                   df1.to_excel(out_file,index=False)
                   result=pd.read_excel(out_file)
                   print("INFO: Successfully created file {}.").format(out_file)

if __name__ == '__main__':
    src_dir = sys.argv[1]
    split_workbook(src_dir)
