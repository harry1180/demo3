MSCK REPAIR TABLE ${hivevar:stagedb}.${hivevar:tablename};
