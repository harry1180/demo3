DROP TABLE IF EXISTS dwnl_stage.BackendModelExecutionEvent_raw_s;
DROP TABLE IF EXISTS dwnl_stage_stageenv.BackendModelExecutionEvent_raw_s;

CREATE EXTERNAL TABLE dwnl_stage.BackendModelExecutionEvent_raw_s (
  envelope STRUCT<exchangeId:STRING, id:STRING, type:STRING, subtype:STRING>,
  payload STRUCT<
    header:STRUCT<
      eventName:STRING,
      `timestamp`:BIGINT,
      guid:STRING,
      environment:STRING,
      serviceCallHeader:STRUCT<
        callerClientId:STRING,
        referringCallerClientId:STRING
      >
    >,
    model_execution_event_id:STRING,
    parent_event_id:STRING,
    parent_event_type:STRING,
    meta:STRING,
    inputs:STRING,
    outputs:STRING
  >
)
PARTITIONED BY (dw_eff_dt DATE)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES (
  "ignore.malformed.json" = "true"
  -- "mapping.event_name" = "envelope.exchangeId" does not work for nested values
)
LOCATION 's3://east1-prod-nerdlake-0/dwnl_stage/BackendModelExecutionEvent_s/';

CREATE EXTERNAL TABLE dwnl_stage_stageenv.BackendModelExecutionEvent_raw_s (
  envelope STRUCT<exchangeId:STRING, id:STRING, type:STRING, subtype:STRING>,
  payload STRUCT<
    header:STRUCT<
      eventName:STRING,
      `timestamp`:BIGINT,
      guid:STRING,
      environment:STRING,
      serviceCallHeader:STRUCT<
        callerClientId:STRING,
        referringCallerClientId:STRING
      >
    >,
    model_execution_event_id:STRING,
    parent_event_id:STRING,
    parent_event_type:STRING,
    meta:STRING,
    inputs:STRING,
    outputs:STRING
  >
)
PARTITIONED BY (dw_eff_dt DATE)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES (
  "ignore.malformed.json" = "true"
)
LOCATION 's3://east1-prod-nerdlake-0/dwnl_stage_stageenv/BackendModelExecutionEvent_s/';

MSCK REPAIR TABLE dwnl_stage.BackendModelExecutionEvent_raw_s;
MSCK REPAIR TABLE dwnl_stage_stageenv.BackendModelExecutionEvent_raw_s;
