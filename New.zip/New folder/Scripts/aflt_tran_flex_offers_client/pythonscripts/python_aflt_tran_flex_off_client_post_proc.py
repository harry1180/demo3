import sys
import requests, json,xml
import xml.etree.cElementTree as ET
import csv
import codecs
import time

i = time.strftime('%y%m%d%H%M%S')

file_name=sys.argv[1]

tree = ET.parse(file_name)
root= tree.getroot()

writer=csv.writer(open("post_foclient.csv",'wb'), delimiter='\t')
header = []
for child in root:
 for i in range(len(child)):
  if child[i].tag not in header : header.append(child[i].tag)
#print header



for child in root:
 line = []
 for columns in header:
  line.append(child.find(columns).text)
 writer.writerow(line)
