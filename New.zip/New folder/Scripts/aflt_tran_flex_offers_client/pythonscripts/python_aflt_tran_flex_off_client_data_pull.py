import sys
import requests, json,xml

start_date=sys.argv[1]
end_date=sys.argv[2]
print "*****************************"
print start_date
print end_date

url = "https://client.linkoffers.com/public/report.aspx?gui=aa4240af-5b1b-4fe0-b836-13d464ed0270&d1="+start_date+"&d2="+end_date+"&t=S&o=3&p=1"
r = requests.get(url,allow_redirects=True,timeout=1000, stream=True)

#print r.text
f=open("pre_foclient.xml",'w')
f.write(r.text.encode('ascii','ignore'))
r.close
f.close
