insert into dw_stage.dw_aflt_tran_consolidated_post_stg
(
Select 
aflt_network_tran_id 
,aflt_network_id
,aflt_fin_tran_type_cd
,dw_eff_dt
,nw_click_dt  
,tran_rev_rlzd_dt 
,tran_post_dt
,tran_click_dt
,tran_post_ts
,tran_click_ts
,src_prod_nm
,dw_site_visitor_id
,prod_src_sys_id
,dw_site_prod_sk
,dw_site_prod_nm
,prog_nm
,case when trim(src_unique_click_id) = '' then null else src_unique_click_id end  as src_unique_click_id
,aflt_catg_nm
,commission_am
,merchant_am
,txn_ct
,dw_load_ts
 from 
 (
Select * from 
(
select
aflt_network_tran_id
,aflt_network_id
,aflt_fin_tran_type_cd as aflt_fin_tran_type_cd
,dw_eff_dt
,nw_click_dt as nw_click_dt
,tran_post_dt as tran_rev_rlzd_dt
,tran_post_dt
,tran_click_dt
,tran_post_ts
,tran_click_ts
--,tran_post_dt as rev_recognized_dt
,src_prod_nm
,dw_site_visitor_id as dw_site_visitor_id
,prod_src_sys_id as prod_src_sys_id
,dw_site_prod_sk as dw_site_prod_sk
,dw_site_prod_nm as dw_site_prod_nm
,prog_nm
,src_unique_click_id as src_unique_click_id
,catg_nm as aflt_catg_nm
,commission_am
,merchant_am as merchant_am
,txn_ct
,dw_load_ts
from
dw_report.dw_aflt_tran_investing_f where dw_load_ts > sysdate - 15 
)
union all
select * from
(
select
aflt_network_tran_id
,aflt_network_id
,aflt_fin_tran_type_cd
,dw_eff_dt
,null::date as nw_click_dt
,tran_post_dt as tran_rev_rlzd_dt
,tran_post_dt
,tran_click_dt
,tran_post_ts
,tran_click_ts
,src_prod_nm
,dw_site_visitor_id as dw_site_visitor_id
,cast(src_sys_id as varchar) as prod_src_sys_id
,dw_site_prod_sk 
,dw_site_prod_nm 
,prog_nm
,src_unique_click_id
,aflt_catg_nm
,commission_am
,merchant_am
,txn_cnt as txn_ct
,dw_load_ts
from
dw_report.dw_aflt_tran_mortgages_f where dw_load_ts > sysdate - 15
)
union all
select * from
(
select
aflt_network_tran_id
,aflt_network_id
,aflt_fin_tran_type_cd
,dw_eff_dt
,tran_click_dt as nw_click_dt
,tran_fund_dt as tran_rev_rlzd_dt
,tran_fund_dt as tran_post_dt
,coalesce(tran_app_st_dt,tran_acc_create_dt,tran_click_dt) as tran_click_dt
,tran_fund_dt as tran_post_ts
,tran_click_dt as tran_click_ts
,src_prod_nm
,dw_site_visitor_id as dw_site_visitor_id
,cast(src_sys_id as varchar) as prod_src_sys_id
,dw_site_prod_sk
,dw_site_prod_nm
,prog_nm
,src_unique_click_id
,aflt_catg_nm
,commission_am
,merchant_am
,txn_cnt as txn_ct
,dw_load_ts
from
dw_report.dw_aflt_tran_edu_loan_f where dw_load_ts > sysdate - 15
)
union all
select * from
(
select 
aflt_network_tran_id 
,aflt_network_id
,aflt_fin_tran_type_cd
,dw_eff_dt
, null::date as nw_click_dt  
, tran_post_dt as tran_rev_rlzd_dt 
,tran_post_dt
,tran_click_dt
,tran_post_ts
,tran_click_ts
--,tran_post_dt as rev_recognized_dt
,src_prod_nm
,dw_site_visitor_id
,cast(src_sys_id as varchar) as prod_src_sys_id
,dw_site_prod_sk
,dw_site_prod_nm
,prog_nm
,src_unique_click_id
,aflt_catg_nm
,commission_am
,merchant_am
, case when coalesce(commission_am,0)>0 then 1 when coalesce(commission_am,0) < 0 then -1 else 0 end txn_ct
,dw_load_ts
from 
dw_report.dw_aflt_tran_growth_personal_loans_f, dw_report.ctl_dw_aflt_tran_personal_loans_f where lower(prog_nm)=lower(lender) and lower(validated_in)='yes' and dw_load_ts > sysdate - 15
)
union all
select * from (
-- only load CC partners because other partners are loaded into dw_aflt_tran_investing_f and dw_aflt_tran_mortgages_f
    SELECT
      aflt_network_tran_id,
      aflt_network_id,
      aflt_fin_tran_type_cd,
      dw_eff_dt,
      nw_click_dt,
      tran_post_dt AS tran_rev_rlzd_dt,
      tran_post_dt,
      tran_click_dt,
      tran_post_ts,
      tran_click_ts,
      src_prod_nm,
      dw_site_visitor_id,
      prod_src_sys_id,
      dw_site_prod_sk,
      dw_site_prod_nm,
      prog_nm,
      src_unique_click_id,
      aflt_catg_nm,
      commission_am,
      merchant_am,
      1 AS txn_ct,
      dw_load_ts
    FROM
      dw_report.dw_aflt_tran_hasoffers_f
    WHERE lower(aflt_catg_nm) = 'credit cards'
      AND dw_load_ts > sysdate - 15
)
union all
select * from (select aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
null::date as nw_click_dt  ,
dw_eff_dt as tran_rev_rlzd_dt ,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commission_am,
merchant_am,
case when coalesce(commission_am,0)>0 then 1 when coalesce(commission_am,0) < 0 then -1 else 0 end txn_ct,
dw_load_ts
FROM
dw_report.dw_aflt_tran_link_share_brokers_f  where dw_load_ts > sysdate - 15)
union all
select * from (select aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
null::date as nw_click_dt  ,
dw_eff_dt as tran_rev_rlzd_dt ,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commission_am,
merchant_am,
case when coalesce(commission_am,0)>0 then 1 when coalesce(commission_am,0) < 0 then -1 else 0 end txn_ct,
dw_load_ts 
FROM
dw_report.dw_aflt_tran_link_share_coupons_f
where dw_load_ts > sysdate - 15
  and lower(prog_nm) not in ('chase consumer bank', 'everbank', 'td bank checking')
)
union all
select * from (select aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
null::date as nw_click_dt  ,
dw_eff_dt as tran_rev_rlzd_dt ,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commission_am,
merchant_am,
case when coalesce(commission_am,0)>0 then 1 when coalesce(commission_am,0) < 0 then -1 else 0 end txn_ct,
dw_load_ts 
FROM
dw_report.dw_aflt_tran_link_share_prequal_f where dw_load_ts > sysdate - 15)
union all
select * from (select aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
null::date as nw_click_dt  ,
dw_eff_dt as tran_rev_rlzd_dt ,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commission_am,
merchant_am,
case when coalesce(commission_am,0)>0 then 1 when coalesce(commission_am,0) < 0 then -1 else 0 end txn_ct,
dw_load_ts
FROM
dw_report.dw_aflt_tran_flex_offers_publisher_f where dw_load_ts > sysdate - 15)
union all
select * from (select aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
null::date as nw_click_dt  ,
dw_eff_dt as tran_rev_rlzd_dt ,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commission_am,
merchant_am,
case when coalesce(commission_am,0)>0 then 1 when coalesce(commission_am,0) < 0 then -1 else 0 end txn_ct,
dw_load_ts
FROM
dw_report.dw_aflt_tran_flex_offers_client_f where dw_load_ts > sysdate - 15)
union all
select * from (select a.aflt_network_tran_id,
a.aflt_network_id,
case
  when lower(a.src_prod_nm) in ('barclay customer creation - advertiser only advanced') then 'Conversion'
  when lower(a.prog_nm) in ('cit bank') then 'Conversion'
  when lower(a.sku) like '%decline%' then 'Decline'
  when lower(a.src_prod_nm) like '%decline%' then 'Decline'
  else a.aflt_fin_tran_type_cd
end as aflt_fin_tran_type_cd,
a.dw_eff_dt,
null::date as nw_click_dt,
case when a.dw_eff_dt <= cast('2016-10-31' as date) then a.dw_eff_dt
     when a.dw_eff_dt > cast('2016-10-31' as date) and ((lower(a.aflt_fin_tran_type_cd) = 'bonus' or a.commission_am < 0) and lower(g.page_hier_lvl1_nm) in ('investing','mortgages'))  then a.tran_post_dt 
     when a.dw_eff_dt > cast('2016-10-31' as date) and ((lower(a.aflt_fin_tran_type_cd) = 'bonus' or a.commission_am < 0) and (lower(g.page_hier_lvl1_nm) not in ('investing','mortgages')) or g.page_hier_lvl1_nm is null) and (a.tran_post_dt - last_day(a.dw_eff_dt) > 15) then a.tran_post_dt else a.dw_eff_dt end
as tran_rev_rlzd_dt, 
a.tran_post_dt,
a.tran_click_dt,
a.tran_post_ts,
a.tran_click_ts,
a.src_prod_nm,
a.dw_site_visitor_id,
a.prod_src_sys_id,
a.dw_site_prod_sk,
a.dw_site_prod_nm,
a.prog_nm,
a.src_unique_click_id,
a.catg_nm,
case
  when lower(prog_nm) in ('cit bank') then 0
  else a.commission_am
end commission_am,
a.merchant_am,
case
  when coalesce(a.commission_am,0)>0 and lower(prog_nm) not in ('cit bank') then 1
  when coalesce(commission_am,0) < 0 then -1
  else 0
end txn_ct,
a.dw_load_ts
FROM
dw_report.dw_aflt_tran_comm_junc_f a
   LEFT JOIN dw_report.dw_aflt_category_map g ON 
     a.src_prod_nm::text = g.src_aflt_prod_nm::text 
   AND a.prog_nm::text = g.src_aflt_prog_nm::text 
   AND a.catg_nm::text = g.src_aflt_catg_nm::text
WHERE lower(prog_nm) NOT IN ('barclays us online savings', 'bbva compass bank affiliate', 'discover bank')
and a.dw_load_ts > sysdate - 15)
union all
select * from (select cast(network_tran_id as varchar),
aflt_network_id,
aflt_fin_actn_type_cd,
dw_eff_dt,
null::date as nw_click_dt  ,
dw_eff_dt as tran_rev_rlzd_dt ,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_app_status_tx,
cast(dw_site_visitor_id as varchar),
cast(prod_src_sys_id as varchar),
dw_site_prod_sk,
src_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commision_am,
merchant_am,
case when coalesce(commision_am,0)>0 then 1 when coalesce(commision_am,0)<0 then -1 else 0 end txn_ct,
sysdate
FROM
dw_report.dw_aflt_fin_tran_f where aflt_network_id not in (1,4,9,7) 
and (lower(trim(prog_nm)) not like 'fidelity-credit%')
and dw_load_ts > sysdate - 15)
union all
select * from (select 
cast(aflt_network_tran_id as varchar(256)),
23 as aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
null::date as nw_click_dt  ,
dw_eff_dt as tran_rev_rlzd_dt ,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
cast(dw_site_visitor_id as varchar),
cast(src_sys_id as varchar),
dw_site_prod_sk,
src_prod_nm,
prog_nm,
src_unique_click_id,
aflt_catg_nm,
commission_am as commision_am,
merchant_am,
case when coalesce(commission_am,0)>0 then 1 when coalesce(commision_am,0)<0 then -1 else 0 end txn_ct,
sysdate
FROM
dw_report.dw_aflt_tran_credit_cards_f 
where dw_load_ts > sysdate - 15)
union all
Select * from
(select 
aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
nw_click_dt,
tran_rev_rlzd_dt,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
prod_src_sys_id,
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commission_am,
merchant_am,
txn_ct,
dw_load_ts
 from
(select
cast(aflt_network_tran_id as varchar(256)) aflt_network_tran_id,
aflt_network_id,
case
    when lower(aflt_fin_tran_type_cd) = 'persav_12' and lower(campaign_nm) = 'american express personal savings'
        then 'Conversion'
    else aflt_fin_tran_type_cd
end as aflt_fin_tran_type_cd,
dw_eff_dt,
null::date as nw_click_dt  ,
dw_eff_dt as tran_rev_rlzd_dt ,
tran_post_ts :: date as tran_post_dt,
tran_click_ts :: date as tran_click_dt,
tran_post_ts,
tran_click_ts,
campaign_nm as src_prod_nm,
null as dw_site_visitor_id,
null as prod_src_sys_id,
null as dw_site_prod_sk,
null as dw_site_prod_nm,
campaign_nm as prog_nm,
coalesce(cast(src_subid1_clickid as varchar(256)),src_subid2_clickid) as src_unique_click_id,
campaign_nm as catg_nm,
cast(comm_payout_am as numeric(10,2)) as commission_am,
cast(sales_am as numeric(10,2)) as merchant_am,
case when coalesce(cast(comm_payout_am as numeric(10,2)),0)>0 then 1 when coalesce(cast(comm_payout_am as numeric(10,2)),0)<0 then -1 else 0 end txn_ct,
dw_load_ts,
ROW_NUMBER() OVER(partition by aflt_network_tran_id,aflt_fin_tran_type_cd ORDER BY dw_eff_dt desc) AS ROW_NUMBER
FROM
dw_report.dw_aflt_tran_impactradius_f
where 
dw_load_ts>sysdate-15
and (
       lower(campaign_nm) not in ('american express personal savings')
    or lower(campaign_nm) in ('american express personal savings') and lower(aflt_fin_tran_type_cd) = 'persav_12'
    )
)
where ROW_NUMBER=1)
union all
SELECT *
FROM (SELECT t.aflt_network_trans_id AS aflt_network_tran_id,
             t.aflt_network_id AS aflt_network_id,
             t.aflt_fin_tran_type_cd AS aflt_fin_tran_type_cd,
             t.dw_eff_dt AS dw_eff_dt,
             null::date as nw_click_dt  ,
             t.dw_eff_dt as tran_rev_rlzd_dt ,
             t.tran_post_dt AS tran_post_dt,
             t.tran_click_dt AS tran_click_dt,
             t.tran_post_ts AS tran_post_ts,
             t.tran_click_ts AS tran_click_ts,
             t.src_prod_nm AS src_prod_nm,
             NULL AS dw_site_visitor_id,
             NULL AS prod_src_sys_id,
             NULL AS dw_site_prod_sk,
             NULL AS dw_site_prod_nm,
             CAST(t.offer_nm AS VARCHAR(256)) AS prog_nm,
             t.nw_unique_click_id AS src_unique_click_id,
             CAST(t.src_micro_event_nm AS VARCHAR(256)) AS aflt_catg_nm,
             CAST(t.commission_am AS NUMERIC(10,2)) AS commission_am,
             CAST(NULL AS NUMERIC(10,2)) AS merchant_am,
	           case when coalesce(cast(t.commission_am as NUMERIC(10,2)),0)>0 then 1 when coalesce(cast(t.commission_am as NUMERIC(10,2)),0)<0 then -1 else 0 end txn_ct,
             t.dw_load_ts AS dw_load_ts
      FROM dw_report.dw_aflt_tran_cake_partners_f  t
      WHERE t.dw_load_ts >SYSDATE- 15 )
union all
select * from (select aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
tran_post_dt as dw_eff_dt,
null::date as nw_click_dt  ,
tran_post_dt as tran_rev_rlzd_dt ,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
dw_site_visitor_id,
cast(src_sys_id as varchar),
dw_site_prod_sk,
dw_site_prod_nm,
prog_nm,
src_unique_click_id,
aflt_catg_nm,
case when commission_am is null then 0.00 else commission_am end,
merchant_am,
case when coalesce(commission_am,0)>0 then 1 when coalesce(commission_am,0)<0 then -1 else 0 end txn_ct,
dw_load_ts 
FROM
dw_report.dw_aflt_tran_insurance_quotacy_f where dw_load_ts>=sysdate-15)

union all 

select 
network_tran_id as aflt_network_tran_id,
aflt_network_id,
aflt_fin_tran_type_cd,
dw_eff_dt,
null::date as nw_click_dt,
dw_eff_dt as tran_rev_rlzd_dt,
tran_post_dt,
tran_click_dt,
tran_post_ts,
tran_click_ts,
src_prod_nm,
cast(dw_site_visitor_id as varchar),
cast(prod_src_sys_id as varchar),
dw_site_prod_sk,
src_prod_nm as dw_site_prod_nm,
prog_nm,
src_unique_click_id,
catg_nm,
commission_am,
merchant_am,
click_ct as txn_ct,
dw_load_ts
from dw_report.dw_aflt_tran_cnsmr_track_f 
where dw_load_ts > sysdate - 15
)
);
