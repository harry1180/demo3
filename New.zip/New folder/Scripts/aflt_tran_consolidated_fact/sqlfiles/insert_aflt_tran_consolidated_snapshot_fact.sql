DELETE FROM dw_report.dw_aflt_tran_consolidated_snapshot_f
WHERE (dw_snapshot_dt <= CURRENT_DATE - 90 OR dw_snapshot_dt = CURRENT_DATE) ;


INSERT INTO dw_report.dw_aflt_tran_consolidated_snapshot_f
(
  aflt_network_tran_id
, aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, dw_imprsn_id
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, commission_am
, merchant_am
, revenue_tran_in
, txn_ct
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, dw_snapshot_dt
, dw_load_ts
)
SELECT

  aflt_network_tran_id
, aflt_network_id
, aflt_fin_tran_type_cd
, dw_eff_dt
, nw_click_dt
, tran_rev_rlzd_dt
, tran_post_dt
, tran_click_dt
, tran_post_ts
, tran_click_ts
, src_clicks_utc_ts
, src_prod_nm
, dw_site_visitor_id
, dw_site_prod_sk
, dw_site_prod_nm
, prog_nm
, src_unique_click_id
, aflt_catg_nm
, dw_click_id
, dw_click_src_id
, src_sys_id
, user_id
, dw_session_id
, dw_page_view_id
, dw_suspected_bot_in
, logged_ip
, dw_click_page_sk
, dw_url_sk
, dw_imprsn_id
, page_vertical_tx
, page_topic_tx
, dw_click_user_agent_id
, dw_catg_nm
, commission_am
, merchant_am
, revenue_tran_in
, txn_ct
, src_commission_am
, src_revenue_tran_in
, dw_last_updt_ts
, dw_last_updt_tx
, CURRENT_DATE
, dw_load_ts
FROM dw_report.dw_aflt_tran_consolidated_f
WHERE dw_eff_dt >= CURRENT_DATE - 60
;