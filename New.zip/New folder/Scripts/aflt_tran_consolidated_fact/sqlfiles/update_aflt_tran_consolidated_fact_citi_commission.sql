UPDATE dw_report.dw_aflt_tran_consolidated_f
      SET commission_am = cc.commission_am,
          revenue_tran_in = CASE WHEN  cc.commission_am <> 0 THEN 'True' ELSE 'False' END
	 ,txn_ct = CASE WHEN  cc.commission_am <> 0 THEN 1 ELSE 0 END
    FROM dw_report.dw_aflt_tran_comm_junc_f cc
      WHERE   COALESCE(dw_report.dw_aflt_tran_consolidated_f.aflt_network_tran_id, 'XXXX') = COALESCE(cc.aflt_network_tran_id, 'XXXX')
      AND (
              COALESCE(dw_report.dw_aflt_tran_consolidated_f.commission_am, 0) <> COALESCE(cc.commission_am, 0))
      
      AND (
            cc.dw_eff_dt >= date_trunc('month', current_date) - '2 month'::interval
        
          )
        AND lower(dw_report.dw_aflt_tran_consolidated_f.src_prod_nm) like '%citi%'
        AND dw_report.dw_aflt_tran_consolidated_f.src_sys_id = 1
        and dw_report.dw_aflt_tran_consolidated_f.dw_eff_dt > '2018-05-31'
;

