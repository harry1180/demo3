update dw_report.dw_aflt_tran_consolidated_f
set revenue_tran_in = case when commission_am <> 0 then 'True' else 'False' end
, src_revenue_tran_in = case when src_commission_am <> 0 then 'True' else 'False' end
where dw_eff_dt >= date_trunc('month', current_date) - '3 month'::interval;

