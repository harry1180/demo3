
UPDATE dw_report.dw_aflt_tran_consolidated_f
 SET dw_catg_nm = b.validated_catg_nm,
     src_sys_id = b.src_sys_id
FROM dw_report.dw_aflt_category_map b
WHERE dw_report.dw_aflt_tran_consolidated_f.src_prod_nm = b.src_aflt_prod_nm
AND   dw_report.dw_aflt_tran_consolidated_f.prog_nm = b.src_aflt_prog_nm
AND   dw_report.dw_aflt_tran_consolidated_f.aflt_catg_nm = b.src_aflt_catg_nm
AND   dw_report.dw_aflt_tran_consolidated_f.aflt_network_id NOT IN (8)
AND   dw_report.dw_aflt_tran_consolidated_f.dw_eff_dt   >= date_trunc('month', current_date) - '3 month'::interval;
