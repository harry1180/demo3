INSERT INTO dw_stage.dw_aflt_tran_link_share_coupons_post_stg
(
  aflt_network_tran_id,
  aflt_network_id,
  aflt_fin_tran_type_cd,
  dw_eff_dt,
  tran_post_dt,
  tran_click_dt,
  tran_post_ts,
  tran_click_ts,
  src_prod_nm,
  prog_nm,
  catg_nm,
  commision_am,
  sku_num,
  quantity,
  merchant_id,
  dw_load_ts
)
SELECT
  bonus.aflt_network_tran_id,
  bonus.aflt_network_id,
  bonus.aflt_fin_tran_type_cd,
  bonus.dw_eff_dt,
  bonus.tran_post_dt,
  bonus.tran_click_dt,
  bonus.tran_post_ts,
  bonus.tran_click_ts,
  bonus.src_prod_nm,
  bonus.prog_nm,
  bonus.catg_nm,
  bonus.commission_am,
  bonus.sku_num,
  bonus.quantity,
  bonus.merchant_id,
  bonus.dw_load_ts
FROM
(
  SELECT DISTINCT
    func_sha1(s.aflt_network_id|| s.prog_nm || s.src_prod_nm || s.dw_eff_dt || s.commission_am) AS aflt_network_tran_id,
    s.aflt_network_id AS aflt_network_id,
    s.aflt_fin_tran_type_cd AS aflt_fin_tran_type_cd,
    s.dw_eff_dt :: DATE AS dw_eff_dt,
    s.dw_eff_dt :: DATE AS tran_post_dt,
    s.dw_eff_dt :: DATE AS tran_click_dt,
    s.dw_eff_dt :: TIMESTAMP AS tran_post_ts,
    s.dw_eff_dt :: TIMESTAMP AS tran_click_ts,
    s.src_prod_nm AS src_prod_nm,
    s.prog_nm AS prog_nm,
    'Coupons' AS catg_nm,
    s.commission_am AS commission_am,
    'Bonus' AS sku_num,
    1.00 AS quantity,
    f.merchant_id AS merchant_id,
    getdate() AS dw_load_ts

  FROM
    dw_stage.dw_aflt_tran_bonus_payments_s s
  LEFT OUTER JOIN dw_report.dw_aflt_tran_link_share_coupons_f f
    ON s.src_prod_nm=f.src_prod_nm
  WHERE s.aflt_network_id='-15'
) bonus

LEFT OUTER JOIN dw_report.dw_aflt_tran_link_share_coupons_f lkp
  ON bonus.aflt_network_tran_id = lkp.aflt_network_tran_id
WHERE lkp.aflt_network_tran_id IS NULL;
