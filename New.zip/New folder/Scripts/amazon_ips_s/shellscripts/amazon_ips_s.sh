job_name='amazon_ips_s'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assigning Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning S3 and data directories" "Started"
find $Linux_Input -type f -delete || true
find $Linux_Output -type f -delete || true
python -c "from s3_modules import delete_key;
delete_key('$S3_Input','$Events_dwh_bucket')" || true
echo_processing_step ${job_name} "Cleaning S3 and data directories" "Completed"

echo_processing_step ${job_name} "Creating tmp table" "Started"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "drop table if exists dw_stage.aws_tmp;"
query_stage_delete="create table dw_stage.aws_tmp (ip varchar(15),service varchar(500));"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo_processing_step ${job_name} "Creating tmp table" "Completed"

echo_processing_step ${job_name} "Copy data to tmp table" "Started"
query="COPY dw_stage.aws_tmp
FROM 's3://$nerdlake_dwh_bucket/dwnl_stage/amazon_ips_s/amazon_ips.csv.gz'
CREDENTIALS 'aws_access_key_id=$s3_access_key;aws_secret_access_key=$s3_secret_key'
CSV GZIP COMPUPDATE OFF STATUPDATE OFF;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query"
echo_processing_step ${job_name} "Copy data to tmp table" "Completed"

echo_processing_step ${job_name} "Copy distinct data to Stage table" "Started"
query1="TRUNCATE TABLE dw_stage.amazon_ips_s"
query2="insert into dw_stage.amazon_ips_s (amazon_ip) select distinct ip from dw_stage.aws_tmp;"
query3="drop table dw_stage.aws_tmp"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query1"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query2"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query3"
echo_processing_step ${job_name} "Copy distinct data to stage table" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
