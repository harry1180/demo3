job_name='aflt_tran_process_google_spreadsheet'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started"
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+---Custom Variables--+----------+----------+'
to_date=`(date +'%Y%m%d')`
vertical=$1
lender=$2
spreadsheet_url=$3
if [ -z "$4" ] ; then
  worksheet="Sheet1"
else
  worksheet="$4"
fi
email_to="$5"
if [ -z "$6" ] ; then
  skiprows=0
else
  skiprows="$6"
fi

echo 'lender 	:- '${lender}
echo 'vertical 	:- '${vertical}
echo 'lender_url :- '${spreadsheet_url}
echo 'worksheet :- '${worksheet}
echo 'email_to :- '${email_to}
echo 'skiprows :- '${skiprows}
echo '+----------+----------+----------+----------+----------+----------+'
bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Cleaning S3 and data direcotried:" "Started"
rm -f ${Linux_Output}* || true
rm -f ${Linux_Input}*  || true
echo_processing_step ${job_name} "Cleaning S3 and data direcotries:" "Completed"

echo_processing_step ${job_name} "Fetching contents from URL and moving it to S3 Bucket" "Started"
python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/${job_name}.py $spreadsheet_url $lender $vertical $Linux_Output $Events_dwh_bucket $S3_Events_Output ${dwh_scripts_base_dir}/${job_name}/pythonscripts/email_info.json $worksheet $email_to $skiprows
echo_processing_step ${job_name} "Fetching contents from URL and moving it to S3 Bucket" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processiing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds

trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'

