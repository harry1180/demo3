CREATE TEMP TABLE temp_clicks_or diststyle key distkey(src_unique_click_id) AS
WITH temp_clicks_or as (
        SELECT
            src_unique_click_id,
            dw_site_visitor_id,
            src_prod_nm,
            dw_src_sys_id,
            dw_site_prod_sk,
            row_number()
            OVER (PARTITION BY src_unique_click_id
                ORDER BY click_utc_ts DESC) AS row_num
        FROM dw_report.dw_clicks_event_f
        WHERE dw_eff_dt >= (
            SELECT min(cast(transaction_date AS DATE)-10)
            FROM dw_stage.aflt_tran_link_share_coupons_optimization_rpt
        )
)
SELECT
    src_unique_click_id,
    dw_site_visitor_id,
    src_prod_nm,
    dw_src_sys_id,
    dw_site_prod_sk
FROM temp_clicks_or
WHERE row_num = 1
;


INSERT INTO dw_stage.dw_aflt_tran_link_share_coupons_optimization_rpt_post_stg
(
   aflt_network_tran_id,
   aflt_network_id,
   aflt_fin_tran_type_cd,
   dw_eff_dt,
   tran_post_dt,
   tran_click_dt,
   tran_post_ts,
   tran_click_ts,
   src_prod_nm,
   dw_site_visitor_id,
   prod_src_sys_id,
   dw_site_prod_sk,
   dw_site_prod_nm,
   prog_nm,
   src_unique_click_id,
   catg_nm,
   commision_am,
   merchant_am,
   merchant_id,
   sku_num,
   quantity,
   order_id,
   dw_load_ts
)
(SELECT func_sha1(concat(concat(concat(concat(a.member_id,a.merchant_name),a.order_id),a.sku_number),a.tran_post_ts)) AS aflt_network_tran_id,
        -15 AS aflt_network_id,
        a.sku_number AS aflt_fin_tran_type_cd,
    CAST (a.tran_click_ts AS date) AS dw_eff_dt,
        CAST (a.tran_post_ts AS date) AS tran_post_dt,
        CAST (a.tran_click_ts AS date) AS tran_click_dt,
        a.tran_post_ts,
        a.tran_click_ts,
        a.merchant_name AS src_prod_nm,
        COALESCE (d.dw_site_visitor_id, -999999999) AS dw_site_visitor_id,
        COALESCE (d.dw_src_sys_id, -999999999) AS prod_src_sys_id,
        COALESCE (d.dw_site_prod_sk, '-999999999') AS dw_site_prod_sk,
        COALESCE (d.src_prod_nm, a.product_nm, 'Not Found In Clicks') AS dw_site_prod_nm,
        a.merchant_name AS prog_nm,
        a.member_id AS src_unique_click_id,
        'Coupons' AS catg_nm,
        a.commissions AS commision_am,
        a.sales AS merchant_am,
        a.merchant_id,
        a.sku_number,
        a.quntity,
          a.order_id as order_id,
          sysdate
FROM  ( SELECT member_id,
               merchant_id,
               merchant_name,
               order_id,
               product_nm,
               MAX(CAST (transaction_date||' '||transaction_time AS TIMESTAMP)) AS tran_click_ts,
               sku_number AS sku_number,
               SUM(sales) AS sales,
               SUM(quntity) AS quntity,
               SUM(commissions) AS commissions,
               CAST (transaction_date||' '||transaction_time AS TIMESTAMP) AS tran_post_ts
        FROM (SELECT DISTINCT * FROM dw_stage.aflt_tran_link_share_coupons_optimization_rpt) AS stg
        GROUP BY member_id,
                 merchant_id,
                 merchant_name,
                 order_id,
                 product_nm,
                 sku_number,
                 transaction_date,
                 transaction_time) a
        LEFT OUTER JOIN temp_clicks_or d
        ON a.member_id = d.src_unique_click_id
        where lower(a.sku_number) like '%decline%');
