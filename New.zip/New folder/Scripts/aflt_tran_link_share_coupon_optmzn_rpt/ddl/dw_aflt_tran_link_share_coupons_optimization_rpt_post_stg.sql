DROP TABLE IF EXISTS dw_stage.dw_aflt_tran_link_share_coupons_optimization_rpt_post_stg CASCADE;

CREATE TABLE dw_stage.dw_aflt_tran_link_share_coupons_optimization_rpt_post_stg
(
   aflt_network_tran_id   varchar(256),
   aflt_network_id        integer,
   aflt_fin_tran_type_cd  varchar(256),
   dw_eff_dt              date,
   tran_post_dt           date,
   tran_click_dt          date,
   tran_post_ts           timestamp,
   tran_click_ts          timestamp,
   src_prod_nm            varchar(256),
   dw_site_visitor_id     varchar(256),
   prod_src_sys_id        varchar(256),
   dw_site_prod_sk        varchar(256),
   dw_site_prod_nm        varchar(256),
   prog_nm                varchar(256),
   src_unique_click_id    varchar(256),
   catg_nm                varchar(256),
   commision_am           numeric(10,2),
   merchant_am            numeric(10,2),
   merchant_id            varchar(256),
   sku_num                varchar(256),
   quantity               numeric(10,2),
   dw_load_ts             timestamp,
   order_id               varchar(256)
);

GRANT REFERENCES, UNKNOWN, TRIGGER, DELETE, RULE, UPDATE, SELECT, INSERT ON dw_stage.dw_aflt_tran_link_share_coupons_optimization_rpt_post_stg TO group grp_etl;
GRANT INSERT, RULE, UNKNOWN, DELETE, TRIGGER, REFERENCES, SELECT, UPDATE ON dw_stage.dw_aflt_tran_link_share_coupons_optimization_rpt_post_stg TO nw_dwh_etl;
GRANT INSERT, SELECT, UNKNOWN, DELETE, TRIGGER, UPDATE, RULE, REFERENCES ON dw_stage.dw_aflt_tran_link_share_coupons_optimization_rpt_post_stg TO group grp_ba_users;

