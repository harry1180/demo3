('SELECT dw_eff_dt, brain_success_in, count(1)
FROM  dw_report.dw_page_view_event_f
WHERE dw_suspected_bot_in = \'False\' 
   AND view_dw_page_sk = 19006 AND dw_eff_dt >= \'2015-06-01\'
GROUP BY dw_eff_dt, brain_success_in')
