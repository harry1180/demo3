from __future__ import division

import datetime
import json
import numpy as np
import os
import pandas as pd
import requests
import sys

from pvs_models import get_predictions

sixty_days_clicks_count             = sys.argv[1]
sixty_days_approvals_count          = sys.argv[2]
external_clicks_count               = sys.argv[3]
clicks_count                        = sys.argv[4]
approvals_count                     = sys.argv[5]
best_credit_cards                   = sys.argv[6]
approval_transactions_from_beg_mon  = sys.argv[7]
clicks_from_beg_of_mon              = sys.argv[8]
bcc_pvs                             = sys.argv[9]
ext_pvs                             = sys.argv[10]
bcc_clicks                          = sys.argv[11]
ext_clicks                          = sys.argv[12]
total_pvs                           = sys.argv[13]
pos_counts                          = sys.argv[14]
clicks_by_card                      = sys.argv[15]
impressions_by_card                 = sys.argv[16]
impressions_by_position             = sys.argv[17]
approvals_by_date_page_card         = sys.argv[18]
approval_estimates = '/data/etl/Data/bcc_brain_app/input/approval_estimates.txt'


KEYS = ['clicks_count', 'external_clicks_count', 'approvals_count', 'approval_estimates']


def calc_card_popularity(
        clicks_by_card_fn='clicks_by_card.txt',
        impressions_by_card_fn='impressions_by_card.txt'):
    names = ['credit_card_id', 'clicks_count']
    clicks_by_card = pd.read_csv(
            clicks_by_card_fn, names=names, sep='\t', dtype={'credit_card_id': int, 'clicks_count': int})
    
    names = ['credit_card_id', 'impressions_count']
    impressions_by_card = pd.read_csv(
            impressions_by_card_fn, names=names, sep='\t', dtype={'credit_card_id': int, 'impressions_count': int})
    result = pd.merge(clicks_by_card, impressions_by_card, how='inner', on='credit_card_id')
    result['probability'] = result.clicks_count / result.impressions_count
    result.set_index('credit_card_id', inplace=True)
    return result.probability.to_dict()


def get_impression_probabilities_by_position(
        impression_by_pos_fn='impressions_by_position.txt',
        total_pvs_fn='total_pvs.txt'):
    names = ['position', 'impressions_count']
    impressions_by_position = pd.read_csv(
        impression_by_pos_fn, names=names, sep='\t', dtype={'position':int, 'impressions_count': int})
    impressions_by_position = impressions_by_position.sort_values(
        by='impressions_count', ascending=False).set_index('position')

    total_pvs = pd.read_csv(
        total_pvs_fn, names=['count'], sep='\t', dtype={'count': int}).ix[0, 'count']
    impressions_by_position['probability'] = impressions_by_position.impressions_count / total_pvs
    del impressions_by_position['impressions_count']
    impressions_by_position = impressions_by_position[:32]
    return impressions_by_position.probability.to_dict()


def get_click_probabilities_for_pos(
        total_pvs_fn='total_pvs.txt', pos_cnt_fn='pos_counts.txt'):
    """Used with page views. It's being phased out."""

    total_pvs = pd.read_csv(
        total_pvs_fn, names=['cnt'], sep='\t', dtype={'cnt': int})
    total_pvs_count = total_pvs.cnt.values[0]

    names = ['position', 'cnt']
    pos_cnts = pd.read_csv(
        pos_cnt_fn, names=names, sep='\t', dtype={'cnt': int})
    pos_cnts = pos_cnts[pos_cnts.position.notnull()].set_index('position')
    pos_cnts['probability'] = pos_cnts.cnt/total_pvs_count
    del pos_cnts['cnt']
    return pos_cnts.to_dict()['probability']


def get_daily_aggregates(
        bcc_pvs_fn='bcc_pvs.txt', ext_pvs_fn='ext_pvs.txt',
        bcc_clicks_fn='bcc_clicks.txt', ext_clicks_fn='ext_clicks.txt'):
    names = ['dw_eff_dt', 'brain_success_in', 'cnt']
    bcc_pageviews = pd.read_csv(bcc_pvs_fn, names=names, sep='\t', dtype={'cnt': int})
    bcc_pageviews['brain_success_in'] = bcc_pageviews.brain_success_in.apply(lambda x: True if x == 't' else False)
    page_views = bcc_pageviews[bcc_pageviews.brain_success_in == True]
    del page_views['brain_success_in']
    page_views = page_views.rename(
        columns={'cnt': 'page_views'}).set_index('dw_eff_dt')
    static_page_views = bcc_pageviews[
        bcc_pageviews.brain_success_in != True].groupby(by='dw_eff_dt').cnt.sum().to_frame().rename(
        columns={'cnt': 'static_bcc_page_views'})

    names = ['dw_eff_dt', 'external_page_views']
    ext_pvs = pd.read_csv(ext_pvs_fn, names=names, sep='\t', dtype={'cnt': int})
    external_pvs = ext_pvs.set_index('dw_eff_dt')

    names = ['dw_eff_dt', 'brain_success_in', 'cnt']
    bcc_clicks_cnt = pd.read_csv(bcc_clicks_fn, names=names, sep='\t', dtype={'cnt': int})
    bcc_clicks_cnt['brain_success_in'] = bcc_clicks_cnt.brain_success_in.apply(lambda x: True if x == 't' else False)
    clicks_count = bcc_clicks_cnt[bcc_clicks_cnt.brain_success_in == True]
    del clicks_count['brain_success_in']
    clicks_count = clicks_count.rename(
        columns={'cnt': 'clicks_count'}).set_index('dw_eff_dt')
    static_bcc_clicks_count = bcc_clicks_cnt[
        bcc_clicks_cnt.brain_success_in != True].groupby(by='dw_eff_dt').cnt.sum().to_frame().rename(
        columns={'cnt': 'static_bcc_clicks_count'})

    names = ['dw_eff_dt', 'external_clicks_count']
    ext_clicks_cnt = pd.read_csv(ext_clicks_fn, names=names, sep='\t', dtype={'cnt': int})
    external_clicks_count = ext_clicks_cnt.set_index('dw_eff_dt')

    pvs = pd.merge(page_views, static_page_views, how='outer', left_index=True, right_index=True)
    pvs = pd.merge(pvs, external_pvs, how='outer', left_index=True, right_index=True)
    clicks = pd.merge(clicks_count, static_bcc_clicks_count, how='outer', left_index=True, right_index=True)
    clicks = pd.merge(clicks, external_clicks_count, how='outer', left_index=True, right_index=True)
    pvs_aggregates = pd.merge(pvs, clicks, how='outer', left_index=True, right_index=True).fillna(0)
    records = pvs_aggregates.to_records().tolist()
    header = (pvs_aggregates.index.name,) + tuple(pvs_aggregates.columns)
    ret = {'header': header, 'records': records}

    return ret


def get_credit_card_ids(
        bcc_fn='best_credit_cards.txt'):
    df = pd.read_csv(bcc_fn, names=['credit_card_id'], dtype={'credit_card_id': str})
    return df['credit_card_id'].values


def calc_approval_probabilities(
        bcc_fn='best_credit_cards.txt', cfn='sixty_days_clicks_count.txt',
        afn='sixty_days_approvals_count.txt'):
    df = pd.read_csv(bcc_fn, names=['credit_card_id'], dtype={'credit_card_id': str})
    cards = df['credit_card_id'].values

    total_clicks = pd.read_csv(
        cfn, sep='\t', names=['credit_card_id', 'clicks_count'],
        dtype={'credit_card_id': str})
    total_clicks = total_clicks[total_clicks.credit_card_id.isin(cards)]
    total_clicks.set_index('credit_card_id', inplace=True)

    total_approvals = pd.read_csv(
        afn, sep='\t', names=['credit_card_id', 'approvals_count'],
        dtype={'credit_card_id': str})
    total_approvals = total_approvals[total_approvals.credit_card_id.isin(cards)]
    total_approvals.set_index('credit_card_id', inplace=True)

    probabilities = pd.merge(total_approvals, total_clicks, left_index=True, right_index=True)
    probabilities['probability'] = probabilities.approvals_count / probabilities.clicks_count
    del probabilities['clicks_count']
    del probabilities['approvals_count']
    return probabilities


def calc_estimates(
        probabilities,
        bcc_fn='best_credit_cards.txt',
        afn='approval_transactions_from_beg_mon.txt',
        cfn='clicks_from_beg_of_mon.txt'):
    """Predict card approvals."""

    cards = pd.read_csv(bcc_fn, names=['credit_card_id'], dtype={'credit_card_id': str})['credit_card_id'].values
    names = [
        'tran_post_dt', 'tran_post_ts', 'tran_click_dt', 'tran_click_ts', 'credit_card_id',
        'dw_eff_dt', 'commission_am']
    date_cols = ['tran_post_dt', 'tran_post_ts', 'tran_click_dt', 'tran_click_ts']
    transactions_beg_of_mon = pd.read_csv(
        afn, names=names, parse_dates=date_cols, sep='\t', dtype={'credit_card_id': str})
    transactions_beg_of_mon = transactions_beg_of_mon[
        transactions_beg_of_mon.credit_card_id.isin(cards)]

    click_times = transactions_beg_of_mon.sort_values(by=['credit_card_id', 'tran_post_ts'], ascending=[False, False])
    click_times['id'] = click_times.credit_card_id.shift(1)
    click_times = click_times[click_times.credit_card_id != click_times.id]

    # {'id': ['credit_card_id', 'tran_click_ts']}
    click_times = click_times[['credit_card_id', 'tran_click_ts']]

    # {'credit_card_id': 'approval_count'}
    approvals_beg_of_mon = transactions_beg_of_mon.groupby('credit_card_id').size().to_frame(name='approval_count')

    names = ['credit_card_id', 'dw_click_id', 'dw_eff_dt', 'click_utc_ts', 'dw_site_visitor_id', 'src_site_visitor_tx']
    date_cols = ['dw_eff_dt', 'click_utc_ts']
    clicks_beg_of_mon = pd.read_csv(
        cfn, names=names, parse_dates=date_cols, sep='\t', dtype={'credit_card_id': str})
    clicks_beg_of_mon = clicks_beg_of_mon[clicks_beg_of_mon.credit_card_id.isin(cards)]
    t = clicks_beg_of_mon[['credit_card_id', 'click_utc_ts']].merge(
        click_times, how='inner', on='credit_card_id')
    t = t[t.click_utc_ts >= t.tran_click_ts]
    clicks_wo_approvals = t.groupby('credit_card_id').size().to_frame(name='clicks_count')

    estimates = pd.merge(approvals_beg_of_mon, clicks_wo_approvals, left_index=True, right_index=True)
    estimates = pd.merge(estimates, probabilities, left_index=True, right_index=True)
    estimates['approval_estimate'] = estimates.approval_count + estimates.clicks_count * estimates.probability
    estimates['approval_estimate'] = np.round(estimates['approval_estimate'])

    estimates[['approval_estimate']].to_csv('/data/etl/Data/bcc_brain_app/input/approval_estimates.txt', header=False, sep='\t')
    return estimates[['approval_estimate']]


def calc_bcc_vs_rest_approvals_ratios(credit_card_ids, fn='approvals_by_date_page_card.txt'):
    names = ['dw_eff_dt', 'bcc_page', 'credit_card_id', 'approvals_count']
    approvals = pd.read_csv(fn, names=names, sep='\t')
    approvals['bcc_page'] = approvals.bcc_page.apply(lambda x: True if x == 't' else False)
    approvals = approvals[approvals.credit_card_id.isin(credit_card_ids)]
    df = approvals.groupby(['credit_card_id', 'bcc_page']).agg(
        {'approvals_count': np.sum}).unstack(level=1)
    df.columns = ['bcc_page' if x else 'non_bcc_page' for x in df.columns.levels[1]]
    df['ratio'] = df.non_bcc_page / (df.bcc_page + df.non_bcc_page)
    df =df.fillna(0)
    return df.ratio.to_dict()


def calc_approvals_by_date_page(credit_card_ids, fn='approvals_by_date_page_card.txt'):
    names = ['dw_eff_dt', 'bcc_page', 'credit_card_id', 'approvals_count']
    approvals = pd.read_csv(fn, names=names, sep='\t')
    approvals['bcc_page'] = approvals.bcc_page.apply(lambda x: True if x == 't' else False)
    approvals = approvals[approvals.credit_card_id.isin(credit_card_ids)]

    df = approvals[approvals.bcc_page == True]
    del df['bcc_page']
    bcc_approvals = df.groupby(['credit_card_id', 'dw_eff_dt']).sum().unstack(level=0)
    bcc_approvals.columns = ['%s_bcc' % x for x in bcc_approvals.columns.levels[1]]
    bcc_approvals = bcc_approvals.fillna(0)
    del df

    df = approvals[approvals.bcc_page == False]
    del df['bcc_page']
    non_bcc_approvals = df.groupby(['credit_card_id', 'dw_eff_dt']).sum().unstack(level=0)
    non_bcc_approvals.columns = ['%s_non_bcc' % x for x in non_bcc_approvals.columns.levels[1]]
    non_bcc_approvals = non_bcc_approvals.fillna(0)
    del df

    approvals_by_date_page = {}
    for card_id in credit_card_ids:
        df = approvals[approvals.credit_card_id == card_id].groupby(['dw_eff_dt', 'bcc_page']).sum()
        df = df.unstack(level=1)
        df = df.fillna(0)
        records = [list(x) for x in df.to_records()]
        header = ['bcc_page' if x else 'non_bcc_pages' for x in list(df.columns.get_level_values(1))]
        header = ['date'] + header
        approvals_by_date_page[card_id] = {'header': header, 'records': records}

    return approvals_by_date_page, bcc_approvals, non_bcc_approvals


def send_metrics(
        approval_probabilities, position_probabilities, pvs_clicks_daily_aggregates,
        non_bcc_approvals_ratio, card_popularity, impression_probability_by_position):
    data = {
        'click_aggregates': {
            'approval_probabilities': approval_probabilities,
            'position_probabilities': position_probabilities,
            'daily_aggregates': pvs_clicks_daily_aggregates,
            'non_bcc_approvals_ratio': non_bcc_approvals_ratio,
            'card_popularity': card_popularity,
            'impression_probability_by_position': impression_probability_by_position
        }
    }
    for key in KEYS:
        data['click_aggregates'][key] = {}

    for key in KEYS:
        fn = '/data/etl/Data/bcc_brain_app/input/%s.txt' % key
        if not os.path.isfile(fn):
            continue
        with open(fn) as f:
            rows = [x.strip() for x in f.readlines()]
            for row in rows:
                if row:
                    vals = [x.strip() for x in row.split()]
                    if len(vals) == 2:
                        if vals[0]:
                            try:
                                data['click_aggregates'][key][int(vals[0])] = float(vals[1])
                            except ValueError as e:
                                print(e.message)
                                print(sys.exc_info()[0])

    print data

    today = datetime.datetime.utcnow()
    yesterday = (today - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    

    url = 'http://bccservices.east1.prod.nerdwallet.com/api/v1/click_aggregates/{}'.format(yesterday)
    # url = 'http://bccservices.nerdwallet.biz/api/v1/click_aggregates/{}'.format(yesterday)
    #url = 'http://localhost:3000/api/v1/click_aggregates/{}'.format(yesterday)
    headers = {'Authorization': 'Token token=7af44fdcc9c68c80e949dcf6a3e6f95f'}

    
    # add timeout and retries
    response = requests.patch(url, json=data, headers=headers)
    if response.ok:
        print json.loads(response.content)
    else:
        print response.reason
        print response.status_code
        print json.loads(response.content)
    return response.ok


def calc_bcc_metrics():
    credit_card_ids = get_credit_card_ids(best_credit_cards)
    # approvals_by_card_date_page, bcc_approvals, non_bcc_approvals = calc_approvals_by_date_page(credit_card_ids)
    non_bcc_approvals_ratio = calc_bcc_vs_rest_approvals_ratios(credit_card_ids,approvals_by_date_page_card)
    approval_probabilities_df = calc_approval_probabilities(best_credit_cards,sixty_days_clicks_count,sixty_days_approvals_count)
    estimates = calc_estimates(approval_probabilities_df,best_credit_cards,approval_transactions_from_beg_mon,clicks_from_beg_of_mon)
    print estimates
    approval_probabilities = approval_probabilities_df.probability.to_dict()
    position_probabilities = get_click_probabilities_for_pos(total_pvs,pos_counts)
    daily_aggregates = get_daily_aggregates(bcc_pvs,ext_pvs,bcc_clicks,ext_clicks)
    card_popularity = calc_card_popularity(clicks_by_card,impressions_by_card)
    impression_probability_by_position = get_impression_probabilities_by_position(impressions_by_position,total_pvs)

    return send_metrics(
        approval_probabilities, position_probabilities, daily_aggregates,
        non_bcc_approvals_ratio, card_popularity, impression_probability_by_position)

if __name__ == '__main__':
    status = calc_bcc_metrics()
    if status:
        get_predictions(
            store_url='http://bccservices.east1.prod.nerdwallet.com/api/v1/items')
