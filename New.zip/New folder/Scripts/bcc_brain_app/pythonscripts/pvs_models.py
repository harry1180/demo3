from __future__ import division

import datetime
import numpy as np
import os
import pandas as pd
import requests
import sklearn.linear_model
import sklearn.model_selection


DEV_KV_STORE_BASE_URL = 'http://localhost:3000/api/v1/items'
KV_STORE_BASE_URL = 'http://bccservices.nerdwallet.com/api/v1/items'
HOLIDAYS = [
    (2015, 7, 3), (2015, 9, 7), (2015, 11, 11), (2015, 11, 26), (2015, 12, 25),
    (2016, 1, 1), (2016, 1, 18), (2016, 2, 15), (2016, 5, 30), (2016, 7, 4), (2016, 9, 5),
    (2016, 11, 11), (2016, 11, 24), (2016, 12, 25), (2016, 12, 26)]
CRAZY_DAYS = []


def build_headers():
    auth_token = os.getenv('BCC_DWH_AUTH_TOKEN') or '7af44fdcc9c68c80e949dcf6a3e6f95f'
    return {'Authorization': 'Token token=%s' % auth_token}


def get_item_from_kv_store(key, store_url=DEV_KV_STORE_BASE_URL):
    url = "%s/%s" % (store_url, key)
    response = requests.get(url, headers=build_headers(), timeout=10)
    if response.ok:
        payload = response.json()
        return payload['value']
    else:
        return None


def get_keys_from_kv_store(store_url=DEV_KV_STORE_BASE_URL):
    response = requests.get(store_url, headers=build_headers(), timeout=10)
    if response.ok:
        return response.json()
    else:
        return None


def add_item_to_kv_store(key, value, store_url=DEV_KV_STORE_BASE_URL):
    payload = {'item': {'key': key, 'value': value}}
    return requests.post(store_url, json=payload, headers=build_headers())


def get_holidays(exclude_thx_giving=True):
    if exclude_thx_giving:
        holidays = [x for x in HOLIDAYS if x != (2015, 11, 26) and x != (2016, 11, 24)]
    else:
        holidays = HOLIDAYS[:]
    return [datetime.datetime(*x).date() for x in holidays]


def get_aggregated_daily_data(store_url=DEV_KV_STORE_BASE_URL):
    aggregates = get_item_from_kv_store('daily_aggregates', store_url=store_url)
    df = pd.DataFrame.from_records(aggregates['records'])
    df.columns = aggregates['header']
    df.dw_eff_dt = df.dw_eff_dt.apply(lambda x: datetime.datetime.strptime(x, '%Y-%m-%d').date())
    df.set_index('dw_eff_dt', inplace=True)
    return df


def prepare_time_series(df, tgt_col, predict_col, store_url=DEV_KV_STORE_BASE_URL):
    r = df[['dw_eff_dt', tgt_col, predict_col]].copy()
    r['dw_eff_dt'] = r.dw_eff_dt.apply(lambda x: x.isoformat())
    r.set_index('dw_eff_dt', inplace=True)
    header = ('date',) + tuple(r.columns)
    records = r.to_records().tolist()
    return {'header': header, 'records': records}


def do_add_features(df):
    df['weekday'] = df.dw_eff_dt.apply(lambda x: x.weekday())
    df['holiday'] = df.dw_eff_dt.apply(lambda x: x in get_holidays())
    df['holiday'] = df.holiday.apply(np.int)
    df['holiday_ext'] = df.holiday + df.holiday.shift() + df.holiday.shift(periods=-1) + df.holiday
    df.holiday_ext = df.holiday_ext.fillna(0)
    df = df.fillna(0)

    df['sin_period_w'] = np.sin(2 * np.pi * df['day'] / 7)
    df['cos_period_w'] = np.cos(2 * np.pi * df['day'] / 7)
    df['sin_period_m'] = np.sin(2 * np.pi * df['day'] / 30)
    df['cos_period_m'] = np.cos(2 * np.pi * df['day'] / 30)
    df['sin_period_q'] = np.sin(2 * np.pi * df['day'] / 91)
    df['cos_period_q'] = np.cos(2 * np.pi * df['day'] / 91)
    df['sin_period_y'] = np.sin(2 * np.pi * df['day'] / 365)
    df['cos_period_y'] = np.cos(2 * np.pi * df['day'] / 365)

    features = [
        'day', 'weekday', 'holiday', 'holiday_ext',
        'sin_period_w', 'cos_period_w',
        'sin_period_m', 'cos_period_m',
        'sin_period_q', 'cos_period_q',
        'sin_period_y', 'cos_period_y']
    return df, features


def add_features(df, tgt_col):
    df[tgt_col] = df[tgt_col].astype(int)
    df['day'] = np.arange(1, len(df) + 1)
    df['dw_eff_dt'] = df.index.values
    df, features = do_add_features(df)
    ret = df[[tgt_col, 'dw_eff_dt'] + features].copy()
    ret.set_index(np.arange(len(df)), inplace=True)
    return ret, features


def fit_model(df, tgt, features=None):
    """Fit a linear regression model."""
    assert not df.isnull().values.any()
    features = features or ['day', 'sin_period_w', 'cos_period_w', 'sin_period_y']
    data = pd.DataFrame(df)
    train_data, test_data = sklearn.model_selection.train_test_split(df, test_size=0.2)
    model = sklearn.linear_model.LinearRegression()
    model.fit(train_data[features], train_data[tgt])
    model.score(test_data[features], test_data[tgt])
    return model, data


def copy_prod_to_dev():
    keys = [x['key'] for x in get_keys_from_kv_store(KV_STORE_BASE_URL)]
    data = {x: get_item_from_kv_store(x) for x in keys}
    for k, v in data.items():
        add_item_to_kv_store(k, v)


def delete_leading_zeros(df, tgt_col):
    dt = df[df[tgt_col] != 0.0][:1].index.values[0]
    return df.loc[dt:].copy()


def gen_features_for_next_thirty_days(df, tgt_col, periods=30):
    dt_rng = pd.date_range(df.iloc[-1]['dw_eff_dt'], periods=periods, freq='D')
    dt_rng = [x.date() for x in dt_rng]
    day_rng = np.arange(df.iloc[-1]['day'] + 1, df.iloc[-1]['day'] + (periods + 1))
    fut_df = pd.DataFrame({'dw_eff_dt': dt_rng, 'day': day_rng, tgt_col: np.zeros(periods)})
    fut_df, _ = do_add_features(fut_df)
    return fut_df


def create_time_series(df, tgt_col, predict_col, store_url=DEV_KV_STORE_BASE_URL):
    fr = delete_leading_zeros(df, tgt_col)
    fr, features = add_features(fr, tgt_col)
    model, data = fit_model(fr, tgt_col, features)
    fr[predict_col] = np.round(model.predict(data[features])).astype(int)
    fut_fr = gen_features_for_next_thirty_days(fr, tgt_col)
    fut_data = pd.DataFrame(fut_fr)
    fut_fr[predict_col] = model.predict(fut_data[features]).astype(int)
    fr = fr.append(fut_fr, ignore_index=True)
    time_series = prepare_time_series(fr, tgt_col, predict_col, store_url=store_url)
    return time_series


def get_predictions(store_url=DEV_KV_STORE_BASE_URL):
    df = get_aggregated_daily_data(store_url=store_url)
    df['bcc_pvs'] = df.static_bcc_page_views + df.page_views
    df['pvs'] = df.static_bcc_page_views + df.page_views + df.external_page_views
    df['bcc_clicks'] = df.static_bcc_clicks_count + df.clicks_count
    df['clicks'] = df.static_bcc_clicks_count + df.clicks_count + df.external_clicks_count

    for tgt_col in ['bcc_pvs', 'pvs', 'bcc_clicks', 'clicks']:
        predict_col = 'prediction'
        time_series = create_time_series(df, tgt_col, predict_col,store_url=store_url)
        response = add_item_to_kv_store(tgt_col, time_series, store_url=store_url)
        print tgt_col, 'status: ', response.ok

if __name__ == '__main__':
    get_predictions()
