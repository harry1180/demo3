INSERT INTO dw_stage.dw_aflt_tran_flex_offers_publisher_post_stg
   (SELECT a.id AS aflt_network_tran_id,
           27 AS aflt_network_id,
           a.type AS aflt_fin_tran_type_cd,
           cast (a.transaction_date AS date) AS dw_eff_dt,
           cast (a.date AS date) AS tran_post_dt,
           cast (a.transaction_date AS date) AS tran_click_dt,
           cast (a.date AS timestamp) AS tran_post_ts,
           cast (a.transaction_date AS timestamp) AS tran_click_ts,
           a.product_name AS src_prod_nm,
           coalesce (d.dw_site_visitor_id, -999999999) AS dw_site_visitor_id,
           coalesce (d.dw_src_sys_id, -999999999) AS prod_src_sys_id,
           coalesce (d.dw_site_prod_sk, '-999999999') AS dw_site_prod_sk,
           coalesce (d.src_prod_nm, 'Not Fount In Clicks') AS dw_site_prod_nm,
           a.program_name AS prog_nm,
           a.subtracking AS src_unique_click_id,
           a.category_name AS catg_nm,
           a.sale_amount AS commision_am,
           a.merchant_amount AS merchant_am,
           a.domain,
           a.other_categories,
           a.campaign,
           a.useragent,
           a.ip,
           a.referer,
           a.order_number,
		   a.program_id,
		   sysdate
      FROM  dw_stage.aflt_tran_flex_offers_publisher a
           LEFT OUTER JOIN
           (  SELECT m.src_unique_click_id,
                     min (dw_site_visitor_id) AS dw_site_visitor_id,
                     min (m.src_prod_nm) AS src_prod_nm,
                     min (m.dw_src_sys_id) AS dw_src_sys_id,
                     min (m.dw_site_prod_sk) AS dw_site_prod_sk
                FROM (  SELECT src_unique_click_id,
                               max (click_utc_ts) AS click_utc_ts
                          FROM dw_report.dw_clicks_f
			  WHERE dw_eff_dt >= sysdate - 10
                      GROUP BY src_unique_click_id) n,
                     dw_report.dw_clicks_f m
               WHERE     coalesce (m.src_unique_click_id, 'NA') =
                            coalesce (n.src_unique_click_id, 'UNKNOWN')
                     AND m.click_utc_ts = n.click_utc_ts
            GROUP BY m.src_unique_click_id) d
              ON coalesce (a.subtracking, 'NA') =
                    coalesce (d.src_unique_click_id, 'UNKNOWN'));
