

job_name='aflt_tran_flex_offers_publisher'

job_start_time=$(date +%s)
echo '+----------+----------+----------+----------+----------+'
echo 'Sourcing Files and assining Job Name variable'
source set_dwh_env_variables.sh
source ${dwh_common_base_dir}/set_dwh_common_variables.sh ${job_name}
source ${dwh_credentials_file_dir}/credentials.ctrl
source ${dwh_common_base_dir}/environment.ctrl
source ${dwh_common_base_dir}/nw_shell_modules/generic_job_functions.sh
echo '+----------+----------+----------+----------+----------+'

trap : 0
echo >&2 '
********************************
*** '$job_name' LOAD STARTED ***
********************************
'
abort()
{
    echo >&2 '
**************************************
*** ERROR CODE '$job_name' ABORTED ***
**************************************
'
    bash ${dwh_common_base_dir}/dwh_job_fail_script.sh ${job_name}
    echo "An error occurred. Exiting while performing *****************"$Processing_Step >&2
    exit 1
}
trap 'abort' 0
set -e

echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Started" 
bash ${dwh_common_base_dir}/dwh_job_start_script.sh ${job_name}

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+---Custom Variables--+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
source_bucket=$Events_dwh_bucket
DAYS=${1:-4}
end_date="$(date -d '1 days' +'%Y-%m-%d')"
start_date="$(date "+%Y-%m-%d" -d "$DAYS days ago")"
from_date=$start_date
step=4
date_add=$step
temp_date="$(date "+%Y-%m-%d" -d "$start_date+$step days")"
aflt_tran_id=27
local_file_nm="flex_offer_publisher"

echo 'start_date                :-   '${start_date}
echo 'end_date                  :-   '${end_date}
echo 'source_bucket             :-   '${source_bucket}
echo 'aflt_tran_id              :-   '${aflt_tran_id}
echo 'local_file_nm		:-   '${local_file_nm}
echo '+----------+----------+----------+----------+----------+----------+'

bash ${dwh_common_base_dir}/setup_dir_structure.sh ${job_name}
echo_processing_step ${job_name} "Setting Variables, Running Preprocess scripts and Creating DIR Structures" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----- Starting to Process Main Script -----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Removing Data Files" "Started"
find $Linux_Input $linux_Output $Linux_Archive -type f -exec rm {} \; || true
echo_processing_step ${job_name} "Removing Data Files" "Completed" 

echo_processing_step ${job_name} "Calling Python script to bring in the API Data" "Started"
if (("$DAYS" >= 4)); then
 while [ $step -le $DAYS ]
 do  
 python ${dwh_scripts_base_dir}/${job_name}/pythonscripts/python_aflt_tran_flex_off_publisher_data_pull.py $start_date $temp_date $Linux_Input
 start_date="$(date "+%Y-%m-%d" -d "$start_date+$(($date_add+1)) days")"
 step=$(($step+4))
 echo $step
 temp_date="$(date "+%Y-%m-%d" -d "$start_date+$date_add days")"
 done
fi
echo_processing_step ${job_name} "Calling Python script to bring in the API Data" "Completed"

echo_processing_step ${job_name} "Moving file to S3" "Started"
python -c "from s3_modules import mv_to_s3 ; import s3_modules;  mv_to_s3('$Linux_Input*', '${S3_Events_Input}${local_file_nm}', '${Events_dwh_bucket}')"
echo_processing_step ${job_name} "Moving files to S3" "Completed"

echo_processing_step ${job_name} "Generating Manifest file" "Started"
python -c "from redshift_modules import generate_manifest_file; generate_manifest_file('Prod','${source_bucket}','${S3_Events_Input}','${local_file_nm}','${job_name}/manifest','$from_date','$end_date','modified')"
echo_processing_step  ${job_name} "Generating Manifest file" "Completed"

echo_processing_step ${job_name} "Delete data from Stage table" "Started"
query_stage_delete="delete from dw_stage.aflt_tran_flex_offers_publisher;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo_processing_step ${job_name} "Delete data from Stage table" "Completed"

echo_processing_step ${job_name} "Copy Data to stage table" "Started"
query_stage_load="copy dw_stage.aflt_tran_flex_offers_publisher from '${s3_bucket_name}/${job_name}/manifest/${local_file_nm}_manifest.json' credentials '$s3_prod_load_creds' JSON as '"$s3_bucket_name"/json/aflt_transactions/aflt_tran_flex_offers_publishers.jsonpaths' DATEFORMAT AS 'auto' TRUNCATECOLUMNS BLANKSASNULL ACCEPTINVCHARS COMPUPDATE OFF STATUPDATE OFF manifest;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  -c "$query_stage_load"
echo_processing_step ${job_name} "Copy Data to stage table" "Completed"

echo_processing_step ${job_name} "Delete Data from post stage table" "Started"
query_stage_delete="delete from dw_stage.dw_aflt_tran_flex_offers_publisher_post_stg;"
psql -h "$pdbHost" -p "$pport" -U "$pusername" -d "$pdatabase"  --single-transaction -c "$query_stage_delete"
echo_processing_step ${job_name} "Delete data from Stage table" "Completed"

echo_processing_step ${job_name} "Insert Data to post stage table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/insert_flex_offers_publisher_post_staging.sql
echo_processing_step ${job_name} "Insert Data to post stage table" "Completed"

echo_processing_step ${job_name} "Loading data to fact table" "Started"
bash ${dwh_common_base_dir}/redshift_sql_function.sh ${dwh_scripts_base_dir}/${job_name}/sqlfiles/insert_flex_offers_publisher_fact.sql
echo_processing_step ${job_name} "Delete data from Stage table" "Completed"

echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Started"
python -c "from tran_log_modules import insert_log; insert_log($aflt_tran_id);"
echo_processing_step ${job_name} "Calling Python script to write to transaction log table" "Completed"

echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+-----Completed Processing Main Script-----+----------+'
echo '+----------+----------+----------+----------+----------+----------+'
echo '+----------+----------+----------+----------+----------+----------+'

echo_processing_step ${job_name} "Calling End Script" "Started"
bash ${dwh_common_base_dir}/dwh_job_end_script.sh ${job_name}
echo_processing_step ${job_name} "Calling End Script" "Completed"

job_end_time=$(date +%s)

echo "Job Completed in : "$(( ($job_end_time-$job_start_time) / ( 60) )) minutes, $(( ($job_end_time-$job_start_time) % 60 )) seconds
trap : 0
echo >&2 '
************************************
***  '$job_name' LOAD COMPLETED  ***
************************************
'
